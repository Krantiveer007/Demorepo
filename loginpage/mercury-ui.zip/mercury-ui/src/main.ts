import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { URLConfig } from './app/configs/url.config';
import { LicenseManager } from "ag-grid-enterprise";
if (environment.production) {
  enableProdMode();
}

LicenseManager.setLicenseKey('Inspired_Technology_Services_Ltd_on_behalf_of_FIL_Investment_Management_Ltd_Mercury_Single_Application_2_Devs__23_December_2020_[v2]_MTYwODY4MTYwMDAwMA==12bc1d6ff23150e9b9feb8198444405f');
platformBrowserDynamic([{ provide: 'EnvName', useValue: URLConfig.getEnv() }, {provide: 'AWSEnvName', useValue: URLConfig.getEnvForAWS() }]).bootstrapModule(AppModule).catch(err => console.log(err));
