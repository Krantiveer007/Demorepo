import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { ErrorService } from 'src/app/core/error/error.service';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { MeetingManagementComponent } from 'src/app/feature/meeting-management/meeting-management.component';
import { FormGroup, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { Inject } from '@angular/core';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { NavigationEnd } from '@angular/router';
@Component({
  selector: 'mv2-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})
export class AppComponent implements OnInit {
  isCollapsedSidebar = true;
  filLogoUrl = '../assets/images/upper-header/fidelity-symbol.svg';
  userDetails = {
    loggedInUserName: '',
    loggedInUserAId: ''
  };
  initials = '';
  selectedNavImage = '';
  userRegion = '';
  userCountry = '';
  userTimezone = '';
  userLocation = '';
  // isModalShown = false;
  routeTo = '';
  checkCreateFormUpdate = false;
  formParam = '';
  currentUrl = '';
  appName = 'MERCURY';
  userName = '';
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  // @ViewChild(MeetingManagementComponent) meetingManagement;
  routeConfirmMessage = 'This page contains unsaved changed. Are you sure you want to exit ?';
  messageHeading = 'Confirm Navigation';
  meetingForm: FormGroup;
  currentAction = '';
  hideStaticView = false;
  constructor(private router: Router, private commonService: CommonService, private errorService: ErrorService, private route: ActivatedRoute, @Inject('EnvName') private envName: string) { }
  ngOnInit() {
    this.commonService.hideStaticView$.subscribe((isAllowed) => {
      if (isAllowed) {
        this.hideStaticView = true;
      }
    })
    let userNameArray = [];
    this.userName = convertToTitleCase(this.commonService.getLoggedInUserInfo().getName());
    userNameArray = this.userName.split(', ');
    this.initials = userNameArray[1][0].toUpperCase() + userNameArray[0][0].toUpperCase();
    this.userRegion = this.commonService.getLoggedInUserInfo().getRegionVal ? this.commonService.getLoggedInUserInfo().getRegionVal() : '';
    this.userCountry = this.commonService.getLoggedInUserInfo().getUserCountry() ? this.commonService.getLoggedInUserInfo().getUserCountry() : '';
    this.userTimezone = this.commonService.getLoggedInUserInfo().getUserTimezoneDesc();
    this.userLocation = this.userRegion;
    // this.userLocation = 'India, Asia-Pacific';
    // this.userTimezone = '(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi';
    this.router.events.subscribe((event) => {
      if (event['url']) {
        this.formParam = event['url'];
        if (event['url'].includes('/meetings') || event['url'] === '/' || event['url'].includes('/events/all') || event['url'].includes('/events/meeting')) {
          this.checkCreateFormUpdate = false;
        } else {
          this.checkCreateFormUpdate = true;
        }
      }
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url;
      }
    });
    this.appName = convertToTitleCase(this.appName) + ' ' + this.envName.toUpperCase();
  }

  //   ngAfterViewInit() {
  // this.meetingForm = this.meetingManagement.meetingForm;
  //   }
  toogleSidebar() {
    this.isCollapsedSidebar = !this.isCollapsedSidebar;
  }
  navigateToModule(imageClicked: any, meetingType: string) {
    if (this.hideStaticView) {
      return;
    }
    this.selectedNavImage = imageClicked + (meetingType ? meetingType : '');
    if (imageClicked === 'mv2-secondary-button') {
      this.commonService.setMeetingType(meetingType);
      this.commonService.setTargetUrl('/meeting/create');
      console.log('checkCreateFormUpdate: ', this.checkCreateFormUpdate);
      if (!this.checkCreateFormUpdate) {
        this.router.navigate(['/meeting/create', { meetingType: meetingType }], { skipLocationChange: true });
      } else {
        console.log(this.formParam);
        if (this.formParam.includes('/contacts') || this.formParam.includes('/editConference')) {
          this.router.navigate(['/meeting/create', { meetingType: meetingType }], { skipLocationChange: true });
        } else if (this.formParam.includes('/conference/update;eventId')) {
          this.commonService.checkConferenceFormSubject.next(true);
        } else if (this.formParam.includes('/contacts/add') || this.formParam.includes('/contacts/update')) {
          this.commonService.checkContactFormChanges.next(true);
        } else {
          this.commonService.resetFormSubject.next(true);
        }
      }
    } else if (imageClicked === this.filLogoUrl) {
      this.commonService.setTargetUrl('/events/meeting');
      if (this.errorService.isError || ((this.formParam === '/meeting/create' && !this.commonService.getLoggedInUserRoles().includes('mercury-create-company-meeting'))
        || (this.formParam === '/meeting/update' && !this.commonService.getLoggedInUserRoles().includes('mercury-update-company-meeting')))) {
        this.router.navigate(['/events/meeting'], { skipLocationChange: true });
      } else {
        if (this.formParam.includes('/contacts') || this.formParam.includes('/editConference')) {
          this.router.navigate(['/events/meeting'], { skipLocationChange: true });
        } else if (this.formParam.includes('/conference/update;eventId')) {
          this.commonService.checkConferenceFormSubject.next(true);
        }
        else if (this.formParam.includes('/contacts/add') || this.formParam.includes('/contacts/update')) {
          this.commonService.checkContactFormChanges.next(true);
        } else {
          this.commonService.checkFormUpdateSubject.next(true);
        }
      }
    }
  }
  // onHidden(): void {
  //   this.confirmModal.hide();
  //   this.isModalShown = false;
  // }

  // confirm(): void {
  //   this.confirmModal.hide();
  //   this.isModalShown = false;
  //   this.commonService.setFormChangeValue(false);
  //   if (this.routeTo === 'view') {
  //     this.router.navigate(['/meetings'], { skipLocationChange: true });
  //   } else {
  //     //  this.commonService.resetFormSubject.next(true);

  //     //  this.router.navigate(['/meetings'], { skipLocationChange: true });
  //     // this.router.navigate(['/meeting/create'], { skipLocationChange: true, relativeTo: '/' });
  //   }
  // }

  // decline(): void {
  //   this.confirmModal.hide();
  //   this.isModalShown = false;
  // }

  checkIfUserAuthorized() {
    if (this.errorService.isError) {
      this.hideStaticView = true;
    }
    return this.errorService.isError;
  }

  checkIfUserAuthorizedForCreate() {
    if (this.errorService.isError || !this.commonService.getLoggedInUserRoles().includes('mercury-create-company-meeting')) {
      return true;
    }
    else {
      return false;
    }
  }
}
