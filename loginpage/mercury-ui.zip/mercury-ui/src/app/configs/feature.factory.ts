import { CommonService } from 'src/app/core/http/common.service';
import { LOCATION_INITIALIZED } from '@angular/common/';
import { Injector } from '@angular/core/';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/shared/models/userDetail.model';
import { ErrorService } from 'src/app/core/error/error.service';
import { AppErrorConstants } from 'src/app/shared/app-constant/app-error.constants';
export function loadUtilData(commonService: CommonService, injector: Injector) {
  return () => new Promise(resolve => {
    const locationInitialized = injector.get(LOCATION_INITIALIZED, Promise.resolve(null));
    locationInitialized.then(() => {
      commonService.getDebtTickerFromPaas().subscribe((response) => {
        if (response) {
         commonService.setDebtTicker(response);
      // commonService.setDebtTicker({'debtTicker': 'Sitel Corp', 'analystName': 'Sharma, Kanika', 'analystCorporateId': 'A608245'});
        } else {
          commonService.setDebtTicker([]);
        }
      },
        (error) => {
          commonService.setDebtTicker([]);
        });
      commonService.getUtilData()
        .subscribe(response => {
          if (response) {
            commonService.utilMessageSource.next(response['Items']);
            resolve(null);
          }
        }, (err) => {
          console.log('error loading data');
          resolve(null);
        });
    });
  });
}

export function loadPersonData(commonService: CommonService, injector: Injector) {

  return () => new Promise(resolve => {
    const locationInitialized = injector.get(LOCATION_INITIALIZED, Promise.resolve(null));
    locationInitialized.then(() => {
      commonService.getPersonData()
        .subscribe(response => {
          //   let roles = ['mercury-view-company-meeting', 'mercury-create-company-meeting', 'mercury-update-company-meeting'];
          //   let roles = ['mercury-view-company-meeting'];
          let roles = [];
          if (response['UserRoles']) {
            response['UserRoles'].forEach((item, index) => {
              roles[index] = item['authority'];
            });
          }


          commonService.setLoggedInUserRoles(roles);
          const userDeatilsObservable = commonService.getLoggedInUserDetails(response['AID'].toUpperCase());
          //   const userDeatilsObservable = commonService.getLoggedInUserDetails('A00000');
          userDeatilsObservable.subscribe((userResponse) => {
            if (userResponse && userResponse['data']) {
              let res = userResponse['data'];
              let userDetails = new UserDetail(res['corporateId'] ? res['corporateId'] : '', res['name'] ? res['name'] : '', res['phoneNo'] ? res['phoneNo'] : '',
                res['userCountry'] ? res['userCountry'] : '', res['userTimezone'] ? res['userTimezone'] : '', res['regionCode'] ? res['regionCode'] : '',
                res['legalEntityCode'] ? res['legalEntityCode'] : '', res['regionDesc'] ? res['regionDesc'] : '', res['userTimezoneDesc'] ? res['userTimezoneDesc'] : '',
                res['businessUnit'] ? res['businessUnit']: '', res['cityCountry']? res['cityCountry']: '');
              commonService.setLoggedInUserInfo(userDetails);

              //     commonService.utilMessageSource.next(userResponse['data']['Items']);
            }
            resolve(null);
          },
            (err) => {
              // errorService.setMessage('Unauthorized');
              console.log(err);
              console.log('error status', err.status)
              console.log('error res', err.error.reason)
              if (err.status === 500) {
                commonService.errorDetailsSubject.next('There is an error loading application. Please try again.');
              } else if (err.status === 400) {
                if (err.error.error === 'Unauthorized') {
                  commonService.errorDetailsSubject.next(AppErrorConstants.USER_NOT_IN_OVERRIDE_TABLE);
                } else {
                  commonService.errorDetailsSubject.next(AppErrorConstants.SEARCH_PAGE_ERROR);
                }
              } else {
                //do nothing
              }
              console.log('error  getting details');
              resolve(null);
            });
        }, (err) => {
          if (err.status === 401) {
            commonService.errorDetailsSubject.next(AppErrorConstants.APP_UNAUTH);
          }
          else {
            commonService.errorDetailsSubject.next(AppErrorConstants.SEARCH_PAGE_ERROR);
          }
          console.log(err);
          resolve(null);
        });
    });
  });
}

