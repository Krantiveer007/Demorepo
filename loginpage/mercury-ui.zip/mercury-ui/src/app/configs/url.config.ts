export class URLConfig {
    public static getEnv() {
        const currentHost = window.location.host;
        // if (currentHost.includes('d38uad6u6swdli.cloudfront.net')) {
        if (currentHost.includes('mercurydev')) {
            return 'dev';
        } else if (currentHost.includes('mercuryint')) {
            return 'int';
        } else if (currentHost.includes('mercuryqa')) {
            return 'qa';
        } else if (currentHost.includes('mercuryuat')) {
            return 'uat';
        } else if (currentHost.includes('mercury.app')) {
            return '';
        } else {
            return 'dev';
        }
    }

    public static getEnvForAWS() {
        const currentHost = window.location.host;
        // if (currentHost.includes('d38uad6u6swdli.cloudfront.net')) {
        if (currentHost.includes('mercurydev')) {
            return 'dev';
        } else if (currentHost.includes('mercuryint')) {
            return 'int';
        } else if (currentHost.includes('mercuryqa')) {
            return 'qa';
        } else if (currentHost.includes('mercuryuat')) {
            return 'uat';
        } else if (currentHost.includes('mercury.app')) {
            return 'prd';
        } else {
            return 'dev';
        }
    }
}
