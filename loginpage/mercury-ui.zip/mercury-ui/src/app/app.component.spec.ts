import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { Mv2SideNavComponent } from './core/sideNav/mv2-side-nav.component';
import { HeaderComponent } from './core/header/header.component';
import { MeetingManagementModule } from './feature/meeting-management/meeting-management.module';
import { Mv2FooterComponent } from './core/mv2-footer/mv2-footer.component';
import { CommonService } from 'src/app/core/http/common.service';
import { ErrorService } from 'src/app/core/error/error.service';
import { UrlHandlerService } from 'src/app/shared/services/url-handler.service';
import { By } from '@angular/platform-browser';
import { TitleCasePipe } from '@angular/common';
import {APP_BASE_HREF} from '@angular/common';
import { PopoverModule } from 'ngx-bootstrap';
import { TypeaheadModule, BsModalService, ModalModule, ModalDirective } from 'ngx-bootstrap';
import { RouterModule, Routes, ActivatedRoute, Params, Router } from '@angular/router';
import { SidenavPanelComponent } from 'src/app/shared/components/sidenav-panel/sidenav-panel.component';
import { Mv2SearchMeetingComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-meeting.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
import { Mv2EventsSearchComponent } from 'src/app/feature/searchEvents/mv2-events-search.component';
import { MeetingManagementComponent } from 'src/app/feature/meeting-management/meeting-management.component';
import { of, throwError } from 'rxjs';
import { Location } from "@angular/common";
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
describe('AppComponent', () => {
  let fixture: any;
  let app: any;
  let router: Router;
  let location: Location;
  const appRoutes: Routes = [
  { path: 'meeting/:action', component: MeetingManagementComponent },
  {
    path: 'meetings',
    component: Mv2SearchMeetingComponent,
    data: { title: 'Meetings' }
  },
  {
    path: '',
    // redirectTo: '/meetings',
    component: Mv2SearchMeetingComponent,
    pathMatch: 'full'
  },
  {
    path: 'sideDrawer',
    component: SidenavPanelComponent,
    children: [
      {
        path: 'filter',
        component: SideNavSearchFiltersComponent
      },
      {
        path: 'signup',
        component: SideNavSearchFiltersComponent
      }]
  }
];
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MeetingManagementModule,
        PopoverModule,
        ModalModule,
        RouterTestingModule.withRoutes(appRoutes)
      ],
      declarations: [
        AppComponent,
        Mv2SideNavComponent,
        HeaderComponent,
        Mv2FooterComponent
      ],
      providers: [{provide: 'EnvName', useValue: 'DEV' }, BsModalService, TitleCasePipe, ErrorService, {provide: APP_BASE_HREF, useValue : '/' }, 
      { provide: ActivatedRoute, useValue: { params: of() } }],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    });
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    router = TestBed.get(Router);
    router.initialNavigation();
    location = TestBed.get(Location);
  });

  it('should create the app', () => {
    expect(app).toBeTruthy();
  });

  it(`should have variable 'isCollapsedSidebar' with default value true`, () => {
    expect(app.isCollapsedSidebar).toEqual(true);
  });

  it(`should have method 'toogleSidebar()'`, () => {
    expect(app.toogleSidebar).toBeTruthy();
  });

  it(`should change value of 'isCollapsedSidebar' from true to false when toogleSidebar() is called`, () => {
    app.isCollapsedSidebar = true;
    app.toogleSidebar();

    expect(app.isCollapsedSidebar).toEqual(false);
  });

  it(`should change value of 'isCollapsedSidebar' from true to false when toogleSidebar() is called`, () => {
    app.isCollapsedSidebar = false;
    app.toogleSidebar();

    expect(app.isCollapsedSidebar).toEqual(true);
  });

  it('should hide create button if user doesnot have create meeting access', () => {
const errorService = fixture.debugElement.injector.get(ErrorService);
const commonService = fixture.debugElement.injector.get(CommonService);
  errorService.isError = false;
  commonService.setLoggedInUserRoles(['mercury-update-company-meeting']);
    expect(app.checkIfUserAuthorizedForCreate()).toEqual(true);
      });

  it('should show create button if user  has create meeting access', () => {
const errorService = fixture.debugElement.injector.get(ErrorService);
const commonService = fixture.debugElement.injector.get(CommonService);
  errorService.isError = false;
  commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
    expect(app.checkIfUserAuthorizedForCreate()).toEqual(false);
      });
 it('should hide create button if app has error due to unauthorized access', () => {
const errorService = fixture.debugElement.injector.get(ErrorService);
const commonService = fixture.debugElement.injector.get(CommonService);
  errorService.isError = true;
  commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
    expect(app.checkIfUserAuthorizedForCreate()).toEqual(true);
      });

 it('should navigate to create meeting page if user is on view meetings page', () => {
  app.checkCreateFormUpdate = false;
  const router = fixture.debugElement.injector.get(Router);
  app.navigateToModule('mv2-tertiary-button');
  router.navigate(["/meeting/create"]).then(() => {
   expect(location.path()).toEqual('/meeting/create');
    });
 });

  it('should navigate to view all meetings page without showing popup if user is on view meetings page and dont have access update meeting', () => {
  const errorService = fixture.debugElement.injector.get(ErrorService);
  const commonService = fixture.debugElement.injector.get(CommonService);
   commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
  errorService.isError = false;
  app.formParam = '/meeting/update'; 
  const router = fixture.debugElement.injector.get(Router);
  app.navigateToModule('../assets/images/upper-header/fidelity-logo.svg');
  router.navigate(["/meetings"]).then(() => {
   expect(location.path()).toEqual('/meetings');
    });
 });

 it('should hide profile data is user is unauthorized', () => {
  const errorService = fixture.debugElement.injector.get(ErrorService);
  errorService.isError = true;
  expect(app.checkIfUserAuthorized()).toEqual(true);
 });

});
