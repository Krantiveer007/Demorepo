import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { MeetingManagementComponent } from 'src/app/feature/meeting-management/meeting-management.component';
import { InviteesDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/invitees-details/invitees-details.component';
import { CanActivateAuthGuard } from 'src/app/shared/route-guards/auth-guard.service';
import { USER_ROLES } from 'src/app/shared/app-constant/meeting.constants';
import { ContactManagementComponent } from 'src/app/feature/contact-management/contact-management.component';
import { ContactAddUpdateComponent } from 'src/app/feature/contact-management/contact-add/contact-add-update.component';
import { SidenavPanelComponent } from 'src/app/shared/components/sidenav-panel/sidenav-panel.component';
import { ErrorComponent } from 'src/app/core/error';
import { ConferenceViewComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/conferences/conference-view/conference-view.component';
import { Mv2SearchMeetingComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-meeting.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
import { Mv2EventsSearchComponent } from 'src/app/feature/searchEvents/mv2-events-search.component';
import { ConferenceManagementComponent } from 'src/app/feature/conference-management/conference-management.component';
import { Mv2SearchEventComponent } from 'src/app/feature/searchEvents/mv2-search-events/mv2-search-event.component';
import { MeetingScheduleComponent } from 'src/app/feature/conference-management/conference-detail/meeting-schedule/meeting-schedule.component';

const appRoutes: Routes = [
  { path: 'meeting/:action', component: MeetingManagementComponent },
  {
    path: 'editConference',
    component: MeetingScheduleComponent
  },
  {
    path: "events",
    component: Mv2EventsSearchComponent,
    children: [
      {
        path: 'all',
        component: Mv2SearchEventComponent,
        canActivate: [CanActivateAuthGuard],
        data: { title: 'Meetings', roles: [USER_ROLES.VIEW_MEETING] }
      },
      {
        path: 'meeting',
        component: Mv2SearchMeetingComponent,
        canActivate: [CanActivateAuthGuard],
        data: { title: 'Meetings', roles: [USER_ROLES.VIEW_MEETING] }
      },
      {
        path: "error", component: ErrorComponent
      }
    ]
  },
  { path: 'conference/:action', component: ConferenceManagementComponent },
  {
    path: 'meetings',
    component: Mv2SearchMeetingComponent,
    canActivate: [CanActivateAuthGuard],
    data: { title: 'Meetings', roles: [USER_ROLES.VIEW_MEETING] }
  },
  {
    path: 'contacts',
    component: ContactManagementComponent,
    canActivate: [CanActivateAuthGuard],
    data: { title: 'Contacts', roles: [USER_ROLES.VIEW_CONTACT] }
  },
  {
    path: 'contacts/:action', component: ContactAddUpdateComponent,
  },
  // {
  //   path: 'events/:action',
  //   component: MeetingManagementComponent,
  //   canActivate: [CanActivateAuthGuard],
  //   data: { title: 'Events', roles: [USER_ROLES.VIEW_MEETING] }
  // },
  // {
  //   path: '',
  //   redirectTo: '/events/all',
  //   // component: Mv2EventsSearchComponent,
  //   pathMatch: 'full',
  //   // canActivate: [CanActivateAuthGuard],
  //   // data: { roles: [USER_ROLES.VIEW_MEETING] }
  // },

  {
    path: '',
    component: Mv2EventsSearchComponent,
    pathMatch: 'full',
  },

  {
    path: 'sideDrawer',
    component: SidenavPanelComponent,
    children: [
      {
        path: 'filter',
        component: SideNavSearchFiltersComponent
      },
      {
        path: 'signup',
        component: SideNavSearchFiltersComponent
      }]
  },

  {
    path: 'error',
    component: ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
