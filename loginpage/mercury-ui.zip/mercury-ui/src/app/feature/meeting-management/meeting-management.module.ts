import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MeetingManagementComponent } from './meeting-management.component';
import { Mv2DynamicContentComponent } from './mv2-dynamic-content/mv2-dynamic-content.component';
import { Mv2StaticContentComponent } from './mv2-static-content/mv2-static-content.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TypeaheadModule, TooltipModule, TimepickerModule, PopoverModule, ModalModule } from 'ngx-bootstrap';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { EventDetailsComponent } from './mv2-dynamic-content/meetings/event-details/event-details.component';
import { MeetingDetailsComponent } from './mv2-dynamic-content/meetings/meeting-details/meeting-details.component';
import { InviteesDetailsComponent } from './mv2-dynamic-content/meetings/invitees-details/invitees-details.component';
import { AgGridModule } from 'ag-grid-angular';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ThirdPartyAttendeeComponent } from './mv2-dynamic-content/meetings/third-party-attendee/third-party-attendee.component';
import { ConfigEditComponent } from 'src/app/shared/components/config-edit/config-edit.component';

import { IntlModule } from '@progress/kendo-angular-intl';
import { Routes, RouterModule } from '@angular/router';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { ConfigSignupComponent } from 'src/app/shared/components/config-signup/config-signup.component';
import { Mv2MtgSignUpComponent } from './mv2-mtg-sign-up/mv2-mtg-sign-up.component';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { SidenavPanelComponent } from '../../shared/components/sidenav-panel/sidenav-panel.component';
import { DatePipe } from '@angular/common';
import { ConfigActionsComponent } from 'src/app/shared/components/config-actions/config-actions.component';
import { ConfigResposneComponent } from 'src/app/shared/components/config-resposne/config-resposne.component';
import { OrganizerDetailsComponent } from './mv2-dynamic-content/meetings/organizer-details/organizer-details.component';
import { TripDetailsComponent } from './mv2-dynamic-content/meetings/trip-details/trip-details.component';
import { AdditionalNotesComponent } from './mv2-dynamic-content/meetings/additional-notes/additional-notes.component';
import { USER_ROLES } from 'src/app/shared/app-constant/meeting.constants';
import { BsDropdownModule } from 'ngx-bootstrap';
import { SecurityHoldersComponent } from './mv2-dynamic-content/meetings/security-holders/security-holders.component';
import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import { CanActivateAuthGuard } from 'src/app/shared/route-guards/auth-guard.service';
import { ErrorComponent } from 'src/app/core/error/error.component';
import { ConfigMultiselectComponent } from 'src/app/shared/components/config-multiselect/config-multiselect.component';
import { MultiSelectModule } from '@syncfusion/ej2-angular-dropdowns';
import { DistributionListComponent } from './mv2-dynamic-content/meetings/invitees-details/distribution-list/distribution-list.component';
import { ContactManagementComponent } from 'src/app/feature/contact-management/contact-management.component';
import { ContactAddUpdateComponent } from 'src/app/feature/contact-management/contact-add/contact-add-update.component';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { ConferenceDetailComponent } from './mv2-dynamic-content/conferences/conference-detail/conference-detail.component';
import { BrokerDetailComponent } from './mv2-dynamic-content/conferences/broker-detail/broker-detail.component';
import { ConferencesComponent } from './mv2-dynamic-content/conferences/conferences.component';
import { MeetingsComponent } from './mv2-dynamic-content/meetings/meetings.component';
import { ConferenceViewComponent } from './mv2-dynamic-content/conferences/conference-view/conference-view.component';
import { Mv2SearchMeetingComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-meeting.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
import { Mv2SearchPanelComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-panel/mv2-search-panel.component';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';
import { Mv2EventsSearchComponent } from 'src/app/feature/searchEvents/mv2-events-search.component';
import { Mv2SearchEventComponent } from 'src/app/feature/searchEvents/mv2-search-events/mv2-search-event.component';
import { Mv2EventSearchPanelComponent } from 'src/app/feature/searchEvents/mv2-search-events/mv2-event-search-panel/mv2-event-search-panel.component';
import { Mv2EventListComponent } from 'src/app/feature/searchEvents/mv2-search-events/mv2-event-list/mv2-event-list.component';
import { SideNavEventSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-events/side-nav-event-search-filters/side-nav-event-search-filters.component';
import { DetailCellRendererComponent } from 'src/app/shared/components/detail-cellrenderer/detail-cellrenderer.component';
import { ConfigRadioComponent } from 'src/app/shared/components/config-radio/config-radio.component';
import { ConfigDropDownComponent } from 'src/app/shared/components/config-drop-down/config-drop-down.component';
import { ConfigDaterendererComponent } from 'src/app/shared/components/config-daterenderer/config-daterenderer.component';
import { ConfigTimerendererComponent } from 'src/app/shared/components/config-timerenderer/config-timerenderer.component';
import { ConfigDurationComponent } from 'src/app/shared/components/config-duration/config-duration.component';
import { ExternalContactSearchComponent } from './mv2-dynamic-content/meetings/third-party-attendee/external-contact-search/external-contact-search.component';
import { ArrangementContactDetailsComponent } from './mv2-dynamic-content/conferences/arrangement-contact-details/arrangement-contact-details.component';

const appRoutes: Routes = [
  { path: 'meeting/:action', component: MeetingManagementComponent },
  {
    path: 'meetings',
    component: Mv2SearchMeetingComponent,
    canActivate: [CanActivateAuthGuard],
    data: { title: 'Meetings', roles: [USER_ROLES.VIEW_MEETING] }
  },
  {
    path: 'contacts',
    component: ContactManagementComponent,
    canActivate: [CanActivateAuthGuard],
    data: { title: 'Contacts', roles: [USER_ROLES.VIEW_CONTACT] }
  },
  {
    path: 'contacts/:action', component: ContactAddUpdateComponent,
  },
  {
    path: '',
    // redirectTo: '/meetings',
    component: Mv2EventsSearchComponent,
    pathMatch: 'full',
    canActivate: [CanActivateAuthGuard],
    data: { roles: [USER_ROLES.VIEW_MEETING] }
  },
  {
    path: 'sideDrawer',
    component: SidenavPanelComponent,
    children: [
      {
        path: 'filter',
        component: SideNavSearchFiltersComponent
      },
      {
        path: 'signup',
        component: SideNavSearchFiltersComponent
      }]
  },

  {
    path: 'error',
    component: ErrorComponent
  }
];

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    TypeaheadModule.forRoot(),
    HttpClientModule,
    TooltipModule.forRoot(),
    NgSelectModule,
    PopoverModule.forRoot(),
    TimepickerModule.forRoot(),
    ModalModule,
    ReactiveFormsModule,
    AgGridModule.withComponents([]),
    IntlModule,
    RouterModule.forRoot(appRoutes),
    TimePickerModule,
    BrowserModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    MultiSelectModule
  ],
  declarations: [
    MeetingManagementComponent,
    Mv2DynamicContentComponent,
    Mv2StaticContentComponent,
    EventDetailsComponent,
    MeetingDetailsComponent,
    InviteesDetailsComponent,
    ConfigInviteesDtlsComponent,
    ConfigCheckboxComponent,
    ConfigDeleteComponent,
    ConfigSignupComponent,
    ConfigActionsComponent,
    ThirdPartyAttendeeComponent,
    Mv2SearchMeetingComponent,
    Mv2SearchPanelComponent,
    Mv2MeetingListComponent,
    Mv2MtgSignUpComponent,
    CommonGridComponent,
    Mv2SearchEventComponent,
    Mv2EventSearchPanelComponent,
    Mv2EventListComponent,
    SideNavEventSearchFiltersComponent,
    SidenavPanelComponent,
    SideNavSearchFiltersComponent,
    OrganizerDetailsComponent,
    TripDetailsComponent,
    AdditionalNotesComponent,
    ConfigResposneComponent,
    SecurityHoldersComponent,
    ConfigRowSelectionComponent,
    ErrorComponent,
    ConfigMultiselectComponent,
    DistributionListComponent,
    ContactAddUpdateComponent,
    ConferenceDetailComponent,
    BrokerDetailComponent,
    ConferencesComponent,
    MeetingsComponent,
    ConferenceViewComponent,
    ExternalContactSearchComponent,
    ArrangementContactDetailsComponent
  ],
  exports: [MeetingManagementComponent],
  entryComponents: [ConfigInviteesDtlsComponent,
    ConfigCheckboxComponent,
    ConfigDeleteComponent,
    ConfigEditComponent,
    ConfigSignupComponent,
    ConfigActionsComponent,
    CommonGridComponent,
    ConfigResposneComponent,
    ConfigRowSelectionComponent,
    ConfigMultiselectComponent,
    DetailCellRendererComponent,
    ConfigRadioComponent,
    ConfigDropDownComponent,
    ConfigDaterendererComponent,
    ConfigTimerendererComponent,
    ConfigDurationComponent
  ],
  providers: [DatePipe, WindowRef]
})
export class MeetingManagementModule { }
