import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetingManagementComponent } from './meeting-management.component';
import { Mv2DynamicContentComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/mv2-dynamic-content.component';
// import { Mv2StaticContentComponent } from 'src/app/feature/meeting-management/mv2-static-content/mv2-static-content.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { TypeaheadModule, TimepickerModule, BsModalService, ModalModule, ModalDirective } from 'ngx-bootstrap';
import { TooltipModule } from 'ngx-bootstrap';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { PopoverModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { TitleCasePipe } from '@angular/common';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { MeetingSubtype } from '../../shared/models/meetingsubtype.model';
import { MeetingInitiator } from '../../shared/models/meetinginitiator.model';
import { Country } from '../../shared/models/country.model';
import { DialIn } from '../../shared/models/dialin.model';
import { MeetingLocation } from '../../shared/models/meetinglocation.model';
import { SecurityDetails } from '../../shared/models/securitydetails.model';
import { AssociatedEventDetail } from '../../shared/models/associatedeventdetail.model';
import { ArrangementContact } from '../../shared/models/arrangementcontact.model';
import { FidelityInvitees } from '../../shared/models/fidelityInvitees.model';
import { MeetingCreator } from '../../shared/models/meetingcreator.model';
import { Meeting } from '../../shared/models/meeting.model';
import { CommonService } from '../../core/http/common.service';
import { of, throwError } from 'rxjs';
import { ThirdPartyAttendee } from 'src/app/shared/models/thirdPartyAttendee.model';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes, ActivatedRoute, Params, Router } from '@angular/router';
import { IntlModule } from '@progress/kendo-angular-intl';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { IntlService } from '@progress/kendo-angular-intl';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { RouterTestingModule } from '@angular/router/testing';
import { BsDropdownModule } from 'ngx-bootstrap';
import { Location } from "@angular/common";
import { SidenavPanelComponent } from '../../shared/components/sidenav-panel/sidenav-panel.component';
import { Mv2SearchMeetingComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-meeting.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
import { Mv2EventsSearchComponent } from 'src/app/feature/searchEvents/mv2-events-search.component';
import { ErrorService } from 'src/app/core/error/error.service';
import { EventDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/event-details/event-details.component';
import { InviteesDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/invitees-details/invitees-details.component';
import { MeetingDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/meeting-details/meeting-details.component';
describe('MeetingManagementComponent', () => {
  let component: MeetingManagementComponent;
  let fixture: ComponentFixture<MeetingManagementComponent>;
  let fb: FormBuilder;
  let rowData: any[];
  let thirdPartyAttendee: any[];
  let meeting: Meeting;
  let meetingWithNoInvitees: Meeting;
  let location: Location;
  let router: Router;
  let meetingFormValue: Meeting;
  let response: any;
  const appRoutes: Routes = [
    { path: 'meeting/:action', component: MeetingManagementComponent },
    {
      path: 'meetings',
      component: Mv2SearchMeetingComponent,
      data: { title: 'Meetings' }
    },
    {
      path: '',
      // redirectTo: '/meetings',
      component: Mv2SearchMeetingComponent,
      pathMatch: 'full'
    },
    {
      path: 'sideDrawer',
      component: SidenavPanelComponent,
      children: [
        {
          path: 'filter',
          component: SideNavSearchFiltersComponent
        },
        {
          path: 'signup',
          component: SideNavSearchFiltersComponent
        }]
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        TooltipModule.forRoot(),
        TimepickerModule.forRoot(),
        NgSelectModule,
        PopoverModule.forRoot(),
        HttpClientModule,
        CommonModule,
        ModalModule.forRoot(),
        AgGridModule.withComponents([]),
        IntlModule,
        TimePickerModule,
        BrowserModule,
        BrowserAnimationsModule,
        BsDropdownModule.forRoot(),
        RouterTestingModule.withRoutes(appRoutes)
      ],
      declarations: [MeetingManagementComponent, Mv2DynamicContentComponent,
        // Mv2StaticContentComponent,
        EventDetailsComponent, MeetingDetailsComponent, InviteesDetailsComponent,
        ConfigInviteesDtlsComponent, ConfigCheckboxComponent, ConfigDeleteComponent, CommonGridComponent, Mv2SearchMeetingComponent,
        SideNavSearchFiltersComponent, SidenavPanelComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, BsModalService, TitleCasePipe, ErrorService, { provide: ActivatedRoute, useValue: { params: of() } }],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ConfigCheckboxComponent, ConfigDeleteComponent],
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    fixture = TestBed.createComponent(MeetingManagementComponent);
    component = fixture.componentInstance;
    fb = new FormBuilder();
    fixture.detectChanges();
    router.initialNavigation();
    rowData = [
      {
        'Attendee': 'Verma, Pankaj',
        'AttendeeId': 'A608245',
        'Call-In': false,
        'Infopacks': false,
        'Info Only': true,
        'Remove': '',
        'Response': ''
      }
    ];

    response = {
      additionalNotes: "abc",
      analyst: null,
      analystCorporateId: null,
      analystTeam: null,
      arrangementContact: {
        organizedThrough: 'Company',
        organizerContactId: '1234',
        organizerName: 'Sharma, Kanika',
        organizerEmail: 'abc@gmail.com',
        organizerCompany: 'Zara',
        organizerPhone: '1234',
        organizerPosition: 'CEO'
      },
      associatedEventId: null,
      bloombergTicker: "ADBE.US",
      brokerUsageInitiator: 'Company',
      businessUnit: "MA - TOK",
      corporateId: null,
      country: null,
      countryCode: "ASTL",
      countryDescription: "Australia",
      creatorName: null,
      cusipIdentifier: null,
      dialIn: "N",
      dialInAccessCode: '123456789',
      dialInNumber: '123456',
      emailSendingReason: "CREATED",
      emailSentIndicator: "N",
      emailSentThrough: "Y",
      emailType: "MEETING REQUEST",
      eventEndDate: null,
      eventName: null,
      eventPrincipalHost: null,
      eventStartDate: null,
      eventType: null,
      executiveInvited: "Y",
      meetingOwnerCorporateId: 'A252525',
      externalLocationAddress: '123/GF',
      fidelityInvitees: [{
        "corporateId": "A608245",
        "inviteeResponse": "",
        "isCallIn": "N",
        "isInfoPackRequired": "N",
        "isInviteForInfoOnly": "Y",
        "name": "Verma, Pankaj"
      }],
      hostCorporateId: "A589589",
      insertedBy: "A535076",
      insertedTimestamp: "2019-06-05T05:54:36.000Z",
      internalLocationRoom: "LDN 1F",
      internalLocationRoomOther: null,
      locationType: "External",
      marketCapitalization: null,
      marketCapitalizationSize: null,
      meetingBody: "Host: JYOTSANA NANDWANI (8-779-1240)↵Subtype: Grp Info↵↵Contact: MERAPPUSER ()↵Dial In Details: Not Applicable↵↵External Attendees: ↵FIL - Analyst Assigned: N/A↵Market Capitalization: ↵↵↵Contact/Additional Notes: JN CREATE CONFIRM",
      meetingCancellationReason: null,
      meetingCity: "Sydney",
      meetingDate: "2019-05-12T00:00:00.000Z",
      meetingDuration: '60',
      meetingId: "",
      meetingInitiatorCode: "BRK",
      meetingInitiatorDescription: "Broker",
      meetingLastUpdatedBy: null,
      meetingLastUpdatedDateTime: null,
      meetingLocation: "AUS Derwent 8772 0592",
      meetingRegion: null,
      meetingState: "CONFIRMED",
      meetingStatus: "",
      meetingSubTypeCode: "GRPRSLT",
      meetingSubTypeDescription: "Grp Result",
      meetingSubTypeOtherDescription: null,
      meetingSubject: "ADOBE SYSTEMS INC - Grp Info - JYOTSANA NANDWANI - <Mer:2019-06-05T05:54:36.000Z-ef22649c-5f67-44ff-a29c-3f570d835138>",
      meetingTime: "0230",
      meetingTimeInGMT: "0230",
      meetingTimezone: "Australia/Sydney GMT+11",
      meetingType: "Company",
      privateMeetingFlag: null,
      scheduleId: "2019-06-05T05:54:36.000Z-ef22649c-5f67-44ff-a29c-3f570d835138",
      sector: null,
      securityDetail: {
        analystRoleTypeCd: 1,
        analystRoleTypeDesc: "Primary",
        assetType: "EQUITY",
        assignmentDate: "2018-01-05 14:19:41",
        assignmentStartDate: "2018-01-05 00:00:00",
        bbCode: "",
        businessUnitName: "FIL LONDON",
        bussinessUnitCd: "FIL-LDN",
        corpId: "A556224",
        corporateId: "A556224",
        grdCountryDesc: "UNITED STATES",
        instrumentLongName: "ZARA",
        instrumentTypeCd: "CS",
        marketCapitalization: 134089,
        marketCapitalizationSize: "Large",
        name: "WAHI, SUMANT",
        phoneNumber: "8-727-4778",
        teamCd: "LdnUSSC",
        teamDept: "FUND",
        teamLocation: "LDN",
        teamName: "Team - FIL US Research",
        ticker: "",
        tradableEntId: '123456',
        tradeableEntityId: '123456'
      },
      sedolIdentifier: null,
      sendMeetingAsInviteRetryCount: 0,
      stockRegion: null,
      thirdPartyAttendee: [{
        Email: "UNKWN528@unknown.uk",
        ExternalContactId: "2019-04-03T05:44:36.000Z#9817f63d-1e20-4517-8d49-3fae6cbcab67",
        ExternalContactName: "East, Warren",
        Notes: "",
        Position: "CEO"
      }],
      ticker: "ADBE",
      emailSubject: "New Meeting",
      tseIdentifier: null
    };

    thirdPartyAttendee = [{
      'Attendee': 'East, Warren',
      'Email': 'UNKWN528@unknown.uk',
      'ExternalContactId': '2019-04-03T05:44:36.000Z#9817f63d-1e20-4517-8d49-3fae6cbcab67',
      'Notes': '',
      'Position': 'CEO',
      'Remove': ''
    }];

    meetingFormValue = new Meeting('Company', '', '', 'MA - TOK', 'Y', 'New Meeting', new MeetingSubtype('GRPRSLT', 'Grp Result', ''), new MeetingInitiator('BRK', 'Broker', 'Company'),
      '12/05/2019', '60', 'Australia/Sydney GMT+11', 'abc', new Country('ASTL', 'Australia'), 'Sydney', '', '', new DialIn('123456', '123456789'), new MeetingLocation('External', 'LDN 1F', '', '123/GF'),
      new SecurityDetails('ZARA', '', '', '', '', '', '', '', '', '', '', '', '', '', '123456'),
      new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '1234', 'Sharma, Kanika', 'Zara', '1234', 'abc@gmail.com', 'CEO',''),
      [new FidelityInvitees("A608245", "Verma, Pankaj", 'N', 'N', 'Y', 'N', '')], [new ThirdPartyAttendee("East, Warren", "2019-04-03T05:44:36.000Z#9817f63d-1e20-4517-8d49-3fae6cbcab67",
        "UNKWN528@unknown.uk", "CEO", '')], new MeetingCreator('', ''), '', 'A252525', '', '', '0230', 'A589589', '', '', '', '', '');

    meeting = new Meeting('Company', 'CREATED', 'DRAFT', 'MA - TOK', 'Y', 'New Meeting', new MeetingSubtype('GRPRSLT', 'Grp Result', ''),
      new MeetingInitiator('BRKR', 'Broker', 'Company'), '12-5-2019', '0130', 'Australia/Sydney GMT+11', 'abc',
      new Country('ASTL', 'Australia'), 'Sydney', '', '',
      new DialIn('123456', '123456789'), new MeetingLocation('External', 'LDN 1F', '', '123/GF'),
      new SecurityDetails('ZARA', '', '', '', '', '', '', '', '', '', '', '', '', '', '123456'),
      new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '1234', 'Sharma, Kanika', 'Zara', '1234', 'abc@gmail.com', 'CEO'),
      [new FidelityInvitees('A608245', 'Verma, Pankaj', 'N', 'N', 'N', 'Y', '')],
      [new ThirdPartyAttendee('East, Warren', '2019-04-03T05:44:36.000Z#9817f63d-1e20-4517-8d49-3fae6cbcab67', 'UNKWN528@unknown.uk', 'CEO', '')],
      new MeetingCreator('', ''), '', 'A252525', '', '', '0230', 'A589589', '', '', '', '', '');
    meetingWithNoInvitees = new Meeting('Company', 'CREATED', 'DRAFT', 'MA - TOK', 'Y', 'New Meeting',
      new MeetingSubtype('GRPRSLT', 'Grp Result', ''),
      new MeetingInitiator('BRKR', 'Broker', 'Company'), '12-5-2019', '0130', 'Australia/Sydney GMT+11', 'abc',
      new Country('ASTL', 'Australia'), 'Sydney', '', '',
      new DialIn('123456', '123456789'), new MeetingLocation('External', 'LDN 1F', '', '123/GF'),
      new SecurityDetails('ZARA', '', '', '', '', '', '', '', '', '', '', '', '', '', '123456'),
      new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '1234', 'Sharma, Kanika', 'Zara', '1234', 'abc@gmail.com', 'CEO'),
      [], [], new MeetingCreator('', ''), '', 'A252525', '', '', '0230', 'A589589', '', '', '', '', '');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have save button enabled if all the required validations are met', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isDraftDisabled();
    expect(result).toEqual(false);
  });

  it('should have confirm button enabled if all the required validations are met', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Camabatela, Angola',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(false);
  });

  it('should have save/confirm button disabled if security is not selected', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: '',
      securityTradableEntityId: '',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = '-';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have save/confirm button disabled if invitees are not selected', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: '',
      securityTradableEntityId: '',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = '-';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have draft button disabled if hostname is not selected', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: ''
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    //  component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
  });

  it('should have save/confirm button disabled if time is not selected', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:00:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    //  component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.meetingTime).toEqual('0000');
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have save/confirm button disabled if date is not selected', () => {
    const eventForm = fb.group({
      date: [''],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });


  it('should have save/draft button disabled if parent meeting form is invalid', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors({ 'invalid': true });
    // component.mv2StaticContentComponent.securities.instrumentLongName = '-';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have save/draft button disabled if event details control is missing in  parent meeting form', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});

    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors({ 'invalid': true });
    // component.mv2StaticContentComponent.securities.instrumentLongName = '-';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have save/draft button disabled if meeting details control is missing in parent meeting form', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')]
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika'
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors({ 'invalid': true });
    // component.mv2StaticContentComponent.securities.instrumentLongName = '-';
    const result = component.isDraftDisabled();
    expect(result).toEqual(true);
    expect(component.isConfirmDisabled()).toEqual(true);
  });

  it('should have confirm button disabled if cityCountry is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: '',
        Country: '',
        GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '',
        KeyCode: '',
        cityCountryVal: '',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button disabled if location is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: [''],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button enabled if room/address is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: ['']
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(false);
  });


  it('should have confirm button enabled if all the required validations are met', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: ['abc']
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(false);
  });

  it('should have confirm button disabled if business unit is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCOuntryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button disabled if subtype', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '#Other', KeyCode: '' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button disabled if initiator is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: '', KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button disabled if subtype', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '#Other', KeyCode: '' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should have confirm button disabled if arrangement contact is missing', () => {
    const eventForm = fb.group({
      date: ['12-05-2019'],
      time: [new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')],
      cityCountry: [{
        Cities: 'Camabatela',
        Country: 'Angola',
        GRD_COUNTRY_CD: 'ANGL',
        ISO_COUNTRY_CD: 'AO',
        KeyCode: 'AO#Camabatela',
        cityCountryVal: 'Angola, Camabatela',
        UtilKeyName: 'country-city-map'
      }],
      location: ['In-house'],
      room: [{ KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }],
    });
    const meetingDtlsForm = fb.group({
      securityName: 'ZARA',
      securityTradableEntityId: '123456',
      hostName: 'Kanika',
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      mtgSubtype: [{ KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' }],
      meetingInitiator: [{ MeetingTypeCode: 'COMP', KeyDesc: 'Comapny', ActiveInd: '', UtilKeyName: '', KeyCode: 'COMP' }],
    });
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });
    const organizerDtlsForm = fb.group({
      organizedThrough: [''],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.meetingForm.setErrors(null);
    // component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
    const result = component.isConfirmDisabled();
    expect(result).toEqual(true);
  });

  it('should insert values entered by user in meeting object if click on ' +
    'save/confirm and show dialog box for user affirmation if meeting is saved in DB', () => {
      const eventForm = fb.group({
        date: ['12-5-2019'],
        time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
        duration: ['0130'],
        timezone: ['Australia/Sydney GMT+11'],
        cityCountry: [{
          Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
          ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
        }],
        location: ['External'],
        room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
        address: ['123/GF'],
        dailin: ['false'],
        dailpicker: ['123456'],
        accesscode: ['123456789'],
        meetingId: ''
      });
      const meetingDtlsForm = fb.group({
        securityName: 'ZARA',
        securityTradableEntityId: '123456',
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: '',
        hostName: 'Kanika',
        mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
        meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
        meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
        brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
        subjectLine: ['New Meeting'],
        meetingNotes: ['nil'],
        personName: ['Jyotsana'],
        meetingExecutive: [true],
        hostCorpId: ['A589589'],
        ownerCorpId: ['A252525']
      });
      const inviteeDtlsForms = fb.group({
        inviteeGrid: [rowData]
      });
      const thirdPartyAttendeeForms = fb.group({
        thirdPartyAttendeeGrid: [thirdPartyAttendee]
      });
      const organizerDtlsForm = fb.group({
        organizedThrough: ['Company'],
        organizerContactId: ['1234'],
        organizerName: ['Sharma, Kanika'],
        organizerEmail: ['abc@gmail.com'],
        organizerCompany: ['Zara'],
        organizerPhone: ['1234'],
        organizerPosition: ['CEO']
      });

      const additionalNoteForm = fb.group({
        additionalNotes: ['abc']
      });
      const meetingForm: FormGroup = fb.group({});
      meetingForm.setControl('event-details', eventForm);
      meetingForm.setControl('meeting-details', meetingDtlsForm);
      meetingForm.setControl('invitee-details', inviteeDtlsForms);
      meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
      meetingForm.setControl('organizer-details', organizerDtlsForm);
      meetingForm.setControl('additional-notes', additionalNoteForm);
      component.meetingForm.setControl('meetingForm', meetingForm);
      component.meetingForm.patchValue({
        ownerCorporateId: 'A252525'
      });
      const peopleDataService = fixture.debugElement.injector.get(CommonService);
      const spy = spyOn(peopleDataService, 'insertMeetingDetails').and.returnValue(of({ 'status': 200 }));
      component.isDraftDisabled();
      component.draftForm('Draft');
      console.log('component.meeting: ', component.meeting);
      expect(component.meeting).toEqual(meeting);
      //  expect(component.draftConfirmMessage).toEqual('Meeting saved as Draft successfully.');
      //expect(component.modalRef).not.toBeNull;
      //expect(component.draftMeetingStatus).toEqual('DRAFT');
    });


  // ---------------------------check--------------------------------------
  it('should insert values entered by user in meeting object, ' +
    'show dialog box with information as Meeting saved as Draft successfully' +
    'if meeting is saved in DB, hide dialog box when clicked ok', () => {
      const eventForm = fb.group({
        date: ['12-5-2019'],
        time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
        duration: ['0130'],
        timezone: ['Australia/Sydney GMT+11'],
        cityCountry: [{
          Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
          ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
        }],
        location: ['External'],
        room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
        address: ['123/GF'],
        dailin: ['false'],
        dailpicker: ['123456'],
        accesscode: ['123456789'],
        meetingId: ''
      });
      const meetingDtlsForm = fb.group({
        securityName: ['ZARA'],
        securityTradableEntityId: ['123456'],
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: '',
        hostName: ['Kanika'],
        mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
        meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
        meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
        brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
        subjectLine: ['New Meeting'],
        personName: ['Jyotsana'],
        meetingExecutive: [true],
        hostCorpId: ['A589589'],
        ownerCorpId: ['A252525']
      });
      const inviteeDtlsForms = fb.group({
        inviteeGrid: [rowData]
      });
      const thirdPartyAttendeeForms = fb.group({
        thirdPartyAttendeeGrid: [thirdPartyAttendee]
      });
      //  component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';

      const organizerDtlsForm = fb.group({
        organizedThrough: ['Company'],
        organizerContactId: ['1234'],
        organizerName: ['Sharma, Kanika'],
        organizerEmail: ['abc@gmail.com'],
        organizerCompany: ['Zara'],
        organizerPhone: ['1234'],
        organizerPosition: ['CEO']
      });

      const additionalNoteForm = fb.group({
        additionalNotes: ['abc']
      });
      component.draftMeetingStatus = 'DRAFT';
      component.emailSendingReason = 'CREATED';
      const meetingForm: FormGroup = fb.group({});
      meetingForm.setControl('event-details', eventForm);
      meetingForm.setControl('meeting-details', meetingDtlsForm);
      meetingForm.setControl('invitee-details', inviteeDtlsForms);
      meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
      meetingForm.setControl('organizer-details', organizerDtlsForm);
      meetingForm.setControl('additional-notes', additionalNoteForm);
      component.meetingForm.setControl('meetingForm', meetingForm);
      component.meetingForm.patchValue({
        ownerCorporateId: 'A252525'
      });
      const peopleDataService = fixture.debugElement.injector.get(CommonService);
      const spy = spyOn(peopleDataService, 'insertMeetingDetails').and.returnValue(of({ 'status': 200 }));
      component.isDraftDisabled();
      component.draftForm('Draft');
      // fixture.detectChanges();
      expect(component.meeting).toEqual(meeting);
      // expect(component.draftConfirmMessage).toEqual('Meeting saved as Draft successfully.');
      expect(component.isModalShown).toEqual(true);
      component.confirm();
      fixture.detectChanges();
   //   expect(component.isModalShown).toEqual(false);
    });

  // -------------------------------------


  // it('should show dialog box with information as The meeting could not be saved as Draft.
  //  Please try again if unable to save meeting in DB', () => {
  //   let eventForm = fb.group({
  //   date: ['12-5-2019'],
  //   time: ['0000'],
  //   duration: ['0130'],
  //   timezone: ['GMT'],
  //   city: ['abc'],
  //   country: ['abcd'],
  //   location: ['External'],
  //   room: ['A'],
  //   address: ['123/GF'],
  //   dailin: ['false'],
  //   dailpicker: ['123456'],
  //   accesscode: ['123456789']
  // });
  //   let meetingDtlsForm = fb.group({
  //     hostName: ['Kanika'],
  //     mtgSubtype: ['Gen'],
  //     meetingBusUnit: ['EQ-EUR'],
  //     meetingInitiator: ['Company'],
  //     brokerUsage: ['FIL'],
  //     subjectLine: ['New Meeting'],
  //     meetingNotes: ['nil'],
  //     personName: ['Jyotsana'],
  //     meetingExecutive: [true],
  //     hostCorpId: ['A589589'],
  //     ownerCorpId: ['A252525']
  //   });
  //  let inviteeDtlsForms = fb.group({
  //     inviteeGrid: [rowData]
  //   });
  //   let meetingForm: FormGroup = fb.group({});

  //   component.mv2StaticContentComponent.securities.instrumentLongName = 'ZARA';
  //   component.draftMeetingStatus = 'DRAFT';
  // component.emailSendingReason = 'CREATED';
  //   meetingForm.setControl('event-details', eventForm);
  //   meetingForm.setControl('meeting-details', meetingDtlsForm);
  //   meetingForm.setControl('invitee-details', inviteeDtlsForms);
  //   component.meetingForm.setControl('meetingForm',meetingForm);
  //   const peopleDataService = fixture.debugElement.injector.get(CommonService);
  //   const spy = spyOn(peopleDataService, 'insertMeetingDetails').and.returnValue(throwError);
  //   component.draftForm();
  //   fixture.detectChanges();
  //   component.meetingObservable.subscribe((response) => {},
  //   (error) => {
  //     expect(component.draftConfirmMessage).toEqual('The meeting could not be saved as Draft. Please try again.');
  //     expect(component.modalRef).not.toBeNull;
  //   });
  //   });

  it('should reset event Details', () => {
    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [false],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetEventDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('event-details').value).toEqual(resetEventForm['value']);
    // expect(component.draftConfirmMessage).toEqual('Meeting saved as Draft successfully.');

  });

  it('should reset Meeting Details', () => {

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
   //   personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589']
     // ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
    //  personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
   //   ownerCorpId: ['']
    });

    component.draftMeetingStatus = 'DRAFT';
    component.emailSendingReason = 'CREATED';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetMeetingDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('meeting-details').value).toEqual(resetMeetingDtlsForm['value']);
  });

  it('should reset Organizer Details', () => {
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });

    component.draftMeetingStatus = 'DRAFT';
    component.emailSendingReason = 'CREATED';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetOrganizerDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('organizer-details').value).toEqual(resetOrganizerDtlsForm['value']);
  });

  it('should reset Organizer Details', () => {
    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });

    component.draftMeetingStatus = 'DRAFT';
    component.emailSendingReason = 'CREATED';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetOrganizerDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('organizer-details').value).toEqual(resetOrganizerDtlsForm['value']);
  });

  it('should reset Invitee Details', () => {
    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    component.draftMeetingStatus = 'DRAFT';
    component.emailSendingReason = 'CREATED';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetInviteeDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('invitee-details').value).toEqual(resetInviteeDtlsForms['value']);
  });


  it('should reset Third Party Attendee Details', () => {
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    component.draftMeetingStatus = 'DRAFT';
    component.emailSendingReason = 'CREATED';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.resetThirdPArtyAttendeeDetails();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('third-party-attendee').value).toEqual(resetThirdPartyAttendeeForms['value']);
  });

  it('should reset complete meeting form', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
    //  personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
    //  ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
    //  personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
    //  ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.initialiseInvites();
    fixture.detectChanges();
    expect(component.meetingForm.get('meetingForm').get('invitee-details').value).toEqual(resetInviteeDtlsForms['value']);
    expect(component.meetingForm.get('meetingForm').get('third-party-attendee').value).toEqual(resetThirdPartyAttendeeForms['value']);
    expect(component.meetingForm.get('meetingForm').get('organizer-details').value).toEqual(resetOrganizerDtlsForm['value']);
    expect(component.meetingForm.get('meetingForm').get('meeting-details').value).toEqual(resetMeetingDtlsForm['value']);
    expect(component.meetingForm.get('meetingForm').get('event-details').value).toEqual(resetEventForm['value']);
    expect(component.meetingForm.get('meetingForm').get('additional-notes').get('additionalNotes').value).toEqual('');
    expect(component.meetingState).toEqual('NEW');
    expect(component.confirmButtonLabel).toEqual('Confirm');
  });

  it('should open a dialog box if we are on create meeting page, page is updated with some data and without saving the data we click on create meeting button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'resetFormSubject').and.returnValue(of(true));
    component.formParam = 'create';
    component.resetFormUpdate(true, '/meeting/create');
    fixture.detectChanges();
    expect(component.messageHeading).toEqual('Confirm Navigation');
    expect(component.draftConfirmMessage).toEqual('This page contains unsaved changes. Are you sure you want to exit ?');
    expect(component.imageStatus).toEqual('alert');
    expect(component.isModalShown).toEqual(true);
    expect(component.showNoButton).toEqual(true);
    expect(component.confirmButton).toEqual('YES');
    expect(component.routeCase).toEqual('meetingRouteToCreate');
  });

  it('should open a dialog box if we are on update meeting page, page is updated with some data and without saving the data we click on create meeting button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const errorService = fixture.debugElement.injector.get(ErrorService);
    errorService.isError = false;
    commonService.setLoggedInUserRoles(['mercury-update-company-meeting']);
    const spy = spyOn(commonService, 'resetFormSubject').and.returnValue(of(true));
    component.formParam = 'update';
    component.checkFormUpdate(true, '/meeting/create');
    fixture.detectChanges();
    expect(component.messageHeading).toEqual('Confirm Navigation');
    expect(component.draftConfirmMessage).toEqual('This page contains unsaved changes. Are you sure you want to exit ?');
    expect(component.imageStatus).toEqual('alert');
    expect(component.isModalShown).toEqual(true);
    expect(component.showNoButton).toEqual(true);
    expect(component.confirmButton).toEqual('YES');
    expect(component.routeCase).toEqual('meetingRouteToCreate');
  });

  it('should open a dialog box if we are on create meeting page, page is updated with some data and without saving the data we click on view meetings button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'checkFormUpdateSubject').and.returnValue(of(true));
    component.formParam = 'update';
    component.resetFormUpdate(true, '/meetings');
    fixture.detectChanges();
    expect(component.messageHeading).toEqual('Confirm Navigation');
    expect(component.draftConfirmMessage).toEqual('This page contains unsaved changes. Are you sure you want to exit ?');
    expect(component.imageStatus).toEqual('alert');
    expect(component.isModalShown).toEqual(true);
    expect(component.showNoButton).toEqual(true);
    expect(component.confirmButton).toEqual('YES');
    expect(component.routeCase).toEqual('meetingRouteToView');
  });

  it('should open a dialog box if we are on update meeting page, page is updated with some data and without saving the data we click on view meetings button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'checkFormUpdateSubject').and.returnValue(of(true));
    component.formParam = 'update';
    component.checkFormUpdate(true, '/meetings');
    fixture.detectChanges();
    expect(component.messageHeading).toEqual('Confirm Navigation');
    expect(component.draftConfirmMessage).toEqual('This page contains unsaved changes. Are you sure you want to exit ?');
    expect(component.imageStatus).toEqual('alert');
    expect(component.isModalShown).toEqual(true);
    expect(component.showNoButton).toEqual(true);
    expect(component.confirmButton).toEqual('YES');
    expect(component.routeCase).toEqual('meetingRouteToView');
  });

  it('should route to view meetings page if we are on create meeting page, page is not updated and we click on view meetings button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const resetAdditionalNoteForm = fb.group({
      additionalNotes: ['']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', resetEventForm);
    meetingForm.setControl('meeting-details', resetMeetingDtlsForm);
    meetingForm.setControl('organizer-details', resetOrganizerDtlsForm);
    meetingForm.setControl('invitee-details', resetInviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', resetThirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', resetAdditionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const router = fixture.debugElement.injector.get(Router);
    const spy = spyOn(commonService, 'checkFormUpdateSubject').and.returnValue(of(true));
    component.formParam = 'create';
    component.resetFormUpdate(true, '/meetings');
    fixture.detectChanges();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
    });
  });

  it('should route to create meetings page if we are on create meeting page, page is not updated and we click on create meetings button', () => {

    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
  //    personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
   //   ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
  //    personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
  //    ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const resetAdditionalNoteForm = fb.group({
      additionalNotes: ['']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', resetEventForm);
    meetingForm.setControl('meeting-details', resetMeetingDtlsForm);
    meetingForm.setControl('organizer-details', resetOrganizerDtlsForm);
    meetingForm.setControl('invitee-details', resetInviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', resetThirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', resetAdditionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);

    const commonService = fixture.debugElement.injector.get(CommonService);
    const router = fixture.debugElement.injector.get(Router);
    const spy = spyOn(commonService, 'resetFormSubject').and.returnValue(of(true));
    component.formParam = 'create';
    component.resetFormUpdate(true, '/meeting/create');
    fixture.detectChanges();
    router.navigate(["/meeting/create"]).then(() => {
      expect(location.path()).toEqual('/meeting/create');
    });
  });

  it('should route to view meetings page if we are on update meeting page, page is not updated and we click on view meetings button', () => {

    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRK' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const resetAdditionalNoteForm = fb.group({
      additionalNotes: ['']
    });
    component.meetingTime = '0230';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.actualMeetingForm = meetingFormValue;
    const commonService = fixture.debugElement.injector.get(CommonService);
    const router = fixture.debugElement.injector.get(Router);
    const spy = spyOn(commonService, 'checkFormUpdateSubject').and.returnValue(of(true));
    component.formParam = 'update';
    component.checkFormUpdate(true, '/meetings');
    fixture.detectChanges();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
    });
  });

  it('should route to create meetings page if we are on update meeting page, page is not updated and we click on create meetings button', () => {

    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRK' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
   //   personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
    //  ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
   //   personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
    //  ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const resetAdditionalNoteForm = fb.group({
      additionalNotes: ['']
    });
    component.meetingTime = '0230';
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.actualMeetingForm = meetingFormValue;
    const commonService = fixture.debugElement.injector.get(CommonService);
    const router = fixture.debugElement.injector.get(Router);
    const spy = spyOn(commonService, 'checkFormUpdateSubject').and.returnValue(of(true));
    component.formParam = 'update';
    component.checkFormUpdate(true, '/meeting/create');
    fixture.detectChanges();
    router.navigate(["/meeting/create"]).then(() => {
      expect(location.path()).toEqual('/meeting/create');
      expect(component.meetingForm.get('meetingForm').get('invitee-details').value).toEqual(resetInviteeDtlsForms['value']);
      expect(component.meetingForm.get('meetingForm').get('third-party-attendee').value).toEqual(resetThirdPartyAttendeeForms['value']);
      expect(component.meetingForm.get('meetingForm').get('organizer-details').value).toEqual(resetOrganizerDtlsForm['value']);
      expect(component.meetingForm.get('meetingForm').get('meeting-details').value).toEqual(resetMeetingDtlsForm['value']);
      expect(component.meetingForm.get('meetingForm').get('event-details').value).toEqual(resetEventForm['value']);
      expect(component.meetingForm.get('meetingForm').get('additional-notes').get('additionalNotes').value).toEqual('');
      expect(component.meetingState).toEqual('NEW');
      expect(component.confirmButtonLabel).toEqual('Confirm');
    });
  });

  it('should set Meeting details into meetung object from service response', () => {
    component.setMeetingDetails(response);
    fixture.detectChanges();
    delete meetingFormValue['securityDetail']['securityName'];
    delete meetingFormValue.thirdPartyAttendee[0]['externalContactName'];
    expect(component.actualMeetingForm).toEqual(meetingFormValue);
  });

  it('should hide modal dialog box on confirmation and navigate to view meetings page when a meeting data is changed', () => {
    component.isModalShown = true;
    component.routeCase = 'meetingRouteToView';
    fixture.detectChanges();
    component.confirm();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
      expect(component.isModalShown).toEqual(false);
    });
  });

  it('should hide modal dialog box on confirmation and navigate to create meetings page when a meeting data is changed', () => {
    const eventForm = fb.group({
      date: ['12-5-2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['0130'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const resetEventForm = fb.group({
      date: [''],
      time: [new Date(0, 0, 0, 0)],
      duration: [''],
      timezone: [''],
      cityCountry: [{
        Cities: '', Country: '', GRD_COUNTRY_CD: '',
        ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
      }],
      cityCountryName: '',
      location: ['In-house'],
      room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
      address: [''],
      dailin: [false],
      dailpicker: [''],
      accesscode: [''],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });

    const meetingDtlsForm = fb.group({
      securityName: ['ZARA'],
      securityTradableEntityId: ['123456'],
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      hostName: ['Kanika'],
      mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
      meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
      meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
      brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
      subjectLine: ['New Meeting'],
      personName: ['Jyotsana'],
      meetingExecutive: [true],
      hostCorpId: ['A589589'],
      ownerCorpId: ['A252525']
    });

    const resetMeetingDtlsForm = fb.group({
      securityName: [''],
      securityTradableEntityId: [''],
      securityBBTicker: [''],
      securityTicker: [''],
      securityTseCode: [''],
      hostName: [''],
      mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
      meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
      meetingInitiator: [{
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }],
      brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
      subjectLine: [''],
      personName: [''],
      meetingExecutive: [''],
      hostCorpId: [''],
      ownerCorpId: ['']
    });

    const organizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: ['1234'],
      organizerName: ['Sharma, Kanika'],
      organizerEmail: ['abc@gmail.com'],
      organizerCompany: ['Zara'],
      organizerPhone: ['1234'],
      organizerPosition: ['CEO']
    });

    const resetOrganizerDtlsForm = fb.group({
      organizedThrough: ['Company'],
      organizerContactId: [''],
      organizerName: [''],
      organizerEmail: [''],
      organizerCompany: [''],
      organizerPhone: [''],
      organizerPosition: ['']
    });
    const thirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [thirdPartyAttendee]
    });

    const resetThirdPartyAttendeeForms = fb.group({
      thirdPartyAttendeeGrid: [null]
    });

    const inviteeDtlsForms = fb.group({
      inviteeGrid: [rowData]
    });

    const resetInviteeDtlsForms = fb.group({
      inviteeGrid: [null]
    });

    const additionalNoteForm = fb.group({
      additionalNotes: ['abc']
    });

    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    meetingForm.setControl('meeting-details', meetingDtlsForm);
    meetingForm.setControl('organizer-details', organizerDtlsForm);
    meetingForm.setControl('invitee-details', inviteeDtlsForms);
    meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
    meetingForm.setControl('additional-notes', additionalNoteForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.isModalShown = true;
    component.routeCase = 'meetingRouteToCreate';
    fixture.detectChanges();
    component.confirm();
    router.navigate(["/meeting/create"]).then(() => {
      expect(location.path()).toEqual('/meeting/create');
      expect(component.isModalShown).toEqual(false);
    });
  });

  it('should hide modal dialog box on decline when a meeting data is changed', () => {
    component.isModalShown = true;
    fixture.detectChanges();
    component.decline();
    expect(component.isModalShown).toEqual(false);

  });

  it('should hide modal dialog box on pressing cross label when a meeting data is changed', () => {
    component.isModalShown = true;
    fixture.detectChanges();
    component.onHidden('create/draft/draftInvite');
    expect(component.isModalShown).toEqual(false);

  });


  it('should route on backdrop click only if meeting confirmation is successful', () => {
    component.draftConfirmMessage = 'Meeting Confirmed successfully.';
    component.checkForBackDropClick('backdrop-click');
    fixture.detectChanges();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
    });

  });

  it('should route on backdrop click only if meeting draft save is successful', () => {
    component.draftConfirmMessage = 'Meeting saved as Draft successfully.';
    component.checkForBackDropClick('backdrop-click');
    fixture.detectChanges();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
    });

  });

  it('should route on backdrop click only if meeting update is successful', () => {
    component.draftConfirmMessage = 'Meeting Updated successfully.';
    component.checkForBackDropClick('backdrop-click');
    fixture.detectChanges();
    router.navigate(["/meetings"]).then(() => {
      expect(location.path()).toEqual('/meetings');
    });

  });

  it('should display draft option under save if meeting state is new', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatus();
    expect(component.checkMeetingStatus()).toEqual(false);
  });

  it('should display draft option under save if meeting state is draft', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['DRAFT']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatus();
    expect(component.checkMeetingStatus()).toEqual(false);
  });


  it('should hide draft option under save only if meeting state is draft and invite', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['DRAFTINVITE']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatus();
    expect(component.checkMeetingStatus()).toEqual(true);
  });

  it('should hide draft option under save only if meeting state is confirmed', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['CONFIRMED']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatus();
    expect(component.checkMeetingStatus()).toEqual(true);
  });


  it('should enable save button if meeting state is new', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['NEW']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatusForSaveEnable();
    expect(component.checkMeetingStatusForSaveEnable()).toEqual(false);
  });

  it('should enable save button if meeting state is draft', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['DRAFT']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatusForSaveEnable();
    expect(component.checkMeetingStatusForSaveEnable()).toEqual(false);
  });

  it('should enable save button if meeting state is draft and invite', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['DRAFTINVITE']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatusForSaveEnable();
    expect(component.checkMeetingStatusForSaveEnable()).toEqual(false);
  });

  it('should hide save button if meeting state is confirmed', () => {
    const eventForm = fb.group({
      date: ['12/05/2019'],
      time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
      duration: ['60'],
      timezone: ['Australia/Sydney GMT+11'],
      cityCountry: [{
        Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
        ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
      }],
      cityCountryName: 'Sydney, Australia',
      location: ['External'],
      room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
      address: ['123/GF'],
      dailin: [true],
      dailpicker: ['123456'],
      accesscode: ['123456789'],
      meetingId: [''],
      meetingStatus: [''],
      meetingState: ['CONFIRMED']
    });
    const meetingForm: FormGroup = fb.group({});
    meetingForm.setControl('event-details', eventForm);
    component.meetingForm.setControl('meetingForm', meetingForm);
    component.checkMeetingStatusForSaveEnable();
    expect(component.checkMeetingStatusForSaveEnable()).toEqual(true);
  });

  it(`should not open a dialog box if we are on update meeting page, page is updated with some data and without saving the
data we click on create meeting button if user doesnot have update meeting right`, () => {

      const eventForm = fb.group({
        date: ['12-5-2019'],
        time: [new Date('Sun Dec 31 1899 02:30:00 GMT+0521 (India Standard Time)')],
        duration: ['0130'],
        timezone: ['Australia/Sydney GMT+11'],
        cityCountry: [{
          Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL',
          ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney', UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
        }],
        cityCountryName: 'Sydney, Australia',
        location: ['External'],
        room: [{ KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' }],
        address: ['123/GF'],
        dailin: [true],
        dailpicker: ['123456'],
        accesscode: ['123456789'],
        meetingId: [''],
        meetingStatus: [''],
        meetingState: ['NEW']
      });

      const resetEventForm = fb.group({
        date: [''],
        time: [new Date(0, 0, 0, 0)],
        duration: [''],
        timezone: [''],
        cityCountry: [{
          Cities: '', Country: '', GRD_COUNTRY_CD: '',
          ISO_COUNTRY_CD: '', KeyCode: '', UtilKeyName: '', cityCountryVal: ''
        }],
        cityCountryName: '',
        location: ['In-house'],
        room: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', Country: '', KeyCode: '', Region: '' }],
        address: [''],
        dailin: [false],
        dailpicker: [''],
        accesscode: [''],
        meetingId: [''],
        meetingStatus: [''],
        meetingState: ['NEW']
      });

      const meetingDtlsForm = fb.group({
        securityName: ['ZARA'],
        securityTradableEntityId: ['123456'],
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: '',
        hostName: ['Kanika'],
        mtgSubtype: [{ KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' }],
        meetingBusUnit: [{ UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }],
        meetingInitiator: [{ MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' }],
        brokerUsage: [{ UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' }],
        subjectLine: ['New Meeting'],
      //  personName: ['Jyotsana'],
        meetingExecutive: [true],
        hostCorpId: ['A589589'],
      //  ownerCorpId: ['A252525']
      });

      const resetMeetingDtlsForm = fb.group({
        securityName: [''],
        securityTradableEntityId: [''],
        securityBBTicker: [''],
        securityTicker: [''],
        securityTseCode: [''],
        hostName: [''],
        mtgSubtype: [{ KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '' }],
        meetingBusUnit: [{ UtilKeyName: '', KeyCode: '', ActiveInd: '' }],
        meetingInitiator: [{
          'ActiveInd': 'Y',
          'MeetingTypeCode': 'BRK',
          'KeyCode': 'COMP',
          'KeyDesc': 'Company',
          'UtilKeyName': 'meetingInitiatorType'
        }],
        brokerUsage: [{ UtilKeyName: '', KeyDesc: '', KeyCode: '' }],
        subjectLine: [''],
     //   personName: [''],
        meetingExecutive: [''],
        hostCorpId: [''],
      //  ownerCorpId: ['']
      });

      const organizerDtlsForm = fb.group({
        organizedThrough: ['Company'],
        organizerContactId: ['1234'],
        organizerName: ['Sharma, Kanika'],
        organizerEmail: ['abc@gmail.com'],
        organizerCompany: ['Zara'],
        organizerPhone: ['1234'],
        organizerPosition: ['CEO']
      });

      const resetOrganizerDtlsForm = fb.group({
        organizedThrough: ['Company'],
        organizerContactId: [''],
        organizerName: [''],
        organizerEmail: [''],
        organizerCompany: [''],
        organizerPhone: [''],
        organizerPosition: ['']
      });
      const thirdPartyAttendeeForms = fb.group({
        thirdPartyAttendeeGrid: [thirdPartyAttendee]
      });

      const resetThirdPartyAttendeeForms = fb.group({
        thirdPartyAttendeeGrid: [null]
      });

      const inviteeDtlsForms = fb.group({
        inviteeGrid: [rowData]
      });

      const resetInviteeDtlsForms = fb.group({
        inviteeGrid: [null]
      });

      const additionalNoteForm = fb.group({
        additionalNotes: ['abc']
      });

      const meetingForm: FormGroup = fb.group({});
      meetingForm.setControl('event-details', eventForm);
      meetingForm.setControl('meeting-details', meetingDtlsForm);
      meetingForm.setControl('organizer-details', organizerDtlsForm);
      meetingForm.setControl('invitee-details', inviteeDtlsForms);
      meetingForm.setControl('third-party-attendee', thirdPartyAttendeeForms);
      meetingForm.setControl('additional-notes', additionalNoteForm);
      component.meetingForm.setControl('meetingForm', meetingForm);

      const commonService = fixture.debugElement.injector.get(CommonService);
      const errorService = fixture.debugElement.injector.get(ErrorService);
      errorService.isError = false;
      commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
      const spy = spyOn(commonService, 'resetFormSubject').and.returnValue(of(true));
      component.formParam = 'update';
      component.checkFormUpdate(true, '/meeting/create');
      fixture.detectChanges();
      router.navigate(["/meeting/create"]).then(() => {
        expect(location.path()).toEqual('/meeting/create');
        expect(component.meetingForm.get('meetingForm').get('invitee-details').value).toEqual(resetInviteeDtlsForms['value']);
        expect(component.meetingForm.get('meetingForm').get('third-party-attendee').value).toEqual(resetThirdPartyAttendeeForms['value']);
        expect(component.meetingForm.get('meetingForm').get('organizer-details').value).toEqual(resetOrganizerDtlsForm['value']);
        expect(component.meetingForm.get('meetingForm').get('meeting-details').value).toEqual(resetMeetingDtlsForm['value']);
        expect(component.meetingForm.get('meetingForm').get('event-details').value).toEqual(resetEventForm['value']);
        expect(component.meetingForm.get('meetingForm').get('additional-notes').get('additionalNotes').value).toEqual('');
        expect(component.meetingState).toEqual('NEW');
        expect(component.confirmButtonLabel).toEqual('Confirm');
      });
    });
  it('should hide submit button bar if error exists in error service due to unauthorized access', () => {
    const errorService = fixture.debugElement.injector.get(ErrorService);
    const commonService = fixture.debugElement.injector.get(CommonService);
    errorService.isError = true;
    component.formParam = 'create'
    commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
    expect(component.checkIfUserAuthorized()).toEqual(true);
  });


  it('should show submit button bar if user is on create page and have create meeting access', () => {
    const errorService = fixture.debugElement.injector.get(ErrorService);
    const commonService = fixture.debugElement.injector.get(CommonService);
    errorService.isError = false;
    component.formParam = 'create'
    commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
    expect(component.checkIfUserAuthorized()).toEqual(false);
  });

  it('should hide submit button bar if user is on create page and dont have create meeting access', () => {
    const errorService = fixture.debugElement.injector.get(ErrorService);
    const commonService = fixture.debugElement.injector.get(CommonService);
    errorService.isError = false;
    component.formParam = 'create'
    commonService.setLoggedInUserRoles(['mercury-update-company-meeting']);
    expect(component.checkIfUserAuthorized()).toEqual(true);
  });

  it('should show submit button bar if user is on update page and have update meeting access', () => {
    const errorService = fixture.debugElement.injector.get(ErrorService);
    const commonService = fixture.debugElement.injector.get(CommonService);
    errorService.isError = false;
    component.formParam = 'update'
    commonService.setLoggedInUserRoles(['mercury-update-company-meeting']);
    expect(component.checkIfUserAuthorized()).toEqual(false);
  });

  it('should hide submit button bar if user is on update page and dont have update meeting access', () => {
    const errorService = fixture.debugElement.injector.get(ErrorService);
    const commonService = fixture.debugElement.injector.get(CommonService);
    errorService.isError = false;
    component.formParam = 'update'
    commonService.setLoggedInUserRoles(['mercury-create-company-meeting']);
    expect(component.checkIfUserAuthorized()).toEqual(true);
  });

});