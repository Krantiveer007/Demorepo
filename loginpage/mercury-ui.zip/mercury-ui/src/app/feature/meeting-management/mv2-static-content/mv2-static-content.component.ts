import { Component, OnInit, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';

import { Security } from 'src/app/shared/models/security.model';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';

@Component({
  selector: 'mv2-static-content',
  templateUrl: './mv2-static-content.component.html',
  styleUrls: ['./mv2-static-content.component.css']
})
export class Mv2StaticContentComponent implements OnInit {

  value = '-';
  securityDetailsCardList: string[] = ['Security Name', 'Analyst', 'Sector', 'MCAP $M', 'Country', 'Size', 'Region'];
  mtgCreatorCardList: string[] = ['Name'];
  mtgUpdatorCardList: string[] = ['Name', 'Time', 'Date'];
  sector = '-';
  sectorSubscription: Subscription;
  @Input('selectedSecurity') selectedSecurity: string;
  securityType = '-';
  securities: Security = new Security('-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
    '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '');
  constructor(private commonService: CommonService) {
  }

  ngOnChanges(change: SimpleChanges) {
  }

  ngOnDestroy() {
    if (this.sectorSubscription) {
      this.sectorSubscription.unsubscribe();
    }
  }
  ngOnInit() {
    this.securities = this.commonService.getSecurityDetails();
    this.sectorSubscription = this.commonService.sectorOfSecurity.subscribe(
      (response) => {
        if (response) {
          this.sector = response
        } else {
          this.sector = '-';
        }
      },
      (error) => { console.log("static error", error) }
    );
  }
}
