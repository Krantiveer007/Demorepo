import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mv2StaticContentComponent } from './mv2-static-content.component';
import { CommonService } from 'src/app/core/http/common.service';
import { UrlHandlerService } from 'src/app/shared/services/url-handler.service';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TypeaheadModule } from 'ngx-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { AgGridModule } from 'ag-grid-angular';
import { RouterTestingModule } from '@angular/router/testing';
import { Mv2SearchPanelComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-panel/mv2-search-panel.component';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';

describe('Mv2StaticContentComponent', () => {
  let component: Mv2StaticContentComponent;
  let fixture: ComponentFixture<Mv2StaticContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({imports: [
      HttpClientModule,
      ReactiveFormsModule,
      BrowserModule,
      CommonModule,
      RouterTestingModule,
      TypeaheadModule.forRoot(),
      NgSelectModule,
      AgGridModule.withComponents([])
    ],
      declarations: [ Mv2StaticContentComponent,  Mv2SearchPanelComponent, Mv2MeetingListComponent, SideNavSearchFiltersComponent],
      providers: [ {provide: 'EnvName', useValue: 'DEV' }],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2StaticContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
