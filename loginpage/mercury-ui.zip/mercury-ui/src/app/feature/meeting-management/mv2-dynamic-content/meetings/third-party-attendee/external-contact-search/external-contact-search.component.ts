import { Component, OnInit,NgZone, OnDestroy, Output, EventEmitter, OnChanges, SimpleChanges, Input } from '@angular/core';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { Security } from 'src/app/shared/models/security.model';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterSecuritydata } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';
import { Observable, Observer, EMPTY } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import { SEARCHTYPE } from 'src/app/shared/app-constant/meeting.constants';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap';
import { ConfigEditComponent } from 'src/app/shared/components/config-edit/config-edit.component';
import Utils from '../../../../../../shared/utils/common.utility';
import { ConfigRadioComponent } from 'src/app/shared/components/config-radio/config-radio.component';

@Component({
  selector: 'mv2-external-contact-search',
  templateUrl: './external-contact-search.component.html',
  styleUrls: ['./external-contact-search.component.css']
})
export class ExternalContactSearchComponent implements OnInit {
securityLoading: boolean;
brokerFirmTypeaheadLoading; boolean
mtgTypeSearchPlaceholder = 'Search by Security name...';
brokerFirmResultId = '';
isValidSecurity = false;
isValidBrokerFirm = false;
securityDataSource: Observable<any>;
contactServiceSubscription: Subscription;
brokerFirmSubscription: Subscription;
brokerFirmDataSource: Observable<any>;
typeaheadLoading: boolean;
selectedParameter: string = '';
selectedSecurityDetail: any;
gridInfoObj: any;
errorResponse = false;
brokerFirmErrorResponse = false;
brokerFirmSelectedParameter: string;
searchType = ['Company', 'Broker', 'Other'];
disableCreateNewContactBtn = true;
searchText = '';
brokerFirmAsyncSelected = '';
actionForContact: string;
contactSearchForm = this.fb.group({    
    searchType: 'Company',
    securityName: '',
    securityTradableEntityId: '',
    securityBBTicker: '',
    securityTicker: '',
    securityTseCode: '',
    lastName: '',
    firstName: '',
    brokerFirm: '',
    brokerFirmId: '',
    otherCompany: '',
  });
  contactData: any;
  selectedCompanyForContactCreation = {};
  actionType = '';
typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
contactToBeUpdated: any;
@Output() emitContactList = new EventEmitter<any>();
@Input('selectedSecurity') selectedSecurity: string;
@Input('meetingType') meetingType: string;
@Input('disableSelectAll') disableSelectAll: boolean;


 modalRef: BsModalRef | null;
config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
  constructor(private fb: FormBuilder, private commonService: CommonService, private ngZone: NgZone, private modalService: BsModalService) { }

  ngOnInit() {
    this.gridInfoObj = {
      columnDefs: [
        {
          headerName: '',
          field: 'selection',
          cellRendererFramework: this.disableSelectAll ? ConfigRadioComponent :  ConfigRowSelectionComponent,
          width: 50,
          sortable: true,
          //hide: Utils.isVoid(this.disableSelectAll) ? false : this.disableSelectAll,
          
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Name',
          field: 'Name',
          width: 180,
          sortable: true,
          cellRenderer: this.tooltipRenderer,
        //  resizable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Company',
          field: 'Company',
          width: 160,
          sortable: true,
          cellRenderer: this.tooltipRenderer,
        //  resizable: true,
          cellStyle: { 'border-right': '1px solid #dadada', 'text-align': 'center' }
        },
        {
          headerName: 'Email',
          field: 'Email',
          width: 180,
          cellRenderer: this.tooltipRenderer,
        //  resizable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Position',
          field: 'Position',
          width: 150,
          cellRenderer: this.tooltipRenderer,
        //  resizable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Notes',
          field: 'Notes',
          width: 100,
          cellRenderer: this.tooltipRenderer,
        //  resizable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: ' ',
          field: 'Edit',
          width: 50,
          cellRendererFramework: ConfigEditComponent,
          cellStyle: { 'text-align': 'center', 'text-overflow': 'clip' }
        }],
      gridType: 'externalContactSearchGrid',
      rowData: []
      //rowSelection: this.disableSelectAll ? "single" : 'mulitpe'
    };
    
    if (this.meetingType === 'Broker') {
      this.searchType = ['Broker'];
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    let queryString = '';

    if (this.meetingType === 'Company' && this.selectedSecurity === 'Equity') {
    let searchedSecurity = this.commonService.getSecurityDetails();
   
    this.searchText = 'Security Name';
    this.contactSearchForm.patchValue({
      searchType: 'Company',
      securityName: searchedSecurity.instrumentLongName !== '-'? searchedSecurity.instrumentLongName: '',
      securityTradableEntityId: searchedSecurity.tradableEntId !== '-'? searchedSecurity.tradableEntId: '',
      securityBBTicker: searchedSecurity.bbCode !== '-'? searchedSecurity.bbCode: '',
      securityTicker: searchedSecurity.ticker !== '-'? searchedSecurity.ticker: '',
      securityTseCode: searchedSecurity.tseCode !== '-'? searchedSecurity.tseCode: '',
      brokerFirm: '',
      brokerFirmId: '',
      otherCompany: '',
    });
    this.selectedCompanyForContactCreation = searchedSecurity;
    if (this.contactSearchForm.get('securityTicker').value) {
      this.isValidSecurity = true;
     this.disableCreateNewContactBtn = false;
      queryString = 'contactType=CC&companyName=' + this.contactSearchForm.get('securityTicker').value;
    }
    } else if (this.meetingType === 'Company' && this.selectedSecurity === 'Fixed Income') {
    let searchedDebtTicker = this.commonService.getSelectedDebtTicker();
    this.searchText = 'Company Name';
    this.contactSearchForm.patchValue({
      searchType: 'Other',
      securityName: '',
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      brokerFirm: '',
      brokerFirmId: '',
      otherCompany: searchedDebtTicker? searchedDebtTicker: '',
    });
    this.selectedCompanyForContactCreation = searchedDebtTicker;
    if (this.contactSearchForm.get('otherCompany').value) {
      
      queryString = 'contactType=OC&companyName=' + this.contactSearchForm.get('otherCompany').value;
    }
    } else if (this.meetingType === 'Other') {    
    this.searchText = 'Company Name';
    this.contactSearchForm.patchValue({
      searchType: 'Other',
      securityName: '',
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      brokerFirm: '',
      brokerFirmId: '',
      otherCompany: ''
    });
    } else if (this.meetingType === 'Broker') {
    let searchBrokerFirm = this.commonService.getBrokerFirmDetails();
    console.log("searchBrokerFirm", searchBrokerFirm)
    this.searchText = 'Broker Firm';
    this.contactSearchForm.patchValue({
      searchType: 'Broker',
      securityName: '',
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      brokerFirm: searchBrokerFirm['brokerFirmName']? searchBrokerFirm['brokerFirmName']: '',
      brokerFirmId: searchBrokerFirm['brokerFirmId']? searchBrokerFirm['brokerFirmId']: '',
      otherCompany: '',
    });
    this.brokerFirmAsyncSelected = searchBrokerFirm['brokerFirmName']? searchBrokerFirm['brokerFirmName']: '';
    let bContact = {'firmName': searchBrokerFirm['brokerFirmName']? searchBrokerFirm['brokerFirmName']: '',
                    'firmId': searchBrokerFirm['brokerFirmId']? searchBrokerFirm['brokerFirmId']: '' }
    this.selectedCompanyForContactCreation = bContact;
    if (this.contactSearchForm.get('brokerFirmId').value) {
      this.isValidBrokerFirm = true;
      this.disableCreateNewContactBtn = false;
      queryString = 'contactType=BC&brokerFirmId=' + this.contactSearchForm.get('brokerFirmId').value;
    }
    } 

    
    if(queryString) {
      this.contactServiceSubscription = this.commonService.getExternalContactsForSearch(queryString)
        .subscribe((response) => {
          if (response['statusCode'] = 200 && response['body'].length > 0) {
            this.contactData = response['body'];
          } 
        },
        (error) => {
          console.log(error)
        });
    }
  }

  ngOnDestroy() {
    if(this.contactServiceSubscription) {
      this.contactServiceSubscription.unsubscribe();
    }
  }
  getSecurities(): void {
    let typeaheadData: TypeaheadData;
    this.isValidSecurity = false;
     this.disableCreateNewContactBtn = true;
    this.contactSearchForm.patchValue({
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: ''
    });
    const searchedValue = this.contactSearchForm.get('securityName').value;
    typeaheadData = this.typeaheadDataSource.getSecurities(searchedValue);
    this.securityDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
    if (searchedValue.length < 3 || this.securityDataSource === EMPTY || this.errorResponse) {
      this.selectedParameter = '';
    }
  }

 onSecurityBlur() {
      if (!this.isValidSecurity) {
        this.contactSearchForm.patchValue({
          securityName: '',
          securityTradableEntityId: '',
          securityBBTicker: '',
          securityTicker: '',
          securityTseCode: ''
        });
        this.selectedParameter = '';
        this.securityLoading = false;
        this.getSecurities();
        this.contactData = [];
        this.selectedCompanyForContactCreation = {};
      }     
  }


  typeaheadOnSelect(event: TypeaheadMatch, dropDownType: string): void {
    if( dropDownType === 'Security') {
      this.isValidSecurity = true;
      this.disableCreateNewContactBtn = false;
      const selectedSecurityInstance = event.item;
      this.selectedSecurityDetail = selectedSecurityInstance;
      this.selectedParameter = event.item.itemValue;
      this.selectedParameter = this.selectedParameter.split('&lt;').join('<').split('&gt;').join('>');
      this.contactSearchForm.patchValue({
        securityName: selectedSecurityInstance.instrumentLongName ? selectedSecurityInstance.instrumentLongName : '',
        securityTradableEntityId: selectedSecurityInstance.tradableEntId ? selectedSecurityInstance.tradableEntId : '',
        securityBBTicker: selectedSecurityInstance.bbCode ? selectedSecurityInstance.bbCode : '',
        securityTicker: selectedSecurityInstance.ticker ? selectedSecurityInstance.ticker : '',
        securityTseCode: selectedSecurityInstance['tseCode'] ? selectedSecurityInstance.tseCode : '',
      });
      
    } else if (dropDownType === 'BrokerFirm') {
      this.brokerFirmResultId = event.item.firmId;
      this.brokerFirmAsyncSelected = convertToTitleCase(event.item.firmName);
      this.contactSearchForm.patchValue({
        brokerFirm: this.brokerFirmAsyncSelected,
        brokerFirmId: this.brokerFirmResultId
      });
      this.isValidBrokerFirm = true;
       this.disableCreateNewContactBtn = false;
    }
    this.selectedCompanyForContactCreation = event.item;
  }
      
  changeTypeaheadLoading(e: boolean, dropDownType: string): void {  
      this.securityLoading = e;
  }
  
  typeaheadNoResults(event: boolean, dropDownType: string): void {  
    if( dropDownType === 'Security') {
      this.errorResponse = event;
    } else if (dropDownType === 'BrokerFirm') {     
      this.brokerFirmErrorResponse = event;  
    }
  }

  getBrokerFirm() {
    this.brokerFirmDataSource = EMPTY;
    this.brokerFirmAsyncSelected = this.contactSearchForm.get('brokerFirm').value;
    this.isValidBrokerFirm = false;
     this.disableCreateNewContactBtn = true;
    this.contactSearchForm.patchValue({
      brokerFirmId: ''
    });
    if (this.brokerFirmAsyncSelected.length >= 3) {
      this.brokerFirmDataSource = new Observable((observer) => {
        if (this.brokerFirmAsyncSelected.length >= 3) {
          this.brokerFirmSubscription = this.commonService.getBrokerFirm("brokerFirmName=" + this.brokerFirmAsyncSelected).subscribe((response) => {
            if (response) {
              this.brokerFirmErrorResponse = false;
              this.ngZone.run(() => observer.next(this.filterFirmdataResults(response)));
            } else {
              this.brokerFirmErrorResponse = true;
              this.brokerFirmSelectedParameter = '';
              observer.next([]);
              this.brokerFirmTypeaheadLoading = false;
              this.typeaheadNoResults(true, 'BrokerFirm');
            }
          },
            (error) => {
              if (this.brokerFirmAsyncSelected.length >= 3) {
                this.brokerFirmErrorResponse = true;
                this.brokerFirmSelectedParameter = '';
                observer.next([]);
                this.brokerFirmTypeaheadLoading = false;
                this.typeaheadNoResults(true, 'BrokerFirm');
              }
            });
        }
      });
    } else {
      this.brokerFirmResultId = '';
      if (this.brokerFirmDataSource !== EMPTY) {
        this.brokerFirmSubscription.unsubscribe();
      }
      this.brokerFirmSelectedParameter = '';
    }
  }

onBrokerFirmBlr() {
    if (!this.isValidBrokerFirm) {
      this.contactSearchForm.patchValue({
        brokerFirm: '',
        brokerFirmId: ''
      });
      this.brokerFirmErrorResponse = false;
      this.contactData = [];
      this.selectedCompanyForContactCreation = {};
      if (this.brokerFirmSubscription) {
        this.brokerFirmSubscription.unsubscribe();
      }
      this.brokerFirmDataSource = EMPTY;
      this.brokerFirmTypeaheadLoading = false;
    }
  }

  filterFirmdataResults(firmData) {
    firmData.forEach((item) => {
      item['firmName'] = convertToTitleCase(item['firmName']);
      item['firmNameAndId'] = item['firmName'] + ' &lt;' + item['firmId'] + '&gt;'
    });
    return firmData;
  }

   selectSearchType(event) {
    this.contactSearchForm.patchValue({
    securityName: '',
    securityTradableEntityId: '',
    securityBBTicker: '',
    securityTicker: '',
    securityTseCode: '',
    lastName: '',
    firstName: '',
    brokerFirm: '',
    brokerFirmId: '',
    otherCompany: '',
    });
    this.selectedParameter = '';
    this.contactData = [];
    if (event === 'Broker') {
      this.searchText = 'Broker Firm';
    } else if (event === 'Company') {
      this.searchText = 'Security Name';
    } else if (event === 'Other') {
      this.searchText = 'Company Name';
    }
    this.isValidBrokerFirm = false;
    this.isValidSecurity = false;
     this.disableCreateNewContactBtn = true;
  }

  disableSearchButton() {
    if ( (this.contactSearchForm.get('searchType').value === 'Broker' && this.isValidBrokerFirm === true)
     || (this.contactSearchForm.get('searchType').value === 'Company' && this.isValidSecurity === true)
     || (this.contactSearchForm.get('searchType').value === 'Other' && this.contactSearchForm.get('otherCompany').value.length >= 3)) {
     //  this.disableCreateNewContactBtn = false;
       return false;
     } else {
     //  this.disableCreateNewContactBtn = true;
       return true;
     }
  }

searchContacts() {
  let queryString = '';
  if (this.contactSearchForm.get('searchType').value === 'Company') {
    queryString = 'contactType=CC&companyName=' + this.contactSearchForm.get('securityTicker').value;
  } else if (this.contactSearchForm.get('searchType').value === 'Broker') {
    queryString = 'contactType=BC&brokerFirmId=' + this.contactSearchForm.get('brokerFirmId').value;
  } else if (this.contactSearchForm.get('searchType').value === 'Other') {
    queryString = 'contactType=OC&companyName=' + this.contactSearchForm.get('otherCompany').value;
  }

  this.contactServiceSubscription = this.commonService.getExternalContactsForSearch(queryString)
        .subscribe((response) => {
          if (response['statusCode'] = 200 && response['body'] && response['body'].length > 0) {
            this.contactData = response['body'];
          }  else {
            this.contactData = [];
          }
        },
        (error) => {
          this.contactData = [];
          console.log(error)
        });
}

getSelectedExternalContacts(event) {
  this.emitContactList.emit(event);
}

private tooltipRenderer(params) {
    if (params.value === null) {
      return undefined;
    } else {
      return '<span title="' + params.value + '">' + params.value + '</span>';
    }
  }

onSubmit(event, template: any) {
  if(event) {
    this.modalRef = this.modalService.show(template, this.config);
    this.actionForContact = 'add';
    this.actionType = 'Add '
  }
}

checkForContactAddUpdate() {
  this.commonService.checkContactFormChanges.next(true);
}

onOtherCompanySelect() {
  this.selectedCompanyForContactCreation = this.contactSearchForm.get('otherCompany').value;
  if (this.selectedCompanyForContactCreation['length'] > 2) {
  this.disableCreateNewContactBtn = false;
  } else {
    this.disableCreateNewContactBtn = true;
  }
}

hideModal(event) {
  if(event) {
    this.modalRef.hide();
  }
}

refreshHideModal(event) {
  if(event) {
    this.searchContacts();
    this.modalRef.hide();
  }
}

editContact(event, template) {
  if(event) {
    this.contactToBeUpdated = event;
    this.modalRef = this.modalService.show(template, this.config);
    this.actionForContact = 'update';
    this.actionType = 'Update '
  }
}
}
