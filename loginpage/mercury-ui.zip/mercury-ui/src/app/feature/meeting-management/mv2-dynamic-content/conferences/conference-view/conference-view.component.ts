import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { ConferenceMeeting } from 'src/app/shared/models/conferenceMeeting.model';
import { EventOwner } from 'src/app/shared/models/eventOwner.model';
import { EventCreator } from 'src/app/shared/models/eventCreator.model';
import { Country } from 'src/app/shared/models/country.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { EventLastUpdateDetails } from 'src/app/shared/models/eventLastUpdateDetails.model';
import { EventInitiator } from 'src/app/shared/models/eventInitiator.model';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
@Component({
  selector: 'mv2-conference-view',
  templateUrl: './conference-view.component.html',
  styleUrls: ['./conference-view.component.css']
})
export class ConferenceViewComponent implements OnInit {

  conferenceMeeting = new ConferenceMeeting('', '', '', '', '', new EventOwner('', ''), '', new EventLastUpdateDetails('', '', '', ''),
    new EventCreator('', '', ''), '', new Country('', ''), '', new BrokerDetail('', ''), new EventInitiator('', ''), '', '', '', '', new ArrangementContact('', '', '', '', '', '', '', ''), '', '');

  constructor(public commonService: CommonService) { }

  ngOnInit() {
    this.conferenceMeeting = this.commonService.getConferenceMeetingDtls();
  }
}
