import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalContactSearchComponent } from './external-contact-search.component';

describe('ExternalContactSearchComponent', () => {
  let component: ExternalContactSearchComponent;
  let fixture: ComponentFixture<ExternalContactSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalContactSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalContactSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
