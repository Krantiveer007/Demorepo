import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrangementContactDetailsComponent } from './arrangement-contact-details.component';

describe('ArrangementContactDetailsComponent', () => {
  let component: ArrangementContactDetailsComponent;
  let fixture: ComponentFixture<ArrangementContactDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArrangementContactDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrangementContactDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
