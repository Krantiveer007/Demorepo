import { Component, OnInit, NgZone, OnDestroy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable, EMPTY, Subscription } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterExternalContactResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadData, TypeaheadDataSource } from 'src/app/shared/utils/typeahead.utility';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
@Component({
  selector: 'mv2-organizer-details',
  templateUrl: './organizer-details.component.html',
  styleUrls: ['./organizer-details.component.css']
})
export class OrganizerDetailsComponent implements OnInit {

  organizerDataSource: Observable<any>;
  organizerDataSubscription: Subscription;
  typeaheadLoading: boolean;
  companyLabel = 'Company Name';
  errorResponse = false;
  organizerDtlsForm = this.fb.group({
    organizedThrough: ['Company'],
    organizerContactId: [''],
    organizerName: [''],
    organizerEmail: ['', [Validators.email, Validators.maxLength(250)]],
    organizerCompany: [''],
    organizerPhone: ['', Validators.maxLength(25)],
    organizerPosition: [''],
    brokerUsage: [{ 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' }],
  }, { validators: MeetingFieldValidations.CheckEmptyEmailAndPhone });
  // Validators.pattern("^[0-9]*$")
  invalidEmail = false;
  invalidPhNo = false;
  invalidLengthorganizerPhone = false;
  invalidLengthorganizerEmail = false;
  isValidOrganizer = false;
  organizerContacts: any = [];
  contactTypes = ['Broker', 'Company', 'Others'];
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  arrangementContactDetails = new ArrangementContact('', '', '', '', '', '', '', '');
  brkUsageInitiator: any[];
  utilDataObservable: Observable<any>;
  utilDataSubs: Subscription;
  utilData = [];
  updateMtgSubs: Subscription;

  @Output() formReady = new EventEmitter<FormGroup>();

  constructor(private fb: FormBuilder, private commonService: CommonService, private ngZone: NgZone, private route: ActivatedRoute) { }

  ngOnInit() {
    this.formReady.emit(this.organizerDtlsForm);

    this.organizerDtlsForm.get('brokerUsage').disable();

    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.isValidOrganizer = true;
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response && response.arrangementContact) {
            this.organizerDtlsForm.patchValue({
              organizedThrough: response.arrangementContact.organizedThrough ? (response.arrangementContact.organizedThrough.includes('Other') ? 'Others' : response.arrangementContact.organizedThrough) : 'Company',
              organizerContactId: response.arrangementContact.organizerContactId ? response.arrangementContact.organizerContactId : '',
              organizerName: response.arrangementContact.organizerName ? response.arrangementContact.organizerName : '',
              organizerEmail: response.arrangementContact.organizerEmail ? response.arrangementContact.organizerEmail : '',
              organizerCompany: response.arrangementContact.organizerCompany ? response.arrangementContact.organizerCompany : '',
              organizerPhone: response.arrangementContact.organizerPhone ? response.arrangementContact.organizerPhone : '',
              organizerPosition: response.arrangementContact.organizerPosition ? response.arrangementContact.organizerPosition : '',
              brokerUsage: { 'UtilKeyName': '', 'KeyDesc': response.arrangementContact.brokerUsageInitiator ? response.arrangementContact.brokerUsageInitiator : '', 'KeyCode': '' },
            });
            this.checkEmail();
            if (this.organizerDtlsForm.get('organizedThrough').value === 'Broker') {
              this.organizerDtlsForm.get('brokerUsage').enable();

              this.organizerDtlsForm.patchValue({
                brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': response.arrangementContact.brokerUsageInitiator ? response.arrangementContact.brokerUsageInitiator : '', 'KeyCode': '' },
              });

            } else {
              this.organizerDtlsForm.patchValue({
                brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' },
              });
              this.organizerDtlsForm.get('brokerUsage').disable();

            }
          }
        });
      }
    });

    this.fetchUtilData();
  }

  ngOnDestroy() {
    this.utilDataSubs.unsubscribe();
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
  }

  resetOrganizerDtls() {
    this.organizerDtlsForm.patchValue({
      'organizerName': '',
      'organizerEmail': '',
      'organizerCompany': '',
      'organizerPhone': '',
      'organizerPosition': '',
      'organizerContactId': '',
      'brokerUsage': { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' }
    });
    this.typeaheadNoResults(true);
    this.typeaheadLoading = false;
    this.errorResponse = false;
    this.invalidLengthorganizerPhone = false;
    this.invalidEmail = false;
    this.invalidLengthorganizerEmail = false;
    this.companyLabel = (this.organizerDtlsForm.get('organizedThrough').value === 'Broker') ? 'Broker Firm' : 'Company Name';
    if (this.organizerDtlsForm.get('organizedThrough').value === 'Broker') {
      this.organizerDtlsForm.get('brokerUsage').enable();
      if (this.commonService.getMeetingType() === 'Company') {
        this.organizerDtlsForm.patchValue({
          brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': 'Company', 'KeyCode': '' },
        });
      } else {
        this.organizerDtlsForm.patchValue({
          brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' },
        });
      }
    } else {
      this.organizerDtlsForm.patchValue({
        brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' },
      });
      this.organizerDtlsForm.get('brokerUsage').disable();

    }
  }

  onBlurMethod() {
    if (!this.isValidOrganizer) {
      this.organizerDtlsForm.patchValue({
        organizerName: '',
        organizerContactId: ''
      });
      this.typeaheadLoading = false;
      this.getOrganizerData();
    }
  }

  getOrganizerData(): void {
    this.invalidEmail = false;
    let typeaheadData: TypeaheadData;
    const searchedValue = this.organizerDtlsForm.get('organizerName').value;
    this.organizerDtlsForm.patchValue({
      'organizerContactId': ''
    });
    if (this.organizerDtlsForm.get('organizedThrough').value === 'Company') {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue.toUpperCase(),
        '',
        'Company',
        '');
    } else {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue.toUpperCase(),
        '',
        this.organizerDtlsForm.get('organizedThrough').value,
        '');
    }
    this.organizerDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
    if (searchedValue.length === 0) {
      this.resetOrganizerDtls();
    }
  }

  changeTypeaheadLoading(e: boolean): void {
    this.typeaheadLoading = e;
  }

  typeaheadOnSelect(event) {
    let oraganizerDetailsInstance = event;

    const organizedThrough = this.organizerDtlsForm.get('organizedThrough').value;
    let organizedCompanyName = '';
    let trdEndId = '';
    this.isValidOrganizer = true;
    if (organizedThrough === 'Company') {
      // trdEndId = oraganizerDetailsInstance.item.TradableEntityId ? oraganizerDetailsInstance.item.TradableEntityId : '';
      this.organizerDtlsForm.patchValue({
        'organizerName': oraganizerDetailsInstance.item.fullname ? convertToTitleCase(oraganizerDetailsInstance.item.fullname) : '',
        'organizerContactId': oraganizerDetailsInstance.item.externalId ? oraganizerDetailsInstance.item.externalId : '',
        'organizerEmail': oraganizerDetailsInstance.item.emailId ? oraganizerDetailsInstance.item.emailId : '',
        'organizerCompany': oraganizerDetailsInstance.item.company ? convertToTitleCase(oraganizerDetailsInstance.item.company) : '',
        'organizerPhone': oraganizerDetailsInstance.item.telephoneNo ? oraganizerDetailsInstance.item.telephoneNo : '',
        'organizerPosition': oraganizerDetailsInstance.item.position ? oraganizerDetailsInstance.item.position : ''
      });
    } else {
      organizedCompanyName = (organizedThrough === 'Broker')
        ? oraganizerDetailsInstance.item.firmName
        : oraganizerDetailsInstance.item.company;
      this.organizerDtlsForm.patchValue({
        'organizerName': oraganizerDetailsInstance.item.fullname ? convertToTitleCase(oraganizerDetailsInstance.item.fullname) : '',
        'organizerContactId': oraganizerDetailsInstance.item.externalId ? oraganizerDetailsInstance.item.externalId : '',
        'organizerEmail': oraganizerDetailsInstance.item.emailId ? oraganizerDetailsInstance.item.emailId : '',
        'organizerCompany': organizedCompanyName ? convertToTitleCase(organizedCompanyName) : '',
        'organizerPhone': oraganizerDetailsInstance.item.telephoneNo ? oraganizerDetailsInstance.item.telephoneNo : '',
        'organizerPosition': oraganizerDetailsInstance.item.position ? convertToTitleCase(oraganizerDetailsInstance.item.position) : ''
      });
    }
    this.arrangementContactDetails.organizedThrough = this.organizerDtlsForm.get('organizedThrough').value ? this.organizerDtlsForm.get('organizedThrough').value : '';
    this.arrangementContactDetails.organizerContactId = this.organizerDtlsForm.get('organizerContactId').value ? this.organizerDtlsForm.get('organizerContactId').value : '';
    this.arrangementContactDetails.organizerName = this.organizerDtlsForm.get('organizerName').value ? this.organizerDtlsForm.get('organizerName').value : '';
    this.arrangementContactDetails.organizerCompany = this.organizerDtlsForm.get('organizerCompany').value ? this.organizerDtlsForm.get('organizerCompany').value : '';
    this.arrangementContactDetails.organizerPhone = this.organizerDtlsForm.get('organizerPhone').value ? this.organizerDtlsForm.get('organizerPhone').value : '';
    this.arrangementContactDetails.organizerEmail = this.organizerDtlsForm.get('organizerEmail').value ? this.organizerDtlsForm.get('organizerEmail').value : '';
    this.arrangementContactDetails.organizerPosition = this.organizerDtlsForm.get('organizerPosition').value ? this.organizerDtlsForm.get('organizerPosition').value : '';
    this.commonService.setArrangementContactDetails(this.arrangementContactDetails);
    this.checkEmail();
  }

  typeaheadNoResults(event: boolean): void {
    this.errorResponse = event;
  }


  checkEmail() {
    if (this.organizerDtlsForm.get('organizerEmail') && this.organizerDtlsForm.get('organizerEmail').errors && this.organizerDtlsForm.get('organizerEmail').errors !== null && this.organizerDtlsForm.get('organizerEmail').errors.email) {
      this.invalidEmail = true;
    } else {
      this.invalidEmail = false;
    }
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataSubs = this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.brkUsageInitiator = this.utilData.filter(element => element.UtilKeyName === 'brokerUsageInitiator');
        this.brkUsageInitiator.splice(0, 0, { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' });
      }
    },
      (error) => {
        console.log(error);
      });
  }

  checkBUIMandatory() {
    if (this.commonService.getMeetingType() === 'Company' && this.organizerDtlsForm.get('organizedThrough').value === 'Broker') {
      return false;
    } else {
      return true;
    }
  }

  validateTextLength(fieldName: string) {
    if (this.organizerDtlsForm.get(fieldName) && this.organizerDtlsForm.get(fieldName).errors !== null && this.organizerDtlsForm.get(fieldName).errors.maxlength) {
      let invalidFieldName = 'invalidLength' + fieldName;
      this[invalidFieldName] = true;
    } else {
      let invalidFieldName = 'invalidLength' + fieldName;
      this[invalidFieldName] = false;
    }
  }

validateEmptyEmailAndPhone() {
  if (this.organizerDtlsForm.errors && this.organizerDtlsForm.errors.eitherEmailOrPhoneReqd) {
    return true;
  } else { return false; }
}
}
