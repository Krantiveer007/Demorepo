import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mv2-trip-details',
  templateUrl: './trip-details.component.html',
  styleUrls: ['./trip-details.component.css']
})
export class TripDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
