import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-conferences',
  templateUrl: './conferences.component.html',
  styleUrls: ['./conferences.component.css']
})
export class ConferencesComponent implements OnInit, OnDestroy {
  meetingType = '';
  arrangmentContactConfig : any = {'showMeetingTypeSelection' : false, 'heading' : 'Who is the Organizer?', 
  'defaultMeetingType': 'Broker', 'contactSearch' : true, 'contactSearchType' : 'Broker', 'disableSelectAll' : true,
    'visiableField':{
      'name':  true,
      'companyName' : true,
      'position': true,
      'email': true,
      'phoneNo' : true,
      'brokerUsageInitiator' : true
    } };
  conferenceForm: FormGroup;
  @Output() formReady = new EventEmitter<FormGroup>();
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private commonService: CommonService) { }
  ngOnInit() {
    this.conferenceForm = this.fb.group({});
    this.formReady.emit(this.conferenceForm);
    this.route.params.subscribe((params) => {
      this.meetingType = params['meetingType'];
    });
    this.meetingType = this.commonService.getMeetingType();
  }

  formInitialized(name, form) {
    this.conferenceForm.setControl(name, form);
  }
  ngOnDestroy(){
    this.commonService.setBrokerFirmDetails({
      brokerFirmName: '',
      brokerFirmId: '',
    });
  }
}