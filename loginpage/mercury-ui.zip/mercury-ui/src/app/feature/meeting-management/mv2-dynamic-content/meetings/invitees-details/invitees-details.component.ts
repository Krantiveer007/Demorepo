import { Component, Output, EventEmitter, OnInit, ChangeDetectorRef, OnDestroy, OnChanges } from '@angular/core';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigResposneComponent } from 'src/app/shared/components/config-resposne/config-resposne.component';
// import { GridOptions } from 'ag-grid-enterprise';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ActivatedRoute, Params } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Subscription } from 'rxjs';
import { INVITEERESPONSE } from 'src/app/shared/app-constant/meeting.constants';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { TemplateRef } from '@angular/core';
import * as moment from 'moment';
import { Router, NavigationEnd } from '@angular/router';
import { Input } from '@angular/core';

@Component({
  selector: 'mv2-invitees-details',
  templateUrl: './invitees-details.component.html',
  styleUrls: ['./invitees-details.component.css']
})
export class InviteesDetailsComponent implements OnInit, OnDestroy {
  gridInfoObj: any;
  // rowDataExpandedView = [];
  // columnDefsExpandedView = [];
  // attainedMaxExpandedHeight = false;
  // gridOptionsExpandedView: GridOptions;
  // gridApiExpandedView: any;
  inviteesResposne = INVITEERESPONSE;
  meetingType = '';
  action = '';
  tradableEntityIdSubscription: Subscription;
  debtTickerSubscription: Subscription;
  // holdersDtlsSourceSubscription: Subscription;
  dLEmployeeSourceSubscription: Subscription;
  resetMeetingDetails: Subscription;
  inviteeDtlsForms = this.fb.group({
    inviteeGrid: [null]
  });
  currentUrl = '';
  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  isSecurityAvailable = false;
  pastMeeting = false;
  updateMtgSubs: Subscription;
  plusIconImage = {
    'enabled': '/assets/images/group-1424-copy.svg',
    'disabled': '/assets/images/group-1424-copy-5.svg'
  };
  plusImageSrc = this.plusIconImage.disabled;
  // expandIconImage = {
  //   'enabled': '/assets/images/group-1457.svg',
  //   'disabled': '/assets/images/group-1457-disable.svg'
  // }
  // expandImageSrc = this.expandIconImage.disabled;
  // holdersList = [];
  dLEmployeeList = [];
  isSubmitHolderEnabled = false;
  isSubmitDLsEnabled = false;
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
  configSecond = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'second'
  };
  messageHeading = 'Confirm Navigation';
  routeConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
  @Output() formReady = new EventEmitter<FormGroup>();
  @Input('selectedSecurity') selectedSecurity: string;
  constructor(private fb: FormBuilder,
    private commonService: CommonService,
    private route: ActivatedRoute,
    private modalService: BsModalService,
    private cdr: ChangeDetectorRef,
    private router: Router) {
  }

  ngOnChanges() {
    // if (this.selectedSecurity === 'Fixed Income') {
    //   this.isSecurityAvailable = true;
    // }
  }
  ngOnInit() {
    this.gridInfoObj = {
      rowData: [
        {
          'Attendee': '',
          'AttendeeId': '',
          'Response': '',
          'Call-In': false,
          'Invite': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        }
      ],
      columnDefs: [
        {
          headerName: 'FIL Invitees',
          field: 'Attendee',
          width: 338,
          cellEditorFramework: ConfigInviteesDtlsComponent,
          editable: true,
          suppressSizeToFit: true,
          singleClickEdit: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Call-In',
          field: 'Call-In',
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Invite',
          field: 'Invite',
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Infopacks',
          field: 'Infopacks',
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Info Only',
          field: 'Info Only',
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Action',
          field: 'Remove',
          cellRendererFramework: ConfigDeleteComponent,
          cellStyle: { 'text-align': 'center' }
        }],
      gridType: 'filAttendeeGrid'
    };
    for (var i = 0; i < 3; i++) {
      this.gridInfoObj.rowData.push({
        'Attendee': '',
        'AttendeeId': '',
        'Response': '',
        'Call-In': false,
        'Invite': false,
        'Infopacks': false,
        'Info Only': false,
        'Remove': ''
      });
    };
    this.formReady.emit(this.inviteeDtlsForms);
    this.route.params.subscribe((params: Params) => {
      this.action = params['action'];
      if (this.action === 'update') {
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            const mtgDetailResponse = response;
            this.meetingType = response.meetingType;
            if (mtgDetailResponse.meetingState === 'CONFIRMED' || mtgDetailResponse.meetingState === 'DRAFTINVITE') {
              const item = {
                headerName: 'Response',
                field: 'Response',
                // width: 120,
                cellEditorFramework: ConfigResposneComponent,
                editable: true,
                singleClickEdit: true,
                sortable: true,
                cellStyle: { 'border-right': '1px solid #dadada' },
                cellClass: ['responseWidth']
              };
              this.gridInfoObj.columnDefs.splice(1, 0, item);
              this.cdr.detectChanges();
            }
          }
        });
      } else {
        this.meetingType = params['meetingType'];
        if (this.meetingType === 'Other' || this.meetingType === 'Broker') {
          this.isSecurityAvailable = true;
          this.plusImageSrc = this.plusIconImage.enabled;
        }
      }
    });

    if ((this.meetingType === 'Other' && this.action === 'create')
      || this.meetingType === 'Broker' && this.action === 'create') {
      this.isSecurityAvailable = true;
      this.plusImageSrc = this.plusIconImage.enabled;
      this.gridInfoObj.columnDefs.splice(3, 1);
      this.gridInfoObj.rowData.forEach((rowNode) => {
        delete rowNode.Infopacks;
      });
      this.cdr.detectChanges();
    }
    this.tradableEntityIdSubscription = this.commonService.tradableEntityIdObservable.subscribe((response) => {
      if (response.length !== 0 && !this.pastMeeting) {
        this.isSecurityAvailable = true;
        this.plusImageSrc = this.plusIconImage.enabled;
        // this.cdr.detectChanges();
      }
    });

    this.debtTickerSubscription = this.commonService.selectedDebtTickerObservable.subscribe((response) => {
      if (response.length !== 0 && !this.pastMeeting) {
        this.isSecurityAvailable = true;
        this.plusImageSrc = this.plusIconImage.enabled;
        // this.cdr.detectChanges();
      }
    })
    // this.holdersDtlsSourceSubscription = this.commonService.holdersDtlsSourceObservable.subscribe((response) => {
    //   if (response) {
    //     if (response.length !== 0) {
    //       this.isSubmitHolderEnabled = true;
    //       // this.cdr.detectChanges();
    //     } else {
    //       this.isSubmitHolderEnabled = false;
    //       // this.cdr.detectChanges();
    //     }
    //   }
    // }); 

    this.dLEmployeeSourceSubscription = this.commonService.dLEmployeeSourceObservable.subscribe((response) => {
      if (response) {
        if (response.length !== 0) {
          this.isSubmitDLsEnabled = true;
          // this.cdr.detectChanges();
        } else {
          this.isSubmitDLsEnabled = false;
          // this.cdr.detectChanges();
        }
      }
    });
    // this.commonService.filAttendeeListSourceObservable.subscribe((response) => {
    //   if (response.length > 0) {
    //     this.expandImageSrc = this.expandIconImage.enabled;
    //     this.gridOptionsExpandedView = {
    //       rowBuffer: 200,
    //       headerHeight: 40,
    //       rowHeight: 32,
    //       suppressMovableColumns: true,
    //       suppressScrollOnNewData: true,
    //       suppressCellSelection: true,
    //       suppressRowClickSelection: true,
    //       localeText: { noRowsToShow: 'No records to show' }
    //     };
    //     if (this.meetingType === 'Company' && this.selectedSecurity === 'Equity') {
    //       this.columnDefsExpandedView = [];
    //       (this.gridInfoObj.columnDefs.filter((item) => item.headerName !== 'Action')).forEach((item, Index) => {
    //         const newItemArray = Object.assign({}, item);
    //         this.columnDefsExpandedView[Index] = newItemArray;
    //       });
    //     } else if (this.meetingType === 'Other' || this.meetingType === 'Broker' || this.selectedSecurity === 'Fixed Income') {
    //       this.columnDefsExpandedView = [];
    //       (this.gridInfoObj.columnDefs.filter((item) => item.headerName !== 'Action' && item.headerName !== 'Infopacks')).forEach((item, Index) => {
    //         const newItemArray = Object.assign({}, item);
    //         this.columnDefsExpandedView[Index] = newItemArray;
    //       });
    //     }
    //     this.rowDataExpandedView = response.filter((item) => item['Attendee'].length > 0);
    //     this.expandImageSrc = this.expandIconImage.enabled;
    //     this.columnDefsExpandedView.forEach((rowNode, Index) => {
    //       rowNode.cellStyle = { 'border-right': '1px solid #dadada', 'background': '#eeeff0' };
    //       rowNode.editable = false;
    //       if (rowNode.field !== 'Attendee') {
    //         rowNode.headerClass = 'mv2-headerCenterAlign';
    //       }
    //     });
    //     if (this.gridApiExpandedView && this.gridApiExpandedView.getDisplayedRowCount() > 16) {
    //       this.attainedMaxExpandedHeight = true;
    //       this.gridApiExpandedView.setDomLayout('normal');
    //     }
    //   } else {
    //     this.rowDataExpandedView = [];
    //   }
    // });
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.meetingType = response.meetingType;
            if ((this.meetingType === "Broker" && response.brokerDetail.brokerFirmName)
              || this.meetingType === "Other" && response.otherMeetingTopic) {
              this.plusImageSrc = this.plusIconImage.enabled;
              this.isSecurityAvailable = true;
            }
            this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
        }
        });
      }
    });

    this.resetMeetingDetails = this.commonService.resetMeetingDetailsSubject.subscribe(res => {
      if (res) {
        this.resetInviteeDetails();
      }
    });
  }

  ngOnDestroy() {
    if (this.meetingType === 'Company') {
      if (this.tradableEntityIdSubscription) {
        this.tradableEntityIdSubscription.unsubscribe();
      }
      if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
    }
    if (this.dLEmployeeSourceSubscription) {
      this.dLEmployeeSourceSubscription.unsubscribe();
    }
  }

  addHolders(template: TemplateRef<any>) {
    if (this.isSecurityAvailable) {
      this.modalRef = this.modalService.show(template, this.config);
    }
  }

  // onGridReady(params) {
  //   this.gridApiExpandedView = params.api;
  //   this.gridApiExpandedView.sizeColumnsToFit();
  //   if (this.gridApiExpandedView.getDisplayedRowCount() > 16) {
  //     this.attainedMaxExpandedHeight = true;
  //     this.gridApiExpandedView.setDomLayout('normal');
  //   } else {
  //     this.gridApiExpandedView.setDomLayout('autoHeight');
  //   }
  // }

  addDistributionList(template: TemplateRef<any>) {
    if (this.isSecurityAvailable) {
      this.modalRef = this.modalService.show(template, this.config);
    }
  }

  // expandAttendeeView(template: TemplateRef<any>) {
  //   if (this.expandImageSrc === this.expandIconImage.enabled) {
  //     this.modalRef = this.modalService.show(template);
  //   }
  // }

  // getSelectedHoldersList(event) {
  //   this.holdersList = event;
  //   if (this.holdersList.length !== 0) {
  //     this.routeConfirmMessage = 'Selected holders will not be added to the meeting. Are you sure you want to exit ?'
  //     this.isSubmitHolderEnabled = true;
  //   } else {
  //     this.isSubmitHolderEnabled = false;
  //   }
  // }

  getSelectedDlEmployeeList(event) {
    this.dLEmployeeList = event;
    if (this.dLEmployeeList.length !== 0) {
      this.routeConfirmMessage = 'Selected fidelity participants will not be added to the meeting. Are you sure you want to exit ?'
      this.isSubmitDLsEnabled = true;
    } else {
      this.isSubmitDLsEnabled = false;
    }
  }

  checkForNewAttendeeEntry(templateNested: TemplateRef<any>) {
    if (this.isSubmitHolderEnabled || this.isSubmitDLsEnabled) {
      this.modalRef2 = this.modalService.show(templateNested, this.configSecond);
    }
    else {
      this.modalRef.hide();
    }
  }

  confirm() {
    this.modalRef2.hide();
    this.modalRef.hide();
  }
  decline() {
    this.modalRef2.hide();
  }
  onSubmit() {
    // if (this.isSubmitHolderEnabled) {
    //   this.commonService.changeHoldersList(this.holdersList);
    // } 
    if (this.isSubmitDLsEnabled) {
      this.commonService.changeDlEmployeeList(this.dLEmployeeList);
    }
    this.modalRef.hide();
    if (this.modalRef2) {
      this.modalRef2.hide();
    }
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.pastMeeting = true;
      this.isSecurityAvailable = false;
      this.plusImageSrc = this.plusIconImage.disabled;
      // this.expandImageSrc = this.expandIconImage.disabled;
      this.cdr.detectChanges();
    }
  }

  resetInviteeDetails() {
    this.isSecurityAvailable = false;
    this.plusImageSrc = this.plusIconImage.disabled;
    // this.expandImageSrc = this.expandIconImage.disabled;
    if (this.pastMeeting) {
      this.pastMeeting = false;
    }
  }
}
