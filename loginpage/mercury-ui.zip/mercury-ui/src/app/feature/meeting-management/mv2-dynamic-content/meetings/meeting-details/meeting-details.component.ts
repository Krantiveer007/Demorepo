import { Component, OnInit, Output, Input, NgZone, OnChanges, SimpleChanges, SimpleChange, EventEmitter, OnDestroy } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable, Observer, EMPTY } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { Security } from 'src/app/shared/models/security.model';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { TitleCasePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Params } from '@angular/router';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterSecuritydata, filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationEnd } from '@angular/router';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';

@Component({
  selector: 'mv2-meeting-details',
  templateUrl: './meeting-details.component.html',
  styleUrls: ['./meeting-details.component.css']
})
export class MeetingDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
  peopleDataSource: Observable<any>;
  debtTickerDataSource: Observable<any>;
  brokerFirmDataSource: Observable<any>;
  updateMtgSubs: Subscription;
  meetingLocationChangeSubs: Subscription;
  meetingLocation = '';
  meetingType = '';
  hostName = '';
  personName: string;
  hostErrorResponse = false;
  isHostAlreadyAddedAsAttendee = false;
  debtTickerErrorResponse = false;
  brokerFirmErrorResponse = false;
  typeaheadLoading: boolean;
  debtTickerTypeaheadLoading: boolean;
  brokerFirmTypeaheadLoading: boolean;
  securityLoading: boolean;
  peopleData: any[] = [];
  meetingSubtypeDesc = '';
  meetingFormatDesc = '';
  searchTypeName = 'Security Name';
  securityType = ['Equity', 'Fixed Income'];
  selectedSearchType = 'Equity';
  mtgTypeSearchPlaceholder = 'Search by Security name...';
  brokerFirmSearchPlaceholder = 'Search by Firm name...';
  message = '';
  isValidHost = false;
  isValidSecurity = false;
  isValidDebtTicker = false;
  isValidBrokerFirm = false;
  executiveInvited = '';
  currentUrl = '';
  peopleDataSubscription: Subscription;
  resetMeetingDetails: Subscription;
  sectorDetailsSubs: Subscription;
  selectedSecurityDetail: any;
  securities: Security = new Security('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-');
  mtgSubTypeList: any[];
  businessUnit: any[];
  meetingFormat: any[];
  utilData: any[];
  mtgInitiator: any[];
  brkUsageInitiator: any[];
  utilDataObservable: Observable<any>;
  bbCodeDataObservable: Observable<any>;
  bbCodeSubs: Subscription;
  securityDescription = '';
  primaryAnalystCorpId = '';
  primaryAnalystName = '';
  previousHostDetail = {
    'hostName': '',
    'hostCorpId': '',
    'hostPhoneNumber': '',
    'primaryAnalystName': '',
    'primaryAnalystId': ''
  };
  @Output() formReady = new EventEmitter<FormGroup>();
  @Output() checkForConflicts = new EventEmitter<String>();
  @Input() meetingSubtypeList;
  // @Output() formSecurityType = new EventEmitter<boolean>();
  // @Input() submitted;
  // formSubmit= false;
  eqMeetingSubytpes = [];
  fiMeetingSubtypes = [];
  meetingLoc = '';
  meetingDtlsForm = this.fb.group({
    hostName: [''],
    securityName: '',
    securityTradableEntityId: '',
    securityBBTicker: '',
    securityTicker: '',
    securityTseCode: '',
    mtgSubtype: [{ 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }],
    meetingBusUnit: [{ 'ActiveInd': '', 'KeyCode': '', 'UtilKeyName': '' }],
    meetingInitiator: [{
      'ActiveInd': 'Y',
      'MeetingTypeCode': 'BRK',
      'KeyCode': 'COMP',
      'KeyDesc': 'Company',
      'UtilKeyName': 'meetingInitiatorType'
    }],
    // brokerUsage: [{ 'UtilKeyName': '', 'KeyDesc': '', 'KeyCode': '' }],
    subjectLine: ['', [Validators.maxLength(150)]],
    meetingNotes: ['', [Validators.maxLength(1800)]],
    //  personName: [''],
    hostCorpId: [''],
    securityType: ['Equity'],
    debtTicker: [''],
    analystName: [''],
    analystCorporateId: [''],
    meetingFormat: [{ 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }]
  });

  securityDataSource: Observable<any>;
  selectedParameter: string;
  action = '';
  securityDetails = [];
  errorResponse = false;
  userDefaultBU = '';
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  // NewMeesage: string;
  constructor(private fb: FormBuilder, private commonService: CommonService, private ngZone: NgZone, private titlecasePipe: TitleCasePipe
    , private route: ActivatedRoute, private router: Router
  ) { }
  ngOnChanges(changes: SimpleChanges) {
    this.mtgSubTypeList = this.meetingSubtypeList;
  }

  ngOnInit() {
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
    // this.meetingDtlsForm.get('brokerUsage').disable();
    // this.meetingDtlsForm.get('securityType').disable();
    this.route.params.subscribe((params: Params) => {
      this.action = params['action'];
      if (params['action'] === 'update') {
        this.isValidHost = true;
        this.isValidSecurity = true;
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.meetingType = response.meetingType;
            this.setMeetingTypeContols();
            let getHostNameFromFILAttendees = '';
            response.fidelityInvitees.forEach(invitee => {
              if (invitee.corporateId === response.hostCorporateId) {
                getHostNameFromFILAttendees = invitee.name;
              }
            });
            this.meetingDtlsForm.patchValue({
              hostCorpId: (response.hostCorporateId) ? response.hostCorporateId : '',
              hostName: convertToTitleCase(getHostNameFromFILAttendees),
              meetingBusUnit: {
                'ActiveInd': '',
                'KeyCode': response.businessUnit ? response.businessUnit : '',
                'UtilKeyName': ''
              },
              meetingInitiator: {
                'ActiveInd': '',
                'MeetingTypeCode': '',
                'KeyCode': response.meetingInitiatorCode ? response.meetingInitiatorCode : '',
                'KeyDesc': response.meetingInitiatorDescription ? response.meetingInitiatorDescription : '',
                'UtilKeyName': ''
              },
              // brokerUsage: { 'UtilKeyName': '', 'KeyDesc': response.brokerUsageInitiator ? response.brokerUsageInitiator : '', 'KeyCode': '' },
              subjectLine: (response.emailSubject) ? response.emailSubject : '',
            });
            if (this.meetingType !== 'Broker') {
              this.meetingDtlsForm.patchValue({
                mtgSubtype: {
                  'ActiveInd': '',
                  'KeyCode': response.meetingSubTypeCode ? response.meetingSubTypeCode : '',
                  'KeyDesc': response.meetingSubTypeDescription ? response.meetingSubTypeDescription : '',
                  'UtilKeyName': ''
                },
                meetingFormat: {
                  'ActiveInd': '',
                  'KeyCode': response.meetingFormatCode ? response.meetingFormatCode : '',
                  'KeyDesc': response.meetingFormatDescription ? response.meetingFormatDescription : '',
                  'UtilKeyName': ''
                }
              });
              this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] !== ''
                ? this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' - '
                : '';
              this.meetingFormatDesc = this.meetingDtlsForm.get('meetingFormat').value['KeyDesc'] !== ''
                ? this.meetingDtlsForm.get('meetingFormat').value['KeyDesc']
                : '';
              if (this.meetingFormatDesc) {
                this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] !== ''
                  ? this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' : '
                  : '';
              }
              
            }
            if (this.meetingType === 'Company' && response.businessEntity === 'EQ') {
              this.mtgSubTypeList = this.eqMeetingSubytpes;
              response.securityDetail.primaryAnalystName = response.securityDetail.name ? response.securityDetail.name : '-';
              console.log('response.securityDetail: ', response.securityDetail);
              this.commonService.setSecurityDetails(response.securityDetail, 'update');
              this.meetingDtlsForm.patchValue({
                securityName: response.securityDetail.instrumentLongName ? response.securityDetail.instrumentLongName : '',
                securityTradableEntityId: response.securityDetail.tradableEntId ? response.securityDetail.tradableEntId : '',
                securityBBTicker: response.securityDetail.bbCode ? response.securityDetail.bbCode : '',
                securityTicker: response.securityDetail.ticker ? response.securityDetail.ticker : '',
                securityTseCode: response.securityDetail.tseIdentifier ? response.securityDetail.tseIdentifier : '',
                securityType: 'Equity',
                analystCorporateId: '',
                analystName: '',
                debtTicker: ''
              });
              if (response.executiveInvited && response.executiveInvited === 'Y') {
                this.executiveInvited = ' - ex - ';
                this.meetingFormatDesc = this.meetingFormatDesc + this.executiveInvited;
                if (this.meetingFormatDesc) {
                  if (!this.meetingFormatDesc.endsWith(' - ')) {
                    this.meetingFormatDesc = this.meetingFormatDesc + ' - ';
                  }
                  //  this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype') && this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc']? this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' : ': '';
                }
              } else { this.executiveInvited = ''; }
              this.sectorDetailsSubs = this.commonService.getSectorForSecurity(this.meetingDtlsForm.get('securityTradableEntityId').value).subscribe(
                (response) => {
                  if (response && response['data'] && response['data'][0]) {
                    this.commonService.sectorOfSecurity.next(response['data'][0]['sector']);
                  }
                },
                (error) => { console.log("error of sector data"), error }
              );
              let securityVal = this.meetingDtlsForm.get('securityName').value !== '' ? this.meetingDtlsForm.get('securityName').value + ' - ' : '';
              let securityBBTickerVal = this.meetingDtlsForm.get('securityBBTicker').value !== '' ? this.meetingDtlsForm.get('securityBBTicker').value + ' - ' : '';
              this.securityDescription = securityVal + securityBBTickerVal;
              this.commonService.searchedSecurityChange(response.securityDetail.tradableEntId);
              this.searchTypeName = 'Security Name';
            } else if (this.meetingType === 'Company' && response.businessEntity === 'FI') {
              this.mtgSubTypeList = this.fiMeetingSubtypes;
              let security = new Security('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
              security.primaryAnalystName = response.debtTickerDetail.analystName ? response.debtTickerDetail.analystName : '-';
              this.commonService.setSecurityDetails(security, 'update');
              this.meetingDtlsForm.patchValue({
                securityName: '',
                securityTradableEntityId: '',
                securityBBTicker: '',
                securityTicker: '',
                securityTseCode: '',
                debtTicker: response.debtTickerDetail ? response.debtTickerDetail.debtTicker : '',
                securityType: 'Fixed Income',
                analystName: response.debtTickerDetail.analystName ? response.debtTickerDetail.analystName : '',
                analystCorporateId: response.debtTickerDetail.analystCorporateId ? response.debtTickerDetail.analystCorporateId : ''

              });
              this.commonService.selectedDebtTicker.next(this.meetingDtlsForm.get('debtTicker').value)
              this.commonService.setSelectedDebtTicker(this.meetingDtlsForm.get('debtTicker').value);
              this.securityDescription = this.meetingDtlsForm.get('debtTicker').value !== ''
                ? this.meetingDtlsForm.get('debtTicker').value + ' - '
                : '';
              this.commonService.searchedSecurityChange(this.meetingDtlsForm.get('debtTicker').value);
              this.searchTypeName = 'Debt Ticker';
            } else if (this.meetingType === 'Other') {
              this.setMeetingTypeContols();
              this.meetingDtlsForm.patchValue({
                'meetingTopic': response.meetingTopic ? response.meetingTopic : ''
              });
            } else if (this.meetingType === 'Broker') {
              this.setMeetingTypeContols();
              this.meetingDtlsForm.patchValue({
                'brokerFirmName': response.brokerDetail.brokerFirmName ? response.brokerDetail.brokerFirmName : '',
                'brokerFirmId': response.brokerDetail.brokerFirmId ? response.brokerDetail.brokerFirmId : '',
                'meetingTopic': response.meetingTopic ? response.meetingTopic : ''
              });
              this.commonService.setBrokerFirmDetails({
                brokerFirmName: this.meetingDtlsForm.get('brokerFirmName').value,
                brokerFirmId: this.meetingDtlsForm.get('brokerFirmId').value,
              });
            }
          }
          if (this.action === 'update') {
        console.log ("subtype", this.meetingDtlsForm.get('mtgSubtype'))
      if (this.meetingDtlsForm.get('mtgSubtype') && this.meetingDtlsForm.get('mtgSubtype').value && this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc']) {
        let mtgSubTypeListDescArr = [];
        let mtgSubTypeListCodeArr = [];
        for (let item of this.mtgSubTypeList) {
          mtgSubTypeListDescArr.push(item['KeyDesc']);
          mtgSubTypeListCodeArr.push(item['KeyCode']);
        }
        if (mtgSubTypeListDescArr.includes(this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc']) && mtgSubTypeListCodeArr.includes(this.meetingDtlsForm.get('mtgSubtype').value['KeyCode'])) {
          // do nothing
        } else {
          this.meetingDtlsForm.patchValue({
            mtgSubtype: {
              'ActiveInd': '',
              'KeyCode': '',
              'KeyDesc': '',
              'UtilKeyName': ''
            }
          });
        }
        }
          }
        });
        if (this.meetingType === 'Company') {
          this.meetingDtlsForm.get('securityName').disable();
          this.meetingDtlsForm.get('securityType').disable();
          this.meetingDtlsForm.get('debtTicker').disable();
        }
        //   if (this.meetingDtlsForm.get('meetingInitiator').value['KeyCode'] === 'BRKR') {
        //     this.meetingDtlsForm.get('brokerUsage').enable();
        //   }
      } else {
        this.meetingType = params['meetingType'];
      }
    });
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url;
        this.setMeetingTypeContols();
      }
    });
    if (this.meetingType === 'Other' || this.meetingType === 'Broker') {
      this.meetingDtlsForm.removeControl('securityName');
      this.meetingDtlsForm.removeControl('securityTradableEntityId');
      this.meetingDtlsForm.removeControl('securityBBTicker');
      this.meetingDtlsForm.removeControl('securityTicker');
      this.meetingDtlsForm.removeControl('securityTseCode');
      if (this.meetingType === 'Broker') {
        this.meetingDtlsForm.addControl('brokerFirmName', new FormControl(''));
        this.meetingDtlsForm.addControl('brokerFirmId', new FormControl(''));
        this.meetingDtlsForm.removeControl('mtgSubtype');
        this.meetingDtlsForm.addControl('meetingTopic', new FormControl('', [Validators.maxLength(150)]));
      } else {
        this.meetingDtlsForm.addControl('meetingTopic', new FormControl('', [Validators.maxLength(150)]));
      }
    }
    this.fetchUtilData();
    // if (this.action === 'update') {
    //   console.log ("subtype", this.meetingDtlsForm.get('mtgSubtype'))
    //   if (this.meetingDtlsForm.get('mtgSubtype') && this.meetingDtlsForm.get('mtgSubtype').value && this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc']) {
    //     let mtgSubTypeListDescArr = [];
    //     let mtgSubTypeListCodeArr = [];
    //     for (let item of this.mtgSubTypeList) {
    //       mtgSubTypeListDescArr.push(item['KeyDesc']);
    //       mtgSubTypeListCodeArr.push(item['KeyCode']);
    //     }
    //     if (mtgSubTypeListDescArr.includes(this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc']) && mtgSubTypeListCodeArr.includes(this.meetingDtlsForm.get('mtgSubtype').value['KeyCode'])) {
    //       // do nothing
    //     } else {
    //       this.meetingDtlsForm.patchValue({
    //         mtgSubtype: {
    //           'ActiveInd': '',
    //           'KeyCode': '',
    //           'KeyDesc': '',
    //           'UtilKeyName': ''
    //         }
    //       });
    //     }
    //   }
    // }

    this.formReady.emit(this.meetingDtlsForm);
    this.peopleDataSource = EMPTY;
    this.resetMeetingDetails = this.commonService.resetMeetingDetailsSubject.subscribe(res => {
      if (res) {
        this.resetMeetingDetailValues();
      }
    });
    this.commonService.hostDataObservable.subscribe((response: any) => {
      if (response && response['primaryAnalystId'].length > 0) {
        this.primaryAnalystCorpId = response['primaryAnalystId'];
        this.primaryAnalystName = response['primaryAnalystName'];
        this.previousHostDetail = response;
      }
    });
    this.commonService.hostAddedAsAttendeeSubject.subscribe((response: boolean) => {
      if (response) {
        this.isHostAlreadyAddedAsAttendee = response;
        this.meetingDtlsForm.get('hostName').setErrors({ 'incorrect': true });
      } else {
        this.isHostAlreadyAddedAsAttendee = false;
      }
    });
  }

  setMeetingTypeContols() {
    if (this.currentUrl.includes('meetingType=Other') || this.meetingType === 'Other') {
      this.meetingDtlsForm.removeControl('securityName');
      this.meetingDtlsForm.removeControl('securityTradableEntityId');
      this.meetingDtlsForm.removeControl('securityBBTicker');
      this.meetingDtlsForm.removeControl('securityTicker');
      this.meetingDtlsForm.removeControl('securityTseCode');
      this.meetingDtlsForm.removeControl('brokerFirmName');
      this.meetingDtlsForm.removeControl('brokerFirmId');
      this.meetingDtlsForm.addControl('mtgSubtype', new FormControl({ 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }));
      this.meetingDtlsForm.addControl('meetingTopic', new FormControl('', [Validators.maxLength(150)]));
      this.fetchUtilData();
    } else if (this.currentUrl.includes('meetingType=Company') || this.meetingType === 'Company') {
      this.meetingDtlsForm.addControl('mtgSubtype', new FormControl({ 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }));
      this.meetingDtlsForm.addControl('securityName', new FormControl(''));
      this.meetingDtlsForm.addControl('securityTradableEntityId', new FormControl(''));
      this.meetingDtlsForm.addControl('securityBBTicker', new FormControl(''));
      this.meetingDtlsForm.addControl('securityTicker', new FormControl(''));
      this.meetingDtlsForm.addControl('securityTseCode', new FormControl(''));
      this.meetingDtlsForm.removeControl('brokerFirmName');
      this.meetingDtlsForm.removeControl('brokerFirmId');
      this.meetingDtlsForm.removeControl('meetingTopic');
      this.fetchUtilData();
    } else if (this.currentUrl.includes('meetingType=Broker') || this.meetingType === 'Broker') {
      this.meetingDtlsForm.addControl('brokerFirmName', new FormControl(''));
      this.meetingDtlsForm.addControl('brokerFirmId', new FormControl(''));
      this.meetingDtlsForm.removeControl('mtgSubtype');
      this.meetingDtlsForm.removeControl('securityName');
      this.meetingDtlsForm.removeControl('securityTradableEntityId');
      this.meetingDtlsForm.removeControl('securityBBTicker');
      this.meetingDtlsForm.removeControl('securityTicker');
      this.meetingDtlsForm.removeControl('securityTseCode');
      this.meetingDtlsForm.addControl('meetingTopic', new FormControl('', [Validators.maxLength(150)]));
    }
  }
  ngAfterViewInit() {
    this.meetingDtlsForm.get('subjectLine').valueChanges.subscribe((response) => {
      if (this.commonService.getMeetingType() !== 'Broker') {
        if (response.length > 0) {
          if (response.includes('Ex present - ')) {
            this.executiveInvited = ' - ex - ';
            this.appendSubjectLine('meetingLocation');
          } else if (response.includes('Ex not present - ')) {
            this.executiveInvited = '';
            this.appendSubjectLine('meetingLocation');
          }
        }
      }
    });
    this.meetingLocationChangeSubs = this.commonService.meetingLocationChangeSubj.subscribe((response) =>{
      if (response) {
        this.meetingLoc = response;
        this.appendSubjectLine('meetingLocation');
      }
    })
  }
  ngOnDestroy() {
    this.resetMeetingDetails.unsubscribe();
    this.isHostAlreadyAddedAsAttendee = false;
    this.commonService.sectorOfSecurity.next('');
    if (this.bbCodeSubs) {
      this.bbCodeSubs.unsubscribe();
    }
    if (this.sectorDetailsSubs) {
      this.sectorDetailsSubs.unsubscribe();
    }
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
     if (this.meetingLocationChangeSubs) {
       this.meetingLocationChangeSubs.unsubscribe();
     }
  }
  securityLabelChange(event) {
    if (event === 'Equity') {
      this.searchTypeName = 'Security Name';
      this.mtgTypeSearchPlaceholder = 'Search by Security name...';
      this.mtgSubTypeList = this.eqMeetingSubytpes;
      this.commonService.sectorOfSecurity.next('');
    } else {
      this.searchTypeName = 'Debt Ticker';
      this.mtgTypeSearchPlaceholder = 'Search by Debt ticker...'
      this.mtgSubTypeList = this.fiMeetingSubtypes;
      this.commonService.sectorOfSecurity.next('');
    }
    this.meetingDtlsForm.patchValue({
      'securityName': '',
      'securityTradableEntityId': '',
      'securityBBTicker': '',
      'securityTicker': '',
      'securityTseCode': '',
      'hostName': '',
      'debtTicker': '',
      'analystName': '',
      'analystCorporateId': ''

    });
    this.securityDescription = '';
    this.selectedParameter = '';
    this.commonService.setSecurityDetails([], 'create');
    this.commonService.defaultCompanyAttendees.next([]);
    // this.appendSubjectLine('securityType');
  }

  getSecurities(): void {
    let typeaheadData: TypeaheadData;
    this.isValidSecurity = false;
    this.meetingDtlsForm.patchValue({
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: ''
    });
    const searchedValue = this.meetingDtlsForm.get('securityName').value;
    typeaheadData = this.typeaheadDataSource.getSecurities(searchedValue);
    this.securityDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
    if (searchedValue.length < 3 || this.securityDataSource === EMPTY || this.errorResponse) {
      this.selectedParameter = '';
    }
  }

  getPeopleData(): void {
    let typeaheadData: TypeaheadData;
    this.isValidHost = false;
    this.isHostAlreadyAddedAsAttendee = false;
    this.meetingDtlsForm.get('hostName').setErrors({ 'invalidHost': true });
    const searchedValue = this.meetingDtlsForm.get('hostName').value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    this.hostErrorResponse = typeaheadData.isResponseError;
    if (this.hostErrorResponse) {
      this.meetingDtlsForm.get('hostName').setErrors({ 'incorrect': true });
    }
    if (searchedValue.length < 3) {
      let hostDetail = {
        'hostName': '',
        'hostCorpId': '',
        'hostPhoneNumber': '',
        'primaryAnalystName': '',
        'primaryAnalystId': ''
      }
      this.commonService.changeHostDetails(hostDetail);
    }
  }

  typeaheadOnSelect(event: TypeaheadMatch, dropDownType: string): void {
    let hostDetail = {
      'hostName': '',
      'hostCorpId': '',
      'hostPhoneNumber': '',
      'primaryAnalystName': '',
      'primaryAnalystId': ''
    }
    if (this.previousHostDetail && this.previousHostDetail['primaryAnalystId'].length > 0
      && this.previousHostDetail['primaryAnalystId'] === this.previousHostDetail['hostCorpId']) {
      hostDetail.primaryAnalystId = this.previousHostDetail['primaryAnalystId'];
      hostDetail.primaryAnalystName = this.previousHostDetail['primaryAnalystName'];
    }
    if (dropDownType === 'Host') {
      this.isValidHost = true;
      this.meetingDtlsForm.patchValue({
        'hostName': convertToTitleCase(event.item.name),
        'hostCorpId': event.item.corporateId,
      });
      hostDetail.hostName = this.meetingDtlsForm.get('hostName').value;
      hostDetail.hostCorpId = this.meetingDtlsForm.get('hostCorpId').value;

      this.commonService.getHostDialInDetails(this.meetingDtlsForm.get('hostCorpId').value).subscribe((response) => {
        hostDetail.hostPhoneNumber = response[this.meetingDtlsForm.get('hostCorpId').value];
        this.commonService.changeHostDetails(hostDetail);
      },
        (error) => {
          console.log(error)
        })
      this.checkForConflicts.emit('Host');

      this.appendSubjectLine('Host');

    } else if (dropDownType === 'Security') {
      this.isHostAlreadyAddedAsAttendee = false;
      this.isValidSecurity = true;
      const selectedSecurityInstance = event.item;
      console.log('selectedSecurityInstance: ', selectedSecurityInstance);
      this.selectedSecurityDetail = selectedSecurityInstance;
      this.selectedParameter = event.item.itemValue;
      this.selectedParameter = this.selectedParameter.split('&lt;').join('<').split('&gt;').join('>');
      this.commonService.changeMessage(selectedSecurityInstance.instrumentLongName);
      this.commonService.searchedSecurityChange(selectedSecurityInstance.tradableEntId);
      this.commonService.setSecurityDetails(selectedSecurityInstance, 'create');
      this.commonService.sectorOfSecurity.next('');
      this.meetingDtlsForm.patchValue({
        securityName: selectedSecurityInstance.instrumentLongName ? selectedSecurityInstance.instrumentLongName : '',
        securityTradableEntityId: selectedSecurityInstance.tradableEntId ? selectedSecurityInstance.tradableEntId : '',
        securityBBTicker: selectedSecurityInstance.bbCode ? selectedSecurityInstance.bbCode : '',
        securityTicker: selectedSecurityInstance.ticker ? selectedSecurityInstance.ticker : '',
        securityTseCode: selectedSecurityInstance['tseCode'] ? selectedSecurityInstance.tseCode : '',
        hostName: '',
        hostCorpId: ''
      });

      this.bbCodeDataObservable = this.commonService.getBBCodeForTradEntId(this.meetingDtlsForm.get('securityTradableEntityId').value);
      this.bbCodeSubs = this.bbCodeDataObservable.subscribe((response) => {
        this.meetingDtlsForm.patchValue({
          securityBBTicker: response.data[0].bbCode ? response.data[0].bbCode : '',
          securityTseCode: response.data[0].tseCode ? response.data[0].tseCode : '',
          securityTicker: response.data[0].ticker ? response.data[0].ticker : ''
        });
        this.appendSubjectLine('Security');
      }, (error) => {
        console.log("error fetching bbcode")
      });

      this.sectorDetailsSubs = this.commonService.getSectorForSecurity(this.meetingDtlsForm.get('securityTradableEntityId').value).subscribe(
        (response) => {
          if (response && response['data'] && response['data'][0]) {
            this.commonService.sectorOfSecurity.next(response['data'][0]['sector']);
          }
        },
        (error) => { console.log("error of sector data"), error }
      )

      selectedSecurityInstance.primaryAnalystCorpId = '';
      if (selectedSecurityInstance.name && selectedSecurityInstance.analystRoleTypeDesc === 'Primary' && selectedSecurityInstance.teamDept === 'FUND') {
        selectedSecurityInstance.primaryAnalystCorpId = selectedSecurityInstance.corpId;
        this.setDefaultHostAttendeeDetails(selectedSecurityInstance);
      } else {
        hostDetail.hostPhoneNumber = '';
        hostDetail.hostName = '';
        hostDetail.hostCorpId = '';
        hostDetail.primaryAnalystId = '';
        hostDetail.primaryAnalystName = '';
        this.commonService.changeHostDetails(hostDetail);
        this.appendSubjectLine('Host');
      }
      this.commonService.setSecurityDetails(selectedSecurityInstance, 'create', this.checkForConflicts);

      this.commonService.getDefaultCompanyAttendees(this.meetingDtlsForm.get('securityTradableEntityId').value).subscribe(
        (response) => {
          this.commonService.defaultCompanyAttendees.next(response['body']['thirdPartyContacts']);

        },
        (error) => { console.log(error) });
    } else if (dropDownType === 'DebtTicker') {
      this.meetingDtlsForm.patchValue({
        debtTicker: event.item.debtTicker,
        analystName: event.item.analystName ? convertToTitleCase(event.item.analystName) : '',
        analystCorporateId: event.item.corporateId ? event.item.corporateId : ''
      });
      this.isValidDebtTicker = true;
      this.commonService.defaultCompanyAttendees.next([]);
      this.commonService.setSelectedDebtTicker(event.item.debtTicker);
      this.commonService.selectedDebtTicker.next(event.item.debtTicker);
      this.commonService.searchedSecurityChange(event.item.debtTicker);
      if (event.item.corporateId) {
        this.selectedSecurityDetail = new Security('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
          '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
        this.setDefaultHost(event.item.analystName, event.item.corporateId, '');
      } else {
        hostDetail.hostPhoneNumber = '';
        hostDetail.hostName = '';
        hostDetail.hostCorpId = '';
        hostDetail.primaryAnalystId = '';
        hostDetail.primaryAnalystName = '';
        this.commonService.changeHostDetails(hostDetail);
        this.meetingDtlsForm.patchValue({
          hostCorpId: '',
          hostName: ''
        });
        this.appendSubjectLine('Host');
        this.commonService.setSecurityDetails(hostDetail, 'create');
      }
      this.appendSubjectLine('DebtTicker');
    } else if (dropDownType === 'BrokerFirm') {
      this.meetingDtlsForm.patchValue({
        brokerFirmName: convertToTitleCase(event.item.firmName),
        brokerFirmId: event.item.firmId
      });
      this.commonService.setBrokerFirmDetails({
        brokerFirmName: this.meetingDtlsForm.get('brokerFirmName').value,
        brokerFirmId: this.meetingDtlsForm.get('brokerFirmId').value,
      });
      if (event.item.brokerFirmAddress) {
        this.commonService.onBrokerFirmChange.next(event);
      }
      this.isValidBrokerFirm = true;
      this.appendSubjectLine('BrokerFirm');
    }
  }

  changeTypeaheadLoading(e: boolean, dropDownType: string): void {
    if (dropDownType === 'Host') {
      this.typeaheadLoading = e;
    } else if (dropDownType === 'Security') {
      this.securityLoading = e;
    } else if (dropDownType === 'DebtTicker') {
      this.debtTickerTypeaheadLoading = e;
    } else if (dropDownType === 'BrokerFirm') {
      this.brokerFirmTypeaheadLoading = e;
    }
  }


  setDefaultHostAttendeeDetails(selectedSecurityInstance) {

    this.commonService.getSecurityAnalysts(selectedSecurityInstance.tradableEntId).subscribe((response) => {
      if (response['status'] === 200 && response['data'].length > 0) {
        response['data'].forEach((rowNode, Index) => {
          if (rowNode.analystRoleTypeDesc === 'Primary' && rowNode.teamDept === 'FUND') {
            if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'EUR'
              && rowNode.teamLocation === 'LDN'
              && rowNode.bussinessUnitCd === 'FIL-LDN') {
              this.setDefaultHost(rowNode.name, rowNode.corporateId, rowNode.phoneNumber);
            } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'JP'
              && rowNode.teamLocation === 'TOK'
              && rowNode.bussinessUnitCd === 'FIL-TOK') {
              this.setDefaultHost(rowNode.name, rowNode.corporateId, rowNode.phoneNumber);
            } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'APxJ'
              && rowNode.teamLocation === 'HKG'
              && rowNode.bussinessUnitCd === 'FIL-HKG') {
              this.setDefaultHost(rowNode.name, rowNode.corporateId, rowNode.phoneNumber);
            } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'CAN'
              && rowNode.teamLocation === 'PYR'
              && rowNode.bussinessUnitCd === 'FIL-CAN') {
              this.setDefaultHost(rowNode.name, rowNode.corporateId, rowNode.phoneNumber);
            }
          }
        });
      }
    });
  }

  setDefaultHost(hostName, hostCorporateId, hostPhoneNumber) {
    this.meetingDtlsForm.patchValue({
      hostName: hostName ? convertToTitleCase(hostName) : '',
      hostCorpId: hostCorporateId
    });
    const hostDetail = {
      'hostName': this.meetingDtlsForm.get('hostName').value,
      'hostCorpId': this.meetingDtlsForm.get('hostCorpId').value,
      'hostPhoneNumber': '',
      'primaryAnalystId': this.meetingDtlsForm.get('hostCorpId').value,
      'primaryAnalystName': this.meetingDtlsForm.get('hostName').value
    }
    this.commonService.getHostDialInDetails(this.meetingDtlsForm.get('hostCorpId').value).subscribe((response) => {
      hostDetail.hostPhoneNumber = response[this.meetingDtlsForm.get('hostCorpId').value];
      this.commonService.changeHostDetails(hostDetail);
    },
      (error) => {
        console.log(error)
      })

    this.selectedSecurityDetail.primaryAnalystName = hostDetail.primaryAnalystName;
    this.commonService.setSecurityDetails(this.selectedSecurityDetail, 'create');
    this.appendSubjectLine('Host');
    if (hostCorporateId) {
      this.isValidHost = true;
    }
  }

  typeaheadNoResults(event: boolean, dropDownType: string): void {
    if (dropDownType === 'Host') {
      this.hostErrorResponse = event;
    }
    if (dropDownType === 'Security') { 
      this.errorResponse = event;
    }
    if (dropDownType === 'DebtTicker') {
      this.debtTickerErrorResponse = event;
    }
    if (dropDownType === 'BrokerFirm') {
      this.brokerFirmErrorResponse = event;
    }
  }

  onBlurMethod() {
    if (!this.isValidHost) {
      this.meetingDtlsForm.patchValue({
        hostName: ''
      });
      this.typeaheadLoading = false;
      this.getPeopleData();
      this.appendSubjectLine('Host');
    }
  }

  // resetBrokerUsageInit() {
  //   if (this.meetingDtlsForm.get('meetingInitiator').value.KeyDesc === 'Broker') {
  //     this.meetingDtlsForm.get('brokerUsage').enable();
  //     this.meetingDtlsForm.patchValue({ 'brokerUsage': { UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' } });
  //   } else {
  //     this.meetingDtlsForm.get('brokerUsage').disable();
  //     this.meetingDtlsForm.patchValue({ 'brokerUsage': '' });
  //   }
  // }
  appendSubjectLine(attributeType: string) {
    if (attributeType === 'Security') {
      let securityVal = this.meetingDtlsForm.get('securityName').value !== '' ? this.meetingDtlsForm.get('securityName').value + ' - ' : '';
      let securityBBTickerVal = this.meetingDtlsForm.get('securityBBTicker').value !== '' ? this.meetingDtlsForm.get('securityBBTicker').value + ' - ' : '';
      this.securityDescription = securityVal + securityBBTickerVal;
    }
    if (attributeType === 'DebtTicker') {
      this.securityDescription = this.meetingDtlsForm.get('debtTicker').value !== '' ? this.meetingDtlsForm.get('debtTicker').value + ' - ' : '';
    }
    if (attributeType === 'BrokerFirm') {
      this.securityDescription = this.meetingDtlsForm.get('brokerFirmName').value !== '' ? this.meetingDtlsForm.get('brokerFirmName').value + ' - ' : '';
    }
    if (attributeType === 'Subtype') {
      this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' - ';
      if (this.meetingFormatDesc || this.meetingLocation) {
        // if (!this.meetingFormatDesc.endsWith(' - ')) {
        //   this.meetingFormatDesc = this.meetingFormatDesc + ' - ';
        // }
        this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype') && this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] ? (this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' : '): '';
      }
    }

     if (attributeType === 'meetingLocation')  {      
      this.meetingLocation = this.meetingLoc + this.executiveInvited;
      if (this.meetingLocation) {
        if (!this.meetingLocation.endsWith(' - ')) {
          this.meetingLocation = this.meetingLocation + ' - ';
        }
        this.meetingFormatDesc = this.meetingDtlsForm.get('meetingFormat') && this.meetingDtlsForm.get('meetingFormat').value['KeyDesc'] ? this.meetingDtlsForm.get('meetingFormat').value['KeyDesc'] + ' : ' : '';
      }
    }

    if (attributeType === 'meetingFormat') {
      this.meetingFormatDesc = this.meetingDtlsForm.get('meetingFormat') && this.meetingDtlsForm.get('meetingFormat').value['KeyDesc'] ? this.meetingDtlsForm.get('meetingFormat').value['KeyDesc'] : ''
      if (this.meetingFormatDesc) {
        if (!this.meetingFormatDesc.endsWith(' : ')) {
          this.meetingFormatDesc = this.meetingFormatDesc + ' : ';
        }
        this.meetingSubtypeDesc = this.meetingDtlsForm.get('mtgSubtype') && this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] ? this.meetingDtlsForm.get('mtgSubtype').value['KeyDesc'] + ' : ' : '';
      }
    }
    if ((this.meetingType === 'Other' && this.meetingDtlsForm.get('meetingTopic').value.trim()) || (this.meetingType === 'Broker' && this.meetingDtlsForm.get('meetingTopic').value.trim())) {
      if ( this.meetingSubtypeDesc || this.meetingFormatDesc) {
      this.meetingDtlsForm.patchValue({
        'subjectLine': this.meetingType.toUpperCase() + ' - ' + this.securityDescription
          + ((this.meetingDtlsForm.get('meetingTopic').value.length > 0) ? (this.meetingDtlsForm.get('meetingTopic').value.trim() + ' - ') : '')
          + this.meetingSubtypeDesc
          + this.meetingFormatDesc
          + this.meetingLocation
          + this.meetingDtlsForm.get('hostName').value
      });
      } else {
        this.meetingDtlsForm.patchValue({
        'subjectLine': this.meetingType.toUpperCase() + ' - ' + this.securityDescription
          + ((this.meetingDtlsForm.get('meetingTopic').value.length > 0) ? (this.meetingDtlsForm.get('meetingTopic').value.trim() + ' - ') : '')
          + this.meetingSubtypeDesc
          + this.meetingFormatDesc
          + this.meetingDtlsForm.get('hostName').value
      });
      }
    } else if (this.meetingType === 'Company') {
      if ( this.meetingSubtypeDesc || this.meetingFormatDesc) {
      this.meetingDtlsForm.patchValue({
        'subjectLine': this.securityDescription + this.meetingSubtypeDesc
         + this.meetingFormatDesc
         + this.meetingLocation
         + this.meetingDtlsForm.get('hostName').value
      });
      } else {
        this.meetingDtlsForm.patchValue({
        'subjectLine': this.securityDescription + this.meetingSubtypeDesc
         + this.meetingFormatDesc
         + this.meetingDtlsForm.get('hostName').value
      });
      }
    } else if (this.meetingType === 'Broker') {
      this.meetingDtlsForm.patchValue({
        'subjectLine': 'BROKER - ' + this.securityDescription + this.meetingDtlsForm.get('hostName').value
      });
    } else {
      this.meetingDtlsForm.patchValue({
        'subjectLine': this.securityDescription + this.meetingSubtypeDesc 
        + this.meetingFormatDesc
        + this.meetingLocation
        + this.meetingDtlsForm.get('hostName').value
      });
    }
  }

  onSecurityBlur() {
    if (this.meetingDtlsForm.get('securityType').value === 'Equity') {
      if (!this.isValidSecurity) {
        this.meetingDtlsForm.patchValue({
          securityName: '',
          securityTradableEntityId: '',
          securityBBTicker: '',
          securityTicker: '',
          securityTseCode: ''
        });
        this.selectedParameter = '';
        this.securityLoading = false;
        this.getSecurities();
        this.appendSubjectLine('Security');
      }
    } else {
      if (!this.isValidDebtTicker) {
        this.meetingDtlsForm.patchValue({
          debtTicker: '',
        });
        this.debtTickerTypeaheadLoading = false;
        this.getDebtTicker();
      }
    }
  }

  onBrokerFirmBlur() {
    if (!this.isValidBrokerFirm) {
      this.meetingDtlsForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.brokerFirmTypeaheadLoading = false;
      this.getBrokerFirm();
    }
  }

  validateTextLength(textType: string) {
    if (textType === 'SubjectLine') {
      if (this.meetingDtlsForm.get('subjectLine').value.length > 150) {
        return true;
      } else {
        return false;
      }
    } else if (textType === 'Notes') {
      if (this.meetingDtlsForm.get('meetingNotes').value.length > 1800) {
        return true;
      } else {
        return false;
      }
    }
  }

  checkHostsValid(control: FormGroup): { [s: string]: boolean } {
    if (this.hostErrorResponse) {
      return { 'hostRequired1': true };
    }
    return null;
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.businessUnit = this.utilData.filter(element => element.UtilKeyName === 'businessUnits');

        if (this.meetingType === 'Company') {
          this.meetingFormat = this.utilData.filter(element => element.UtilKeyName === 'meetingFormat.Company');
          this.fiMeetingSubtypes = this.utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Company');
          this.eqMeetingSubytpes = this.utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Company' && element.SubtypeEntity !== 'FI');
          // this.fiMeetingSubtypes = this.utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Company');
          // this.eqMeetingSubytpes = this.utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Company' && element.SubtypeEntity !== 'FI');
          if (this.meetingDtlsForm && this.meetingDtlsForm.get('securityType').value === 'Equity') {
            this.mtgSubTypeList = this.eqMeetingSubytpes;
          } else if (this.meetingDtlsForm && this.meetingDtlsForm.get('securityType').value === 'Fixed Income') {
            this.mtgSubTypeList = this.fiMeetingSubtypes
          } else {
            this.mtgSubTypeList = this.eqMeetingSubytpes;
          }
        } else if (this.meetingType === 'Other') {
          this.meetingFormat = this.utilData.filter(element => element.UtilKeyName === 'meetingFormat.Company');
          this.mtgSubTypeList = this.utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Other');
          // this.mtgSubTypeList = this.utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Other');
        }
        this.mtgInitiator = this.utilData.filter(element => element.UtilKeyName === 'meetingInitiatorType');
        // this.brkUsageInitiator = this.utilData.filter(element => element.UtilKeyName === 'brokerUsageInitiator');
        if (this.action !== 'update') {
          let buValue = this.businessUnit.filter(element => element.KeyCode === this.userDefaultBU);
          if (buValue[0]) {
            this.meetingDtlsForm.patchValue({
              'meetingBusUnit': buValue[0]
            });
          }
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }

  resetMeetingDetailValues() {
    //  this.meetingDtlsForm.get('brokerUsage').disable();
    if (this.meetingType === 'Company') {
      this.meetingDtlsForm.get('securityName').enable();
    }
    this.searchTypeName = 'Security Name';
    this.mtgTypeSearchPlaceholder = 'Search by Security name...';
    this.selectedParameter = '';
    this.securityDescription = '';
    this.meetingSubtypeDesc = '';
    this.meetingFormatDesc = '';
    this.executiveInvited = '';
  }

  getDebtTicker() {
    this.debtTickerDataSource = EMPTY;
    let typeaheadData: TypeaheadData;
    this.isValidDebtTicker = false;
    const searchedValue = this.meetingDtlsForm.get('debtTicker').value;
    typeaheadData = this.typeaheadDataSource.getDebtTicker(searchedValue);
    this.debtTickerDataSource = typeaheadData.dataSource;
    this.debtTickerErrorResponse = typeaheadData.isResponseError;
  }

  getBrokerFirm() {
    this.brokerFirmDataSource = EMPTY;
    let typeaheadData: TypeaheadData;
    this.isValidBrokerFirm = false;
    const searchedValue = this.meetingDtlsForm.get('brokerFirmName').value;
    typeaheadData = this.typeaheadDataSource.getBrokerFirms(searchedValue);
    this.brokerFirmDataSource = typeaheadData.dataSource;
    this.brokerFirmErrorResponse = typeaheadData.isResponseError;
  }

  checkIfMeetingFormatMandatory() {
    if (this.meetingType === 'Company' || (this.meetingType === 'Other' && this.meetingDtlsForm.get('mtgSubtype').value && this.meetingDtlsForm.get('mtgSubtype').value['KeyCode'])) {
      return true;
    } else {
      return false;
    }
  }
}
