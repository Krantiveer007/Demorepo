import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Subscription } from 'rxjs/internal/Subscription';

@Component({
  selector: 'mv2-meetings',
  templateUrl: './meetings.component.html',
  styleUrls: ['./meetings.component.css']
})
export class MeetingsComponent implements OnInit {
  meetingType = '';
  selectedSecurity = 'Equity';
  subjectLine = '';
  meetingForm: FormGroup;
  updateMtgSubs: Subscription;
  currentAction = '';
  @Output() formReady = new EventEmitter<FormGroup>();
  @Output() checkMeetingConflicts = new EventEmitter<String>();
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private commonService: CommonService) { }
  ngOnInit() {
    this.meetingForm = this.fb.group({});
    this.formReady.emit(this.meetingForm);
    this.route.params.subscribe((params) => {
      this.meetingType = params['meetingType'];
      this.currentAction = params['action'];
      if (this.currentAction === 'update') {
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.subjectLine = response.emailSubject ? response.emailSubject : '';
          }
        });
      }
    });
    this.meetingType = this.commonService.getMeetingType();
  }

  checkForConflicts(field) {
    this.checkMeetingConflicts.emit(field);
  }

  formInitialized(name, form) {
    this.meetingForm.setControl(name, form);
    if (name === 'meeting-details') {
      this.selectedSecurity = this.meetingForm.get('meeting-details').get('securityType').value;
      this.meetingForm.get('meeting-details').get('securityType').valueChanges.subscribe((response) => {
      this.selectedSecurity = response;
      });
      this.meetingForm.get('meeting-details').get('subjectLine').valueChanges.subscribe((response) => {
        this.subjectLine = response ? response : '';
      });
    }
  }
  ngOnDestroy() {
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
    this.subjectLine = '';
  }
}
