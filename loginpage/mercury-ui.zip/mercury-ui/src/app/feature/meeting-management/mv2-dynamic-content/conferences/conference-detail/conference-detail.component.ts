import { Component, OnInit, EventEmitter, Output, NgZone } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs/internal/Observable';
import { CommonService } from 'src/app/core/http/common.service';
import * as cityTimezones from 'city-timezones';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { DatePipe } from '@angular/common';
import { BsDatepickerConfig, BsDaterangepickerDirective } from 'ngx-bootstrap/datepicker';
import { ViewChild } from '@angular/core';
import { ModalDirective, BsDatepickerDirective } from 'ngx-bootstrap';
import { Subscription } from 'rxjs/internal/Subscription';
import { Validators } from '@angular/forms';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'mv2-conference-detail',
  templateUrl: './conference-detail.component.html',
  styleUrls: ['./conference-detail.component.css']
})
export class ConferenceDetailComponent implements OnInit {

  conferenceDetailForm = this.fb.group({
    conferenceName: ['', Validators.maxLength(150)],
    venue: ['', Validators.maxLength(300)],
    websiteLink: ['', Validators.maxLength(300)],
    dateRange: ['', MeetingFieldValidations.DateRangeValidator],
    // fromDate: ['', MeetingFieldValidations.InvalidDateValidator],
    // toDate: ['', MeetingFieldValidations.InvalidDateValidator],
    meetingRequestDeadline: ['', MeetingFieldValidations.Date],
    meetingRegistrationDeadline: ['', MeetingFieldValidations.Date],
    cityCountry: [{
      'Cities': '',
      'Country': '',
      'GRD_COUNTRY_CD': '',
      'ISO_COUNTRY_CD': '',
      'KeyCode': '',
      'UtilKeyName': '',
      'cityCountryVal': ''
    }],
    cityCountryName: [''],
    timezone: [''],
    businessUnit: [{ 'ActiveInd': '', 'KeyCode': '', 'UtilKeyName': '' }],
  }, { validators: MeetingFieldValidations.CheckMtgRequestDeadline });

  //  { validators: MeetingFieldValidations.FromToDate }
  public cityCountry: any[];
  utilData: any[];
  meetingTimeZone = '';
  businessUnit: any[];
  utilDataObservable: Observable<any>;
  isValidCity = false;
  errorResponse = false;
  dateErrorReason = '';
  regestrationDeadLineError = '';
  minDate: Date;
  minDateForRequestDeadline: Date;
  bsInlineRangeValue: Date[];
  config = {
    ignoreBackdropClick: true
  };
  isModalShown = false;
  dateConfirmMessage = 'You are about to create a meeting in past date.';
  resetMeetingDetailSubscription: Subscription;
  maxCharLength = '';
  userDefaultBU = '';
  userDefaultCityCountry = '';
  // fromDate: Date = new Date();
  // toDate: Date = new Date();

  @Output() formReady = new EventEmitter<FormGroup>();
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  @ViewChild('drp') dateRangePicker: BsDaterangepickerDirective;
  @ViewChild('dp') datePicker: BsDatepickerDirective;

  constructor(private fb: FormBuilder, private commonService: CommonService, private datePipe: DatePipe, private ngZone: NgZone) { }

  ngOnInit() {
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
    this.userDefaultCityCountry = this.commonService.getLoggedInUserInfo().getDefaultCityCountry();
    this.formReady.emit(this.conferenceDetailForm);
    this.fetchUtilData();
    this.minDate = new Date();
    this.minDateForRequestDeadline = new Date();
    this.minDate.setDate(this.minDate.getDate() - 365);
    this.resetMeetingDetailSubscription = this.commonService.resetMeetingDetailsSubject.subscribe((response) => {
      if (response) {
        this.resetConferenceDetailForm();
      }
    });

  }

  ngOnDestroy() {
    if (this.resetMeetingDetailSubscription) {
      this.resetMeetingDetailSubscription.unsubscribe();
    }
  }
  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.businessUnit = this.utilData.filter(element => element.UtilKeyName === 'businessUnits');
        let buValue = this.businessUnit.filter(element => element.KeyCode === this.userDefaultBU);
        if (buValue[0]) {
          this.conferenceDetailForm.patchValue({
            'businessUnit': buValue[0]
          });
        }
        this.cityCountry = this.utilData.filter(element => element.UtilKeyName === 'country-city-map');
        for (const item of this.cityCountry) {
          item['cityCountryVal'] = item.Cities + ', ' + item.Country;
        }
        let cityValue = this.cityCountry.filter(element => element.cityCountryVal === this.userDefaultCityCountry);
        if (cityValue[0]) {
          this.conferenceDetailForm.patchValue({
            'cityCountry': cityValue[0],
            'cityCountryName': cityValue[0]['cityCountryVal']
          });
          this.isValidCity = true;
          this.populateTimeZone(cityValue[0]);
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }
  getCityCountry() {
    this.isValidCity = false;
    this.conferenceDetailForm.patchValue({
      cityCountry: {
        'Cities': '',
        'Country': '',
        'GRD_COUNTRY_CD': '',
        'ISO_COUNTRY_CD': '',
        'KeyCode': '',
        'UtilKeyName': '',
        'cityCountryVal': ''
      }
    });
    this.errorResponse = false;
  }
  typeaheadOnSelect(event) {
    this.isValidCity = true;
    this.conferenceDetailForm.patchValue({
      'cityCountry': event.item
    });
    this.populateTimeZone(event.item);
    this.errorResponse = false;
  }
  onCityBlur() {
    if (!this.isValidCity) {
      this.conferenceDetailForm.patchValue({
        cityCountry: {
          'Cities': '',
          'Country': '',
          'GRD_COUNTRY_CD': '',
          'ISO_COUNTRY_CD': '',
          'KeyCode': '',
          'UtilKeyName': '',
          'cityCountryVal': ''
        },
        cityCountryName: ''
      });
      this.errorResponse = false;
    }
  }

  typeaheadNoResults(event) {
    this.errorResponse = event;
  }
  populateTimeZone(event: {
    Cities: string, Country: string, GRD_COUNTRY_CD: string, ISO_COUNTRY_CD: string,
    KeyCode: string, UtilKeyName: string, cityCountryVal: string
  }) {
    this.conferenceDetailForm.patchValue({
      timezone: ''
    });
    this.meetingTimeZone = '';
    if (event) {
      const cityDescription = cityTimezones.lookupViaCity(event['Cities']);
      let timeZoneDesc = null;
      if (cityDescription.length !== 0) {
        if (cityDescription.length > 1) {
          const filteredCity = cityDescription.filter(element => element.iso2 === event['ISO_COUNTRY_CD']);
          if (filteredCity.length !== 0) {
            timeZoneDesc = filteredCity[0].timezone;
          } else {
            timeZoneDesc = null;
            //  this.nocitycountrymap.push(event)
          }
        } else {
          timeZoneDesc = cityDescription[0]['timezone'];
        }

        if (timeZoneDesc !== null) {
          const date = new Date().toLocaleString('en-US', { timeZone: timeZoneDesc, timeZoneName: 'short' });
          const indexOfOpenBracket = date.indexOf('GMT');
          if (indexOfOpenBracket !== -1) {
            // this.correcttimezone.push(event)
            this.conferenceDetailForm.patchValue({
              timezone: timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length)
            });
            this.meetingTimeZone = timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length);
          } else {
            this.conferenceDetailForm.patchValue({
              timezone: timeZoneDesc + ' ' + date.substring(date.length - 3, date.length)
            });
            this.meetingTimeZone = timeZoneDesc + ' ' + date.substring(date.length - 3, date.length);
            //   this.wrongtimezone.push(event);
          }
        }
      } else {
        // this.notimezone.push(event);
        this.conferenceDetailForm.patchValue({
          timezone: event['timezoneVal'] ? event['timezoneVal'] : ''
        });
        this.meetingTimeZone = event['timezoneVal'] ? event['timezoneVal'] : '';
      }
    }
  }

  checkInvalidDate(dateType: string): boolean {
    if (this.conferenceDetailForm.get(dateType).errors !== null && this.conferenceDetailForm.get(dateType).errors.invalidDate) {
      this.conferenceDetailForm.get(dateType).errors.bsDate.invalid = 'Invalid date'
      return true;
    }
    return false;
  }

  checkStartAndMtgDeadlineDateDiff(dateType): boolean {
    if (this.conferenceDetailForm.errors !== null && this.conferenceDetailForm.errors.mtgDeadlineExceedEndDateError
      && this.conferenceDetailForm.get('dateRange').errors === null
      && this.conferenceDetailForm.get(dateType).errors === null) {
      this.dateErrorReason = `Meeting Request Deadline date should not be greater than Start date`;
      return true;
    }
    return false;
  }
  checkStartAndRegDeadlineDateDiff(dateType): boolean {
    if (this.conferenceDetailForm.errors !== null && this.conferenceDetailForm.errors.mtgRegDeadlineExceedEndDateError
      && this.conferenceDetailForm.get('dateRange').errors === null
      && this.conferenceDetailForm.get(dateType).errors === null) {
      this.regestrationDeadLineError = `Registration Deadline date should not be greater than Start date`;
      return true;
    }
    return false;
  }
  checkMoreThanOneYearDate(dateType: string): boolean {
    if (this.conferenceDetailForm.get(dateType).errors !== null && this.conferenceDetailForm.get(dateType).errors.moreThanOneYearDate) {
      this.dateErrorReason = 'Start Date must be within past 365 days';
      this.regestrationDeadLineError = 'Start Date must be within past 365 days';
      return true;
    }
    return false;
  }
  onDateRangeChange(event) {
    if (event && event.length === 2) {
      const ONE_DAY = 1000 * 60 * 60 * 24;
      const startDate = event[0];
      const todayDate: Date = new Date();
      const differenceDays = Math.floor((todayDate.getTime() - startDate.getTime()) / (ONE_DAY));
      if (differenceDays <= 365 && differenceDays > 0) {
        this.isModalShown = true;
      }
    }
  }
  onHidden(): void {
    this.confirmModal.hide();
    this.isModalShown = false;
  }
  decline(): void {
    this.conferenceDetailForm.patchValue({
      dateRange: ''
    });
    this.confirmModal.hide();
    this.isModalShown = false;
  }
  confirm(): void {
    this.confirmModal.hide();
    this.isModalShown = false;
  }
  resetConferenceDetailForm() {
    this.conferenceDetailForm.patchValue({
      conferenceName: '',
      venue: '',
      websiteLink: '',
      dateRange: '',
      meetingRequestDeadline: '',
      meetingRegistrationDeadline: '',
      cityCountry: [{
        'Cities': '',
        'Country': '',
        'GRD_COUNTRY_CD': '',
        'ISO_COUNTRY_CD': '',
        'KeyCode': '',
        'UtilKeyName': '',
        'cityCountryVal': ''
      }],
      cityCountryName: '',
      timezone: '',
      businessUnit: [{ 'ActiveInd': '', 'KeyCode': '', 'UtilKeyName': '' }],
    });
    this.fetchUtilData();
  }
  validateTextLength(attrType) {
    let attributeValue = this.conferenceDetailForm.get(attrType).value;
    if (attributeValue) {
      let isAttrLengthValid = false;
      if (attrType === 'conferenceName' && attributeValue.length > 150) {
        this.maxCharLength = '150';
        isAttrLengthValid = true;
      } else if ((attrType === 'venue' || attrType === 'websiteLink') && attributeValue.length > 300) {
        this.maxCharLength = '300'
        isAttrLengthValid = true;
      }
      return isAttrLengthValid;
    }
  }
  onKeyDown(event, type) {
    if (event.keyCode === 9) {
      if (type === 'range') {
        this.dateRangePicker.hide();
      } else {
        this.datePicker.hide();
      }
    } else {
      if (type === 'range') {
        this.dateRangePicker.show();
      } else {
        this.datePicker.show();
      }
    }
  }
}
