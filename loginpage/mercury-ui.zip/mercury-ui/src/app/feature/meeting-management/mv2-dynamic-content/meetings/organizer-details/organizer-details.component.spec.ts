import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrganizerDetailsComponent } from './organizer-details.component';
import { TypeaheadModule, TooltipModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { of, throwError } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
describe('OrganizerDetailsComponent', () => {
  let component: OrganizerDetailsComponent;
  let fixture: ComponentFixture<OrganizerDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrganizerDetailsComponent ],
      imports: [ TypeaheadModule.forRoot(),
      FormsModule,
      ReactiveFormsModule, 
      HttpClientModule ],
       providers: [{ provide: 'EnvName', useValue: 'DEV' }, {provide: ActivatedRoute, useValue: {params: of()}}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
