import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { SecurityHoldersComponent } from './security-holders.component';
import { GridApi } from 'ag-grid-community/dist/lib/gridApi';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
describe('SecurityHoldersComponent', () => {
  let component: SecurityHoldersComponent;
  let fixture: ComponentFixture<SecurityHoldersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecurityHoldersComponent, CommonGridComponent],
      imports: [ AgGridModule, HttpClientModule ],
       providers: [{ provide: 'EnvName', useValue: 'DEV' }, {provide: ActivatedRoute, useValue: {params: of()}}]
    })
    .compileComponents();
  })); 

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityHoldersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
