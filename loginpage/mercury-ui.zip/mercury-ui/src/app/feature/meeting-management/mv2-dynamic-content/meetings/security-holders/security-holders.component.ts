import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { CommonService } from 'src/app/core/http/common.service';
import { Security } from 'src/app/shared/models/security.model';
import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs';

@Component({
  selector: 'mv2-security-holders',
  templateUrl: './security-holders.component.html',
  styleUrls: ['./security-holders.component.css']
})
export class SecurityHoldersComponent implements OnInit, OnDestroy {
  gridInfoObj: any;
  isSubmitHolderEnabled = false;
  holdersList = [];
  holdersDtlsSourceSubscription: Subscription;
  // @Output() emitHoldersList = new EventEmitter<any>();
  @Input('selectedSecurity') selectedSecurity: string;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.gridInfoObj = {
      columnDefs: [
        {
          headerName: '',
          field: 'selection',
          cellRendererFramework: ConfigRowSelectionComponent,
          width: 50,
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Rank',
          field: 'holderRank',
          width: 80,
          sort: 'asc',
          sortingOrder: ['desc', 'asc'],
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada', 'text-align': 'center' }
        },
        {
          headerName: 'Name',
          field: 'Attendee',
          width: 190,
          sortable: true,
          sortingOrder: ['desc', 'asc'],
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Call-In',
          field: 'Call-In',
          // width: 70,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Invite',
          field: 'Invite',
          // width: 70,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Infopacks',
          field: 'Infopacks',
          // width: 100,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Info Only',
          field: 'Info Only',
          // width: 100,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        }],
      gridType: 'holdersGrid'
    }; 
    if (this.selectedSecurity === 'Fixed Income') {
     this.gridInfoObj.columnDefs.splice(1, 1);
      this.gridInfoObj.columnDefs.splice(4, 1);
    }
    this.holdersDtlsSourceSubscription = this.commonService.holdersDtlsSourceObservable.subscribe((response) => {
      if (response) {
        if (response.length !== 0) {
          this.isSubmitHolderEnabled = true;
          // this.cdr.detectChanges();
        } else {
          this.isSubmitHolderEnabled = false;
          // this.cdr.detectChanges();
  }
      }
    });
  }

  ngOnDestroy() {
    this.commonService.changeHoldersList([]);
    if (this.holdersDtlsSourceSubscription) {
      this.holdersDtlsSourceSubscription.unsubscribe();
  }
  }
  getSelectedHolders(event) {
    this.holdersList = event
    if (this.holdersList.length !== 0) {
      this.isSubmitHolderEnabled = true;
      // this.emitHoldersList.emit(this.holdersList);
    } else {
      this.isSubmitHolderEnabled = false;
  }
  }
  onSubmit() {
    if (this.isSubmitHolderEnabled) {
      this.commonService.changeHoldersList(this.holdersList);
    }
  }
}
