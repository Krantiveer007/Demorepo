import { Component, OnInit, NgZone } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable, EMPTY, Subscription } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { Output, Input } from '@angular/core';
import { EventEmitter, TemplateRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterExternalContactResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadData, TypeaheadDataSource } from 'src/app/shared/utils/typeahead.utility';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
@Component({
  selector: 'mv2-arrangement-contact-details',
  templateUrl: './arrangement-contact-details.component.html',
  styleUrls: ['./arrangement-contact-details.component.css']
})
export class ArrangementContactDetailsComponent implements OnInit {
  utilDataObservable: Observable<any>;
  brkUsageInitiator: any[];
  utilData: any[];
  organizerDataSource: Observable<any>;
  organizerDataSubscription: Subscription;
  typeaheadLoading: boolean;
  companyLabel = 'Broker Firm Name';
  errorResponse = false;
  arrangmentDtlsForm = this.fb.group({
    organizedThrough: [''],
    organizerContactId: [''],
    organizerName: [''],
    organizerEmail: ['', Validators.email],
    organizerCompany: [''],
    organizerPhone: [''],
    organizerPosition: [''],
    brokerUsageInitiator: ['Company'],
  });
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
  configSecond = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'second'
  };
  plusIconImage = {
    'enabled': '/assets/images/group-1424-copy.svg',
    'disabled': '/assets/images/group-1424-copy-5.svg'
  };
  plusImageSrc = this.plusIconImage.enabled
  // Validators.pattern("^[0-9]*$")
  invalidEmail = false;
  invalidPhNo = false;
  isValidOrganizer = false;
  organizerContacts: any = [];
  contactTypes = ['Broker', 'Company', 'Others'];
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  arrangementContactDetails = new ArrangementContact('', '', '', '', '', '', '', '');
  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  routeConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
  isSubmitEnabled = false;
  contactList = [];
  resetMeetingDetailSubscription: Subscription;
  meetingType: string = "Broker";
  @Output() formReady = new EventEmitter<FormGroup>();
  @Input() configData: any;
  @Input('selectedSecurity') selectedSecurity: string;
  constructor(private fb: FormBuilder, private commonService: CommonService, private ngZone: NgZone, private route: ActivatedRoute, private modalService: BsModalService) { }

  ngOnInit() {
    this.formReady.emit(this.arrangmentDtlsForm);
    this.fetchUtilData();
    this.arrangmentDtlsForm.patchValue({
      organizedThrough: this.configData.defaultMeetingType
    });
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.isValidOrganizer = true;
        this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response && response.arrangementContact) {
            this.arrangmentDtlsForm.patchValue({
              organizedThrough: response.arrangementContact.organizedThrough ? (response.arrangementContact.organizedThrough.includes('Other') ? 'Others' : response.arrangementContact.organizedThrough) : this.configData.defaultMeetingType,
              organizerContactId: response.arrangementContact.organizerContactId ? response.arrangementContact.organizerContactId : '',
              organizerName: response.arrangementContact.organizerName ? response.arrangementContact.organizerName : '',
              organizerEmail: response.arrangementContact.organizerEmail ? response.arrangementContact.organizerEmail : '',
              organizerCompany: response.arrangementContact.organizerCompany ? response.arrangementContact.organizerCompany : '',
              organizerPhone: response.arrangementContact.organizerPhone ? response.arrangementContact.organizerPhone : '',
              organizerPosition: response.arrangementContact.organizerPosition ? response.arrangementContact.organizerPosition : ''
            });
          }
        });
      }
    });
    this.resetMeetingDetailSubscription = this.commonService.resetMeetingDetailsSubject.subscribe((response) => {
      if (response) {
        this.resetOrganizerDtls();
      }
    });
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.brkUsageInitiator = this.utilData.filter(element => element.UtilKeyName === 'brokerUsageInitiator');
      }
    },
      (error) => {
        console.log(error);
      });
  }

  resetOrganizerDtls() {
    this.arrangmentDtlsForm.patchValue({
      'organizerName': '',
      'organizerEmail': '',
      'organizerCompany': '',
      'organizerPhone': '',
      'organizerPosition': '',
      'organizerContactId': '',
      'brokerUsageInitiator': 'Company'
    });
    this.typeaheadNoResults(true);
    this.typeaheadLoading = false;
    this.errorResponse = false;
    // this.companyLabel = (this.arrangmentDtlsForm.get('organizedThrough').value === 'Broker') ? 'Broker Firm Name' : 'Broker Firm Name';
  }

  onBlurMethod() {
    if (!this.isValidOrganizer) {
      this.arrangmentDtlsForm.patchValue({
        organizerName: '',
        organizerContactId: ''
      });
      this.typeaheadLoading = false;
      this.getOrganizerData();
    }
  }

  getOrganizerData(): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.arrangmentDtlsForm.get('organizerName').value;
    this.arrangmentDtlsForm.patchValue({
      'organizerContactId': ''
    });
    if (this.arrangmentDtlsForm.get('organizedThrough').value === 'Company') {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue.toUpperCase(),
        '',
        'Company',
        '');
    } else {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue.toUpperCase(),
        '',
        this.arrangmentDtlsForm.get('organizedThrough').value,
        '');
    }
    this.organizerDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
    if (searchedValue.length === 0) {
      this.resetOrganizerDtls();
    }
  }

  changeTypeaheadLoading(e: boolean): void {
    this.typeaheadLoading = e;
  }

  typeaheadOnSelect(event) {
    let oraganizerDetailsInstance = event;

    const organizedThrough = this.arrangmentDtlsForm.get('organizedThrough').value;
    let organizedCompanyName = '';
    let trdEndId = '';
    this.isValidOrganizer = true;
    if (organizedThrough === 'Company') {
      // trdEndId = oraganizerDetailsInstance.item.TradableEntityId ? oraganizerDetailsInstance.item.TradableEntityId : '';
      this.arrangmentDtlsForm.patchValue({
        'organizerName': oraganizerDetailsInstance.item.fullname ? convertToTitleCase(oraganizerDetailsInstance.item.fullname) : '',
        'organizerContactId': oraganizerDetailsInstance.item.externalId ? oraganizerDetailsInstance.item.externalId : '',
        'organizerEmail': oraganizerDetailsInstance.item.emailId ? oraganizerDetailsInstance.item.emailId : '',
        'organizerCompany': oraganizerDetailsInstance.item.company ? convertToTitleCase(oraganizerDetailsInstance.item.company) : '',
        'organizerPhone': oraganizerDetailsInstance.item.telephoneNo ? oraganizerDetailsInstance.item.telephoneNo : '',
        'organizerPosition': oraganizerDetailsInstance.item.position ? oraganizerDetailsInstance.item.position : ''
      });
    } else {
      organizedCompanyName = (organizedThrough === 'Broker')
        ? oraganizerDetailsInstance.item.firmName
        : oraganizerDetailsInstance.item.company;
      this.arrangmentDtlsForm.patchValue({
        'organizerName': oraganizerDetailsInstance.item.fullname ? convertToTitleCase(oraganizerDetailsInstance.item.fullname) : '',
        'organizerContactId': oraganizerDetailsInstance.item.externalId ? oraganizerDetailsInstance.item.externalId : '',
        'organizerEmail': oraganizerDetailsInstance.item.emailId ? oraganizerDetailsInstance.item.emailId : '',
        'organizerCompany': organizedCompanyName ? convertToTitleCase(organizedCompanyName) : '',
        'organizerPhone': oraganizerDetailsInstance.item.telephoneNo ? oraganizerDetailsInstance.item.telephoneNo : '',
        'organizerPosition': oraganizerDetailsInstance.item.position ? convertToTitleCase(oraganizerDetailsInstance.item.position) : ''
      });
    }
    this.arrangementContactDetails.organizedThrough = this.arrangmentDtlsForm.get('organizedThrough').value ? this.arrangmentDtlsForm.get('organizedThrough').value : '';
    this.arrangementContactDetails.organizerContactId = this.arrangmentDtlsForm.get('organizerContactId').value ? this.arrangmentDtlsForm.get('organizerContactId').value : '';
    this.arrangementContactDetails.organizerName = this.arrangmentDtlsForm.get('organizerName').value ? this.arrangmentDtlsForm.get('organizerName').value : '';
    this.arrangementContactDetails.organizerCompany = this.arrangmentDtlsForm.get('organizerCompany').value ? this.arrangmentDtlsForm.get('organizerCompany').value : '';
    this.arrangementContactDetails.organizerPhone = this.arrangmentDtlsForm.get('organizerPhone').value ? this.arrangmentDtlsForm.get('organizerPhone').value : '';
    this.arrangementContactDetails.organizerEmail = this.arrangmentDtlsForm.get('organizerEmail').value ? this.arrangmentDtlsForm.get('organizerEmail').value : '';
    this.arrangementContactDetails.organizerPosition = this.arrangmentDtlsForm.get('organizerPosition').value ? this.arrangmentDtlsForm.get('organizerPosition').value : '';
    this.commonService.setArrangementContactDetails(this.arrangementContactDetails);
  }

  typeaheadNoResults(event: boolean): void {
    this.errorResponse = event;
  }


  checkEmail() {
    if (this.arrangmentDtlsForm.get('organizerEmail') && this.arrangmentDtlsForm.get('organizerEmail').errors && this.arrangmentDtlsForm.get('organizerEmail').errors !== null && this.arrangmentDtlsForm.get('organizerEmail').errors.email) {
      this.invalidEmail = true;
    } else {
      this.invalidEmail = false;
    }
  }
  searchExternalContacts(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
  }
  getSelectedContactList(event) {
    this.contactList = event;
    if (this.contactList.length !== 0) {
      this.routeConfirmMessage = 'Selected third party contacts will not be added to the meeting. Are you sure you want to exit ?'
      this.isSubmitEnabled = true;
    } else {
      this.isSubmitEnabled = false;
    }
  }
  checkForNewAttendeeEntry(templateNested: TemplateRef<any>) {
    if (this.isSubmitEnabled) {
      this.modalRef2 = this.modalService.show(templateNested, this.configSecond);
    }
    else {
      this.modalRef.hide();
    }
  }
  decline() {
    this.modalRef2.hide();
  }

  confirm() {
    this.modalRef2.hide();
    this.modalRef.hide();
  }
  onSubmit() {
    if (this.isSubmitEnabled) {
      const contact = this.contactList[0].contactTypeObj.contact;
      this.arrangmentDtlsForm.patchValue({
        'organizerName': contact.fullName,
        'organizerEmail': contact.email,
        'organizerCompany': this.contactList[0].Company,
        'organizerPhone': contact.telephone,
        'organizerPosition': this.contactList[0].Position,
        'organizerContactId': this.contactList[0].ExternalContactId
        // 'brokerUsageInitiator': contact.contactTypes
      });
    this.arrangementContactDetails.organizedThrough = this.arrangmentDtlsForm.get('organizedThrough').value ? this.arrangmentDtlsForm.get('organizedThrough').value : '';
    this.arrangementContactDetails.organizerContactId = this.arrangmentDtlsForm.get('organizerContactId').value ? this.arrangmentDtlsForm.get('organizerContactId').value : '';
    this.arrangementContactDetails.organizerName = this.arrangmentDtlsForm.get('organizerName').value ? this.arrangmentDtlsForm.get('organizerName').value : '';
    this.arrangementContactDetails.organizerCompany = this.arrangmentDtlsForm.get('organizerCompany').value ? this.arrangmentDtlsForm.get('organizerCompany').value : '';
    this.arrangementContactDetails.organizerPhone = this.arrangmentDtlsForm.get('organizerPhone').value ? this.arrangmentDtlsForm.get('organizerPhone').value : '';
    this.arrangementContactDetails.organizerEmail = this.arrangmentDtlsForm.get('organizerEmail').value ? this.arrangmentDtlsForm.get('organizerEmail').value : '';
    this.arrangementContactDetails.organizerPosition = this.arrangmentDtlsForm.get('organizerPosition').value ? this.arrangmentDtlsForm.get('organizerPosition').value : '';
    this.commonService.setArrangementContactDetails(this.arrangementContactDetails);
      this.commonService.changeExternalContactList(this.contactList);

    }
    this.modalRef.hide();
    if (this.modalRef2) {
      this.modalRef2.hide();
    }
  }
  ngOnDestroy() {
    if (this.resetMeetingDetailSubscription) {
      this.resetMeetingDetailSubscription.unsubscribe();
    }
  }
}
