import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { EventDetailsComponent } from './event-details.component';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { TimepickerModule, BsModalService, ModalModule } from 'ngx-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
declare var jquery: any;
declare var $: any;
import { Observable } from 'rxjs';
import { of, throwError } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { TooltipModule, TypeaheadModule } from 'ngx-bootstrap';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { MeetingManagementComponent } from '../../meeting-management.component';
import { Mv2DynamicContentComponent } from '../../mv2-dynamic-content/mv2-dynamic-content.component';
import { Mv2StaticContentComponent } from '../../mv2-static-content/mv2-static-content.component';
import { InviteesDetailsComponent } from '../invitees-details/invitees-details.component';
import { MeetingDetailsComponent } from '../meeting-details/meeting-details.component';
import { ThirdPartyAttendeeComponent } from '../third-party-attendee/third-party-attendee.component';
import { AdditionalNotesComponent } from '../additional-notes/additional-notes.component';
import { OrganizerDetailsComponent } from '../organizer-details/organizer-details.component';
import { AgGridModule } from 'ag-grid-angular';
import { APP_BASE_HREF } from '@angular/common';
import { IntlModule } from '@progress/kendo-angular-intl';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { BsDropdownModule } from 'ngx-bootstrap';
import { IntlService } from '@progress/kendo-angular-intl';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
const appRoutes: Routes = [
  { path: 'meeting/:action', component: MeetingManagementComponent }
];

describe('EventDetailsComponent', () => {
  let component: EventDetailsComponent;
  let fixture: ComponentFixture<EventDetailsComponent>;
  const options = {
    hour: {
      value: 0,
      min: 0,
      max: 24,
      step: 1,
      symbol: 'h'
    },
    minute: {
      value: 0,
      min: 0,
      max: 60,
      step: 15,
      symbol: 'mins'
    },
    direction: 'increment', // increment or decrement
    inputHourTextbox: null, // hour textbox
    inputMinuteTextbox: null, // minutes textbox
    postfixText: '', // text to display after the input fields',
    numberPaddingChar: '0' // number left padding character ex: 00052
  };

  const utilData = [
    { KeyDesc: 'Fixed Income', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'FIXI' },
    { KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Other', KeyCode: 'GOVTBDY' },
    { KeyDesc: 'APxJ - Country Position', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Internal#APxJ', KeyCode: 'CNP' },
    { KeyDesc: 'APxJ - Industry Review', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Internal#APxJ', KeyCode: 'ISRA' },
    { KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPRSLT' },
    { KeyDesc: 'Grp Small', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GRPSMALL' },
    { KeyDesc: 'Governance', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes#Company', KeyCode: 'GVRN' },
    { KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' },
    { KeyDesc: 'LDN 1G', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1G', Region: 'EUR' },
    { KeyDesc: 'LDN 1H', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1H', Region: 'EUR' },
    { KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' },
    { UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' },
    { UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FCAM', KeyCode: 'FCAM' },
    { UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FIL', KeyCode: 'FIL' },
    { MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR' },
    { MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP' },
    { UtilKeyName: 'businessUnits', KeyCode: 'FI - TOK', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - HKG', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - LON', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' },
    {
      Cities: 'Camabatela',
      Country: 'Angola',
      GRD_COUNTRY_CD: 'ANGL',
      ISO_COUNTRY_CD: 'AO',
      KeyCode: 'AO#Camabatela',
      UtilKeyName: 'country-city-map'
    }
  ];


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TimepickerModule.forRoot(),
        NgSelectModule,
        HttpClientModule,
        ModalModule.forRoot(),
        TooltipModule.forRoot(),
        RouterModule.forRoot(appRoutes),
        AgGridModule.withComponents([]),
        TimePickerModule,
        BrowserModule,
        BrowserAnimationsModule,
        BsDropdownModule.forRoot(),
        TypeaheadModule.forRoot()
      ],
      declarations: [EventDetailsComponent, MeetingManagementComponent, Mv2DynamicContentComponent,
        Mv2StaticContentComponent, InviteesDetailsComponent, OrganizerDetailsComponent,
        MeetingDetailsComponent, ThirdPartyAttendeeComponent, CommonGridComponent, AdditionalNotesComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, BsModalService,
      { provide: APP_BASE_HREF, useValue: '/' }, { provide: ActivatedRoute, useValue: { params: of() } }],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // UtilData test cases

  it('should return list of utilData and should populate in respective placeholders', () => {
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    // const spy = spyOn(peopleDataService, 'utilMessageObservable').and.returnValue(of(utilData));
    peopleDataService.utilMessageObservable = of(utilData);
    fixture.detectChanges();
    component.fetchUtilData();
    fixture.detectChanges();
    component.utilDataObservable.subscribe(response => {
      expect(response).toEqual(utilData);
      expect(component.rooms).toEqual([
        { KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR' },
        { KeyDesc: 'LDN 1G', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1G', Region: 'EUR' },
        { KeyDesc: 'LDN 1H', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1H', Region: 'EUR' },
        { KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR' }
      ]);
      expect(component.cityCountry).toEqual([
        {
          Cities: 'Camabatela', Country: 'Angola', GRD_COUNTRY_CD: 'ANGL', ISO_COUNTRY_CD: 'AO',
          KeyCode: 'AO#Camabatela', UtilKeyName: 'country-city-map', cityCountryVal: 'Camabatela, Angola'
        }]);
    });
  });


  // Test cases for date picker
  it('should find jquery', () => {
    expect($).not.toBeNull();
  });

  it('should enable flag morethanoneyearvalue if date select is more than one year past', () => {
    $('#datepicker').datepicker('setDate', '15/01/2015');
    $('#datepicker').change();
    component.checkInvalidDate();
    component.checkMoreThanOneYearDate();
    fixture.detectChanges();
    expect(component.eventForm.get('date').errors.moreThanOneYearDate).toEqual(true);
    expect(component.eventForm.get('date').value).toEqual('15/01/2015');
    expect(component.eventForm.get('date').errors).not.toBeNull;
    expect(component.checkInvalidDate()).toEqual(false);
    expect(component.checkMoreThanOneYearDate()).toEqual(true);
  });

  it('should enable popup with Yes and No button if date select is within past one year', () => {
    $('#datepicker').datepicker('setDate', '15/01/2019');
    expect(component.modalRef).toBeNull;
    $('#datepicker').change();
    component.checkInvalidDate();
    component.checkMoreThanOneYearDate();
    fixture.detectChanges();
    expect(component.modalRef).not.toBeNull;
    expect(component.eventForm.get('date').value).toEqual('15/01/2019');
    expect(component.checkInvalidDate()).toEqual(false);
    expect(component.checkMoreThanOneYearDate()).toEqual(false);
  });

// check --------------------------------------------
  it('should hide dialog box if user allows creation of past date meeting (within past one year)'
    + 'and date should be set as the one selected by user', () => {
      $('#datepicker').datepicker('setDate', '15/01/2019');
      $('#datepicker').change();
      expect(component.modalRef).not.toBeNull;
      component.confirm();
      component.checkInvalidDate();
      component.checkMoreThanOneYearDate();
      fixture.detectChanges();
      expect(component.modalRef).toBeNull;
      expect(component.eventForm.get('date').value).toEqual('15/01/2019');
      expect(component.previousDate).toEqual($('#datepicker').datepicker('getDate'));
      expect(component.eventForm.get('date').errors).toBeNull;
      expect(component.checkInvalidDate()).toEqual(false);
      expect(component.checkMoreThanOneYearDate()).toEqual(false);
    });

  it('should hide dialog box if user denies creation of past date meeting (within past one year)'
    + 'and date should be null (if no previously selected date exisits)', () => {
      component.previousDate = '';
      $('#datepicker').datepicker('setDate', '15/01/2019');
      $('#datepicker').change();
      expect(component.modalRef).not.toBeNull;
      component.decline();
      component.checkInvalidDate();
      component.checkMoreThanOneYearDate();
      fixture.detectChanges();
      expect(component.modalRef).toBeNull;
      expect(component.eventForm.get('date').value).toEqual('');
      expect(component.checkInvalidDate()).toEqual(false);
      expect(component.checkMoreThanOneYearDate()).toEqual(false);
    });

  it('should hide dialog box if user denies creation of past date meeting (within past one year)'
    + 'and date should be previously selected date', () => {
      component.previousDate = '12/01/2019';
      $('#datepicker').datepicker('setDate', '15/01/2019');
      $('#datepicker').change();
      expect(component.modalRef).not.toBeNull;
      component.decline();
      component.checkInvalidDate();
      component.checkMoreThanOneYearDate();
      fixture.detectChanges();
      expect(component.modalRef).toBeNull;
      expect(component.eventForm.get('date').value).toEqual('12/01/2019');
      expect(component.eventForm.get('date').errors).toBeNull;
      expect(component.checkInvalidDate()).toEqual(false);
      expect(component.checkMoreThanOneYearDate()).toEqual(false);
    });
// check complete ----------------------------
  it('should be able to select current date as meeting date', () => {
    $('#datepicker').datepicker('setDate', new Date());
    $('#datepicker').change();
    component.checkInvalidDate();
    component.checkMoreThanOneYearDate();
    fixture.detectChanges();
    expect(component.eventForm.get('date').value).toEqual($('#datepicker').val());
    expect(component.previousDate).toEqual($('#datepicker').datepicker('getDate'));
    expect(component.eventForm.get('date').errors).toBeNull;
    expect(component.checkInvalidDate()).toEqual(false);
    expect(component.checkMoreThanOneYearDate()).toEqual(false);
  });

  it('should be able to select future date as meeting date', () => {
    $('#datepicker').datepicker('setDate', '12/01/2026');
    $('#datepicker').change();
    component.checkInvalidDate();
    component.checkMoreThanOneYearDate();
    fixture.detectChanges();
    expect(component.eventForm.get('date').value).toEqual('12/01/2026');
    expect(component.previousDate).toEqual($('#datepicker').datepicker('getDate'));
    expect(component.eventForm.get('date').errors).toBeNull;
    expect(component.checkInvalidDate()).toEqual(false);
    expect(component.checkMoreThanOneYearDate()).toEqual(false);
  });

  it('should throw error if date is invalid', () => {
    component.eventForm.patchValue({
      date: '12/1254/1254789'
    });
    component.checkInvalidDate();
    component.checkMoreThanOneYearDate();
    fixture.detectChanges();
    expect(component.eventForm.get('date').errors.invalidDate).toEqual(true);
    expect(component.checkInvalidDate()).toEqual(true);
    expect(component.checkMoreThanOneYearDate()).toEqual(false);
  });


  // Test cases for timepicker

  it('should have default hours and minutes as 00', () => {
    expect(component.eventForm.get('time').value).toEqual(new Date(0, 0, 0, 0));
  });

  it('should check if time is 0000 then Please enter valid meeting time should be shown', () => {
    component.eventForm.patchValue({
      time: new Date('Sun Dec 31 1899 00:00:00 GMT+0521 (India Standard Time)')
    });
    component.timeChange('Sun Dec 31 1899 00:00:00 GMT+0521 (India Standard Time)');
    fixture.detectChanges();
    expect(component.eventForm.get('time').errors.timeRequired).toEqual(true);
    expect(component.checkInvalidTime()).toEqual(true);
    const de = fixture.debugElement.query(By.css('.responseWidthTime'));
    const el = de.nativeElement;
    expect(el).toBeTruthy();
  });
  it('should not show :Please enter valid meeting time should be shown, if  valid time is entered', () => {
    component.eventForm.patchValue({
      time: new Date('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)')
    });
    component.timeChange('Sun Dec 31 1899 00:02:00 GMT+0521 (India Standard Time)');
    fixture.detectChanges();
    expect(component.eventForm.get('time').errors).toEqual(null);
    expect(component.checkInvalidTime()).toEqual(false);
  });





  // Test cases for duration

  it('should have default meeting duration value as 60 minutes', () => {
    expect($('.duration').timesetter().getHoursValue()).toEqual(1);
    expect($('.duration').timesetter().getMinutesValue()).toEqual(0);
    expect(component.eventForm.get('duration').value).toEqual(60);
  });

  it('should be able to attain value for duration as enetered by user', () => {
    $('.duration').timesetter(options).setHour(12);
    $('.duration').timesetter(options).setMinute(30);
    expect(component.eventForm.get('duration').value).toEqual(750);
  });

  it('should throw error if duration entered by user is 0000', () => {
    $('.duration').timesetter(options).setHour(0);
    $('.duration').timesetter(options).setMinute(0);
    component.checkInvalidDuration();
    fixture.detectChanges();
    expect(component.eventForm.get('duration').value).toEqual(0);
    expect(component.eventForm.get('duration').errors.invalidDuration).toEqual(true);
    expect(component.checkInvalidDuration()).toEqual(true);
    const de = fixture.debugElement.query(By.css('.responseWidthDuration'));
    const el = de.nativeElement;
    expect(el).toBeTruthy();
  });

  // Test cases for city and country and timezone

  it('should display timezone in tooltip when city/country is selected and timezone exists', () => {
    component.eventForm.patchValue(
      {
        cityCountry: {
          Cities: 'Ajmer', Country: 'India', GRD_COUNTRY_CD: 'IND',
          ISO_COUNTRY_CD: 'IN', KeyCode: 'IN#Ajmer', UtilKeyName: 'country-city-map', cityCountryVal: 'Ajmer, India'
        }
      });
    component.populateTimeZone(
      {
        Cities: 'Ajmer', Country: 'India', GRD_COUNTRY_CD: 'IND', ISO_COUNTRY_CD: 'IN',
        KeyCode: 'IN#Ajmer', UtilKeyName: 'country-city-map', cityCountryVal: 'Ajmer, India'
      });
    expect(component.eventForm.get('timezone').value).toEqual('Asia/Kolkata GMT+5:30');
  });

  it('should display timezone in tooltip when city/country is selected and timezone is not proper like CST/AST', () => {
    component.populateTimeZone(
      {
        Cities: 'Victoria', Country: 'Canada', GRD_COUNTRY_CD: 'CANA', ISO_COUNTRY_CD: 'CA',
        KeyCode: 'CA#Victoria', UtilKeyName: 'country-city-map', cityCountryVal: 'Victoria, Canada'
      });
    expect(component.eventForm.get('timezone').value).toEqual('America/Vancouver PDT');
  });

  it('should display timezone in tooltip when city/country is selected and city name is'
    + 'duplicate for two records and timezone exists for both', () => {
      component.populateTimeZone(
        {
          Cities: 'Sydney', Country: 'Australia', GRD_COUNTRY_CD: 'ASTL', ISO_COUNTRY_CD: 'AU', KeyCode: 'AU#Sydney',
          UtilKeyName: 'country-city-map', cityCountryVal: 'Sydney, Australia'
        });
      expect(component.eventForm.get('timezone').value).toEqual('Australia/Sydney GMT+10');
    });


   it('should have cityCountry value, errorresponse, timezone blank when value to be searched is typed in typeahead', () => {
      component.eventForm.patchValue({
        cityCountryName: 'del'
      });
      component.getCityCountry();
      fixture.detectChanges();
      expect(component.eventForm.get('cityCountry').value).toEqual({ 
      'Cities': '',
      'Country': '',
      'GRD_COUNTRY_CD': '',
      'ISO_COUNTRY_CD': '',
      'KeyCode': '',
      'UtilKeyName': '',
      'cityCountryVal': ''
    });
    expect(component.eventForm.get('timezone').value).toEqual('');
    expect(component.errorResponse).toEqual(false);
    });

    it('should populate timezone and cityCountryVlaue when value is selected from typeahead dropdown', () => {
      const event = { 'header': false, 
'item': {
'Cities': 'Delhi',
'Country': 'India',
'GRD_COUNTRY_CD': 'IND',
'ISO_COUNTRY_CD': 'IN',
'KeyCode': 'IN#Delhi',
'UtilKeyName': 'country-city-map',
'cityCountryVal': 'Delhi, India'
}, 
'value': 'Delhi, India'
      }

      component.typeaheadOnSelect(event);
      fixture.detectChanges();
      expect(component.eventForm.get('cityCountry').value).toEqual({ 
      'Cities': 'Delhi',
      'Country': 'India',
      'GRD_COUNTRY_CD': 'IND',
      'ISO_COUNTRY_CD': 'IN',
      'KeyCode': 'IN#Delhi',
      'UtilKeyName': 'country-city-map',
      'cityCountryVal': 'Delhi, India'
    });
    expect(component.eventForm.get('timezone').value).toEqual('Asia/Kolkata GMT+5:30');
    expect(component.errorResponse).toEqual(false);
    expect(component.isValidCity).toEqual(true);
    });

  
   it('should have cityCountry value, errorresponse, timezone blank when value to be searched is typed in typeahead, value from typeahead is not selected and focus is lost', () => {
      component.eventForm.patchValue({
        cityCountryName: 'del'
      });
      component.getCityCountry();
    component.onCityBlur();
      fixture.detectChanges();
      expect(component.eventForm.get('cityCountry').value).toEqual({ 
      'Cities': '',
      'Country': '',
      'GRD_COUNTRY_CD': '',
      'ISO_COUNTRY_CD': '',
      'KeyCode': '',
      'UtilKeyName': '',
      'cityCountryVal': ''
    });
    expect(component.eventForm.get('timezone').value).toEqual('');
    expect(component.errorResponse).toEqual(false);
    });




  // it('shoud display error as Please enter country first if country is blank but city is not', () => {
  //   component.eventForm.setErrors({ countryRequired: true });
  //   component.checkCountryRequired();
  //   fixture.detectChanges();
  //   expect(component.checkCountryRequired()).toEqual(true);
  //   const de = fixture.debugElement.query(By.css('.responseWidthCountry'));
  //   const el = de.nativeElement;
  //   expect(el).toBeTruthy();

  // });

  // it('city can be blank if country is not blank', () => {
  //   component.eventForm.patchValue({
  //     country: {KeyDesc: "PANAMA", ActiveInd: "Y", UtilKeyName: "countries", KeyCode: "PANA", Region: "AME"},
  //     city: ''
  //   });
  //   fixture.detectChanges();
  //   expect(component.eventForm.errors).toEqual(null);
  // });

  // it('country cannot be blank if city is not blank', () => {
  //   component.eventForm.patchValue({
  //     country: {KeyDesc: '', ActiveInd: '', UtilKeyName: '', KeyCode: '', Region: ''},
  //     city: 'Austria'
  //   });
  //   fixture.detectChanges();
  //   expect(component.eventForm.errors.countryRequired).toEqual(true);
  // });



  // Test cases for location, room and address
  it('should have location as internal and room as default', () => {
    fixture.detectChanges();
    const de = fixture.debugElement.query(By.css('.ngSelectPicker'));
    const el = de.nativeElement;
    expect(component.eventForm.get('location').value).toEqual('In-house');
    expect(component.eventForm.get('room').value).toEqual(
      { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' });
    expect(el).toBeTruthy();
  });

  it('should have venue as room as when location is internal', () => {
    component.eventForm.patchValue({
      location: 'In-house'
    });
    const de = fixture.debugElement.query(By.css('.ngSelectPicker'));
    const el = de.nativeElement;
    fixture.detectChanges();
    expect(el).toBeTruthy();
  });

  it('should have venue as address as when location is external', () => {
    component.eventForm.patchValue({
      location: 'External'
    });
    fixture.detectChanges();
    const de = fixture.debugElement.query(By.css('.addressStyle'));
    const el = de.nativeElement;
    expect(el).toBeTruthy();
  });

  it('should have room and address value as null whenever location is swtiched', () => {
    component.setVenue();
    fixture.detectChanges();
    expect(component.eventForm.get('room').value).toEqual(
      { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' });
    expect(component.eventForm.get('address').value).toEqual('');
  });

 it('should throw error if more than 300 characters has been entered in address field', () => {
    component.eventForm.patchValue({
      address: 'Apart from counting words and characters, our online editor can help you to improve word choice and writing'
        + 'style, and, optionally, help you to detect grammar mistakes and plagiarism. To check word count, simply place your'
        + 'cursor into the text box above and start typing. You the number of characters.  decrease as you type, delete, and'
        + 'edit them. You can also copy and paste text from another program over into the online editor above. The Auto-Save'
        + ' feature will make sure you wont lose any changes while editing, even if you leave the site and come back later'
    });
    component.checkAddressLength();
    expect(component.checkAddressLength()).toEqual(true);
    fixture.detectChanges();
    const de = fixture.debugElement.query(By.css('.responseWidthaddress'));
    const el = de.nativeElement;
    expect(el).toBeTruthy();
  });
  // Test cases for Dial in, dial in picker and access code
  it('should have dial in as unchecked, access code as disbled and dial in picker as disbled by default', () => {
    expect(component.eventForm.get('dailin').value).toEqual(false);
    expect(component.eventForm.controls.dailpicker.status).toEqual('DISABLED');
    expect(component.eventForm.controls.accesscode.status).toEqual('DISABLED');
  });

  it('should enable dial picker and access code if dial in is checked and the values should be null', () => {
    component.eventForm.patchValue({
      dailin: true
    });
    component.onChange(true);
    fixture.detectChanges();
    expect(component.eventForm.controls.dailpicker.status).toEqual('VALID');
    expect(component.eventForm.controls.accesscode.status).toEqual('VALID');
    expect(component.eventForm.get('dailpicker').value).toEqual('');
    expect(component.eventForm.get('accesscode').value).toEqual('');
  });

  it('should disable dial picker and access code if dial in is unchecked and the values should be null', () => {
    component.eventForm.patchValue({
      dailin: false
    });
     component.onChange(false);
    fixture.detectChanges();
    expect(component.eventForm.controls.dailpicker.status).toEqual('DISABLED');
    expect(component.eventForm.controls.accesscode.status).toEqual('DISABLED');
    expect(component.eventForm.get('dailpicker').value).toEqual('');
    expect(component.eventForm.get('accesscode').value).toEqual('');
  });

  it('should throw error if more than 100 characters has been entered in dialpicker field', () => {
    component.eventForm.patchValue({
      dailpicker: 'Apart from counting words and characters, our online editor can help you to improve word choice and writing style'
    });
    component.checkDialLength();
    fixture.detectChanges();
    const de = fixture.debugElement.query(By.css('.responseWidthDial'));
    const el = de.nativeElement;
    expect(component.checkDialLength()).toEqual(true);
    expect(el).toBeTruthy();
  });

  it('should throw error if more than 50 characters has been entered in accesscode field', () => {
    component.eventForm.patchValue({
      accesscode: 'Apart from counting words and characters, our online editor can help you to improve word choice and writing style'
    });
    component.checkAccessCodeLength();
    fixture.detectChanges();
    const de = fixture.debugElement.query(By.css('.responseWidthDial'));
    const el = de.nativeElement;
    expect(component.checkAccessCodeLength()).toEqual(true);
    expect(el).toBeTruthy();
  });

   it('should throw error if dialin is checked and dial in number is empty', () => {
    component.eventForm.patchValue({
      dailin: true,
      dailpicker: '',
      accesscode: '123'
    });
    fixture.detectChanges();
   expect(component.eventForm.errors).toEqual({dialpickerRequired: true});   
  });

  it('should throw error if dialin is checked and accesscode is empty', () => {
    component.eventForm.patchValue({
      dailin: true,
      dailpicker: '123',
      accesscode: ''
    });
    fixture.detectChanges();
   expect(component.eventForm.errors).toEqual({accessCodeRequired: true});   
  });

  it('should not throw error if dialin is unchecked and dial picker and accesscode is empty', () => {
    component.eventForm.patchValue({
      dailin: false,
      dailpicker: '',
      accesscode: ''
    });
    fixture.detectChanges();
   expect(component.eventForm.errors).toEqual(null);   
  });

  it('should not throw error if dialin is checked and dial picker and accesscode is not empty', () => {
    component.eventForm.patchValue({
      dailin: true,
      dailpicker: '123',
      accesscode: '123'
    });
    fixture.detectChanges();
   expect(component.eventForm.errors).toEqual(null);   
  });
});
