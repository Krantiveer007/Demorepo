import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { APP_BASE_HREF } from '@angular/common';
import { AdditionalNotesComponent } from './additional-notes.component';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { of, throwError } from 'rxjs';
describe('AdditionalNotesComponent', () => {
  let component: AdditionalNotesComponent;
  let fixture: ComponentFixture<AdditionalNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalNotesComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        HttpClientModule
        ],
        providers: [{ provide: 'EnvName', useValue: 'DEV' },
      { provide: APP_BASE_HREF, useValue: '/' }, { provide: ActivatedRoute, useValue: { params: of() } }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should throw error and return true if additional notes length is greater than 1800', () => {
    component.additionalNoteForm.patchValue({
      additionalNotes: `Apart from counting words and characters, our online editor can help you to improve
       word choice and writing style, and, optionally, help you to detect grammar mistakes and plagiarism.
       To check word count, simply place your cursor into the text box above and start typing. You'll see
       the number of characters and words increase or decrease as you type, delete, and edit them. You can
       also copy and paste text from another program over into the online editor above. The Auto-Save feature
       will make sure you won't lose any changes while editing, even if you leave the site and come back later.
       Tip: Bookmark this page now. Knowing the word count of a text can be important. For example, if an
       author has to write a minimum or maximum amount of words for an article, essay, report, story, book,
       paper, you name it. WordCounter will help to make sure its word count reaches a specific requirement
       or stays within a certain limit. In addition, WordCounter shows you the top 10 keywords and keyword
       density of the article you're writing. This allows you to know which keywords you use how often and
       at what percentages. This can prevent you from over-using certain words or word combinations and
       check for best distribution of keywords in your writing. Disclaimer: We strive to make our tools as
       accurate as possible but we cannot guarantee it will always be so. Apart from counting words and
       characters, our online editor can help you to improve word choice and writing style, and, optionally,
       help you to detect grammar mistakes and plagiarism. To check word count, simply place your cursor into
       the text box above and start typing. You'll see the number of characters and words increase or decrease
       as you type, delete, and edit them. You can also copy and paste text from another program over into the
       online editor above. The Auto-Save feature will make sure you won't lose any changes while editing, even
       if you leave the site and come back later. Tip: Bookmark this page now.`
    });
    component.validateTextLength();
    fixture.detectChanges();
    expect(component.validateTextLength()).toEqual( true);
  });

   it('should not throw error and return false if additional notes length is greater than 1800', () => {
    component.additionalNoteForm.patchValue({
      additionalNotes: `Apart from counting words and characters, our online editor can help you to improve
       word choice and writing style, and, optionally, help you to detect grammar mistakes and plagiarism.
       To check word count, simply place your cursor into the text box above and start typing. You'll see
       the number of characters and words increase or decrease as you type, delete, and edit them.`
    });
    component.validateTextLength();
    fixture.detectChanges();
    expect(component.validateTextLength()).toEqual(false);
  });
});
