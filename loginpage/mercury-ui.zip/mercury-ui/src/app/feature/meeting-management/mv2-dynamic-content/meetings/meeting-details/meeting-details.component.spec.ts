import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { MeetingDetailsComponent } from './meeting-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule, TooltipModule } from 'ngx-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { CommonService } from 'src/app/core/http/common.service';
import { HttpClientModule } from '@angular/common/http';
import { UrlHandlerService } from 'src/app/shared/services/url-handler.service';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';

import { Observable } from 'rxjs';
import { of, throwError } from 'rxjs';
import { TitleCasePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';


describe('MeetingDetailsComponent', () => {
  let component: MeetingDetailsComponent;
  let fixture: ComponentFixture<MeetingDetailsComponent>;
  const service: CommonService = null;
  const peopleData =
    [{ 'corpId': 'A482682', 'displayName': 'SHEVADEKAR, SAPAN' },
    { 'corpId': 'A366680', 'displayName': 'MAINI, PANKAJ' },
    { 'corpId': 'A497865', 'displayName': 'GANDHI, PANKAJ' },
    { 'corpId': 'A501403', 'displayName': 'YADAV, PANKAJ' },
    { 'corpId': 'A498527', 'displayName': 'GUPTA, SAPAN' }
    ];

const utilData = [
{KeyDesc: 'Fixed Income', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Other', KeyCode: 'FIXI'},
{KeyDesc: 'Government Body', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Other', KeyCode: 'GOVTBDY'},
{KeyDesc: 'APxJ - Country Position', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Internal.APxJ', KeyCode: 'CNP'},
{KeyDesc: 'APxJ - Industry Review', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Internal.APxJ', KeyCode: 'ISRA'},
{KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GRPRSLT'},
{KeyDesc: 'Grp Small', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GRPSMALL'},
{KeyDesc: 'Governance', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GVRN'},
{KeyDesc: 'LDN 1F', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1F', Region: 'EUR'},
{KeyDesc: 'LDN 1G', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1G', Region: 'EUR'},
{KeyDesc: 'LDN 1H', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1H', Region: 'EUR'},
{KeyDesc: 'LDN 1I', ActiveInd: 'Y', UtilKeyName: 'meetingRooms', Country: 'UK', KeyCode: '1I', Region: 'EUR'},
{UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP'},
{UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FCAM', KeyCode: 'FCAM'},
{UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FIL', KeyCode: 'FIL'},
{MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR'},
{MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP'},
{UtilKeyName: 'locations', KeyDesc: 'External', KeyCode: 'External'},
{UtilKeyName: 'locations', KeyDesc: 'Internal', KeyCode: 'Internal'},
{UtilKeyName: 'businessUnits', KeyCode: 'FI - TOK', ActiveInd: 'Y'},
{UtilKeyName: 'businessUnits', KeyCode: 'MA - HKG', ActiveInd: 'Y'},
{UtilKeyName: 'businessUnits', KeyCode: 'MA - LON', ActiveInd: 'Y'},
{UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y'}
];


  const manipulatePeopleData = [
    'Shevadekar, Sapan' + ' &lt;' + 'A482682' + '&gt;',
    'Maini, Pankaj' + ' &lt;' + 'A366680' + '&gt;',
    'Gandhi, Pankaj' + ' &lt;' + 'A497865' + '&gt;',
    'Yadav, Pankaj' + ' &lt;' + 'A501403' + '&gt;',
    'Gupta, Sapan' + ' &lt;' + 'A498527' + '&gt;'
  ];

  const event: TypeaheadMatch = new TypeaheadMatch('Yadav, Pankaj &lt;A501403&gt;', 'Yadav, Pankaj &lt;A501403&gt;', false);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        TypeaheadModule.forRoot(),
        NgSelectModule,
        HttpClientModule,
        ReactiveFormsModule,
        TooltipModule.forRoot()
      ],
      declarations: [MeetingDetailsComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, TitleCasePipe, {provide: ActivatedRoute, useValue: {params: of()}}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeetingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


// UtilData test cases

  it('should return list of utilData and should populate in respective placeholders', () => {
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
   // const spy = spyOn(peopleDataService, 'utilMessageObservable').and.returnValue(of(utilData));
    peopleDataService.utilMessageObservable = of(utilData);
    fixture.detectChanges();
    component.fetchUtilData();
    fixture.detectChanges();
    component.utilDataObservable.subscribe(response => {
    expect(response).toEqual(utilData);
    expect(component.mtgSubTypeList).toEqual([
      {KeyDesc: 'Grp Result', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GRPRSLT'},
      {KeyDesc: 'Grp Small', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GRPSMALL'},
      {KeyDesc: 'Governance', ActiveInd: 'Y', UtilKeyName: 'meetingSubtypes.Company', KeyCode: 'GVRN'}]);
    expect(component.businessUnit).toEqual([
      {UtilKeyName: 'businessUnits', KeyCode: 'FI - TOK', ActiveInd: 'Y'},
      {UtilKeyName: 'businessUnits', KeyCode: 'MA - HKG', ActiveInd: 'Y'},
      {UtilKeyName: 'businessUnits', KeyCode: 'MA - LON', ActiveInd: 'Y'},
      {UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y'}]);
    expect(component.mtgInitiator).toEqual([
      {MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR'},
      {MeetingTypeCode: 'BRK', KeyDesc: 'Company', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'COMP'}
    ]);
    expect(component.brkUsageInitiator).toEqual([
      {UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP'},
      {UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FCAM', KeyCode: 'FCAM'},
      {UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'FIL', KeyCode: 'FIL'}
    ]);
    });
  });


  // Host name test cases
  it('should return list of people when 3 or more characters are typed in Meeting Host search box', () => {
    component.meetingDtlsForm.patchValue({ 'hostName': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData('Host');
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
    expect(response).toEqual(manipulatePeopleData);
    });
  });

 

  it('should throw error while fetching data from service', () => {
    component.meetingDtlsForm.patchValue({ 'hostName': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(throwError);
    fixture.detectChanges();
    component.getPeopleData('Host');
    fixture.detectChanges();
    component.peopleDataSource.subscribe((response) => { },
      (error) => {
        //  expect(component.peopledataSource).toBeNull;
      });
  });

  it('should return only name on typeheadselect for Meeting Host', () => {
    component.typeaheadOnSelect(event, 'Host');
    fixture.detectChanges();
    expect(component.meetingDtlsForm.get('hostName').value).toEqual('Yadav, Pankaj');
  });

  

  // it('should show error on person search if the searched results are not found', () => {
  //   component.typeaheadNoResults(true, 'Owner');
  //   expect(component.ownerErrorResponse).toEqual(true);
  // });
  it('should show error on person search if the searched results are not found', () => {
    component.typeaheadNoResults(false, 'Host');
    expect(component.hostErrorResponse).toEqual(false);
  });

  it('should catch boolean event and show loader on people search', () => {
    component.changeTypeaheadLoading(true, 'Host');
    expect(component.typeaheadLoading).toEqual(true);
  });
  // it('should catch boolean event and show loader on people search', () => {
  //   component.changeTypeaheadLoading(false, 'Owner');
  //   expect(component.ownerLoading).toEqual(false);
  // });
  it('should set business Unit Initiator to `Company` if meeting initiator is equal to broker', () => {
    component.meetingDtlsForm.patchValue(
    { 'meetingInitiator': {MeetingTypeCode: 'BRK', KeyDesc: 'Broker', ActiveInd: 'Y', UtilKeyName: 'meetingInitiatorType', KeyCode: 'BRKR'} });
    component.resetBrokerUsageInit();
    // expect(component.meetingDtlsForm.get('brokerUsage').enable()).toHaveBeenCalled;
    expect(component.meetingDtlsForm.get('brokerUsage').value).toEqual({UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP'});
  });
  it('should reset business Unit Initiator if meeting initiator is not equal to broker', () => {
    component.meetingDtlsForm.patchValue({ 'meetingInitiator': 'PM' });
    component.resetBrokerUsageInit();
    // expect(component.meetingDtlsForm.get('brokerUsage').enable()).toHaveBeenCalled;
    expect(component.meetingDtlsForm.get('brokerUsage').value).toEqual('');
  });

  it('should append the security name, meeting host and meeting subtype in email subject', () => {
    // component.message = 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201';

     const emailSubject ='ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201 - Grp 1:1 - Kanika';
    component.meetingDtlsForm.patchValue({ 
      'securityName': 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201',
     'hostName': 'Kanika',
     'mtgSubtype': { 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': 'Grp 1:1', 'UtilKeyName': '' }
    });
    component.appendSubjectLine('Subtype');
    component.appendSubjectLine('Security');
    expect(component.meetingDtlsForm.get('subjectLine').value).toEqual(emailSubject);
  });

  it('should show an error message(return True) when length of subjectLine is greater than 150 characters', () => {
    component.meetingDtlsForm.patchValue({
      'subjectLine':
        'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.' +
        'Aenean massa. Cum sociis natoque penatibus et magnis dis parturient'
    });
    const result = component.validateTextLength('subjectLine');
    expect(result).toEqual(true);
  });

  it('should show an error message(return True) when length of Additional Notes is greater than 1800 characters', () => {
    component.meetingDtlsForm.patchValue({
      'meetingNotes': 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.' +
        'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,' +
        'nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat' +
        'massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut,' +
        'imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus.' +
        'Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,' +
        'eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus' +
        'varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi.' +
        'Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing' +
        'sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt' +
        'tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt.' +
        'Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue' +
        'velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis' +
        'sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum' +
        'primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis' +
        'et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis,' +
        'et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis'
    });
    const result = component.validateTextLength('Notes');
    expect(result).toEqual(true);
  });
  it('should show return False when length of subjectLine is less than  150 characters', () => {
    component.meetingDtlsForm.patchValue({
      'subjectLine': 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.' +
        'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque'
    });
    const result = component.validateTextLength('subjectLine');
    expect(result).toEqual(false);
  });
  it('should show an return False when length of Additional Notes are less than  1800 characters', () => {
    component.meetingDtlsForm.patchValue({
      'meetingNotes': 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.' +
        'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,' +
        'nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat' +
        'massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut,' +
        'imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus.' +
        'Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,' +
        'eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus' +
        'varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi.' +
        'Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing' +
        'sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt' +
        'tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt.' +
        'Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue' +
        'velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis'
    });
    const result = component.validateTextLength('Notes');
    expect(result).toEqual(false);
  });
});
