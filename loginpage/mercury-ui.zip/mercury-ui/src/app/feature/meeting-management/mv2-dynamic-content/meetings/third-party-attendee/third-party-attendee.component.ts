import { Component, OnInit, ChangeDetectorRef, Input, OnDestroy } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { TemplateRef } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { FormBuilder } from '@angular/forms';
import { EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Output } from '@angular/core';
import { ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Params } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import * as moment from 'moment';
import { SimpleChanges } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'mv2-third-party-attendee',
  templateUrl: './third-party-attendee.component.html',
  styleUrls: ['./third-party-attendee.component.css']
})
export class ThirdPartyAttendeeComponent implements OnInit, OnDestroy {
  gridInfoObj: any;
  tradableEntityId: '';
  meetingType = '';
  enableCheckBox = true;
  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  removeExecutiveCheckbox = false;
  isSubmitEnabled = false;
  thirdPartyAttendeeForms = this.fb.group({
    thirdPartyAttendeeGrid: [null],
    meetingExecutive: [''],
  });
  contactList = [];
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
   configSecond = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'second'
  };
  plusIconImage = {
    'enabled': '/assets/images/group-1424-copy.svg',
    'disabled': '/assets/images/group-1424-copy-5.svg'
  };
  plusImageSrc = this.plusIconImage.enabled;
  messageHeading = 'Confirm Navigation';
  routeConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
  @Output() formReady = new EventEmitter<FormGroup>();
  @Input('selectedSecurity') selectedSecurity: string;
  updateMtgSubs: Subscription;
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private commonService: CommonService, private modalService: BsModalService) {
  }
  
  ngOnDestroy() {
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
  }
  ngOnInit() {
    this.thirdPartyAttendeeForms.get('meetingExecutive').disable();
    this.gridInfoObj = {
      rowData: [
        {
          'ExternalContactName': '',
          'ExternalContactId': '',
          'Company': '',
          'Email': '',
          'Position': '',
          'Notes': '',
          'Remove': ''
        },
        {
          'ExternalContactName': '',
          'ExternalContactId': '',
          'Company': '',
          'Email': '',
          'Position': '',
          'Notes': '',
          'Remove': ''
        },
        {
          'ExternalContactName': '',
          'ExternalContactId': '',
          'Company': '',
          'Email': '',
          'Position': '',
          'Notes': '',
          'Remove': ''
        }
        // {
        //   'ExternalContactName': '',
        //   'ExternalContactId': '',
        //   'Company': '',
        //   'Email': '',
        //   'Position': '',
        //   'Notes': '',
        //   'Remove': ''
        // }
      ],
      columnDefs: [
        {
          headerName: 'Attendee',
          field: 'ExternalContactName',
          width: 250,
          cellEditorFramework: ConfigInviteesDtlsComponent,
          editable: true,
          singleClickEdit: true,
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada'}
        },
        {
          headerName: 'Company',
          field: 'Company',
          // width: 170,
          cellRenderer: this.tooltipRenderer,
          cellStyle: { 'border-right': '1px solid #dadada'}
        },
        {
          headerName: 'Email',
          field: 'Email',
          // width: 170,
          cellRenderer: this.tooltipRenderer,
          cellStyle: { 'border-right': '1px solid #dadada'}
        },
        {
          headerName: 'Position',
          field: 'Position',
          // width: 120,
          cellRenderer: this.tooltipRenderer,
          cellStyle: { 'border-right': '1px solid #dadada'}
        },
        {
          headerName: 'Notes',
          field: 'Notes',
          // width: 80,
          cellRenderer: this.tooltipRenderer,
          cellStyle: { 'border-right': '1px solid #dadada'}
        },
        {
          headerName: 'Action',
          field: 'Remove',
          // width: 50,
          // pinned: 'right',
          cellRendererFramework: ConfigDeleteComponent,
          cellStyle: { 'text-align': 'center' }
        }],
      gridType: 'thirdPartyAttendeeGrid'
    };
    this.formReady.emit(this.thirdPartyAttendeeForms);
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
          this.meetingType = response.meetingType;
          this.thirdPartyAttendeeForms.patchValue({
            meetingExecutive: (response.executiveInvited === 'Y') ? true : false,
          });
          this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
        }
        });
      } else {
        this.meetingType = params['meetingType'];
      }
    });
    if (this.meetingType === 'Company') {
      this.commonService.tradableEntityIdObservable.subscribe((trdEntId) => {
        if (trdEntId) {
          this.thirdPartyAttendeeForms.get('meetingExecutive').enable();
        } else {
          this.thirdPartyAttendeeForms.get('meetingExecutive').disable();
        }
      });
    } else {
      this.removeExecutiveCheckbox = true;
      this.thirdPartyAttendeeForms.get('meetingExecutive').enable();
    }
  }
  ngOnChanges(change: SimpleChanges) {
  }
  private tooltipRenderer(params) {
    if (params.value === null) {
      return undefined;
    } else {
      return '<span title="' + params.value + '">' + params.value + '</span>';
    }
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.enableCheckBox = true;
    }

  }

  searchExternalContacts(template: TemplateRef<any>) {   
      this.modalRef = this.modalService.show(template, this.config);   
  }

  checkForNewAttendeeEntry(templateNested: TemplateRef<any>) {
    if (this.isSubmitEnabled) {
       this.modalRef2 = this.modalService.show(templateNested, this.configSecond);
    }
    else {
      this.modalRef.hide();
     }
  }

  decline() {
    this.modalRef2.hide();
  }

   confirm() {
    this.modalRef2.hide();
    this.modalRef.hide();
  }

  getSelectedContactList(event) {
     this.contactList = event;
     
    if (this.contactList.length !== 0) {
      this.routeConfirmMessage = 'Selected third party contacts will not be added to the meeting. Are you sure you want to exit ?'
      this.isSubmitEnabled = true;
    } else {
      this.isSubmitEnabled = false;
    }
  }

   onSubmit() {   
    if (this.isSubmitEnabled) {
      this.commonService.changeExternalContactList(this.contactList);
    }
    this.modalRef.hide();
    if (this.modalRef2) {
      this.modalRef2.hide();
    }
  }
}
