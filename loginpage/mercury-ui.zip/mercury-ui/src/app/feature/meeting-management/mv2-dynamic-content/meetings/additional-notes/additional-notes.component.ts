import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Subscription} from 'rxjs';
@Component({
  selector: 'mv2-additional-notes',
  templateUrl: './additional-notes.component.html',
  styleUrls: ['./additional-notes.component.css']
})
export class AdditionalNotesComponent implements OnInit, OnDestroy {
  additionalNoteForm = this.fb.group({
    additionalNotes: ['', [Validators.maxLength(1800)]]
  });
  updateMtgSubs: Subscription;
  @Output() formReady = new EventEmitter<FormGroup>();
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private commonService: CommonService) { }

  ngOnInit() {
    this.formReady.emit(this.additionalNoteForm);
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
          this.additionalNoteForm.patchValue({
            additionalNotes: response.additionalNotes ? response.additionalNotes : ''
          });
        }
        });
      }
    });
  }

  ngOnDestroy() {
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
  }
  validateTextLength() {
    if (this.additionalNoteForm.get('additionalNotes').value) {
      if (this.additionalNoteForm.get('additionalNotes').value.length > 1800) {
        return true;
      } else {
        return false;
      }
    }
  }
}
