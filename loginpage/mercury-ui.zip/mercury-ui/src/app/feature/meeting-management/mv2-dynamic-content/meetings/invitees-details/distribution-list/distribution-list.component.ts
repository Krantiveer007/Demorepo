import { Component, OnInit, Output, EventEmitter, NgZone, Input } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { Subscription } from 'rxjs/internal/Subscription';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Observable, Observer, EMPTY } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';

@Component({
  selector: 'mv2-distribution-list',
  templateUrl: './distribution-list.component.html',
  styleUrls: ['./distribution-list.component.css']
})
export class DistributionListComponent implements OnInit, OnDestroy {

  searchedDL = '';
  distributionListError = false;
  gridInfoObj: any;
  employeeList: Subscription;
  dlInputPlaceholder = 'Start typing...';
  infoIconToolTip = 'Input Format Example: FIL - IMT - MERCURY DEV';
  distributionListErrorMsg = '';
  isValidDl = false;
  asyncSelected = '';
  dataSource: Observable<any>;
  dlSubscription: Subscription;
  selectedParameter: string;
  errorResponse = false;
  dlLoading: boolean;
  @Output() emitEmployeeList = new EventEmitter<any>();
  @Input('selectedSecurity') selectedSecurity: string;

  constructor(private commonService: CommonService, private ngZone: NgZone) { }

  ngOnInit() {
    this.gridInfoObj = {
      columnDefs: [
        {
          headerName: '',
          field: 'selection',
          cellRendererFramework: ConfigRowSelectionComponent,
          width: 50,
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Name',
          field: 'Attendee',
          width: 190,
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Corp ID',
          field: 'AttendeeId',
          width: 180,
          sortable: true,
          cellStyle: { 'border-right': '1px solid #dadada', 'text-align': 'center' }
        },
        {
          headerName: 'Call-In',
          field: 'Call-In',
          width: 80,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Invite',
          field: 'Invite',
          width: 70,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Infopacks',
          field: 'Infopacks',
          width: 100,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        },
        {
          headerName: 'Info Only',
          field: 'Info Only',
          width: 100,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: { 'border-right': '1px solid #dadada' }
        }],
      gridType: 'distributionListGrid',
      rowData: []
    };
    if (this.commonService.getMeetingType() === 'Other' || this.selectedSecurity === 'Fixed Income' || this.commonService.getMeetingType() === 'Broker') {
      this.gridInfoObj.columnDefs.splice(5, 1);
    }
  }

  searchDL() {
    if (this.asyncSelected.length > 0) {
      this.employeeList = this.commonService.getDistributionListEmployees(this.asyncSelected.toUpperCase()).subscribe((response) => {
        if (response.length > 0) {
          this.distributionListError = false;
          this.gridInfoObj = {
            columnDefs: this.gridInfoObj.columnDefs,
            gridType: this.gridInfoObj.gridType,
            rowData: response
          };
        } else {
          this.distributionListError = true;
          this.distributionListErrorMsg = 'Empty Distribution List, Please try again.';
          this.gridInfoObj = {
            columnDefs: this.gridInfoObj.columnDefs,
            gridType: this.gridInfoObj.gridType,
            rowData: []
          };
        }
        if(!this.isValidDl) {
          this.commonService.addDlName(this.asyncSelected.toUpperCase()).subscribe((response) => {
          }, 
          (error) => {
            console.log(error)
          })
        }
      },
        (error) => {
          this.distributionListError = true;
          this.distributionListErrorMsg = 'Invalid Distribution List, Please try again.';
          this.gridInfoObj = {
            columnDefs: this.gridInfoObj.columnDefs,
            gridType: this.gridInfoObj.gridType,
            rowData: []
          };
        });
    }
  }

  getSelectedDlPeople(event) {
    this.emitEmployeeList.emit(event);
  }
  ngOnDestroy() {
    this.commonService.changeDlEmployeeList([]);
    if(this.dlSubscription) {
      this.dlSubscription.unsubscribe();
    }
  }


  getDLList() {
    this.distributionListError = false;
    this.isValidDl = false;
    if (this.asyncSelected.length >= 3) {
      this.dataSource = new Observable((observer) => {
        if (this.asyncSelected.length >= 3) {
          this.dlSubscription = this.commonService.getDliListNames(this.asyncSelected).subscribe((response) => {
            if (response['body'] && response['body'].length > 0) {
              this.errorResponse = false;
              this.typeaheadNoResults(false);
              this.ngZone.run(() => observer.next(response['body']));
            } else {
              this.selectedParameter = '';
              observer.next([]);
              this.dlLoading = false;
              this.distributionListErrorMsg = `Distribution List not present in Mercury, please press 'Go' to continue.`;
              this.typeaheadNoResults(true);
            }
          },
            (error) => {
              if (this.asyncSelected.length >= 3) {
                this.selectedParameter = '';
                observer.next([]);
                this.dlLoading = false;
                this.typeaheadNoResults(true);
              }
            });
        }
      });
    } else {
      if (this.dataSource !== EMPTY && this.dlSubscription) {
        this.dlSubscription.unsubscribe();
      }
      this.selectedParameter = '';
      this.typeaheadNoResults(false);
      // this.commonService.setSecurityDetails(this.securities);
    }
  }

  typeaheadOnSelect(event: TypeaheadMatch): void {  
      this.isValidDl = true;    
  }

  changeTypeaheadLoading(e: boolean): void {   
      this.dlLoading = e;   
  }


typeaheadNoResults(event: boolean): void {
      this.distributionListError = event;
  }


}
