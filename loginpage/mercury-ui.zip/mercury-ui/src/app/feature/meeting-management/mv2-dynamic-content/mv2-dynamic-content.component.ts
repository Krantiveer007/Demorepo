import { Component, OnInit, AfterViewInit, NgZone, ViewChild, Output, Input, EventEmitter, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-dynamic-content',
  templateUrl: './mv2-dynamic-content.component.html',
  styleUrls: ['./mv2-dynamic-content.component.css']
})
export class Mv2DynamicContentComponent implements OnInit {
  meetingType = '';
  dynamicForm: FormGroup;
  @Output() formReady = new EventEmitter<FormGroup>();
  @Output() checkMeetingConflicts = new EventEmitter<String>();
  @Input() meetingSubtypeList;
  @Input() roomDataList;
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private commonService: CommonService) { }
  ngOnInit() {
    this.dynamicForm = this.fb.group({});
    this.formReady.emit(this.dynamicForm);
    this.route.params.subscribe((params) => {
      this.meetingType = params['meetingType'];
    });
    this.meetingType = this.commonService.getMeetingType();
  }

  formInitialized(name, form) {
    this.dynamicForm.setControl(name, form);
  }
  checkForConflicts(field) {
    this.checkMeetingConflicts.emit(field);
  }
}
