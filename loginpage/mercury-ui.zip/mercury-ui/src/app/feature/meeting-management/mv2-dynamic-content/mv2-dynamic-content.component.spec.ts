import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mv2DynamicContentComponent } from './mv2-dynamic-content.component';
import { TimepickerModule, TypeaheadModule, BsModalService, ModalModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { EventDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/event-details/event-details.component';
import { MeetingDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meeting-details/meeting-details.component';
import { HttpClientModule } from '@angular/common/http';
import { InviteesDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/invitees-details/invitees-details.component';
import { AgGridModule } from 'ag-grid-angular';
import { TitleCasePipe } from '@angular/common';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { forwardRef } from '@angular/core';
import { TooltipModule } from 'ngx-bootstrap';
import { RouterModule, Routes, ActivatedRoute, Params, Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { IntlService } from '@progress/kendo-angular-intl';

// class MockRouter {
//   // ActivatedRoute.params is Observable
//   private subject = new BehaviorSubject(this.testParams);
//   params = this.subject.asObservable();
//   public events = new Observable(observer => {
//     observer.complete();
//   });
//   // Test parameters
//   private _testParams: {};
//   get testParams() { return this._testParams; }
//   set testParams(params: {}) {
//     this._testParams = params;
//     this.subject.next(params);
//   }

//   // ActivatedRoute.snapshot.params
//   get snapshot() {
//     return { params: this.testParams };
//   }
// }

describe('Mv2DynamicContentComponent', () => {
  let component: Mv2DynamicContentComponent;
  let fixture: ComponentFixture<Mv2DynamicContentComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        NgSelectModule,
        TimepickerModule.forRoot(),
        TypeaheadModule.forRoot(),
        HttpClientModule,
        ReactiveFormsModule,
        TooltipModule.forRoot(),
        AgGridModule.withComponents([]),
        RouterModule,
        IntlModule,
        TimePickerModule,
        BrowserModule,
        BrowserAnimationsModule,
        ModalModule.forRoot()
      ],
      declarations: [Mv2DynamicContentComponent, EventDetailsComponent, MeetingDetailsComponent, InviteesDetailsComponent,
        ConfigInviteesDtlsComponent, ConfigCheckboxComponent, ConfigDeleteComponent, CommonGridComponent],
      providers: [BsModalService, { provide: 'EnvName', useValue: 'DEV' }, TitleCasePipe, {provide: ActivatedRoute, useValue: {params: of()}}],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ConfigCheckboxComponent, ConfigDeleteComponent],
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2DynamicContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
