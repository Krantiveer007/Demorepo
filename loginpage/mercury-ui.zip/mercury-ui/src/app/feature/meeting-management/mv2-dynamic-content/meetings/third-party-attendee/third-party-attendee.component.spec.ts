import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThirdPartyAttendeeComponent } from './third-party-attendee.component';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { FormGroup, FormControl, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap';
import { GridApi } from 'ag-grid-community/dist/lib/gridApi';
import { HttpClientModule } from '@angular/common/http';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

describe('ThirdPartyAttendeeComponent', () => {
  let component: ThirdPartyAttendeeComponent;
  let fixture: ComponentFixture<ThirdPartyAttendeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        AgGridModule.withComponents([]),
        HttpClientModule
      ],
      declarations: [ThirdPartyAttendeeComponent,
        ConfigInviteesDtlsComponent,
        ConfigDeleteComponent,
        CommonGridComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, {provide: ActivatedRoute, useValue: {params: of()}}]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ConfigDeleteComponent],
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdPartyAttendeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //   it('grid API is not available until  `detectChanges`', () => {
  //     expect(component.gridOptions.api).not.toBeTruthy();
  // });
});
