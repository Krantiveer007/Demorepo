import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SecurityHoldersComponent } from './security-holders/security-holders.component';
import { InviteesDetailsComponent } from './invitees-details.component';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { FormGroup, FormControl, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule, BsModalService } from 'ngx-bootstrap';
import { GridApi } from 'ag-grid-community/dist/lib/gridApi';
import { HttpClientModule } from '@angular/common/http';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

describe('InviteesDetailsComponent', () => {
  let component: InviteesDetailsComponent;
  let fixture: ComponentFixture<InviteesDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        AgGridModule.withComponents([]),
        HttpClientModule
      ],
      declarations: [InviteesDetailsComponent,
        ConfigInviteesDtlsComponent,
        ConfigCheckboxComponent,
        ConfigDeleteComponent,
        CommonGridComponent,
        SecurityHoldersComponent],
      providers: [ BsModalService, { provide: 'EnvName', useValue: 'DEV' }, {provide: ActivatedRoute, useValue: {params: of()}}]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ConfigCheckboxComponent, ConfigDeleteComponent, CommonGridComponent],
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteesDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //   it('grid API is not available until  `detectChanges`', () => {
  //     expect(component.gridOptions.api).not.toBeTruthy();
  // });
});
