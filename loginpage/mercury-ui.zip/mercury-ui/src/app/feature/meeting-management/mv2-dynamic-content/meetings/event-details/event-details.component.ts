import { Component, OnInit, ElementRef, Output, Input, EventEmitter, ViewChild, TemplateRef, NgZone, AfterViewInit, OnDestroy, SimpleChanges } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { TimepickerComponent } from 'ngx-bootstrap/timepicker';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { ModalModule } from 'ngx-bootstrap';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { LOCATIONS, MEETINGSTATUS } from 'src/app/shared/app-constant/meeting.constants';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable, Observer, EMPTY, Subscribable } from 'rxjs';
import * as cityTimezones from 'city-timezones';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { IntlService } from '@progress/kendo-angular-intl';
import { Subscription } from 'rxjs/internal/Subscription';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import * as _ from 'lodash';
import 'rxjs/add/observable/forkJoin';
import { WindowRef } from 'src/app/shared/services/windowRef.service';


declare var jquery: any;
declare var $: any;

@Component({
  selector: 'mv2-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
  checkCountryFlag = false;
  dialInChecked = false;
  meetingTimeZone = '';
  disableDateTimeDuration = false;
  resetMeetingDetails: Subscription;
  brokerFirmChangeSubscription: Subscription;
  brokerFirmAddress = '';
  meetingUpdateExternalAddress = '';
  meetingUpdateBrokerLocation = false;
  meetingState = '';
  meetingType = '';
  disableRoom = false;
  errorResponse = false;
  dateErrorReason = '';
  pastMeeting = false;
  options = {
    hour: {
      value: 0,
      min: 0,
      max: 24,
      step: 1,
      symbol: 'h'
    },
    minute: {
      value: 0,
      min: 0,
      max: 60,
      step: 5,
      symbol: 'mins'
    },
    direction: 'increment', // increment or decrement
    inputHourTextbox: null, // hour textbox
    inputMinuteTextbox: null, // minutes textbox
    postfixText: '', // text to display after the input fields',
    numberPaddingChar: '0' // number left padding character ex: 00052
  };
  value;
  eventForm = this.fb.group({
    date: ['', MeetingFieldValidations.Date],
    meetingId: '',
    // time: ['0000'],
    time: [{ value: new Date(0, 0, 0, 0, 0), disabled: true }],
    meetingTime: [new Date(0, 0, 0, 0, 0)],
    duration: [''],
    timezone: [''],
    cityCountry: [{
      'Cities': '',
      'Country': '',
      'GRD_COUNTRY_CD': '',
      'ISO_COUNTRY_CD': '',
      'KeyCode': '',
      'UtilKeyName': '',
      'cityCountryVal': '',
      'timezoneVal': ''
    }],
    cityCountryName: '',
    // country: [{'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': ''}],
    location: ['In-house'],
    room: [{ 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' }],
    internalLocationRoomOther: ['', [Validators.maxLength(50)]],
    address: ['', [Validators.maxLength(300)]],
    dailin: [false],
    meetingStatus: [{ 'status': '' }],
    delayedByMins: 0,
    meetingState: ['NEW'],
    dailpicker: ['', [Validators.maxLength(100)]],
    accesscode: ['', [Validators.maxLength(50)]],
    brokerLocation: [false]
  }, { validators: MeetingFieldValidations.CheckInvalidValues });
  previousDate = '';
  utilData: any[];
  dateConfirmationMessage = '';
  modalRef: BsModalRef;
  hostAccessCode = '';
  hostDialInCode = '';
  meetingDateBeforeUpdate = '';
  config = {
    ignoreBackdropClick: true
  };
  isModalShown = false;
  isValidCity = false;
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  @Input() roomDataList
  usertz = '';
  roomList = [];

  // citycountrymap = timezoneValue;
  // nocitycountrymap = [];
  // wrongtimezone = [];
  // notimezone =[];
  // correcttimezone= [];

  dateConfirmMessage = 'You are about to create a meeting in past date.';
  @ViewChild('template') ModalTemplate: TemplateRef<any>;
  // @ViewChild('timeValue') TimeValue: TimepickerComponent;
  @Output() formReady = new EventEmitter<FormGroup>();
  @Output() checkForConflicts = new EventEmitter<String>();

  public cityCountry: any[];
  public countries: any[];
  public locations = LOCATIONS;
  public meetingStatus = MEETINGSTATUS;
  public rooms: any[];
  action: string;
  meetings = [];
  updateMtgSubs: Subscription;
  userDefaultCityCountry = '';
  utilDataObservable: Observable<any>;
  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private commonService: CommonService,
    private route: ActivatedRoute,
    private ngZone: NgZone, private windowRef: WindowRef) { }

  ngOnChanges(changes: SimpleChanges) {

    this.rooms = this.roomDataList;
  }

  ngOnInit() {
    this.commonService.meetingLocationChangeSubj.next('In-house');
    this.usertz = this.commonService.getLoggedInUserInfo().getUserTimezone();

    this.userDefaultCityCountry = this.commonService.getLoggedInUserInfo().getDefaultCityCountry();

    // configuration for datepicker
    $('#datepicker').datepicker({
      numberOfMonths: 2,
      showButtonPanel: false,
      dateFormat: 'dd/mm/yy'
    });

    $('#datepicker').change(() => {
      let isRequiredToFetchMeetings = true;
      this.eventForm.patchValue({
        date: $('#datepicker').val()
      });
      this.commonService.setFormChangeValue(true);
      const ONE_DAY = 1000 * 60 * 60 * 24;
      const meetingDate = $('#datepicker').datepicker('getDate');
      let difference_ms: number;
      const todayDate: Date = new Date();
      const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
      difference_ms = Math.round(difference_ms / ONE_DAY);
      const format = 'DD/MM/YYYY';
      const val = moment(this.meetingDateBeforeUpdate, format, true);
      const meetingDateValueBeforUpdate = val.toDate();

      if (this.action === 'update') {
        const differenceInMeetingDateBeforeUpdate = Math.floor((todayDate.getTime() - meetingDateValueBeforUpdate.getTime()) / (ONE_DAY));
        if (differenceInMeetingDateBeforeUpdate > 0 && differenceDays < 0) {
          this.dateErrorReason = 'Past Dated meeting cannot be changed to future date';
          this.eventForm.get('date').setErrors({ 'meetingDateUpdateFail': true });
          isRequiredToFetchMeetings = false;
        }
        if (differenceInMeetingDateBeforeUpdate < 0 && differenceDays > 0) {
          this.dateErrorReason = 'Future Dated meeting cannot be changed to past date';
          this.eventForm.get('date').setErrors({ 'meetingDateUpdateFail': true });
          isRequiredToFetchMeetings = false;
        }
      }
      if (differenceDays <= 365 && differenceDays > 0) {
        if (this.modalService.getModalsCount() === 0 && !(this.eventForm.get('date').errors !== null && this.eventForm.get('date').errors.meetingDateUpdateFail)) {
          if (this.eventForm.get('meetingState').value !== 'NEW') {
            this.dateConfirmMessage = 'You are about to update a meeting in past date.';
          }
          isRequiredToFetchMeetings = false;
          this.isModalShown = true;
          //  this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
        }
      }
      if (differenceDays <= 0) {
        this.previousDate = $('#datepicker').datepicker('getDate');
      }
      if (isRequiredToFetchMeetings) {
        this.fetchMeetingData($('#datepicker').val());
      }
    });

    $('.duration').timesetter(this.options);
    $('.duration').timesetter(this.options).setHour(1);
    this.eventForm.patchValue({
      duration: 60
    });
    $('.duration').change(() => {
      const hours = $('.duration').timesetter().getHoursValue();
      const minutes = $('.duration').timesetter().getMinutesValue();
      const durationValue = (hours * 60) + minutes;
      this.eventForm.patchValue({
        duration: durationValue
      });
      this.commonService.setFormChangeValue(true);
      if (durationValue === 0) {
        this.eventForm.get('duration').setErrors({ 'invalidDuration': true });
      }
      // this.checkForConflicts.emit('duration');
    });


    this.eventForm.get('dailpicker').disable();
    this.eventForm.get('accesscode').disable();
    this.eventForm.get('meetingStatus').disable();
    // this.disableElements();

    this.route.params.subscribe((params: Params) => {
      this.action = params['action'];
      if (this.action === 'update') {
        this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            const mtgDetailResponse = response;
            this.meetingType = mtgDetailResponse.meetingType;
            const convertDate = new Date(mtgDetailResponse.meetingDate);
            const convertDurationInHours = Math.floor((mtgDetailResponse.meetingDuration) / 60);
            const convertDurationInMinutes = (mtgDetailResponse.meetingDuration) % 60;
            const splitMeetingTimeInGMT = (mtgDetailResponse.meetingTimeInGMT) ? mtgDetailResponse.meetingTimeInGMT.match(/.{1,2}/g) : '';
            let meetingTimezone = mtgDetailResponse.meetingTimezone;
            let spliMeetingTimezone = meetingTimezone.split(' ');

            if (this.options) {
              $('.duration').timesetter(this.options).setHour(convertDurationInHours);
              $('.duration').timesetter(this.options).setMinute(convertDurationInMinutes);
            }
            // time conversion into user's Region
            // let dateArrray = moment(mtgDetailResponse.meetingDate).format('YYYY-MM-DD');
            let dateArrray = mtgDetailResponse.meetingDate.substring(0, 10);
            let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
            let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
            let meetingTimeInMeetingTimezone = '';
            if (spliMeetingTimezone.length === 2) {
              meetingTimeInMeetingTimezone = gmtTime.clone().tz(spliMeetingTimezone[0]).format();
            }

            $('#datepicker').datepicker('setDate', moment(meetingTimeInMeetingTimezone.substring(0, 10)).format('DD/MM/YYYY'));
            this.eventForm.patchValue({
              date: (mtgDetailResponse.meetingDate) ? moment(meetingTimeInMeetingTimezone.substring(0, 10)).format('DD/MM/YYYY') : '',
            });
            // private setTimeInUserTimezone(currentTimezone, toTimezone, currentTime, formFieldToBeUpdated) {
            if (splitMeetingTimeInGMT) {
              this.setTimeInUserTimezone("Europe/London", this.commonService.getLoggedInUserInfo().getUserTimezone(), splitMeetingTimeInGMT[0], splitMeetingTimeInGMT[1], 'time');
            }
            if (mtgDetailResponse.meetingTimezone) {
              this.meetingTimeZone = mtgDetailResponse.meetingTimezone;
              this.setTimeInUserTimezone("Europe/London", mtgDetailResponse.meetingTimezone.split(' ')[0], splitMeetingTimeInGMT[0], splitMeetingTimeInGMT[1], 'meetingTime');
            }
            this.meetingUpdateExternalAddress = mtgDetailResponse.externalLocationAddress ? mtgDetailResponse.externalLocationAddress : '';
            this.meetingUpdateBrokerLocation = (mtgDetailResponse.brokerLocationIndicator === 'Y') ? true : false;
            this.brokerFirmAddress = this.meetingUpdateExternalAddress;

            this.eventForm.patchValue({

              // time: new Date(0, 0, 0, +localTime.substring(11, 13), +localTime.substring(14, 16)),
              duration: (mtgDetailResponse.meetingDuration) ? mtgDetailResponse.meetingDuration : '',
              timezone: (mtgDetailResponse.meetingTimezone) ? mtgDetailResponse.meetingTimezone : '',
              cityCountry: {
                'Cities': mtgDetailResponse.meetingCity
                  ? mtgDetailResponse.meetingCity
                  : '',
                'Country': mtgDetailResponse.countryDescription
                  ? mtgDetailResponse.countryDescription
                  : '',
                'GRD_COUNTRY_CD': mtgDetailResponse.countryCode ? mtgDetailResponse.countryCode : '',
                'ISO_COUNTRY_CD': '',
                'KeyCode': '',
                'UtilKeyName': '',
                'cityCountryVal': (mtgDetailResponse.meetingCity && mtgDetailResponse.countryDescription)
                  ? mtgDetailResponse.meetingCity + ', ' + mtgDetailResponse.countryDescription
                  : '',
                'timezoneVal': (mtgDetailResponse.meetingTimezone) ? mtgDetailResponse.meetingTimezone : ''
              },
              cityCountryName: (mtgDetailResponse.meetingCity && mtgDetailResponse.countryDescription)
                ? mtgDetailResponse.meetingCity + ', ' + mtgDetailResponse.countryDescription
                : '',
              location: (mtgDetailResponse.locationType) ? mtgDetailResponse.locationType : '',
              room: (mtgDetailResponse.internalLocationRoom)
                ? {
                  'ActiveInd': '',
                  'Country': '',
                  'KeyCode': '',
                  'KeyDesc': mtgDetailResponse.internalLocationRoom,
                  'Region': '',
                  'UtilKeyName': ''
                }
                : {
                  'ActiveInd': '',
                  'Country': '',
                  'KeyCode': '',
                  'KeyDesc': '',
                  'Region': '',
                  'UtilKeyName': ''
                },
              internalLocationRoomOther: mtgDetailResponse.internalLocationRoomOther ? mtgDetailResponse.internalLocationRoomOther : '',
              address: mtgDetailResponse.externalLocationAddress ? mtgDetailResponse.externalLocationAddress : '',
              brokerLocation: (mtgDetailResponse.brokerLocationIndicator === 'Y') ? true : false,
              dailin: (mtgDetailResponse.dialIn && mtgDetailResponse.dialIn.dialInNumber) ? true : false,
              dailpicker: (mtgDetailResponse.dialIn && mtgDetailResponse.dialIn.dialInNumber) ? mtgDetailResponse.dialIn.dialInNumber : '',
              accesscode: (mtgDetailResponse.dialIn && mtgDetailResponse.dialIn.dialInAccessCode) ? mtgDetailResponse.dialIn.dialInAccessCode : '',
              meetingState: mtgDetailResponse.meetingState,
              meetingId: mtgDetailResponse.meetingId
            });
            if (this.eventForm.get('cityCountry').value && this.eventForm.get('cityCountry').value['cityCountryVal']) {
              this.isValidCity = true;
            }
            if (this.eventForm.get('dailin').value) {
              this.eventForm.get('dailpicker').enable();
              this.eventForm.get('accesscode').enable();
            }
            if (this.eventForm.get('date').value && !this.checkIfMeetingDateIsInPast()) {
              this.fetchMeetingData(this.eventForm.get('date').value);
            }
            if (this.eventForm.get('dailin').value === false) {
              this.commonService.getHostDialInDetails(mtgDetailResponse.hostCorporateId).subscribe((response) => {
                let hostPhoneNumber = '';
                let splitHostPhoneNumber = [];
                hostPhoneNumber = response[mtgDetailResponse.hostCorporateId];
                if (hostPhoneNumber) {
                  splitHostPhoneNumber = hostPhoneNumber.split(',;');
                  this.hostDialInCode = splitHostPhoneNumber[0];
                  this.hostAccessCode = splitHostPhoneNumber[1];
                } else {
                  this.hostDialInCode = '';
                  this.hostAccessCode = '';
                }
              },
                (error) => {
                  console.log(error)
                })
            }
            this.meetingDateBeforeUpdate = this.eventForm.get('date').value;

            this.previousDate = this.eventForm.get('date').value;
            // if (this.checkPastDateFromToday()) {
            //  $('.duration').attr('disabled', true);
            // }
            if (this.eventForm.get('meetingState').value === 'CONFIRMED' || this.eventForm.get('meetingState').value === 'CANCELLED') {
              this.eventForm.get('meetingStatus').enable();
              this.eventForm.patchValue({
                meetingStatus: (mtgDetailResponse.meetingStatus && mtgDetailResponse.meetingStatus !== '')
                  ? { 'status': mtgDetailResponse.meetingStatus }
                  : { 'status': 'Confirmed' },
                delayedByMins: (mtgDetailResponse.meetingStatus && mtgDetailResponse.meetingStatus === 'Delayed')
                  ? mtgDetailResponse.delayedByMins
                  : 0
              });
              if (mtgDetailResponse.meetingStatus === 'Arrived') {
                // this.meetingStatus.forEach((rowNode) => {
                //   if (rowNode.status === 'Confirmed' || rowNode.status === 'Delayed' || rowNode.status === 'On Time') {
                //     rowNode['disabled'] = true;
                //   }
                // });
                this.eventForm.get('meetingStatus').disable();
              } else if (mtgDetailResponse.meetingStatus === 'Delayed' || mtgDetailResponse.meetingStatus === 'On Time') {
                this.meetingStatus.forEach((rowNode) => {
                  if (rowNode.status === 'Confirmed') {
                    rowNode['disabled'] = true;
                  }
                });
              }
            } else {
              this.eventForm.patchValue({
                meetingStatus: { 'status': '' },
                delayedByMins: 0
              });
            }

            this.checkIfMeetingDateISMoreThan365Days(this.eventForm.get('date').value, this.eventForm.get('meetingState').value);
          }
        });
        if (this.eventForm.get('dailin').value) {
          this.eventForm.get('dailpicker').enable();
          this.eventForm.get('accesscode').enable();
        }
      }
    });
    this.fetchUtilData();
    this.formReady.emit(this.eventForm);
    this.resetMeetingDetails = this.commonService.resetMeetingDetailsSubject.subscribe(res => {
      if (res) {
        this.resetEventDetails();
      }
    });
    this.meetingType = this.commonService.getMeetingType();
    this.brokerFirmChangeSubscription = this.commonService.onBrokerFirmChange.subscribe((response) => {

      if (response) {
        this.brokerFirmAddress = response.item.brokerFirmAddress;
        this.eventForm.patchValue({
          location: 'In-house',
          room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
          address: '',
          brokerLocation: false,
          internalLocationRoomOther: ''
        });
      }
    });
  this.commonService.meetingLocationChangeSubj.next(this.eventForm.get('location').value);

  }

  ngAfterViewInit() {
    this.commonService.setFormChangeValue(false);
    this.commonService.hostDataObservable.subscribe((response) => {
      if (response) {
        let hostPhoneNumber = '';
        let splitHostPhoneNumber = [];
        hostPhoneNumber = response['hostPhoneNumber'];
        // if (hostPhoneNumber.search('N/A') < 0 && hostPhoneNumber.length > 0) {
        //   hostPhoneNumber = hostPhoneNumber.replace('8-', '');
        //   hostPhoneNumber = hostPhoneNumber.replace('8 -', '');
        //   splitHostPhoneNumber = hostPhoneNumber.split('-');
        //   this.hostAccessCode = splitHostPhoneNumber.pop();
        //   this.hostDialInCode = splitHostPhoneNumber.join();
        if (hostPhoneNumber) {
          splitHostPhoneNumber = hostPhoneNumber.split(',;');
          this.hostDialInCode = splitHostPhoneNumber[0];
          this.hostAccessCode = splitHostPhoneNumber[1];
          if (this.eventForm.get('dailin').value) {
            this.eventForm.patchValue({
              dailpicker: this.hostDialInCode,
              accesscode: this.hostAccessCode
            });
          }
        }
        else {
          this.hostDialInCode = '';
          this.hostAccessCode = '';
          if (this.eventForm.get('dailin').value) {
            this.eventForm.patchValue({
              dailpicker: '',
              accesscode: ''
            });
          }
        }
      }
    });
  }

  ngOnDestroy() {
    this.resetMeetingDetails.unsubscribe();
    if (this.brokerFirmChangeSubscription) {
      this.brokerFirmChangeSubscription.unsubscribe();
    }
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
  }

  onHidden(): void {
    this.confirmModal.hide();
    this.isModalShown = false;
  }

  confirm(): void {
    this.dateConfirmationMessage = 'Confirmed!';
    this.previousDate = $('#datepicker').datepicker('getDate');
    this.confirmModal.hide();
    this.isModalShown = false;
  }

  decline(): void {
    this.dateConfirmationMessage = 'Declined!';
    $('#datepicker').datepicker('setDate', this.previousDate);
    this.eventForm.patchValue({
      date: $('#datepicker').val()
    });
    this.confirmModal.hide();
    this.isModalShown = false;
  }

  fetchMeetingData(date) {
    const queryString = this.createQueryStringForsearch(date);
    const serachMeetingData = this.commonService.getMeetings(queryString.substr(0, queryString.length - 1));
    this.windowRef.nativeWindow.Pace.restart();
    serachMeetingData.subscribe((response) => {
      if (response) {
        let meetings = [];
        response.forEach((responseArray) => {
          if (responseArray['body'] && responseArray['body'].length > 0) {
            responseArray['body'].forEach((element) => {
              if (element.meetingState.toUpperCase() === "CONFIRMED") {
                meetings.push(element);
              }
            });
          }
        });
        if (this.action === "update" && meetings.length > 0) {
          const duplicateMeetingIndex = meetings.findIndex((meeting) => (meeting.meetingId === this.eventForm.controls.meetingId.value));
          if (duplicateMeetingIndex >= 0 && duplicateMeetingIndex < meetings.length) {
            meetings.splice(duplicateMeetingIndex, 1);
          }
        }

        if (meetings && meetings.length > 0) {
          if (this.commonService.getMeetingType() === 'Company') {
            let tradableEntIds = [], securitiesMarketCap = {}, securityIdMap = {};
            tradableEntIds = meetings.filter((meeting) => (meeting.securityTradableEntityId)).map((meeting) => meeting.securityTradableEntityId);
            tradableEntIds = _.uniq(tradableEntIds);
            if (tradableEntIds.length) {
              const secrities$ = this.commonService.getSecurityForTrdEntId(tradableEntIds);
              const marketCaps$ = this.commonService.getMarketCapForTrdEntId(tradableEntIds)
              const join$ = Observable.forkJoin(secrities$, marketCaps$);
              join$.subscribe((res: any[]) => {
                if (res[0].data && res[0].data.length > 0) {
                  res[0].data.forEach(security => {
                    securityIdMap[security.tradableEntId] = security.instrumentLongName;
                  });
                }
                if (res[1].data && res[1].data.length > 0) {
                  res[1].data.forEach(element => {
                    securitiesMarketCap[element.tradableEntId] = element.marketCapitalization
                      ? element.marketCapitalization
                      : '-';
                  });
                }
                meetings.forEach(meeting => {
                  if (securitiesMarketCap[meeting.securityTradableEntityId]) {
                    meeting.securitiesMarketCap = securitiesMarketCap[meeting.securityTradableEntityId];
                  }
                  if (securityIdMap[meeting.securityTradableEntityId]) {
                    meeting.instrumentLongName = securityIdMap[meeting.securityTradableEntityId];
                  }
                });
                this.commonService.setMeetingsForConflict(meetings);
                this.checkForConflicts.emit('Date');
              });

            } else {
              this.commonService.setMeetingsForConflict(meetings);
              this.checkForConflicts.emit('Date');
            }
          } else {
            this.commonService.setMeetingsForConflict(meetings);
            this.checkForConflicts.emit('Date');
          }
        }
      }
    },
      (error) => { console.log(error); });
  }

  createQueryStringForsearch(date): string {
    let queryString = '';
    if (date) {
      queryString += 'fromDate=' + this.convertDateToStandardFormat(date) + '&';
      queryString += 'toDate=' + this.convertDateToStandardFormat(date) + '&';
    }

    return queryString;

  }

  convertDateToStandardFormat(date: string): string {
    let dateArray = date.split('/');
    let newDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
    return newDate;
  }

  timeChange(event: string) {
    const newdate: Date = new Date(this.eventForm.get('meetingTime').value);
    let hours = newdate.getHours();
    let minutes = newdate.getMinutes();
    if (hours === 0 && minutes === 0) {
      this.eventForm.get('meetingTime').setErrors({ 'timeRequired': true });
    } else {
      this.eventForm.get('meetingTime').setErrors(null);
      // console.log("meetingtime", this.eventForm.get('meetingTime').value);
      let hrs = newdate.getHours() < 10 ? 0 + '' + newdate.getHours() : newdate.getHours();
      let mins = newdate.getMinutes() < 10 ? 0 + '' + newdate.getMinutes() : newdate.getMinutes();
       
      this.setTimeInUserTimezone(this.eventForm.controls.timezone.value.split(' ')[0],
      this.commonService.getLoggedInUserInfo().getUserTimezone(), hrs, mins, "time");
        // this.eventForm.get('meetingTime').value.toLocaleString().split(':')[0].slice(-2), this.eventForm.get('meetingTime').value.toLocaleString().split(':')[1], "time");
      // this.checkForConflicts.emit('meetingTime');
    }
  }

  private setTimeInUserTimezone(currentTimezone, toTimezone, currentTimeHrs, currentTimeMins, formFieldToBeUpdated) {  

    let date =  this.eventForm.get('date').value;
    let dateArr = date.split('/');
    let currentDate = dateArr[2] + '-' + dateArr[1] + '-' + dateArr[0];  
    const currentDateMoment = moment($('#datepicker').datepicker('getDate')).format('YYYY-MM-DD');
    const currentMomentTime = currentDate + ' ' + currentTimeHrs + ':' + currentTimeMins;    
    const meetingTimeZone = momentTimezone.tz(currentMomentTime, currentTimezone);

    // const meetingTimeZone = momentTimezone.tz("2019-10-19 08:00", "Asia/Kolkata");

    // this.gmtTime = momentTimezone.tz(("2019-09-29" + ' ' + "20" + ':' + "00"), "Europe/London");
    // const zone  = this.eventForm.controls.timezone.value.split(' ')[0];
    // this.updateTimeOnTimezoneChange(this.eventForm.controls.timezone.value.split(' ')[0]);
    const userTime = meetingTimeZone.clone().tz(toTimezone).format();
    //  let meetingTime = this.gmtTime.clone().tz(timezone).format();
    // let localTime = this.gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    this.eventForm.patchValue({
      [formFieldToBeUpdated]: new Date(0, 0, 0, + userTime.substring(11, 13), + userTime.substring(14, 16)),
    })
  }

  onDelayedByBlur() {
    this.eventForm.patchValue({ 'delayedByMins': this.eventForm.get('delayedByMins').value });
  }

  checkCountryRequired(): boolean {
    if (this.eventForm.errors !== null && this.eventForm.errors.countryRequired) {
      return true;
    }
    return false;
  }
  setVenue(event: any) {
    if (event === 'External') {
      if (this.action === 'update') {
        this.eventForm.patchValue({
          room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
          address: this.meetingUpdateExternalAddress,
          brokerLocation: this.meetingUpdateBrokerLocation,
          internalLocationRoomOther: ''
        });
      } else {
        this.eventForm.patchValue({
          room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
          address: '',
          brokerLocation: false,
          internalLocationRoomOther: ''
        });
      }
    } else {
      this.eventForm.patchValue({
        room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
        address: '',
        brokerLocation: false,
        internalLocationRoomOther: ''
      });
    }
    this.commonService.meetingLocationChangeSubj.next(event);
  }
  checkAddressLength() {
    if (this.eventForm.get('address').value && this.eventForm.get('address').value.length > 300) {
      return true;
    }
  }

  checkDialLength() {
    if (this.eventForm.get('dailpicker').value && this.eventForm.get('dailpicker').value.length > 100) {
      return true;
    }
  }

  checkAccessCodeLength() {
    if (this.eventForm.get('accesscode').value && this.eventForm.get('accesscode').value.length > 50) {
      return true;
    }
  }



  checkInvalidDate(): boolean {
    if (this.eventForm.get('date').errors !== null && this.eventForm.get('date').errors.invalidDate) {
      return true;
    }
    return false;
  }

  checkMoreThanOneYearDate(): boolean {
    if (this.eventForm.get('date').errors !== null && this.eventForm.get('date').errors.moreThanOneYearDate) {
      this.dateErrorReason = 'Meeting Date must be within past 365 days';
      return true;
    }
    return false;
  }

  checkMoreMeetingDateUpdateFail(): boolean {
    if (this.eventForm.get('date').errors !== null && this.eventForm.get('date').errors.meetingDateUpdateFail) {

      return true;
    }
    return false;
  }

  checkInvalidTime(): boolean {
    if (this.eventForm.get('time').errors !== null &&
      (this.eventForm.get('time').errors.invalidTime || this.eventForm.get('time').errors.timeRequired)) {
      return true;
    }
    return false;
  }

  checkInvalidDuration(): boolean {
    if (this.eventForm.get('duration').errors !== null && this.eventForm.get('duration').errors.invalidDuration) {
      return true;
    }
    return false;
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.roomList = this.utilData.filter(element => element.UtilKeyName === 'meetingRooms');
        this.roomList.unshift({
          KeyCode: '',
          KeyDesc: ''
        });
        this.cityCountry = this.utilData.filter(element => element.UtilKeyName === 'country-city-map');
        for (const item of this.cityCountry) {
          item['cityCountryVal'] = item.Cities + ', ' + item.Country;
        }
        if (this.action !== 'update') {
          let cityValue = this.cityCountry.filter(element => element.cityCountryVal === this.userDefaultCityCountry);
          if (cityValue[0]) {
          this.eventForm.patchValue({
            'cityCountry': cityValue[0],
            'cityCountryName': cityValue[0]['cityCountryVal']
          });
          this.isValidCity = true;

            if (cityValue[0] && cityValue[0]['GRD_COUNTRY_CD']) {
          let roomData = this.roomList.filter(roomItem => roomItem['Country'] === cityValue[0]['GRD_COUNTRY_CD'] || roomItem['KeyDesc'].toUpperCase().includes('OTHER'));
          // roomData.push({
          // KeyCode: 'Other',
          // KeyDesc: 'Other'
          // });
          roomData.unshift({
          KeyCode: '',
          KeyDesc: ''
          });
          this.rooms = Object.assign([], roomData);
          } else {
          this.rooms = this.roomList
          }
          this.populateTimeZone(this.eventForm.get('cityCountry').value);
          } else {
            this.rooms = this.roomList;
          }
          } else {
          if (this.eventForm.get('cityCountry') && this.eventForm.get('cityCountry').value['GRD_COUNTRY_CD']) {
              let roomData = this.roomList.filter(roomItem => roomItem['Country'] === this.eventForm.get('cityCountry').value['GRD_COUNTRY_CD'] || roomItem['KeyDesc'].toUpperCase().includes('OTHER'));
              // roomData.push({
              // KeyCode: 'Other',
              // KeyDesc: 'Other'
              // });
              roomData.unshift({
              KeyCode: '',
              KeyDesc: ''
              });
              this.rooms = Object.assign([], roomData);

              if (this.eventForm.get('room').value) {
                let selectedRoom = roomData.filter(item => item['KeyDesc'] === this.eventForm.get('room').value['KeyDesc']);
                this.eventForm.patchValue({
                  room: selectedRoom[0]
                });
              }
            }
          }
        }

    },
      (error) => {
        console.log(error);
      });
  }

  populateTimeZone(event: {
    Cities: string, Country: string, GRD_COUNTRY_CD: string, ISO_COUNTRY_CD: string,
    KeyCode: string, UtilKeyName: string, cityCountryVal: string, timezoneVal: string
  }) {
    // this.eventForm.patchValue({
    //   timezone: event['timezoneVal']? event['timezoneVal']: ''
    // });
    this.eventForm.patchValue({
      timezone: ''
    });
    this.meetingTimeZone = '';
    if (event) {
      const cityDescription = cityTimezones.lookupViaCity(event['Cities']);
      let timeZoneDesc = null;
      if (cityDescription.length !== 0) {
        if (cityDescription.length > 1) {
          const filteredCity = cityDescription.filter(element => element.iso2 === event['ISO_COUNTRY_CD']);
          if (filteredCity.length !== 0) {
            timeZoneDesc = filteredCity[0].timezone;
          } else {
            
            timeZoneDesc = null;
            //  this.nocitycountrymap.push(event)
          }
        } else {
          timeZoneDesc = cityDescription[0]['timezone'];
        }

        if (timeZoneDesc !== null) {
          const date = new Date().toLocaleString('en-US', { timeZone: timeZoneDesc, timeZoneName: 'short' });
          const indexOfOpenBracket = date.indexOf('GMT');
          if (indexOfOpenBracket !== -1) {
            // this.correcttimezone.push(event)
            this.eventForm.patchValue({
              timezone: timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length)
            });
            this.meetingTimeZone = timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length);
          } else {
            this.eventForm.patchValue({
              timezone: timeZoneDesc + ' ' + date.substring(date.length - 3, date.length)
            });
            this.meetingTimeZone = timeZoneDesc + ' ' + date.substring(date.length - 3, date.length);
            //   this.wrongtimezone.push(event);
          }
        }
      } else {
        // this.notimezone.push(event);
        this.eventForm.patchValue({
          timezone: event['timezoneVal']? event['timezoneVal']: ''
        });
        this.meetingTimeZone = event['timezoneVal']? event['timezoneVal'] : '';
      }
    }
  }

  // checkSelectedValue(element) {
  //   if (element === 'cityCountry') {
  //     if (this.eventForm.get('cityCountry').value) {
  //       if (this.eventForm.get('cityCountry').value['cityCountryVal'] !== '') {
  //         return false;
  //       }
  //     }
  //   }
  //   return true;
  // }

  // clearValue(element: string) {
  //   if (element === 'cityCountry') {
  //     this.eventForm.patchValue({
  //       cityCountry: {
  //         'Cities': '',
  //         'Country': '',
  //         'GRD_COUNTRY_CD': '',
  //         'ISO_COUNTRY_CD': '',
  //         'KeyCode': '',
  //         'UtilKeyName': '',
  //         'cityCountryVal': ''
  //       }
  //     });
  //   }
  // }

  checkMeetingStatus() {
    if (this.eventForm.get('meetingState').value === 'New' || this.eventForm.get('meetingState').value === 'Draft') {
      return true;
    }
    return false;
  }

  // checkPastDateFromToday(): boolean {
  //   if(this.eventForm.errors && this.eventForm.errors.pastDatedMeeting) {
  //     return true;
  //   }
  //   return false;
  // }

  checkLocationSelected() {
    if (!(this.eventForm.get('location').value === 'In-house') && !(this.eventForm.get('location').value === 'Conference Call') && !(this.eventForm.get('location').value === 'Video Call')) {
      this.eventForm.get('room').disable();
      return true;
    } else if (this.disableRoom) {
      this.eventForm.get('room').disable();
    } else {
      this.eventForm.get('room').enable();
      return false;
    }
  }

  resetEventDetails() {
    $('.duration').timesetter(this.options).setHour(1);
    $('.duration').timesetter(this.options).setMinute(0);
    this.eventForm.patchValue({
      duration: 60,
      brokerLocation: false
    });
    $('#datepicker').datepicker('setDate', '');

    this.eventForm.get('dailpicker').disable();
    this.eventForm.get('accesscode').disable();
    this.eventForm.get('meetingStatus').disable();
    if (this.pastMeeting) {
      this.eventForm.get('address').enable();
      this.eventForm.get('room').enable();
      this.disableRoom = false;
      // this.eventForm.get('dailin').enable();
      // document.getElementById('dialIn').disabled = true;
      $("#duration").removeClass("disabledbutton");
      // $("#dialIn").addClass("disabledbutton");
      $("#datepicker").removeClass("disabledbutton");
      $("#datepicker").removeClass("disabledbuttonDate");
      $("#timeDiv").removeClass("disabledbutton");
      $("#txtHours").removeClass("disabledbutton");
      $("#txtMinutes").removeClass("disabledbutton");
      this.pastMeeting = false;
    }
    this.meetingType = this.commonService.getMeetingType();
  }

  onChange(event) {
    if (this.eventForm.get('dailin').value) {
      this.eventForm.get('dailpicker').enable();
      this.eventForm.get('accesscode').enable();
      this.eventForm.patchValue({
        dailpicker: this.hostDialInCode,
        accesscode: this.hostAccessCode
      });
    } else {
      this.eventForm.get('dailpicker').disable();
      this.eventForm.get('accesscode').disable();
      this.eventForm.patchValue({
        dailpicker: '',
        accesscode: ''
      });
    }
  }

  checkDialValuesRequired() {
    if (this.eventForm.get('dailin').value) {
      return true;
    } else {
      return false;
    }
  }


  getCityCountry() {
    this.isValidCity = false;
    this.eventForm.patchValue({
      cityCountry: {
        'Cities': '',
        'Country': '',
        'GRD_COUNTRY_CD': '',
        'ISO_COUNTRY_CD': '',
        'KeyCode': '',
        'UtilKeyName': '',
        'cityCountryVal': '',
        'timezoneVal': ''
      },
      time: new Date(0, 0, 0, 0, 0),
      meetingTime: new Date(0, 0, 0, 0, 0),
      timezone: ''
    });
    this.meetingTimeZone = '';
    this.errorResponse = false;
  }
  typeaheadOnSelect(event) {
    this.isValidCity = true;
    this.eventForm.patchValue({
      'cityCountry': event.item,
      'room': { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
    });
    this.populateTimeZone(event.item);
    let roomData = this.roomList.filter(roomItem => roomItem['Country'] === event.item['GRD_COUNTRY_CD'] || roomItem['KeyDesc'].toUpperCase().includes('OTHER'));
    // roomData.push({
    //       KeyCode: 'Other',
    //       KeyDesc: 'Other'
    //     });
        roomData.unshift({
          KeyCode: '',
          KeyDesc: ''
        });
  this.rooms = Object.assign([], roomData);
    this.errorResponse = false;
  }
  onCityBlur() {
    if (!this.isValidCity) {
      this.eventForm.patchValue({
        cityCountry: {
          'Cities': '',
          'Country': '',
          'GRD_COUNTRY_CD': '',
          'ISO_COUNTRY_CD': '',
          'KeyCode': '',
          'UtilKeyName': '',
          'cityCountryVal': '',
          'timezoneVal': ''
        },
        cityCountryName: '',
        timezone: ''
      });

      this.errorResponse = false;
    }
  }

  typeaheadNoResults(event) {
    this.errorResponse = event;

  }

  onRoomChange() {
    this.checkForConflicts.emit('room');
    this.eventForm.patchValue({
      internalLocationRoomOther: ''
    });
  }

  disableElements() {
    //  put room condition in checklocationSelected
    this.eventForm.get('address').disable();
    this.eventForm.get('room').disable();
    // this.eventForm.get('dailin').enable();
    // document.getElementById('dialIn').disabled = true;
    $("#duration").addClass("disabledbutton");
    // $("#dialIn").addClass("disabledbutton");
    $("#datepicker").addClass("disabledbutton");
    $("#datepicker").addClass("disabledbuttonDate");
    $("#timeDiv").addClass("disabledbutton");
    $("#txtHours").addClass("disabledbutton");
    $("#txtMinutes").addClass("disabledbutton");
  }


  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.disableElements();
      this.disableRoom = true;
      this.pastMeeting = true;
    }
  }

  checkIfMeetingDateIsInPast() {
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = $('#datepicker').datepicker('getDate');
    let difference_ms: number;
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
   
    if (differenceDays <= 365 && differenceDays > 0) {
      return true;
    }
    return false;
  }

  onBrokerLocationChange() {
    if (this.eventForm.get('brokerLocation').value) {
      this.eventForm.patchValue({
        room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
        address: this.brokerFirmAddress
      });
    } else {
      this.eventForm.patchValue({
        room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
        address: ''
      });
    }
  }
  addressInput() {
    this.eventForm.patchValue({
      brokerLocation: false
    });
  }

  displayOtherRoomInput() {
    if (this.eventForm.get('location').value !== 'External' && this.eventForm.get('room').value && this.eventForm.get('room').value['KeyDesc'].toUpperCase().includes('OTHER')) {
      return true;
    } else {
      return false;
    }
  }

  validateTextLength() {
      if (this.eventForm.get('internalLocationRoomOther') && this.eventForm.get('internalLocationRoomOther').value.length > 50) {
        return true;
      } else {
        return false;
      }

  }

  emitConflicts() {
    const newdate: Date = new Date(this.eventForm.get('meetingTime').value);
    const hours = newdate.getHours();
    const minutes = newdate.getMinutes();
    if (!(hours === 0 && minutes === 0)) {
    this.checkForConflicts.emit('meetingTime');
    }
  }
}
