import { Component, OnInit, NgZone, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable } from 'rxjs/internal/Observable';
import { EMPTY } from 'rxjs';
import { TypeaheadData, TypeaheadDataSource } from 'src/app/shared/utils/typeahead.utility';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { Subscription } from 'rxjs/internal/Subscription';
import { NgSelectComponent } from '@ng-select/ng-select';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'mv2-broker-detail',
  templateUrl: './broker-detail.component.html',
  styleUrls: ['./broker-detail.component.css']
})
export class BrokerDetailComponent implements OnInit {
  brokerDetailForm = this.fb.group({
    brokerFirmName: [''],
    brokerFirmId: [''],
    telephone: [''],
    meetingInitiator: [{
      'ActiveInd': 'Y',
      'MeetingTypeCode': 'BRK',
      'KeyCode': 'COMP',
      'KeyDesc': 'Company',
      'UtilKeyName': 'meetingInitiatorType'
    }],
    // brokerUsageInitiator: [{ 'UtilKeyName': '', 'KeyDesc': '', 'KeyCode': '' }]
  });
  utilData: any[];
  utilDataObservable: Observable<any>;
  brokerFirmErrorResponse = false;
  brokerFirmTypeaheadLoading: boolean;
  brokerFirmSearchPlaceholder = 'Search by Firm name...';
  isValidCity = false;
  errorResponse = false;
  mtgInitiator: any[];
  // brkUsageInitiator: any[];
  isValidBrokerFirm = false;
  brokerFirmDataSource: Observable<any>;
  resetMeetingDetailSubscription: Subscription;
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  @Output() formReady = new EventEmitter<FormGroup>();

  constructor(private fb: FormBuilder, public commonService: CommonService, public ngZone: NgZone) { }

  ngOnInit() {
    this.formReady.emit(this.brokerDetailForm);
    // this.brokerDetailForm.get('brokerUsageInitiator').disable();
    this.fetchUtilData();
    this.resetMeetingDetailSubscription = this.commonService.resetMeetingDetailsSubject.subscribe((response) => {
      if (response) {
        this.resetBrokerDetailForm();
      }
    });
  }

  ngOnDestroy() {
    if (this.resetMeetingDetailSubscription) {
      this.resetMeetingDetailSubscription.unsubscribe();
    }
  }
  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.mtgInitiator = this.utilData.filter(element => element.UtilKeyName === 'meetingInitiatorType');
        // this.brkUsageInitiator = this.utilData.filter(element => element.UtilKeyName === 'brokerUsageInitiator');
      }
    },
      (error) => {
        console.log(error);
      });
  }
  // resetBrokerUsageInit() {
  //   if (this.brokerDetailForm.get('meetingInitiator').value.KeyDesc === 'Broker') {
  //     // this.brokerDetailForm.get('brokerUsageInitiator').enable();
  //     // this.brokerDetailForm.patchValue({ 'brokerUsageInitiator': { UtilKeyName: 'brokerUsageInitiator', KeyDesc: 'Company', KeyCode: 'CMP' } });
  //   } else {
  //     this.brokerDetailForm.get('brokerUsageInitiator').disable();
  //     this.brokerDetailForm.patchValue({ 'brokerUsageInitiator': '' });
  //   }
  // }
  getBrokerFirm() {
    this.brokerFirmDataSource = EMPTY;
    let typeaheadData: TypeaheadData;
    this.isValidBrokerFirm = false;
    const searchedValue = this.brokerDetailForm.get('brokerFirmName').value;
    typeaheadData = this.typeaheadDataSource.getBrokerFirms(searchedValue);
    this.brokerFirmDataSource = typeaheadData.dataSource;
    this.brokerFirmErrorResponse = typeaheadData.isResponseError;
  }
  onBrokerFirmBlur() {
    if (!this.isValidBrokerFirm) {
      this.brokerDetailForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.brokerFirmTypeaheadLoading = false;
      this.getBrokerFirm();
    }
  }
  typeaheadOnSelect(event: TypeaheadMatch): void {
    this.brokerDetailForm.patchValue({
      brokerFirmName: convertToTitleCase(event.item.firmName),
      brokerFirmId: event.item.firmId,
      telephone: event.item.telephone ? event.item.telephone : ''
    });
    this.commonService.setBrokerFirmDetails({
      brokerFirmName: this.brokerDetailForm.get('brokerFirmName').value,
      brokerFirmId: this.brokerDetailForm.get('brokerFirmId').value,
      telephone: this.brokerDetailForm.get('telephone').value
    });
    this.isValidBrokerFirm = true;
  }
  typeaheadNoResults(event: boolean): void {
    this.brokerFirmErrorResponse = event;
  }
  changeTypeaheadLoading(e: boolean): void {
    this.brokerFirmTypeaheadLoading = e;
  }
  resetBrokerDetailForm() {
    if (this.brokerDetailForm) {
      this.brokerDetailForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: '',
        telephone: '',
        meetingInitiator: [{
          'ActiveInd': 'Y',
          'MeetingTypeCode': 'BRK',
          'KeyCode': 'COMP',
          'KeyDesc': 'Company',
          'UtilKeyName': 'meetingInitiatorType'
        }],
        // brokerUsageInitiator: [{ 'UtilKeyName': '', 'KeyDesc': '', 'KeyCode': '' }]
      });
      this.brokerDetailForm.controls['meetingInitiator'].setValue({
        'ActiveInd': 'Y',
        'MeetingTypeCode': 'BRK',
        'KeyCode': 'COMP',
        'KeyDesc': 'Company',
        'UtilKeyName': 'meetingInitiatorType'
      }, {onlySelf: true});
      // this.brokerDetailForm.get('brokerUsageInitiator').disable();
    }
  }
}
