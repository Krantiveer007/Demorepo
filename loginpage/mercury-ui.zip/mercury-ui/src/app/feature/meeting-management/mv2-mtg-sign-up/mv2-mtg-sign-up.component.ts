import { Component, OnInit, OnDestroy } from '@angular/core';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { CommonService, SignUpRequired } from 'src/app/core/http/common.service';
import { Subscription } from 'rxjs/internal/Subscription';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Input } from '@angular/core';

@Component({
  selector: 'mv2-mv2-mtg-sign-up',
  templateUrl: './mv2-mtg-sign-up.component.html',
  styleUrls: ['./mv2-mtg-sign-up.component.css']
})
export class Mv2MtgSignUpComponent implements OnInit, OnDestroy {
  gridType = 'signUpAttendeeGrid';
  subjectLine = '';
  mtgDateTime: any;
  mtgHost = '';
  mtgLocation = '';
  mtgSubType = '';
  meetingType = '';
  gridInfoObj: any;
  meetingId: any;
  disableSignupForMe: SignUpRequired = {
    isRequired: false,
    requiredReason: ''
  };
  checkSignupForMe = false;
  disableSignupForMeubscription: Subscription;
  selectedSecurity = 'Equity';
  @Output() changeToDLScreenEvent = new EventEmitter<boolean>();
  constructor(private commonService: CommonService) {
  }
  @Input('distributionList') signUpDLAddedAttendees: any;
  ngOnInit() {
    this.gridInfoObj = {
      columnDefs: [
        {
          headerName: 'FIL Invitees',
          field: 'signUpAttendeeName',
          width: 338,
          cellEditorFramework: ConfigInviteesDtlsComponent,
          singleClickEdit: true,
          sortable: true,
          cellStyle: {
            // 'border-right': '1px solid #dadada'
            'color': 'black'
            , 'font-size': '13px'
            , 'font-family': 'Neuzeit Grotesk Regular'
            , 'padding-left': '20px'
            // , 'padding-top': '8px'
          }
        },
        {
          headerName: 'Call-In',
          field: 'isCallIn',
          width: 130,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: {
            // 'border-right': '1px solid #dadada'
            // 'padding-top': '10px',
            'padding-bottom': '10px'
          }
        },
        {
          headerName: 'Invite',
          field: 'isInviteRequired',
          width: 130,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: {
            // 'border-right': '1px solid #dadada'
            // 'padding-top': '10px',
            'padding-bottom': '10px'
          }
        },
        {
          headerName: 'Infopacks',
          field: 'isInfoPackRequired',
          width: 130,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: {
            // 'border-right': '1px solid #dadada'
            // 'padding-top': '10px',
            'padding-bottom': '10px'
          }
        },
        {
          headerName: 'Info Only',
          field: 'isInviteForInfoOnly',
          width: 130,
          cellRendererFramework: ConfigCheckboxComponent,
          cellStyle: {
            // 'border-right': '1px solid #dadada'
            // 'padding-top': '10px',
            'padding-bottom': '10px'
          }
        },
        {
          headerName: 'Actions',
          field: 'Remove',
          width: 130,
          // pinned: 'right',
          cellRendererFramework: ConfigDeleteComponent,
          cellStyle: {
            // 'padding-top': '6px'
            'padding-bottom': '10px'
            , 'text-align': 'center'
          }
        }],
      gridType: 'signUpAttendeeGrid'
    };
    if (this.commonService.getMeetingType() && !this.commonService.getMeetingType().includes('Company - EQ')) {
      this.gridInfoObj.columnDefs = this.gridInfoObj.columnDefs.filter((item) => item.headerName !== 'Infopacks');
    }
    this.disableSignupForMeubscription = this.commonService.disableSignupForMeSubject.subscribe((res) => {
      this.disableSignupForMe = res;
      this.checkSignupForMe = true;
      if (res.isRequired === false) {
        this.checkSignupForMe = false;
      }
    });
  }

  ngOnDestroy() {
    if (this.disableSignupForMeubscription) {
      this.disableSignupForMeubscription.unsubscribe();
    }
    if (this.commonService.getMeetingType()) {
      this.commonService.setMeetingType('');
    }
  }
  getMtgDtls(event: any) {
    this.subjectLine = event.subjectLine;
    this.mtgDateTime = event.mtgDateTime;
    this.mtgHost = event.mtgHost;
    this.mtgLocation = event.mtgLocation;
    this.mtgSubType = event.mtgSubType;
    this.meetingType = event.meetingType;
    if (event.businessEntity === 'FI') {
      this.selectedSecurity = 'Fixed Income';
    }
  }

  onChange(event) {
    if (event.target.checked === true) {
      this.checkSignupForMe = true;
      this.commonService.signUpForMeSubject.next(true);
    }
  }
  switchToDLScreen() {
    this.changeToDLScreenEvent.emit(true);
  }
}
