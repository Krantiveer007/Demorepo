import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TooltipModule } from 'ngx-bootstrap';
import { Mv2MtgSignUpComponent } from './mv2-mtg-sign-up.component';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

describe('Mv2MtgSignUpComponent', () => {
  let component: Mv2MtgSignUpComponent;
  let fixture: ComponentFixture<Mv2MtgSignUpComponent>;
  const mockEvent = {
    subjectLine: 'Test Meeting',
    mtgDateTime: '12 : 00',
    mtgHost: 'Parker, Peter',
    mtgLocation: 'In-house',
    mtgSubType: 'Conference Call'
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, TooltipModule.forRoot()],
      declarations: [Mv2MtgSignUpComponent, CommonGridComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, {provide: ActivatedRoute, useValue: {params: of()}}],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2MtgSignUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should show Meeting Details for signUp meeting selected by user', () => {
    component.getMtgDtls(mockEvent);
    fixture.detectChanges();
    expect(component.subjectLine).toBeTruthy(mockEvent.subjectLine);
    expect(component.mtgDateTime).toBeTruthy(mockEvent.mtgDateTime);
    expect(component.mtgHost).toBeTruthy(mockEvent.mtgHost);
    expect(component.mtgLocation).toBeTruthy(mockEvent.mtgLocation);
    expect(component.mtgSubType).toBeTruthy(mockEvent.mtgSubType);
  });
});
