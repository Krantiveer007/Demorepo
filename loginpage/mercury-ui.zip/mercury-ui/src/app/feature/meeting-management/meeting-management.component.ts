import { Component, OnInit, TemplateRef, ViewChild, AfterViewInit, Output, EventEmitter, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Mv2DynamicContentComponent } from './mv2-dynamic-content/mv2-dynamic-content.component';
import { Mv2StaticContentComponent } from './mv2-static-content/mv2-static-content.component';
import { FormGroup, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { ModalModule, TypeaheadMatch } from 'ngx-bootstrap';
import { MeetingSubtype } from '../../shared/models/meetingsubtype.model';
import { MeetingFormat } from '../../shared/models/meetingFormat.model';
import { MeetingInitiator } from '../../shared/models/meetinginitiator.model';
import { Country } from '../../shared/models/country.model';
import { DialIn } from '../../shared/models/dialin.model';
import { MeetingLocation } from '../../shared/models/meetinglocation.model';
import { SecurityDetails } from '../../shared/models/securitydetails.model';
import { AssociatedEventDetail } from '../../shared/models/associatedeventdetail.model';
import { ArrangementContact } from '../../shared/models/arrangementcontact.model';
import { FidelityInvitees } from '../../shared/models/fidelityInvitees.model';
import { ThirdPartyAttendee } from '../../shared/models/thirdPartyAttendee.model';
import { MeetingCreator } from '../../shared/models/meetingcreator.model';
import { Meeting } from '../../shared/models/meeting.model';
import { CommonService } from '../../core/http/common.service';
import { ErrorService } from '../../core/error/error.service';
import { Observable, Observer, EMPTY, Subscription } from 'rxjs';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { NgZone } from '@angular/core';
import { ElementRef } from '@angular/core';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { DatePipe } from '@angular/common';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';
import { DebtTickerDetail } from '../../shared/models/debtTickerDetail.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { Contacts } from 'src/app/shared/models/contacts.model';
import { CompanyContact } from 'src/app/shared/models/companyContact.model';
import { ContactMapper } from 'src/app/shared/models/contactMapper.model';
import { Contact } from 'src/app/shared/models/contact.model';
import { BrokerContact } from 'src/app/shared/models/brokerContact.model';
import { OtherContact } from 'src/app/shared/models/otherContact.model';
import { InternalContact } from 'src/app/shared/models/internalContact.model';
import { BrokerFirm } from 'src/app/shared/models/brokerFirm.model';
import { LocalLanguage } from 'src/app/shared/models/localLanguage.model';
import { ConferenceMeeting } from 'src/app/shared/models/conferenceMeeting.model';
import { EventLastUpdateDetails } from 'src/app/shared/models/eventLastUpdateDetails.model';
import { EventOwner } from 'src/app/shared/models/eventOwner.model';
import { EventCreator } from 'src/app/shared/models/eventCreator.model';
import { EventInitiator } from 'src/app/shared/models/eventInitiator.model';
import { GridOptions, Utils } from 'ag-grid-community';
import * as cityTimezones from 'city-timezones';
import { Security } from 'src/app/shared/models/security.model';
import { ConfigEmailComponent } from '../../shared/components/config-email/config-email.component'
@Component({
  selector: 'mv2-meeting-management',
  templateUrl: './meeting-management.component.html',
  styleUrls: ['./meeting-management.component.css']
})
export class MeetingManagementComponent implements OnInit, AfterViewInit, OnDestroy {
  hideStaticView: boolean;
  @ViewChild(Mv2DynamicContentComponent) mv2DynamicContentComponent;
  meetingForm: FormGroup;
  eventDetails;
  meetingDetails;
  organizerDetails;
  conferenceDetail;
  brokerDetail;
  arrangementContactDetails: ArrangementContact = new ArrangementContact('', '', '', '', '', '', '', '');
  inviteeDetails = [];
  thirdPartyAttendeeDetails;
  meetingType = '';
  emailSendingReason = '';
  draftMeetingStatus = '';
  meetingObservable: Observable<any>;
  meetingTime: string;
  isUserAutherised = false;
  meetingMomentTime: string;
  imageStatus = '';
  previouFILInviteeData = [];
  previouCompanyAttendeeData = [];
  pastMeeting = false;
  meetingState = 'New';
  modalRef: BsModalRef;
  draftConfirmMessage = '';
  messageHeading = '';
  navigationSubscription: any;
  eqMeetingSubtypes = [];
  fiMeetingSubtypes = [];
  config = {
    ignoreBackdropClick: false
  };
  isModalShown = false;
  isUpdateModalShown = false;
  checkCreateFormUpdate = false;
  updatedReason = '';
  updateMethod = '';
  // creatorDetails = {};
  isOwnerEditable = false;
  ownerErrorResponse = false;
  isValidOwner = false;
  ownerLoading: boolean;
  ownerEditImageSource = {
    pencilIcon: "assets/images/group-2.svg"
  }
  ownerEditImage = '';
  modalRef1: BsModalRef | null;
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  peopleDataSource: Observable<any>;
  peopleDataSubscription: Subscription;
  isModifiedByVisible = false;
  isModifiedOnVisible = false;
  modifiedBy = '';
  modifiedOn = '';
  meetingId = '';
  selectedOwnerName = '';
  showNoButton = false;
  confirmButton = 'OK';
  conferenceSuccessEventId = '';
  resetFormSubscription: Subscription;
  checkFormUpdateSubscription: Subscription;
  updateMtgDtlsSourceSubscription: Subscription;
  isConferenceVisible = true;
  bbCodeSubs: Subscription;
  sectorDetailsSubs: Subscription;
  mtgSubtypelist = [];
  roomDataList = [];
  defaultCityRoomDataList = [];
  updateMtgSubs: Subscription;
  utilDataObservable: Observable<any>;


  actualMeetingForm = new Meeting('', '', '', '', '', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('', ''),
    '', '', '', '', new Country('', ''), '', '', '', new DialIn('', ''), new MeetingLocation('', '', '', ''),
    new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
    new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('', '', '', '', '', '', '', ''),
    [], [], new MeetingCreator('', ''), '', '', '', '', '', '', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
    '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), 'N', '');
  utilDataCountries: any[];
  emptyCompanyMeetingForm = new Meeting('Company', '', '', '', 'N', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('COMP', 'Company'),
    '', 60, '', '', new Country('', ''), '', this.commonService.getLoggedInUserInfo().getRegionVal(), '', new DialIn('', ''), new MeetingLocation('In-house', '', '', ''),
    new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
    new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '', '', '', '', '', '', ''),
    [], [], new MeetingCreator(this.commonService.getLoggedInUserInfo().getCorporateId(), convertToTitleCase(this.commonService.getLoggedInUserInfo().getName())),
    '', this.commonService.getLoggedInUserInfo().getCorporateId(), '', '', '0000', '0000', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
    'EQ', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), 'N', '');

  emptyOtherMeetingForm = new Meeting('Other', '', '', '', 'N', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('COMP', 'Company'),
    '', 60, '', '', new Country('', ''), '', this.commonService.getLoggedInUserInfo().getRegionVal(), '', new DialIn('', ''), new MeetingLocation('In-house', '', '', ''),
    new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
    new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '', '', '', '', '', '', ''),
    [], [], new MeetingCreator(this.commonService.getLoggedInUserInfo().getCorporateId(), convertToTitleCase(this.commonService.getLoggedInUserInfo().getName())),
    '', this.commonService.getLoggedInUserInfo().getCorporateId(), '', '', '0000', '0000', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
    '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), 'N', '');

  emptyBrokerMeetingForm = new Meeting('Broker', '', '', '', 'N', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('COMP', 'Company'),
    '', 60, '', '', new Country('', ''), '', this.commonService.getLoggedInUserInfo().getRegionVal(), '', new DialIn('', ''), new MeetingLocation('In-house', '', '', ''),
    new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
    new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('Company', '', '', '', '', '', '', ''),
    [], [], new MeetingCreator(this.commonService.getLoggedInUserInfo().getCorporateId(), convertToTitleCase(this.commonService.getLoggedInUserInfo().getName())),
    '', this.commonService.getLoggedInUserInfo().getCorporateId(), '', '', '0000', '0000', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
    '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), 'N', '');


  emptyConferenceMeetingForm = new ConferenceMeeting('', 'Conference', '', '', '', new EventOwner(this.commonService.getLoggedInUserInfo().getCorporateId(), convertToTitleCase(this.commonService.getLoggedInUserInfo().getName())), '', new EventLastUpdateDetails('', '', '', ''),
    new EventCreator(this.commonService.getLoggedInUserInfo().getCorporateId(), convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()), ''),
    '', new Country('', ''), '', new BrokerDetail('', ''), new EventInitiator('COMP', 'Company'), '', '', '', '', new ArrangementContact('', '', '', '', '', '', '', ''), 'New', '');

  contactMapper: ContactMapper = new ContactMapper('',
    new CompanyContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', '', '', '', ''),
    new BrokerContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')),
      new BrokerFirm('', '', '', '', '', '', '', '', '', '', null, '', null, '')),
    new OtherContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', ''));
  // @Output() formChange = new EventEmitter<boolean>();
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  yearObj = {
    '01': 'Jan',
    '02': 'Feb',
    '03': 'Mar',
    '04': 'Apr',
    '05': 'May',
    '06': 'Jun',
    '07': 'Jul',
    '08': 'Aug',
    '09': 'Sep',
    '10': 'Oct',
    '11': 'Nov',
    '12': 'Dec'
  }
  arrangementContactEmail = '';
  arrangementContactPhone = '';
  arrangementContactId = '';
  defaultMeetingBusUnit = { 'ActiveInd': '', 'KeyCode': '', 'UtilKeyName': '' };
  defaultCityCountry = {
    'Cities': '',
    'Country': '',
    'GRD_COUNTRY_CD': '',
    'ISO_COUNTRY_CD': '',
    'KeyCode': '', 'UtilKeyName': '',
    'cityCountryVal': '',
    'timezoneVal': ''
  };
  defaultTimezone = '';

  @ViewChild('saveDialogModal') saveDialogModal: ModalDirective;
  @ViewChild('owner') ownerElement: ElementRef;

  confirmButtonLabel = 'Confirm';
  saveButtonLabel = 'Draft';
  routeCase = 'draftmeeting';
  currentAction = '';
  subjectLine = '';
  mtgDateTime = '';
  mtgHost = '';
  mtgLocation = '';
  mtgSubtype = '';
  meetingUpdateActionHeading = '';
  meetingUpdateActionMessage = '';
  updateReasonLabel = '';
  mtgState = '';
  businessEntity = '';
  debtTcker = '';
  securityNameOnUpdateMeeting = '';

  meeting = new Meeting('', '', '', '', '', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('', ''),
    '', '', '', '', new Country('', ''), '', '', '', new DialIn('', ''), new MeetingLocation('', '', '', ''),
    new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
    new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('', '', '', '', '', '', '', ''),
    [], [], new MeetingCreator('', ''), '', '', '', '', '', '', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
    '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), '', '');

  conferenceMeeting = new ConferenceMeeting('', '', '', '', '', new EventOwner('', ''), '', new EventLastUpdateDetails('', '', '', ''),
    new EventCreator('', '', ''), '', new Country('', ''), '', new BrokerDetail('', ''), new EventInitiator('', ''), '', '', '', '', new ArrangementContact('', '', '', '', '', '', '', ''), '', '');

  formParam = '';
  duplicateSecurityMeeting = 0;
  duplicateMeetingWithDiffSec = 0;
  duplicateMeetingWithDiffRoom = 0;
  duplicateMeetingWith5BnMrktCap = 0;
  duplicateMeetingWithDiffSecAcceptedState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
  duplicateMeetingWith5BnMrktCapAcceptedState = { securityId: 0, date: '', time: '', marketCap: '' };
  duplicateMeetingWithDiffSecState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
  duplicateMeetingWith5BnMrktCapState = { securityId: 0, date: '', time: '', marketCap: '' };
  duplicateSecurityMeetingState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
  duplicateMeetingWithSameRoomState = { date: '', time: '', duration: 0, room: '' };
  meetingCurrentState = { securityId: 0, date: '', time: '', host: '', marketCap: '', duration: 0, room: '' };
  duplicateMeetingDiffSecHost;
  duplicateMeetingSameSecHost;
  duplicateMeetingSameSecName;
  gridOptions: GridOptions;
  rowData = [];
  columnDefs: any[];
  totalClashes = 0;
  userDefaultBU = '';
  userDefaultCityCountry = '';

  roomClashGridOptions: GridOptions;
  roomClashRowData = [];
  roomClashColumnDefs: any[];

  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef, private errorService: ErrorService, private ngZone: NgZone,
    private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.isConferenceVisible = this.commonService.getConferenceVisiblity();
    // console.log('isConferenceVisiblisConferenceVisiblee: ', this.isConferenceVisible);
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
    this.userDefaultCityCountry = this.commonService.getLoggedInUserInfo().getDefaultCityCountry();
    this.gridOptions = {
      rowBuffer: 200,
      headerHeight: 30,
      rowHeight: 30,
      // suppressNoRowsOverlay: true,
      suppressMovableColumns: true,
      suppressScrollOnNewData: true,
      context: {
        componentParent: this
      },
      rowSelection: 'single',
      onGridReady: function (params) {
        params.api.sizeColumnsToFit();
      }
    };
    this.roomClashGridOptions = {
      rowBuffer: 200,
      headerHeight: 30,
      rowHeight: 30,
      // suppressNoRowsOverlay: true,
      suppressMovableColumns: true,
      suppressScrollOnNewData: true,
      context: {
        componentParent: this
      },
      rowSelection: 'single',
      onGridReady: function (params) {
        params.api.sizeColumnsToFit();
      }
    };
    this.roomClashColumnDefs = [

      {
        headerName: 'Company Name',
        field: 'instrumentLongName',
        width: 300
      },

      {
        headerName: 'Date & Time',
        field: 'meetingTime',
        valueGetter: this.getDataTime,
        width: 180
      },
      {
        headerName: 'Room',
        field: 'internalLocationRoom',
        width: 100
      },
      {
        headerName: 'Creator',
        field: 'meetingCreatorName',
        width: 180
      }];
    this.columnDefs = [
      {
        headerName: 'Company Name',
        field: 'instrumentLongName',
        width: 270
      },
      {
        headerName: 'Sector',
        field: 'sector',
        width: 270
      },
      {
        headerName: 'Date & Time',
        field: 'meetingTime',
        valueGetter: this.getDataTime,
        width: 180
      },
      {
        headerName: 'Host',
        field: 'hostName',
        width: 180
      },
      {
        headerName: 'MCap M$',
        field: 'securitiesMarketCap',
        width: 130
      }
      // {
      //   headerName: 'Meeting Details',
      //   field: '',
      //   width: 180,
      //   cellRenderer: this.meetingDetailsLink          
      // }
    ];
    this.meetingForm = this.fb.group({
      creatorCorporateId: [''],
      creatorName: [''],
      ownerCorporateId: [''],
      ownerName: [''],
      meetingLastUpdatedByCorporateId: [''],
      meetingLastUpdatedByName: [''],
      meetingUpdatedMethod: [''],
      meetingUpdatedReason: [''],
      meetingCancellationReason: [''],
      meetingRegion: ['']
    });
    console.log('meetingForm: ', this.meetingForm);
    //  this.creatorDetails = Object.assign({}, this.commonService.getLoggedInUserInfo());
    this.meetingForm.patchValue({
      'creatorCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
      'creatorName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
      'ownerCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
      'ownerName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
      'meetingRegion': this.commonService.getLoggedInUserInfo().getRegionVal()
    });
    this.peopleDataSource = EMPTY;
    this.ownerEditImage = this.ownerEditImageSource.pencilIcon;
    this.selectedOwnerName = this.meetingForm.get('ownerName').value;

    this.route.params.subscribe((params) => {
      this.currentAction = params['action'];
      this.meetingType = this.commonService.getMeetingType();
      if (params['action'] === 'view') {
        if (this.commonService.getMeetingType() === 'Conference') {
          this.commonService.getConferenceMeeting(params['eventId']).subscribe((response) => {
            if (response['body'] && response['statusCode'] === 200) {
              // console.log('response: ', response['body']);
              this.meetingType = response['body']['eventType'];
              this.meetingState = 'Confirmed'
              this.meetingForm.patchValue({
                'creatorCorporateId': response['body']['eventCreator'] ? response['body']['eventCreator'] : '',
                'creatorName': response['body']['eventCreator'] ? response['body']['eventCreator'] : '',
                'ownerCorporateId': response['body']['eventOwner'] ? response['body']['eventOwner'] : '',
                'ownerName': response['body']['eventOwner'] ? response['body']['eventOwner'] : ''
              });
              this.commonService.setConferenceMeetingDtls(response['body']);
            }
          });
        }
      }
      if (params['action'] === 'update') {
        // if (!params['source']) {
        //   this.hideStaticView = true;
        //   this.commonService.hideStaticView(true);
        // }
        // const meetingId = params['id'];
        // const meetingType = params['type']; 
        // if (!params['source']) {
        //   this.hideStaticView = true;
        //   this.commonService.hideStaticView(true);
        // }
        // const meetingId = params['id'];
        // const meetingType = params['type'];
        // this.commonService.getMtgDetailsForMtgId(meetingId, meetingType).subscribe((response) => {
        this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          // response = response.body;
          // response = response.body;
          this.meetingType = response.meetingType;
          this.businessEntity = response.businessEntity;
          this.debtTcker = response.debtTickerDetail ? response.debtTickerDetail.debtTicker : '';
          // this.commonService.updateMtgDtlsChange(response);
          // this.commonService.updateMtgDtlsChange(response);
          this.commonService.setMeetingType(response.meetingType);
          this.meetingId = response.meetingId ? response.meetingId : '';
          if (response.arrangementContact) {
            this.arrangementContactEmail = response.arrangementContact.organizerEmail ? response.arrangementContact.organizerEmail : '';
            this.arrangementContactPhone = response.arrangementContact.organizerPhone ? response.arrangementContact.organizerPhone : '';
            this.arrangementContactId = response.arrangementContact.organizerContactId ? response.arrangementContact.organizerContactId : '';
          }
          if (response.meetingType === 'Company' && response.businessEntity === 'EQ') {
            this.securityNameOnUpdateMeeting = response.securityDetail.instrumentLongName ? response.securityDetail.instrumentLongName : '';
          }
          if (response.meetingLastUpdatedByName) {
            this.isModifiedByVisible = true;
            this.modifiedBy = ' ' + convertToTitleCase(response.meetingLastUpdatedByName) + ' ';
          }
          if (response.meetingLastUpdatedDateTime) {
            this.isModifiedOnVisible = true;
            // moment(response.meetingLastUpdatedDateTime).format('DD MMM YYYY') 
            this.modifiedOn = this.getUpdatedDateInLocaltime(response.meetingLastUpdatedDateTime).toString();
          }
          if (response.meetingCreator) {
            this.meetingForm.patchValue({
              'creatorCorporateId': response.meetingCreator.corporateId ? response.meetingCreator.corporateId : '',
              'creatorName': response.meetingCreator.name ? convertToTitleCase(response.meetingCreator.name) : ''
            });
          }
          if (response.meetingOwner) {
            this.selectedOwnerName = response.meetingOwner.name
              ? convertToTitleCase(response.meetingOwner.name)
              : convertToTitleCase(this.commonService.getLoggedInUserInfo().getName());
            this.meetingForm.patchValue({
              'ownerCorporateId': response.meetingOwner.corporateId ? response.meetingOwner.corporateId : '',
              'ownerName': this.selectedOwnerName
            });
          }

          if (response.meetingUpdateDetails) {
            this.meetingForm.patchValue({
              meetingLastUpdatedByCorporateId: response.meetingUpdateDetails.meetingLastUpdatedByCorporateId,
              meetingLastUpdatedByName: convertToTitleCase(response.meetingUpdateDetails.meetingLastUpdatedByName),
              // meetingUpdatedMethod: response.meetingUpdateDetails.meetingUpdatedMethod,
              // meetingUpdatedReason: response.meetingUpdateDetails.meetingUpdatedReason
            });
          }
          this.meetingForm.patchValue({
            meetingRegion: response.meetingRegion ? response.meetingRegion : ''
          });
          if (response.hostCorporateId && response.fidelityInvitees.length > 0) {
            response.fidelityInvitees.forEach((rowNode) => {
              if (rowNode.corporateId === response.hostCorporateId) {
                this.mtgHost = convertToTitleCase(rowNode.name.replace(' (Host)', ''));
              }
            });
          }

          this.subjectLine = response.emailSubject ? response.emailSubject : '';
          this.mtgLocation = response.locationType ? response.locationType : '';
          if (response.meetingType !== 'Broker') {
            this.mtgSubtype = response.meetingSubTypeDescription ? response.meetingSubTypeDescription : '';
          }
          this.mtgState = response.meetingState ? response.meetingState : '';
          this.meetingState = response.meetingState ? response.meetingState : '';
        });
      } else {
        this.meetingType = params['meetingType'];
      }
    });
    this.router.events.subscribe((event) => {
      if (event['url']) {
        this.formParam = event['url'];
        if (event['url'] === '/events/meeting' || event['url'] === '/') {
          this.checkCreateFormUpdate = false;
        } else {
          this.checkCreateFormUpdate = true;
        }
      }
    });
    // console.log(this.meetingForm);
    this.fetchUtilData();
  }

  meetingDetailsLink(params) {
    return `<a href="/meeting/update;id=${params.data.meetingId};type=${params.data.meetingType}" target="_blank">View more details</a>`;
  }

  // getDataTime(params) {
  //   console.log(params)
  //   params.data.meetingTime = ((params.data.meetingDate)
  //     ? params.context.componentParent.datePipe.transform((params.context.componentParent.getMeetngDateInLocalTime(params.data))['date'], 'dd MMM yyyy')
  //     : '')
  //     + ' ' + ((params.data.meetingTimeInGMT) ? (params.context.componentParent.getMeetngDateInLocalTime(params.data))['time'] : '');
  //   return params.data.meetingTime;
  // }

  getDataTime(params) {

    params.data.meetingTime = (params.data.meetingDate) ? params.context.componentParent.getMeetngDateLocal(params.data) : '';
    return params.data.meetingTime;
  }

  checkMeetingConflicts(changedField, template: TemplateRef<any>) {
    if (this.modalRef1) {
      this.modalRef1.hide();
    }
    const meetings = this.commonService.getMeetingsForConflict();
    if (meetings && meetings.length > 0 && this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings')
      && this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details') && this.meetingForm.get('dynamicForm').get('meetings').get('event-details') && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value) {
      const hostCorpId = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('hostCorpId').value;
      let host = (hostCorpId && hostCorpId !== '-') ? hostCorpId : '';
      let securityId, marketCap;
      if (this.meetingType === "Company") {
        const securityDetail = this.commonService.getSecurityDetails();
        host = (hostCorpId && hostCorpId !== '-') ? hostCorpId : this.commonService.getSecurityDetails().primaryAnalystCorpId;
        securityId = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityTradableEntityId').value;
        marketCap = this.commonService.getSecurityDetails().marketCapitalization;
      }

      const room = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('room').value ? this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('room').value.KeyDesc : '',
        date = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value,
        time = this.getTimeInGMT(date),
        meetingDuration = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('duration').value;


      if (meetings && meetings.length > 0) {
        this.meetingCurrentState = { securityId: securityId, date: date, time: time, host: host, marketCap: marketCap, duration: meetingDuration, room: room };
        const duplicateSecurityMeetingIni = this.duplicateSecurityMeeting,
          duplicateMeetingWithDiffSecIni = this.duplicateMeetingWithDiffSec, duplicateMeetingWith5BnMrktCapIni = this.duplicateMeetingWith5BnMrktCap,
          duplicateMeetingWithDiffRoomIni = this.duplicateMeetingWithDiffRoom;
        this.duplicateSecurityMeeting = 0, this.duplicateMeetingWithDiffSec = 0,
          this.duplicateMeetingWithDiffRoom = 0, this.duplicateMeetingWith5BnMrktCap = 0;
        if (this.meetingType === "Company") {
          if (this.checkForDuplicateSecurityMeeting(meetings, securityId, date, time, host, room, meetingDuration)) {
            ++this.duplicateSecurityMeeting;
          }
          if (!this.duplicateMeetingWithDiffSecFlag() && this.checkForDuplicateMeetingWithDifferentSec(meetings, securityId, date, time, host, room, meetingDuration)) {
            ++this.duplicateMeetingWithDiffSec;
          }
          if (!this.duplicateMeetingWith5BnMrktCapFlag() && this.checkForDuplicateMeetingWith5BnMrktCap(meetings, securityId, date, time, host, room, marketCap, meetingDuration)) {
            ++this.duplicateMeetingWith5BnMrktCap;
          }
        }
        if (this.checkForDuplicateMeetingWithSameRoom(meetings, securityId, date, time, host, room, meetingDuration)) {
          ++this.duplicateMeetingWithDiffRoom;
        }

        this.updateTotalClashCount();
        if (this.totalClashes > 0) {
          if (this.checkIfIncrementInClashCount(duplicateSecurityMeetingIni, duplicateMeetingWithDiffSecIni, duplicateMeetingWith5BnMrktCapIni, duplicateMeetingWithDiffRoomIni)) {
            this.modalRef1 = this.modalService.show(template, this.config);
          } else if (this.checkIfNoChangeInCountButClashChanges()) {
            this.modalRef1 = this.modalService.show(template, this.config);
          }
        }
        this.updateDuplicateMeetingClashesToCheckStateChange();
      }
    }
    // meetingDuration
    // if (meetings && meetings.length > 0) {
    //   if(meetings.filter((meeting) => (meeting.securityTradableEntityId === securityId && meeting.meetingTimeInGMT === time && moment(meeting.meetingDate).format('DD/MM/YYYY') === date && meeting.hostCorporateId === host && meeting.internalLocationRoom === room)))
    // }

    // if (group.get('date').value === '') {
    //     debugger;
    //     return { dialpickerRequired: true };
    // }
    return null;
  }

  checkIfNoChangeInCountButClashChanges() {
    if (this.duplicateSecurityMeeting > 0 && !this.checkForDuplicateSecurityMeetingStateChange()) {
      return true;
    } else if (this.duplicateMeetingWithDiffSec > 0 && !this.checkForduplicateMeetingWithDiffSecStateChange()) {
      return true;
    } else if (this.duplicateMeetingWith5BnMrktCap > 0 && !this.checkduplicateMeetingWith5BnMrktCapStateChange()) {
      return true;
    } else if (this.duplicateMeetingWithDiffRoom > 0 && !this.checkForDuplicateMeetingWithSameRoomStateChange()) {
      return true;
    }
  }

  checkIfIncrementInClashCount(duplicateSecurityMeetingIni, duplicateMeetingWithDiffSecIni, duplicateMeetingWith5BnMrktCapIni, duplicateMeetingWithDiffRoomIni) {
    return (this.duplicateSecurityMeeting > duplicateSecurityMeetingIni || this.duplicateMeetingWithDiffSec > duplicateMeetingWithDiffSecIni ||
      this.duplicateMeetingWith5BnMrktCap > duplicateMeetingWith5BnMrktCapIni || this.duplicateMeetingWithDiffRoom > duplicateMeetingWithDiffRoomIni);
  }

  resetClashes() {
    this.duplicateSecurityMeeting = 0;
    this.duplicateMeetingWithDiffSec = 0;
    this.duplicateMeetingWithDiffRoom = 0;
    this.duplicateMeetingWith5BnMrktCap = 0;
    this.duplicateMeetingWithDiffSecAcceptedState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
    this.duplicateMeetingWith5BnMrktCapAcceptedState = { securityId: 0, date: '', time: '', marketCap: '' };
    this.duplicateMeetingWithDiffSecState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
    this.duplicateMeetingWith5BnMrktCapState = { securityId: 0, date: '', time: '', marketCap: '' };
    this.duplicateSecurityMeetingState = { securityId: 0, date: '', time: '', duration: 0, host: '' };
    this.duplicateMeetingWithSameRoomState = { date: '', time: '', duration: 0, room: '' };
    this.meetingCurrentState = { securityId: 0, date: '', time: '', host: '', marketCap: '', duration: 0, room: '' };
    this.duplicateMeetingDiffSecHost = '';
    this.duplicateMeetingSameSecHost = '';
    this.duplicateMeetingSameSecName = '';
    this.updateTotalClashCount();
    if (this.modalRef1) {
      this.modalRef1.hide();
    }
  }

  showClashes(template: TemplateRef<any>) {
    if (this.totalClashes > 0) {
      this.modalRef1 = this.modalService.show(template, this.config);
    }
  }

  private updateTotalClashCount() {
    this.totalClashes = (this.duplicateSecurityMeeting + this.duplicateMeetingWithDiffSec + this.duplicateMeetingWithDiffRoom + this.duplicateMeetingWith5BnMrktCap);
  }

  onOk(clashType) {
    if (clashType === "duplicateMeetingWithDiffSec") {
      this.duplicateMeetingWithDiffSec = 0;
      this.duplicateMeetingWithDiffSecAcceptedState = this.meetingCurrentState;
    } else if (clashType === "duplicateMeetingWith5BnMrktCap") {
      this.duplicateMeetingWith5BnMrktCap = 0;
      this.duplicateMeetingWith5BnMrktCapAcceptedState = this.meetingCurrentState;
    }
    this.updateTotalClashCount();
    if (this.totalClashes === 0) {
      this.modalRef1.hide();
    }
  }

  updateDuplicateMeetingClashesToCheckStateChange() {
    this.duplicateSecurityMeetingState = this.meetingCurrentState;
    this.duplicateMeetingWithDiffSecState = this.meetingCurrentState;
    this.duplicateMeetingWithSameRoomState = this.meetingCurrentState;
    this.duplicateMeetingWith5BnMrktCapState = this.meetingCurrentState;
  }

  checkForDuplicateSecurityMeeting(meetings, securityId, date, time, host, room, meetingDuration) {
    if (securityId && securityId !== "-" && date && date !== "-" && time && time !== "-" && meetingDuration && meetingDuration !== "-" && host && host !== "-") {
      const duplicateMeetings = meetings.filter((meeting) => (meeting.securityTradableEntityId === securityId && this.isTimeOverlap(time, this.getMeetingEndTime(date, time, meetingDuration), meeting.meetingTimeInGMT, this.getMeetingEndTime(meeting.meetingDate, meeting.meetingTimeInGMT, meeting.meetingDuration)) && moment(meeting.meetingDate).format('DD/MM/YYYY') === date && meeting.hostCorporateId === host));
      if (duplicateMeetings.length > 0) {
        this.duplicateMeetingSameSecName = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityName').value;
        this.duplicateMeetingSameSecHost = duplicateMeetings[0].hostName;
        // this.duplicateSecurityMeetingState = this.meetingCurrentState;
      }
      return (duplicateMeetings.length > 0);
    }
    return false;
  }

  checkForDuplicateMeetingWithDifferentSec(meetings, securityId, date, time, host, room, meetingDuration) {
    if (securityId && securityId !== "-" && date && date !== "-" && time && time !== "-" && meetingDuration && meetingDuration !== "-" && host && host !== "-") {
      const duplicateMeetings = meetings.filter((meeting) => (meeting.securityTradableEntityId !== securityId && this.isTimeOverlap(time, this.getMeetingEndTime(date, time, meetingDuration), meeting.meetingTimeInGMT, this.getMeetingEndTime(meeting.meetingDate, meeting.meetingTimeInGMT, meeting.meetingDuration)) && moment(meeting.meetingDate).format('DD/MM/YYYY') === date && meeting.hostCorporateId === host));
      if (duplicateMeetings.length > 0) {
        this.duplicateMeetingDiffSecHost = duplicateMeetings[0].hostName;
        // this.duplicateMeetingWithDiffSecState = this.meetingCurrentState;
      }

      return (duplicateMeetings.length > 0);
    }
    return false;
  }

  checkForDuplicateMeetingWithSameRoom(meetings, securityId, date, time, host, room, meetingDuration) {
    if (room && room !== "-" && date && date !== "-" && time && time !== "-" && meetingDuration && meetingDuration !== "-") {
      const duplicateMeetings = meetings.filter((meeting) => (this.isTimeOverlap(time, this.getMeetingEndTime(date, time, meetingDuration), meeting.meetingTimeInGMT, this.getMeetingEndTime(meeting.meetingDate, meeting.meetingTimeInGMT, meeting.meetingDuration)) && moment(meeting.meetingDate).format('DD/MM/YYYY') === date && meeting.internalLocationRoom === room));
      this.roomClashRowData = duplicateMeetings;
      // if (duplicateMeetings.length > 0) {
      //   this.duplicateMeetingWithSameRoomState = this.meetingCurrentState;
      // }
      return (duplicateMeetings.length > 0);
    }
    return false;
  }
  checkForDuplicateMeetingWith5BnMrktCap(meetings, securityId, date, time, host, room, marketCap, meetingDuration) {
    if (securityId && securityId !== "-" && date && date !== "-" && time && time !== "-" && meetingDuration && meetingDuration !== "-" && marketCap && marketCap !== "-") {
      const duplicateMeetings = meetings.filter((meeting) => (meeting.securityTradableEntityId !== securityId && this.isTimeOverlap(time, this.getMeetingEndTime(date, time, meetingDuration), meeting.meetingTimeInGMT, this.getMeetingEndTime(meeting.meetingDate, meeting.meetingTimeInGMT, meeting.meetingDuration)) && moment(meeting.meetingDate).format('DD/MM/YYYY') === date && (meeting.securitiesMarketCap > 5000 && marketCap > 5000)));
      if (duplicateMeetings && duplicateMeetings.length !== 0) {
        let duplicateMeetingsTradableEntId = [];
        duplicateMeetings.forEach(item => {
          duplicateMeetingsTradableEntId.push(item['securityTradableEntityId'])
        });
        this.sectorDetailsSubs = this.commonService.getSectorForSecurity(duplicateMeetingsTradableEntId.join()).subscribe(
          (response) => {
            if (response && response['data'] && response['data'].length !== 0) {
              response['data'].forEach((item) => {
                duplicateMeetings.forEach((duplicatMeetingItem) => {
                  if (duplicatMeetingItem['securityTradableEntityId'] === item['tradableEntId']) {
                    duplicatMeetingItem['sector'] = item['sector']
                  }
                });
              })
            }
            this.rowData = duplicateMeetings;
          },
          (error) => { console.log("error of sector data"), error }
        );
      }



      // if (duplicateMeetings.length > 0) {
      //   this.duplicateMeetingWith5BnMrktCapState = this.meetingCurrentState;
      // }
      return (duplicateMeetings.length > 0);
    }
    return false;
  }

  getTimeInGMT(meetingDate) {
    let dateArrray = meetingDate.split('/');
    const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
    const momenttime = moment(meetingTime, "hmm").format("HH:mm");
    let newDate: string = dateArrray[2] + '-' + dateArrray[1] + '-' + dateArrray[0];
    const meetingTimeZone = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value;
    let localTime = momentTimezone.tz((newDate + ' ' + momenttime), meetingTimeZone.split(' ')[0]);
    let meetingTimeInGMT = localTime.clone().tz("Europe/London").format();
    return meetingTimeInGMT;
  }



  getMeetngDateInLocalTime(meetingData): Object {

    const splitMeetingTimeInGMT = (meetingData.meetingTimeInGMT) ? meetingData.meetingTimeInGMT.match(/.{1,2}/g) : '';
    // time conversion into user's Region
    let dateArrray = moment(meetingData.meetingDate).format('YYYY-MM-DD');
    let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
    let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();

    return {
      'date': new Date(localTime),
      'time': localTime.substring(11, 13) + ':' + localTime.substring(14, 16)
    }
    //  return moment(localTime.substring(0,10)).format();
  }
  getUpdatedDateInLocaltime(lastUpdateDate): Object {
    const splitMeetingTimeInGMT = (lastUpdateDate) ? lastUpdateDate.split("T")[1] : '';
    let dateArrray = moment(lastUpdateDate).format('YYYY-MM-DD');
    let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT), "Europe/London");
    let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    return moment(localTime.substring(0, 10)).format('DD MMM YYYY') + ' at ' + localTime.substring(11, 13) + ':' + localTime.substring(14, 16);
    //  return moment(localTime.substring(0,10)).format();
  }
  getMeetingEndTime(meetingDate, meetingStartTime, meetingDuration) {
    let momentDate, momenttime;
    if (moment(meetingDate).isValid()) {
      momentDate = moment(meetingDate).format('YYYY-MM-DD');
    } else {
      const meetingDateArray = meetingDate.split('/');
      momentDate = meetingDateArray[2] + "-" + meetingDateArray[1] + "-" + meetingDateArray[0];
    }
    if (meetingStartTime.indexOf('T') >= 0) {
      momenttime = momentDate + ' ' + meetingStartTime.substring(11, 13) + ':' + meetingStartTime.substring(14, 16);
    } else {
      momenttime = momentDate + ' ' + meetingStartTime.substring(0, 2) + ':' + meetingStartTime.substring(2, 4);
    }
    let momnetObj = moment(momenttime);
    const endTimeMomentObj = momnetObj.add(meetingDuration, 'm');
    const endTime = this.getTwoDigitTime(endTimeMomentObj.hours()) + '' + this.getTwoDigitTime(endTimeMomentObj.minutes());
    return endTime;
  }

  isTimeOverlap(startTime1, endTime1, startTime2, endTime2) {
    if (startTime1.indexOf('T') >= 0) {
      startTime1 = startTime1.substring(11, 13) + ':' + startTime1.substring(14, 16);
    }
    return (startTime1 < endTime2 && startTime2 < endTime1);
  }

  getTwoDigitTime(value) {
    if (/^\d$/.test(value)) {
      return '0' + value;
    }
    return value;
  }

  private duplicateMeetingWithDiffSecFlag() {
    if (this.duplicateMeetingWithDiffSecAcceptedState["securityId"] === this.meetingCurrentState.securityId && this.duplicateMeetingWithDiffSecAcceptedState["date"] === this.meetingCurrentState.date &&
      this.duplicateMeetingWithDiffSecAcceptedState["time"] === this.meetingCurrentState.time && this.duplicateMeetingWithDiffSecAcceptedState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateMeetingWithDiffSecAcceptedState["host"] === this.meetingCurrentState.host) {
      return true;
    }
    return false;
  }

  private duplicateMeetingWith5BnMrktCapFlag() {
    if (this.duplicateMeetingWith5BnMrktCapAcceptedState["securityId"] === this.meetingCurrentState.securityId && this.duplicateMeetingWith5BnMrktCapAcceptedState["date"] === this.meetingCurrentState.date &&
      this.duplicateMeetingWith5BnMrktCapAcceptedState["time"] === this.meetingCurrentState.time && this.duplicateMeetingWith5BnMrktCapAcceptedState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateMeetingWith5BnMrktCapAcceptedState["marketCap"] === this.meetingCurrentState.marketCap) {
      return true;
    }
    return false;
  }

  private checkForDuplicateSecurityMeetingStateChange() {
    if (this.duplicateSecurityMeetingState["securityId"] === this.meetingCurrentState.securityId && this.duplicateSecurityMeetingState["date"] === this.meetingCurrentState.date &&
      this.duplicateSecurityMeetingState["time"] === this.meetingCurrentState.time && this.duplicateSecurityMeetingState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateSecurityMeetingState["host"] === this.meetingCurrentState.host) {
      return true;
    }
    return false;
  }

  private checkForDuplicateMeetingWithSameRoomStateChange() {
    if (this.duplicateMeetingWithSameRoomState["date"] === this.meetingCurrentState.date &&
      this.duplicateMeetingWithSameRoomState["time"] === this.meetingCurrentState.time && this.duplicateMeetingWithSameRoomState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateMeetingWithSameRoomState["room"] === this.meetingCurrentState.room) {
      return true;
    }
    return false;
  }

  private checkForduplicateMeetingWithDiffSecStateChange() {
    if (this.duplicateMeetingWithDiffSecState["securityId"] === this.meetingCurrentState.securityId && this.duplicateMeetingWithDiffSecState["date"] === this.meetingCurrentState.date &&
      this.duplicateMeetingWithDiffSecState["time"] === this.meetingCurrentState.time && this.duplicateMeetingWithDiffSecState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateMeetingWithDiffSecState["host"] === this.meetingCurrentState.host) {
      return true;
    }
    return false;
  }

  private checkduplicateMeetingWith5BnMrktCapStateChange() {
    if (this.duplicateMeetingWith5BnMrktCapState["securityId"] === this.meetingCurrentState.securityId && this.duplicateMeetingWith5BnMrktCapState["date"] === this.meetingCurrentState.date &&
      this.duplicateMeetingWith5BnMrktCapState["time"] === this.meetingCurrentState.time && this.duplicateMeetingWith5BnMrktCapState["duration"] === this.meetingCurrentState.duration &&
      this.duplicateMeetingWith5BnMrktCapState["marketCap"] === this.meetingCurrentState.marketCap) {
      return true;
    }
    return false;
  }

  ngAfterViewInit() {
    if (this.currentAction === 'view' && this.meetingType === 'Conference') {
      this.meetingState = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'DRAFTINVITE' ?
        'DRAFT & INVITE' : this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value;
      this.cdr.detectChanges();
    }
    this.route.params.subscribe((params) => {
      this.formParam = params['action']
      if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
        this.confirmButtonLabel = 'Update';
        this.cdr.detectChanges();
      }
      if (params['action'] === 'update') {
        //For hiding draft and invite
        this.saveButtonLabel = 'Save';
        //
        this.updateMtgDtlsSourceSubscription = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.setMeetingDetails(response);
            this.cdr.detectChanges();
          }
          if (params['action'] === 'create') {

          }
        });
      }
    });

    this.checkFormUpdateSubscription = this.commonService.checkFormUpdateSubject.subscribe((response) => {
      if (response) {
        if (this.formParam.includes('create')) {
          this.resetFormUpdate(response, this.commonService.getTargetUrl())
          this.cdr.detectChanges();
        } else {
          this.checkFormUpdate(response, this.commonService.getTargetUrl());
          this.cdr.detectChanges();
        }
      }
    });

    this.resetFormSubscription = this.commonService.resetFormSubject
      .subscribe((res) => {
        if (res) {
          if (this.formParam.includes('create')) {
            this.resetFormUpdate(res, '/meeting/create')
            this.cdr.detectChanges();
          } else {
            this.checkFormUpdate(res, '/meeting/create');
            this.cdr.detectChanges();
          }
        }
      });


    if (this.currentAction === 'update') {
      this.updateMtgSubs = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
        if (response) {
          this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
        }
      });
    }
    // if (this.currentAction === 'view' && this.meetingType === 'Conference') {
    this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').get('meetingExecutive').valueChanges.subscribe((response) => {
      const subjectLine = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('subjectLine').value;
      if (subjectLine.length > 0) {
        if (response) {
          this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').patchValue({
            subjectLine: 'Ex present - ' + subjectLine
          });
        } else {
          this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').patchValue({
            subjectLine: 'Ex not present - ' + subjectLine
          });
        }
      }
    });
    this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityType').valueChanges.subscribe((response) => {
      this.roomDataList = [];
      this.resetEventDetails();
      this.resetInviteeDetails();
      this.resetMeetingDetailsOnSecurityTypeChange();
      this.resetOrganizerDetails();
      this.resetThirdPArtyAttendeeDetails();
      this.resetClashes();
      this.roomDataList = this.defaultCityRoomDataList;
      this.meetingForm.get('dynamicForm').get('meetings').get('additional-notes').patchValue({
        additionalNotes: ''
      });
      this.isModifiedByVisible = false;
      this.isModifiedOnVisible = false;
      this.modifiedBy = '';
      this.modifiedOn = '';
      this.meetingState = 'NEW';
      this.commonService.setSecurityDetails([], 'create');
      this.commonService.resetMeetingDetailsSubject.next(true);
      this.confirmButtonLabel = 'Confirm';
      //For hiding draft and invite
      this.saveButtonLabel = 'Draft';
      //
      if (this.commonService.getMeetingType() === 'Company') {
        this.meeting = JSON.parse(JSON.stringify(this.emptyCompanyMeetingForm));
      } else if (this.commonService.getMeetingType() === 'Other') {
        this.meeting = JSON.parse(JSON.stringify(this.emptyOtherMeetingForm));
      } else if (this.commonService.getMeetingType() === 'Broker') {
        this.meeting = JSON.parse(JSON.stringify(this.emptyBrokerMeetingForm));
      }
      this.meetingForm.patchValue({
        'creatorCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
        'creatorName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
        'ownerCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
        'ownerName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
        'meetingRegion': this.commonService.getLoggedInUserInfo().getRegionVal(),
        'meetingLastUpdatedByCorporateId': '',
        'meetingLastUpdatedByName': '',
        'meetingUpdatedMethod': '',
        'meetingUpdatedReason': '',
        'meetingCancellationReason': ''
      });
      this.cdr.detectChanges();
    });
    // }
    this.isUserAutherised = this.checkIfUserAuthorized();
    this.cdr.detectChanges();
  }

  ngOnDestroy() {
    this.route.params.subscribe((params) => {
      this.commonService.setSecurityDetails([], params['action']);
    });
    //   this.commonService.setFormChangeValue(false);
    this.checkFormUpdateSubscription.unsubscribe();
    this.resetFormSubscription.unsubscribe();
    if (this.updateMtgDtlsSourceSubscription) {
      this.updateMtgDtlsSourceSubscription.unsubscribe();
    }
    if (this.updateMtgSubs) {
      this.updateMtgSubs.unsubscribe();
    }
    this.commonService.changeHoldersList([]);
    this.commonService.changeDlEmployeeList([]);
    this.commonService.changeFilAttendeeList([]);
    this.commonService.changeExternalContactList([]);
    this.commonService.searchedSecurityChange('');
    this.commonService.defaultCompanyAttendees.next([]);
    this.commonService.setArrangementContactDetails(new ArrangementContact('', '', '', '', '', '', '', ''));
    this.commonService.setSelectedDebtTicker('');
    this.commonService.setBrokerFirmDetails({
      brokerFirmName: '',
      brokerFirmId: '',
    });

    if (this.sectorDetailsSubs) {
      this.sectorDetailsSubs.unsubscribe();
    }
    this.commonService.securities = new Security('-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
      '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
  }

  editOwner() {
    this.isOwnerEditable = !this.isOwnerEditable;
    if (this.isOwnerEditable) {
      this.ownerEditImage = '';
      setTimeout(() => {
        this.ownerElement.nativeElement.focus();
      }, 0);
    }
    else {
      this.ownerEditImage = this.ownerEditImageSource.pencilIcon;
    }
  }

  getPeopleData(): void {
    let typeaheadData: TypeaheadData;
    this.isValidOwner = false;
    const searchedValue = this.meetingForm.get('ownerName').value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    this.ownerErrorResponse = typeaheadData.isResponseError;
  }

  typeaheadOnSelect(event: TypeaheadMatch): void {
    this.isValidOwner = true;
    this.isOwnerEditable = false;
    this.ownerEditImage = this.ownerEditImageSource.pencilIcon;
    this.meetingForm.patchValue({
      'ownerName': convertToTitleCase(event.item.name),
      'ownerCorporateId': event.item.corporateId
    });
    this.selectedOwnerName = this.meetingForm.get('ownerName').value;
  }

  changeTypeaheadLoading(e: boolean): void {
    this.ownerLoading = e;
  }

  typeaheadNoResults(event: boolean): void {
    this.ownerErrorResponse = event;
  }

  onBlurMethod(event, isEditable) {
    if (!this.isValidOwner) {
      this.meetingForm.patchValue({
        ownerName: this.selectedOwnerName
      });
    }
    this.ownerLoading = false;
    this.ownerErrorResponse = false;
    if (event.relatedTarget === null) {
      this.isOwnerEditable = false;
      this.ownerEditImage = this.ownerEditImageSource.pencilIcon;
    } else {
      if (event.relatedTarget.className === 'dropdown-item active') {
        this.isOwnerEditable = true;
      } else {
        this.isOwnerEditable = false;
        this.ownerEditImage = this.ownerEditImageSource.pencilIcon;
      }
    }
  }

  isDraftDisabled(): boolean {
    if (this.meetingType !== 'Conference') {
      if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details')) {
        const newdate: Date = new Date(this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value);
        const hours = newdate.getHours() < 10 ? 0 + '' + newdate.getHours() : newdate.getHours();
        const minutes = newdate.getMinutes() < 10 ? 0 + '' + newdate.getMinutes() : newdate.getMinutes();
        this.meetingTime = hours + '' + minutes;
        this.meetingMomentTime = hours + ':' + minutes;
      }
      if (this.meetingForm.status === 'VALID' && this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings')
        && this.meetingForm.get('dynamicForm').get('meetings').get('event-details') && this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details')
        && this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details')
        && this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('hostName').value !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value
        && this.meetingTime !== '0000' && this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value !== null
        && this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value[0]['AttendeeId'] !== '') {
        if ((this.meetingType === 'Company' && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityTradableEntityId').value !== ''))
          || (this.meetingType === 'Company' && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('debtTicker').value !== ''))
          || (this.meetingType === 'Other' && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingTopic').value !== ''))
          || (this.meetingType === 'Broker' && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingTopic').value !== ''))
          || (this.meetingType === 'Broker' && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('brokerFirmId').value !== ''))) {
          if (this.totalClashes === 0 || (this.totalClashes === 1 && this.duplicateMeetingWith5BnMrktCap === 1)) {
            return false;
          }
        }
      }
    } else {
      if (this.meetingForm.status === 'VALID' && this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('conferences')
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details')
        && this.meetingForm.get('dynamicForm').get('conferences').get('broker-details')
        && this.meetingForm.get('dynamicForm').get('conferences').get('arrangement-contact-details')
        && this.meetingForm.get('dynamicForm').get('conferences').get('arrangement-contact-details').get('organizerName').value !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('arrangement-contact-details').get('brokerUsageInitiator').value !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').get('conferenceName').value !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').get('venue').value !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').get('dateRange').value !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').get('cityCountry').value['cityCountryVal'] !== ''
        && this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').get('businessUnit').value['KeyCode'] !== '') {
        return
      }
    }
    return true;
  }

  isConfirmDisabled() {
    if (this.meetingType === 'Company') {
      if (!this.isDraftDisabled() && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('cityCountry').value['cityCountryVal'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingBusUnit').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('mtgSubtype').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingFormat').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingInitiator').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('location').value !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details')
        && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerContactId').value !== ''
        && (!(this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerEmail').value === '' && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerPhone').value === ''))
        && ((this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizedThrough').value !== 'Broker') ||
          (this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizedThrough').value === 'Broker' && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('brokerUsage').value['KeyDesc'] !== ''))) {

        if (this.totalClashes === 0) {
          return false;
        }
      }
    } else if (this.meetingType === 'Other') {
      if (!this.isDraftDisabled() && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('cityCountry').value['cityCountryVal'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingBusUnit').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingInitiator').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('location').value !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingTopic').value.trim() !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details')
        && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerContactId').value !== ''
        && (!(this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerEmail').value === '' && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerPhone').value === ''))
        && (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('mtgSubtype').value['KeyCode'] === '' || (
          this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('mtgSubtype').value['KeyCode'] !== '' &&
          this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingFormat').value['KeyCode'] !== ''))
      ) {

        if (this.totalClashes === 0) {
          return false;
        }
      }

    } else if (this.meetingType === 'Broker') {
      if (!this.isDraftDisabled() && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('cityCountry').value['cityCountryVal'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingBusUnit').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingInitiator').value['KeyCode'] !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('meetingTopic').value.trim() !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('location').value !== '' &&
        this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details')
        && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerContactId').value !== ''
        && (!(this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerEmail').value === '' && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('organizerPhone').value === ''))) {

        if (this.totalClashes === 0) {
          return false;
        }
      }
    } else if (this.meetingType === 'Conference') {
      return true;
    }
    return true;
  }
  draftForm(buttonClicked: string) {
    if (this.confirmButtonLabel === 'Update') {
      this.emailSendingReason = 'UPDATED';
    } else {
      this.emailSendingReason = 'CREATED';
    }
    if (buttonClicked === 'Draft&Invite') {
      this.draftMeetingStatus = 'DRAFTINVITE';
    } else if (buttonClicked === 'Confirm') {
      this.draftMeetingStatus = 'CONFIRMED';
    } else {
      this.draftMeetingStatus = 'DRAFT';
    }
    let dateLocal = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value;
    let dateArr = dateLocal.split('/');
    let dateFormat = dateArr[0] + ' ' + this.yearObj[dateArr[1]] + ' ' + dateArr[2];
    // let isoFormat = new Date(Date.parse(dateFormat));
    // let dateToDisplay = this.datePipe.transform(isoFormat, 'dd MMM yyyy');
    const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
    const momenttime = moment(meetingTime, "hmm").format("HH:mm");
    this.mtgDateTime = dateFormat + ' ' + momenttime;
    this.eventDetails = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').value;
    this.meetingDetails = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').value;
    this.inviteeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value;
    this.thirdPartyAttendeeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').value;
    this.organizerDetails = this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').value;
    this.mtgLocation = this.eventDetails.location;
    this.mtgSubtype = this.meetingDetails.mtgSubtype && this.meetingDetails.mtgSubtype['KeyDesc'] ? this.meetingDetails.mtgSubtype['KeyDesc'] : '';
    if (this.currentAction === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value !== 'DRAFT') {
      this.meetingForm.patchValue({
        meetingLastUpdatedByCorporateId: this.commonService.getLoggedInUserInfo().getCorporateId(),
        meetingLastUpdatedByName: convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
        meetingUpdatedMethod: 'NO_UPDATE',
      });
      this.insertMeetingValues();
      const newMtgObj = Object.assign({}, this.meeting);
      const oldMtgObj = Object.assign({}, this.actualMeetingForm);
      //For All meeting update popup ask
      delete newMtgObj.fidelityInvitees;
      delete newMtgObj.meetingInitiator;
      delete newMtgObj.arrangementContact;
      delete newMtgObj.meetingOwnerCorporateId;
      delete newMtgObj.meetingUpdateDetails;
      delete newMtgObj.meetingState;
      delete newMtgObj.emailSendingReason;
      delete oldMtgObj.fidelityInvitees;
      delete oldMtgObj.meetingInitiator;
      delete oldMtgObj.arrangementContact;
      delete oldMtgObj.meetingUpdateDetails;
      delete oldMtgObj.meetingState;
      delete oldMtgObj.emailSendingReason;
      delete oldMtgObj.meetingOwnerCorporateId;
      const newMeetingForm = JSON.stringify(newMtgObj);
      const oldMeetingForm = JSON.stringify(oldMtgObj);
      if (newMeetingForm !== oldMeetingForm) {
        this.meetingUpdateActionHeading = 'Update Meeting';
        this.meetingUpdateActionMessage = 'Are you sure you want to update this meeting ?';
        this.updateReasonLabel = 'Reason for Updation (Optional)';
        this.isUpdateModalShown = true;
        this.imageStatus = 'alert';
      } else {
        const newMtgAttendeeObj = {
          'fidelityInvitees': this.meeting.fidelityInvitees
        };
        const oldMtgAttendeeObj = {
          'fidelityInvitees': this.actualMeetingForm.fidelityInvitees
        };
        const newMtgAttendeeForm = JSON.stringify(newMtgAttendeeObj);
        const oldMtgAttendeeForm = JSON.stringify(oldMtgAttendeeObj);
        let attendeeCount = 0;
        newMtgAttendeeObj.fidelityInvitees.forEach((newMeetingInvitee) => {
          oldMtgAttendeeObj.fidelityInvitees.forEach((oldMeetingInvitee) => {
            if (newMeetingInvitee['corporateId'] === oldMeetingInvitee['corporateId']) {
              attendeeCount++;
            }
          });
        });
        if ((newMtgAttendeeForm !== oldMtgAttendeeForm)
          && (attendeeCount < newMtgAttendeeObj.fidelityInvitees.length)) {
          this.updateMeeting('SEND_INVITE');
        } else if ((newMtgAttendeeForm !== oldMtgAttendeeForm)
          && (attendeeCount < oldMtgAttendeeObj.fidelityInvitees.length)) {
          this.updateMeeting('SEND_INVITE');
        } else {
          const newMtgArrangementContactObj = {
            'arrangementContact': this.meeting.arrangementContact
          };
          const oldMtgArrangementContactObj = {
            'arrangementContact': this.actualMeetingForm.arrangementContact
          };
          const newMtgArrangementContactForm = JSON.stringify(newMtgArrangementContactObj);
          const oldMtgArrangementContactForm = JSON.stringify(oldMtgArrangementContactObj);
          if (newMtgArrangementContactForm !== oldMtgArrangementContactForm) {
            this.updateMeeting('AUTO_UPDATE');
          } else {
            this.insertMeetingValues();
            if (this.currentAction === 'update' && this.commonService.getMeetingType() === 'Company') {
              this.meeting.securityDetail.securityName = this.securityNameOnUpdateMeeting;
            }
            let dateArrray = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value.split('/');
            const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
            const momenttime = moment(meetingTime, "hmm").format("HH:mm");
            let newDate: string = dateArrray[2] + '-' + dateArrray[1] + '-' + dateArrray[0];
            const meetingTimeZone = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value;
            let localTime = momentTimezone.tz((newDate + ' ' + momenttime), meetingTimeZone.split(' ')[0]);
            let userTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
            this.meeting['meetingDateInLocal'] = this.eventDetails.date !== '' ? userTime.substring(0, 10) : '';
            this.meeting.meetingLocation['internalLocationRoomCode'] = this.eventDetails.room ? this.eventDetails.room.KeyCode : '';

            if (this.currentAction === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()
              && this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail) {
              this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction, this.arrangementContactEmail);
            } else if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()) {
              this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction, this.commonService.getArrangementContactDetails().getArrangementContactEmail());
            } else {
              this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction);
            }

            this.meetingObservable.subscribe((response) => {
              if (this.currentAction === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()) {
                if (this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail ||
                  this.meeting.arrangementContact.organizerPhone.toString() !== this.arrangementContactPhone.toString()) {
                  this.commonService.updateExternalContact(this.meeting.arrangementContact, this.arrangementContactEmail).then(response => {
                    console.log('contaacts updated successfully', response);
                    if (this.currentAction === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                      this.draftConfirmMessage = 'Meeting Updated successfully.';
                      this.messageHeading = 'Meeting updated';
                      this.isModalShown = true;
                      this.imageStatus = 'success';
                    }
                    this.commonService.setFormChangeValue(false);
                    this.showNoButton = false;
                    this.routeCase = 'draftmeeting';
                    this.confirmButton = 'OK';
                    this.modalService.onHide.subscribe((reason) => {
                      this.checkForBackDropClick(reason);
                    });
                  }).catch(error => {
                    this.handleUpdateContactError();
                  });
                } else {
                  if (this.currentAction === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                    this.draftConfirmMessage = 'Meeting Updated successfully.';
                    this.messageHeading = 'Meeting updated';
                    this.isModalShown = true;
                    this.imageStatus = 'success';
                  }
                  this.commonService.setFormChangeValue(false);
                  this.showNoButton = false;
                  this.routeCase = 'draftmeeting';
                  this.confirmButton = 'OK';
                  this.modalService.onHide.subscribe((reason) => {
                    this.checkForBackDropClick(reason);
                  });
                }
              } else {
                if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()
                  || this.meeting.arrangementContact.organizerPhone.toString() !== this.commonService.getArrangementContactDetails().getArrangementContactPhone().toString()) {
                  this.commonService.updateExternalContact(this.meeting.arrangementContact, this.commonService.getArrangementContactDetails().getArrangementContactEmail()).then(response => {
                    console.log('contaacts updated successfully', response);
                    if (this.currentAction === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                      this.draftConfirmMessage = 'Meeting Updated successfully.';
                      this.messageHeading = 'Meeting updated';
                      this.isModalShown = true;
                      this.imageStatus = 'success';
                    }
                    this.commonService.setFormChangeValue(false);
                    this.showNoButton = false;
                    this.routeCase = 'draftmeeting';
                    this.confirmButton = 'OK';
                    this.modalService.onHide.subscribe((reason) => {
                      this.checkForBackDropClick(reason);
                    });
                  }).catch(error => {
                    this.handleUpdateContactError();
                  });
                } else {
                  if (this.currentAction === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                    this.draftConfirmMessage = 'Meeting Updated successfully.';
                    this.messageHeading = 'Meeting updated';
                    this.isModalShown = true;
                    this.imageStatus = 'success';
                  }
                  this.commonService.setFormChangeValue(false);
                  this.showNoButton = false;
                  this.routeCase = 'draftmeeting';
                  this.confirmButton = 'OK';
                  this.modalService.onHide.subscribe((reason) => {
                    this.checkForBackDropClick(reason);
                  });
                }
              }

            },
              (error) => {
                this.draftConfirmMessage = 'The meeting could not be saved. Please try again.';
                this.messageHeading = 'Error';
                this.updatedReason = '';
                this.updateMethod = '';
                this.imageStatus = 'alert';
                this.isModalShown = true;
                this.showNoButton = false;
              });
          }
        }
      }
    } else {
      this.meetingForm.patchValue({
        meetingLastUpdatedByCorporateId: this.commonService.getLoggedInUserInfo().getCorporateId(),
        meetingLastUpdatedByName: convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
        meetingUpdatedMethod: '',
        meetingUpdatedReason: '',
        meetingCancellationReason: ''
      });
      this.insertMeetingValues();
      if (this.currentAction === 'update' && this.commonService.getMeetingType() === 'Company') {
        this.meeting.securityDetail.securityName = this.securityNameOnUpdateMeeting;
      }
      let dateArrray = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value.split('/');
      const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
      const momenttime = moment(meetingTime, "hmm").format("HH:mm");
      let newDate: string = dateArrray[2] + '-' + dateArrray[1] + '-' + dateArrray[0];
      const meetingTimeZone = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value;
      let localTime = momentTimezone.tz((newDate + ' ' + momenttime), meetingTimeZone.split(' ')[0]);
      let userTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
      this.meeting['meetingDateInLocal'] = this.eventDetails.date !== '' ? userTime.substring(0, 10) : '';
      this.meeting.meetingLocation['internalLocationRoomCode'] = this.eventDetails.room ? this.eventDetails.room.KeyCode : '';
      // this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction);

      if (this.currentAction === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()
        && this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail) {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction, this.arrangementContactEmail);
      } else if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()) {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction, this.commonService.getArrangementContactDetails().getArrangementContactEmail());
      } else {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, this.currentAction);
      }

      this.meetingObservable.subscribe(async (response) => {
        if (this.currentAction === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()) {
          if (this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail || this.meeting.arrangementContact.organizerPhone.toString() !== this.arrangementContactPhone.toString()) {
            this.commonService.updateExternalContact(this.meeting.arrangementContact, this.arrangementContactEmail).then(response => {
              console.log('contaacts updated successfully', response);
              if (buttonClicked === 'Confirm') {
                this.draftConfirmMessage = 'Meeting Confirmed successfully.';
                this.messageHeading = 'Meeting confirmed';
                this.isModalShown = true;
                this.imageStatus = 'success';
              } else {
                this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
                this.messageHeading = 'Meeting saved';
                this.isModalShown = true;
                this.imageStatus = 'success';
              }
              this.commonService.setFormChangeValue(false);
              this.showNoButton = false;
              this.routeCase = 'draftmeeting';
              this.confirmButton = 'OK';
              // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
              this.modalService.onHide.subscribe((reason) => {
                this.checkForBackDropClick(reason);
              });
            }).catch(error => {
              this.handleUpdateContactError();
            });
          } else {
            if (buttonClicked === 'Confirm') {
              this.draftConfirmMessage = 'Meeting Confirmed successfully.';
              this.messageHeading = 'Meeting confirmed';
              this.isModalShown = true;
              this.imageStatus = 'success';
            } else {
              this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
              this.messageHeading = 'Meeting saved';
              this.isModalShown = true;
              this.imageStatus = 'success';
            }
            this.commonService.setFormChangeValue(false);
            this.showNoButton = false;
            this.routeCase = 'draftmeeting';
            this.confirmButton = 'OK';
            // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
            this.modalService.onHide.subscribe((reason) => {
              this.checkForBackDropClick(reason);
            });
          }
        } else {
          if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()
            || this.meeting.arrangementContact.organizerPhone.toString() !== this.commonService.getArrangementContactDetails().getArrangementContactPhone().toString()) {
            this.commonService.updateExternalContact(this.meeting.arrangementContact, this.commonService.getArrangementContactDetails().getArrangementContactEmail()).then(response => {
              console.log('contaacts updated successfully', response);
              if (buttonClicked === 'Confirm') {
                this.draftConfirmMessage = 'Meeting Confirmed successfully.';
                this.messageHeading = 'Meeting confirmed';
                this.isModalShown = true;
                this.imageStatus = 'success';
              } else {
                this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
                this.messageHeading = 'Meeting saved';
                this.isModalShown = true;
                this.imageStatus = 'success';
              }
              this.commonService.setFormChangeValue(false);
              this.showNoButton = false;
              this.routeCase = 'draftmeeting';
              this.confirmButton = 'OK';
              // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
              this.modalService.onHide.subscribe((reason) => {
                this.checkForBackDropClick(reason);
              });
            }).catch(error => {
              this.handleUpdateContactError();
            });
          } else {
            if (buttonClicked === 'Confirm') {
              this.draftConfirmMessage = 'Meeting Confirmed successfully.';
              this.messageHeading = 'Meeting confirmed';
              this.isModalShown = true;
              this.imageStatus = 'success';
            } else {
              this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
              this.messageHeading = 'Meeting saved';
              this.isModalShown = true;
              this.imageStatus = 'success';
            }
            this.commonService.setFormChangeValue(false);
            this.showNoButton = false;
            this.routeCase = 'draftmeeting';
            this.confirmButton = 'OK';
            // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
            this.modalService.onHide.subscribe((reason) => {
              this.checkForBackDropClick(reason);
            });
          }
        }

      },
        (error) => {
          this.draftConfirmMessage = 'The meeting could not be saved. Please try again.';
          this.messageHeading = 'Error';
          this.imageStatus = 'alert';
          this.isModalShown = true;
          this.showNoButton = false;
          // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
        });
    }
  }
  formInitialized(name, form) {
    this.meetingForm.setControl(name, form);
  }

  saveConferenceForm(event: any) {
    this.conferenceDetail = this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').value;
    this.brokerDetail = this.meetingForm.get('dynamicForm').get('conferences').get('broker-details').value;
    this.arrangementContactDetails = this.meetingForm.get('dynamicForm').get('conferences').get('arrangement-contact-details').value;
    this.insertConferenceMeetingValues();
    let conferenceMeetingCopy = Object.assign(this.conferenceMeeting);
    if (conferenceMeetingCopy.arrangementContact && conferenceMeetingCopy.arrangementContact.brokerUsageInitiator) {
      conferenceMeetingCopy['brokerUsageInitiator'] = conferenceMeetingCopy.arrangementContact.brokerUsageInitiator['KeyDesc']
        ? conferenceMeetingCopy.arrangementContact.brokerUsageInitiator['KeyDesc'] : conferenceMeetingCopy.arrangementContact.brokerUsageInitiator;
    }

    const updateArrangmentContact = () => {
      if ((this.arrangementContactDetails.organizerEmail && this.arrangementContactDetails.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail())
        || (this.arrangementContactDetails.organizerPhone && this.arrangementContactDetails.organizerPhone.toString() !== this.commonService.getArrangementContactDetails().getArrangementContactPhone().toString())) {
        this.commonService.updateExternalContact(this.arrangementContactDetails, this.commonService.getArrangementContactDetails().getArrangementContactEmail()).then(response => {
          this.draftConfirmMessage = 'Conference Confirmed successfully.';
          this.messageHeading = 'Conference confirmed';
          this.isModalShown = true;
          this.imageStatus = 'success';
          // this.commonService.setFormChangeValue(false);
          this.showNoButton = false;
          this.routeCase = 'draftmeeting';
          this.confirmButton = 'OK';
          this.modalService.onHide.subscribe((reason) => {
            this.checkForBackDropClick(reason);
          });
        }).catch(error => {
          this.handleUpdateContactError();
        });
      } else {
        this.draftConfirmMessage = 'Conference Confirmed successfully.';
        this.messageHeading = 'Conference confirmed';
        this.isModalShown = true;
        this.imageStatus = 'success';
        // this.commonService.setFormChangeValue(false);
        this.showNoButton = false;
        this.routeCase = 'draftmeeting';
        this.confirmButton = 'OK';
        this.modalService.onHide.subscribe((reason) => {
          this.checkForBackDropClick(reason);
        });
      }
    }

    this.commonService.insertConferenceMeetings(conferenceMeetingCopy).subscribe((conferenceInsertResponse) => {
      // console.log('responseConference: ', conferenceInsertResponse);
      // console.log('utilDataCountries: ', this.utilDataCountries);
      this.conferenceSuccessEventId = conferenceInsertResponse['body'] ? conferenceInsertResponse['body'].eventId : '';
      if (this.brokerDetail.brokerFirmId
        && this.commonService.getBrokerFirmDetails()['telephone'] !== this.brokerDetail.telephone) {
        let querySTring = 'brokerFirmId=' + this.brokerDetail.brokerFirmId;
        this.commonService.getBrokerFirm(querySTring).subscribe((brokerFirmSearchResponse) => {
          if (brokerFirmSearchResponse) {
            let contactUpdated = brokerFirmSearchResponse[0];
            this.contactMapper.brokerContact.brokerFirm.versionNumber = contactUpdated['versionNumber'];
            this.contactMapper.brokerContact.brokerFirm.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
            this.contactMapper.brokerContact.brokerFirm.updatedTimestamp = new Date();
            this.contactMapper.contactType = 'Broker Firm';
            this.contactMapper.brokerContact.brokerFirm.firmName = this.brokerDetail.brokerFirmName;
            this.contactMapper.brokerContact.brokerFirm.firmId = this.brokerDetail.brokerFirmId;
            this.contactMapper.brokerContact.brokerFirm.telephone = this.brokerDetail.telephone;
            this.contactMapper.brokerContact.brokerFirm.insertID = contactUpdated['insertID'];
            this.contactMapper.brokerContact.brokerFirm.insertTimestamp = contactUpdated['insertTimestamp'];
            this.contactMapper.brokerContact.brokerFirm.region = contactUpdated['region'];
            this.contactMapper.brokerContact.brokerFirm.brokerFirmWebsite = contactUpdated['brokerFirmWebsite'];
            this.contactMapper.brokerContact.brokerFirm.brokerFirmAddress = contactUpdated['brokerFirmAddress'];
            this.contactMapper.brokerContact.brokerFirm.brokerFirmDescription = contactUpdated['brokerFirmDescription'];
            this.contactMapper.brokerContact.brokerFirm['brokerGroupFlag'] = 'N';
            this.contactMapper.brokerContact.brokerFirm['brokerGroup'] = {};
            this.contactMapper.brokerContact.brokerFirm['brokerGroup']['brokerGroupName'] = '';
            this.contactMapper.brokerContact.brokerFirm['brokerGroup']['brokerGroupId'] = '';
            let countryDetails: any;
            this.utilDataCountries.forEach((countryInfo) => {
              if (countryInfo['KeyDesc'].toUpperCase() === contactUpdated['country'].toUpperCase()) {
                countryDetails = countryInfo;
              }
            });
            console.log('countryDetails: ', countryDetails);
            this.contactMapper.brokerContact.brokerFirm.country = countryDetails['KeyCode'];
            // contactUpdated['country'];
            this.commonService.insertNewContact(this.contactMapper, 'update').subscribe((brokerFirmInsertResponse) => {
              console.log('Broker Firm Details updated successfully', brokerFirmInsertResponse);
              updateArrangmentContact();
            }, (error) => {
              this.handleUpdateContactError();
            });
          }
        }, (error) => {
          this.handleUpdateContactError();
        });
      } else {
        updateArrangmentContact();
      }
    },
      (error) => {
        console.log('errorConference: ', error)
        this.draftConfirmMessage = 'The meeting could not be saved. Please try again.';
        this.messageHeading = 'Error';
        this.updatedReason = '';
        this.updateMethod = '';
        this.imageStatus = 'alert';
        this.isModalShown = true;
        this.isUpdateModalShown = false;
      });
  }
  resetConferenceMeeting() {
    this.commonService.resetMeetingDetailsSubject.next(true);
  }
  confirm(): void {
    if (this.routeCase === 'draftmeeting') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      this.routeIfMeetingCreationSuccess();
      this.cdr.detectChanges();
    } else if (this.routeCase === 'meetingRouteToView') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      this.router.navigate(['/events/meeting'], { skipLocationChange: true })
      this.cdr.detectChanges();
    } else if (this.routeCase === 'meetingRouteToContacts') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      this.router.navigate(['/contacts'], { skipLocationChange: true })
      this.cdr.detectChanges();
    } else {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      this.initialiseInvites();
      this.router.navigate(['/meeting/create', { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
      this.cdr.detectChanges();
    }
    this.commonService.sectorOfSecurity.next('');
  }

  onHidden(operationType): void {
    if (operationType === 'update/cancel') {
      this.saveDialogModal.hide();
      this.isUpdateModalShown = false;
    } else if (operationType === 'create/draft/draftInvite') {
      if (this.routeCase === 'draftmeeting') {
        this.saveDialogModal.hide();
        this.isModalShown = false;
        this.routeIfMeetingCreationSuccess();
        this.cdr.detectChanges();
      } else if (this.routeCase === 'meetingRouteToView') {
        this.saveDialogModal.hide();
        this.isModalShown = false;
        this.router.navigate(['/events/meeting'], { skipLocationChange: true })
        this.cdr.detectChanges();
      }
    }
  }

  hideUpdateBox() {
    this.isUpdateModalShown = false;
    this.updatedReason = '';
    this.updateMethod = '';
    this.emailSendingReason = '';
    this.draftMeetingStatus = '';
  }

  updateMeeting(event: string) {
    this.updateMethod = event;
    this.meetingForm.patchValue({
      meetingLastUpdatedByCorporateId: this.commonService.getLoggedInUserInfo().getCorporateId(),
      meetingLastUpdatedByName: convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
      meetingUpdatedMethod: this.updateMethod,
    });

    this.route.params.subscribe((params) => {
      if (this.updateMethod === 'cancelMeeting') {
        this.draftMeetingStatus = 'CANCELLED';
        this.meetingForm.patchValue({
          meetingUpdatedReason: '',
          meetingCancellationReason: this.updatedReason
        });
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details').patchValue({
          meetingStatus: { 'status': 'Cancelled' },
          meetingState: 'CANCELLED',
        });
        this.eventDetails = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').value;
        this.meetingDetails = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').value;
        this.inviteeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value;
        this.thirdPartyAttendeeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').value;
        // this.thirdPartyAttendees = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').get('thirdPartyAttendeeGrid').value;
        this.organizerDetails = this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').value;
        this.emailSendingReason = 'CANCELLED';
      } else if (this.updateMethod === 'AUTO_UPDATE' || this.updateMethod === 'SEND_INVITE') {
        this.meetingForm.patchValue({
          meetingUpdatedReason: this.updatedReason,
          meetingCancellationReason: ''
        });
        this.emailSendingReason = 'UPDATED';
      }
      this.insertMeetingValues();
      if (params['action'] === 'update' && this.commonService.getMeetingType() === 'Company') {
        this.meeting.securityDetail.securityName = this.securityNameOnUpdateMeeting;
      }
      let dateArrray = this.eventDetails.date.split('/');
      const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
      const momenttime = moment(meetingTime, "hmm").format("HH:mm");
      let newDate: string = dateArrray[2] + '-' + dateArrray[1] + '-' + dateArrray[0];
      const meetingTimeZone = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value;
      let localTime = momentTimezone.tz((newDate + ' ' + momenttime), meetingTimeZone.split(' ')[0]);
      let userTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
      this.meeting['meetingDateInLocal'] = this.eventDetails.date !== '' ? userTime.substring(0, 10) : '';
      this.meeting.meetingLocation['internalLocationRoomCode'] = this.eventDetails.room ? this.eventDetails.room.KeyCode : '';

      if (params['action'] === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()
        && this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail) {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, params['action'], this.arrangementContactEmail);
      } else if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()) {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, params['action'], this.commonService.getArrangementContactDetails().getArrangementContactEmail());
      } else {
        this.meetingObservable = this.commonService.insertMeetingDetails(this.meeting, params['action']);
      }


      this.meetingObservable.subscribe((response) => {
        if (params['action'] === 'update' && this.meeting.arrangementContact.organizerContactId.toString() === this.arrangementContactId.toString()) {
          if (this.meeting.arrangementContact.organizerEmail !== this.arrangementContactEmail ||
            this.meeting.arrangementContact.organizerPhone.toString() !== this.arrangementContactPhone.toString()) {
            this.commonService.updateExternalContact(this.meeting.arrangementContact, this.arrangementContactEmail).then(response => {
              console.log('contaacts updated successfully', response);
              if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CANCELLED') {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting Cancelled successfully.';
                this.messageHeading = 'Meeting Cancelled';
                this.isModalShown = true;
                this.imageStatus = 'success';

              } else if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting Updated successfully.';
                this.messageHeading = 'Meeting updated';
                this.isModalShown = true;
                this.imageStatus = 'success';
              } else {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
                this.messageHeading = 'Meeting saved';
                this.isModalShown = true;
                this.imageStatus = 'success';
              }
              this.commonService.setFormChangeValue(false);
              this.showNoButton = false;
              if (this.updateMethod === 'cancelMeeting') {
                this.routeCase = 'meetingRouteToView';
              } else {
                this.routeCase = 'draftmeeting';
              }
              this.confirmButton = 'OK';
              this.modalService.onHide.subscribe((reason) => {
                this.checkForBackDropClick(reason);
              });
            }).catch(error => {
              this.handleUpdateContactError();
            });
          } else {
            if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CANCELLED') {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting Cancelled successfully.';
              this.messageHeading = 'Meeting Cancelled';
              this.isModalShown = true;
              this.imageStatus = 'success';

            } else if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting Updated successfully.';
              this.messageHeading = 'Meeting updated';
              this.isModalShown = true;
              this.imageStatus = 'success';
            } else {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
              this.messageHeading = 'Meeting saved';
              this.isModalShown = true;
              this.imageStatus = 'success';
            }
            this.commonService.setFormChangeValue(false);
            this.showNoButton = false;
            if (this.updateMethod === 'cancelMeeting') {
              this.routeCase = 'meetingRouteToView';
            } else {
              this.routeCase = 'draftmeeting';
            }
            this.confirmButton = 'OK';
            this.modalService.onHide.subscribe((reason) => {
              this.checkForBackDropClick(reason);
            });
          }
        } else {
          if (this.meeting.arrangementContact.organizerEmail !== this.commonService.getArrangementContactDetails().getArrangementContactEmail()
            || this.meeting.arrangementContact.organizerPhone.toString() !== this.commonService.getArrangementContactDetails().getArrangementContactPhone().toString()) {
            this.commonService.updateExternalContact(this.meeting.arrangementContact, this.commonService.getArrangementContactDetails().getArrangementContactEmail()).then(response => {
              //console.log('contaacts updated successfully', response);
              if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CANCELLED') {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting Cancelled successfully.';
                this.messageHeading = 'Meeting Cancelled';
                this.isModalShown = true;
                this.imageStatus = 'success';

              } else if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting Updated successfully.';
                this.messageHeading = 'Meeting updated';
                this.isModalShown = true;
                this.imageStatus = 'success';
              } else {
                this.isUpdateModalShown = false;
                this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
                this.messageHeading = 'Meeting saved';
                this.isModalShown = true;
                this.imageStatus = 'success';
              }
              this.commonService.setFormChangeValue(false);
              this.showNoButton = false;
              if (this.updateMethod === 'cancelMeeting') {
                this.routeCase = 'meetingRouteToView';
              } else {
                this.routeCase = 'draftmeeting';
              }
              this.confirmButton = 'OK';
              this.modalService.onHide.subscribe((reason) => {
                this.checkForBackDropClick(reason);
              });
            }).catch(error => {
              this.handleUpdateContactError();
            });
          } else {
            if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CANCELLED') {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting Cancelled successfully.';
              this.messageHeading = 'Meeting Cancelled';
              this.isModalShown = true;
              this.imageStatus = 'success';

            } else if (params['action'] === 'update' && this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED') {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting Updated successfully.';
              this.messageHeading = 'Meeting updated';
              this.isModalShown = true;
              this.imageStatus = 'success';
            } else {
              this.isUpdateModalShown = false;
              this.draftConfirmMessage = 'Meeting saved as Draft successfully.';
              this.messageHeading = 'Meeting saved';
              this.isModalShown = true;
              this.imageStatus = 'success';
            }
            this.commonService.setFormChangeValue(false);
            this.showNoButton = false;
            if (this.updateMethod === 'cancelMeeting') {
              this.routeCase = 'meetingRouteToView';
            } else {
              this.routeCase = 'draftmeeting';
            }
            this.confirmButton = 'OK';
            this.modalService.onHide.subscribe((reason) => {
              this.checkForBackDropClick(reason);
            });
          }
        }

      },
        (error) => {
          if (this.updateMethod === 'cancelMeeting') {
            this.draftConfirmMessage = 'The meeting could not be cancelled. Please try again.';
          } else {
            this.draftConfirmMessage = 'The meeting could not be saved. Please try again.';
          }
          this.messageHeading = 'Error';
          this.updatedReason = '';
          this.updateMethod = '';
          this.imageStatus = 'alert';
          this.isModalShown = true;
          this.isUpdateModalShown = false;
        });
    });
  }

  decline() {
    this.saveDialogModal.hide();
    this.isModalShown = false;
  }
  insertMeetingValues() {
    let dateArrray = this.eventDetails.date.split('/');
    const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
    const momenttime = moment(meetingTime, "hmm").format("HH:mm");
    let newDate: string = dateArrray[2] + '-' + dateArrray[1] + '-' + dateArrray[0];
    const meetingTimeZone = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('timezone').value;
    let localTime = momentTimezone.tz((newDate + ' ' + momenttime), meetingTimeZone.split(' ')[0]);
    let gmtTime = localTime.clone().tz("Europe/London").format();
    let userLocalTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();

    this.meeting.meetingType = this.meetingType;
    this.meeting.emailSendingReason = this.emailSendingReason;
    this.meeting.meetingState = this.draftMeetingStatus;
    this.meeting.executiveInvited = this.thirdPartyAttendeeDetails.meetingExecutive ? 'Y' : 'N';
    // this.meetingDetails.meetingExecutive ? 'Y' : 'N';
    this.meeting.meetingLocation.externalLocationAddress = this.eventDetails.address ? this.eventDetails.address.trim() : '';
    this.meeting.brokerLocationIndicator = this.eventDetails.brokerLocation ? 'Y' : 'N';
    if (this.actualMeetingForm.meetingStatus.toUpperCase() === 'ARRIVED') {
      this.meeting.meetingStatus = this.actualMeetingForm.meetingStatus;
    } else {
      this.meeting.meetingStatus = this.eventDetails.meetingStatus ? this.eventDetails.meetingStatus.status : '';
    }
    this.meeting.delayedByMins = this.eventDetails.delayedByMins ? this.eventDetails.delayedByMins : 0;
    ({ GRD_COUNTRY_CD: this.meeting.country.countryCode, Country: this.meeting.country.countryDescription, Cities: this.meeting.meetingCity }
      = this.eventDetails.cityCountry);
    this.meeting.meetingLocation.internalLocationRoom = this.eventDetails.room ? this.eventDetails.room.KeyDesc : '';
    this.meeting.meetingLocation.internalLocationRoomOther = this.eventDetails.internalLocationRoomOther ? this.eventDetails.internalLocationRoomOther : '';
    if (this.meetingType !== 'Broker') {
      ({ KeyCode: this.meeting.meetingSubType.meetingSubTypeCode, KeyDesc: this.meeting.meetingSubType.meetingSubTypeDescription }
        = this.meetingDetails.mtgSubtype);
      if (this.meeting.meetingSubType.meetingFormat) {
        ({
          KeyCode: this.meeting.meetingSubType.meetingFormat.meetingFormatCode,
          KeyDesc: this.meeting.meetingSubType.meetingFormat.meetingFormatDescription
        }
          = this.meetingDetails.meetingFormat);
      }
    }
    this.meeting.businessUnit = this.meetingDetails.meetingBusUnit.KeyCode;
    ({ KeyCode: this.meeting.meetingInitiator.meetingInitiatorCode, KeyDesc: this.meeting.meetingInitiator.meetingInitiatorDescription }
      = this.meetingDetails.meetingInitiator);

    this.meeting.dialIn.dialInNumber = this.eventDetails.dailin && this.eventDetails.dailpicker ? this.eventDetails.dailpicker.trim() : '';
    this.meeting.dialIn.dialInAccessCode = this.eventDetails.dailin && this.eventDetails.accesscode ? this.eventDetails.accesscode.trim() : '';
    this.meeting.meetingTimeInGMT = this.meetingTime !== '0000' ? gmtTime.substring(11, 13) + gmtTime.substring(14, 16) : '0000';
    this.meeting.meetingTimeInLocalTimezone = this.meetingTime !== '0000' ? userLocalTime.substring(11, 13) + userLocalTime.substring(14, 16) : '0000'
    this.meeting.meetingDate = this.eventDetails.date !== '' ? gmtTime.substring(0, 10) : '';
    if ((this.meetingType === 'Company' && this.meetingDetails.securityType === 'Equity') || (this.meetingType === 'Company' && this.businessEntity === 'EQ')) {
      ({
        securityName: this.meeting.securityDetail.securityName,
        securityTradableEntityId: this.meeting.securityDetail.securityTradableEntityId,
        securityBBTicker: this.meeting.securityDetail.bloombergTicker,
        securityTicker: this.meeting.securityDetail.ticker,
        securityTseCode: this.meeting.securityDetail.tseIdentifier
      } = this.meetingDetails);
    } else if (this.meetingType === 'Other') {
      this.meeting.meetingTopic = this.meetingDetails.meetingTopic.trim();
    } else if (this.meetingType === 'Broker') {
      this.meeting.meetingTopic = this.meetingDetails.meetingTopic.trim();
      this.meeting.brokerDetail.brokerFirmName = this.meetingDetails.brokerFirmName;
      this.meeting.brokerDetail.brokerFirmId = this.meetingDetails.brokerFirmId;
    }
    ({
      hostCorpId: this.meeting.hostCorporateId,
      subjectLine: this.meeting.emailSubject
    } = this.meetingDetails);
    ({
      meetingId: this.meeting.meetingId,
      duration: this.meeting.meetingDuration,
      timezone: this.meeting.meetingTimezone,
      location: this.meeting.meetingLocation.locationType
    } = this.eventDetails);
    this.meeting.fidelityInvitees = [];
    this.meeting.thirdPartyAttendee = [];
    if (this.inviteeDetails !== null) {
      const inviteeArray = [];
      Object.values(this.inviteeDetails).forEach((rowNode, Index) => {
        const inviteeObj = Object.assign({}, rowNode);
        inviteeArray[Index] = inviteeObj;
        inviteeArray[Index]['Call-In'] = inviteeArray[Index]['Call-In'] === true ? 'Y' : 'N';
        inviteeArray[Index]['Invite'] = inviteeArray[Index]['Invite'] === true ? 'Y' : 'N';
        if (this.meetingType === 'Company') {
          inviteeArray[Index]['Infopacks'] = inviteeArray[Index]['Infopacks'] === true ? 'Y' : 'N';
        }
        inviteeArray[Index]['Info Only'] = inviteeArray[Index]['Info Only'] === true ? 'Y' : 'N';
      });
      for (const item of inviteeArray) {
        if (item['AttendeeId'].length !== 0) {
          let attendee: any;
          attendee = new FidelityInvitees(item['AttendeeId'].toUpperCase(),
            item['Attendee'] ? convertToTitleCase(item['Attendee'].replace(' (Host)', '')) : '',
            item['Call-In'],
            item['Invite'],
            item['Infopacks'],
            item['Info Only'],
            item['Response']);
          if (this.meetingType === 'Other' || this.meetingType === 'Broker') {
            delete attendee['isInfoPackRequired'];
          }
          this.meeting.fidelityInvitees.push(attendee);
        }
      }
    }
    if (this.thirdPartyAttendeeDetails.thirdPartyAttendeeGrid !== null) {
      const externalContactsArray = Object.values(this.thirdPartyAttendeeDetails.thirdPartyAttendeeGrid);
      for (const item of externalContactsArray) {
        if (item['ExternalContactName'].length !== 0) {
          const externalAttendee = new ThirdPartyAttendee(item['ExternalContactName'] ? convertToTitleCase(item['ExternalContactName']) : '', item['ExternalContactId'],
            item['Email'], item['Position'], item['Notes']);
          this.meeting.thirdPartyAttendee.push(externalAttendee);
        }
      }
    }
    this.meeting.arrangementContact.organizedThrough = this.organizerDetails.organizedThrough ? this.organizerDetails.organizedThrough : '';
    this.meeting.arrangementContact.organizerContactId = this.organizerDetails.organizerContactId ? this.organizerDetails.organizerContactId : '';
    this.meeting.arrangementContact.organizerName = this.organizerDetails.organizerName ? this.organizerDetails.organizerName : '';
    this.meeting.arrangementContact.organizerCompany = this.organizerDetails.organizerCompany ? this.organizerDetails.organizerCompany : '';
    this.meeting.arrangementContact.organizerPhone = this.organizerDetails.organizerPhone ? this.organizerDetails.organizerPhone : '';
    this.meeting.arrangementContact.organizerEmail = this.organizerDetails.organizerEmail ? this.organizerDetails.organizerEmail : '';
    this.meeting.arrangementContact.organizerPosition = this.organizerDetails.organizerPosition ? this.organizerDetails.organizerPosition : '';
    this.meeting.arrangementContact.brokerUsageInitiator = this.organizerDetails.brokerUsage ? this.organizerDetails.brokerUsage.KeyDesc : '';
    this.meeting.additionalNotes = this.meetingForm.get('dynamicForm').get('meetings').get('additional-notes').get('additionalNotes').value.trim();
    this.meeting.meetingCreator.creatorName = this.meetingForm.get('creatorName').value;
    this.meeting.meetingCreator.corporateId = this.meetingForm.get('creatorCorporateId').value;
    this.meeting.meetingOwnerCorporateId = this.meetingForm.get('ownerCorporateId').value;
    this.meeting.meetingRegion = this.meetingForm.get('meetingRegion').value;
    this.meeting.meetingUpdateDetails.meetingLastUpdatedByCorporateId = this.meetingForm.get('meetingLastUpdatedByCorporateId').value;
    this.meeting.meetingUpdateDetails.meetingLastUpdatedByName = this.meetingForm.get('meetingLastUpdatedByName').value;
    this.meeting.meetingUpdateDetails.meetingUpdatedMethod = this.meetingForm.get('meetingUpdatedMethod').value.trim();
    this.meeting.meetingUpdateDetails.meetingUpdatedReason = this.meetingForm.get('meetingUpdatedReason').value.trim();
    this.meeting.meetingCancellationReason = this.meetingForm.get('meetingCancellationReason').value.trim();
    this.meeting.businessEntity = this.meetingType === 'Company' ? this.meetingDetails.securityType ? this.meetingDetails.securityType === 'Fixed Income' ? 'FI' : 'EQ' : this.businessEntity ? this.businessEntity : '' : '';
    this.meeting.debtTickerDetail.debtTicker = this.meetingType === 'Company' && this.meeting.businessEntity === 'FI' ? this.meetingDetails.debtTicker ? this.meetingDetails.debtTicker : this.debtTcker ? this.debtTcker : '' : '';
    this.meeting.debtTickerDetail.analystName = this.meetingType === 'Company' && this.meeting.businessEntity === 'FI' ? this.meetingDetails.analystName ? this.meetingDetails.analystName : '' : '';
    this.meeting.debtTickerDetail.analystCorporateId = this.meetingType === 'Company' && this.meeting.businessEntity === 'FI' ? this.meetingDetails.analystCorporateId ? this.meetingDetails.analystCorporateId : '' : '';
  }

  checkForBackDropClick(reason: string) {
    if (reason === 'backdrop-click') {
      // this.routeIfMeetingCreationSuccess();
    }
  }
  routeIfMeetingCreationSuccess() {
    // console.log('here: ', this.commonService.getMeetingType());
    if (this.draftConfirmMessage === 'Meeting Confirmed successfully.' || this.draftConfirmMessage === 'Meeting saved as Draft successfully.' ||
      this.draftConfirmMessage === 'Conference Confirmed successfully.' ||
      this.draftConfirmMessage === 'Meeting Updated successfully.' || this.draftConfirmMessage === 'Contact details could not be updated. Please try again.') {
      if (this.commonService.getMeetingType() === 'Conference') {
        this.router.navigate(['/conference/update', { eventId: this.conferenceSuccessEventId }], { skipLocationChange: true });
      } else {
        this.router.navigate(['/events/meeting'], { skipLocationChange: true });
      }
    }
  }

  checkMeetingStatus() {
    if (this.meetingForm.get('dynamicForm').get('meetings').get('event-details')
      && (this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'NEW'
        || this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'DRAFT')) {
      return false;
    }
    return true;
  }

  checkMeetingStatusForSaveEnable() {
    if ((this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings')
      && this.meetingForm.get('dynamicForm').get('meetings').get('event-details')
      && (this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CONFIRMED')) || (
        this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') &&
        this.meetingForm.get('dynamicForm').get('meetings').get('event-details')
        && (this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingState').value === 'CANCELLED')
      )) {
      return true;
    }
    return false;
  }

  discardDraftMeeting(isDiscardConfirm) {

    let dateLocal = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('date').value;
    let dateArr = dateLocal.split('/');
    //let dateFormat = dateArr[2] + '-' + dateArr[1] + '-' + dateArr[0]+ 'T00:00:00Z';
    //let isoFormat = new Date(Date.parse(dateFormat));
    // let dateToDisplay = this.datePipe.transform(isoFormat, 'dd MMM yyyy');
    let dateFormat = dateArr[0] + ' ' + this.yearObj[dateArr[1]] + ' ' + dateArr[2];
    const meetingTime = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('meetingTime').value;
    const momenttime = moment(meetingTime, "hmm").format("HH:mm");
    this.mtgDateTime = dateFormat + ' ' + momenttime;
    if (isDiscardConfirm === 'askedDiscardConfirmation') {
      this.meetingUpdateActionHeading = 'Discard Meeting';
      this.meetingUpdateActionMessage = 'Are you sure you want to discard this meeting ?'
        + "\n" + 'Once discarded you will not be able to retrieve it back.'
      // this.updateReasonLabel = 'Reason for Discard (optional)';
      this.imageStatus = 'alert';
      this.isUpdateModalShown = true;
    } else if (isDiscardConfirm === 'askedCancelConfirmation') {
      this.meetingUpdateActionHeading = 'Cancel Meeting';
      this.meetingUpdateActionMessage = 'Are you sure you want to cancel this meeting ?'
      this.updateReasonLabel = 'Reason for Cancellation (mandatory)';
      this.imageStatus = 'alert';
      this.isUpdateModalShown = true;
    } else if (isDiscardConfirm === 'discardConfirmed') {
      if (this.meetingId.length > 0) {
        this.commonService.discardDraftMeeting(this.meetingId).subscribe((response) => {
          this.isUpdateModalShown = false;
          this.draftConfirmMessage = 'Meeting Discarded successfully.';
          this.messageHeading = 'Meeting discarded';
          this.isModalShown = true;
          this.imageStatus = 'success';
          this.commonService.setFormChangeValue(false);
          this.showNoButton = false;
          this.routeCase = 'meetingRouteToView';
          this.confirmButton = 'OK';
        },
          (error) => {
            this.draftConfirmMessage = 'The meeting could not be discarded. Please try again.';
            this.messageHeading = 'Error';
            this.imageStatus = 'alert';
            this.isModalShown = true;
            this.isUpdateModalShown = false;
            // this.modalRef = this.modalService.show(this.ModalTemplate, this.config);
          });
      }
    }
  }

  resetEventDetails() {
    if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') && this.meetingForm.get('dynamicForm').get('meetings').get('event-details')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('event-details').patchValue({
        date: '',
        meetingId: '',
        // time: ['0000'],
        time: new Date(0, 0, 0, 0, 0),
        meetingTime: new Date(0, 0, 0, 0, 0),
        duration: '',
        timezone: this.populateTimeZone(this.defaultCityCountry),
        cityCountry: this.defaultCityCountry,
        cityCountryName: this.defaultCityCountry['cityCountryVal'],
        // country: [{'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': ''}],
        location: 'In-house',
        internalLocationRoomOther: '',
        room: { 'ActiveInd': '', 'Country': '', 'KeyCode': '', 'KeyDesc': '', 'Region': '', 'UtilKeyName': '' },
        address: '',
        dailin: false,
        meetingStatus: { 'status': '' },
        delayedByMins: 0,
        meetingState: 'NEW',
        dailpicker: '',
        accesscode: '',
        brokerLocation: false
      });
      this.commonService.meetingLocationChangeSubj.next('In-house');
      this.cdr.detectChanges();
    }
  }

  resetMeetingDetails() {
    if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') && this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').patchValue({
        hostName: '',
        securityName: '',
        securityTradableEntityId: '',
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: '',
        mtgSubtype: { 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' },
        meetingBusUnit: this.defaultMeetingBusUnit,
        meetingInitiator: {
          'ActiveInd': 'Y',
          'MeetingTypeCode': 'BRK',
          'KeyCode': 'COMP',
          'KeyDesc': 'Company',
          'UtilKeyName': 'meetingInitiatorType'
        },

        subjectLine: '',
        meetingNotes: '',
        hostCorpId: '',
        meetingTopic: '',
        brokerFirmName: '',
        brokerFirmId: '',
        securityType: 'Equity',
        debtTicker: '',
        analystName: '',
        analystCorporateId: '',
        meetingFormat: { 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }
      });
      if (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityType')) {
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityType').enable();
      }
      if (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('debtTicker')) {
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('debtTicker').enable();
      }
      if (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityName')) {
        this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityName').enable();
      }
      this.cdr.detectChanges();

    }
  }

  resetOrganizerDetails() {
    if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') && this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').patchValue({
        organizedThrough: 'Company',
        organizerContactId: '',
        organizerName: '',
        organizerEmail: '',
        organizerCompany: '',
        organizerPhone: '',
        organizerPosition: '',
        brokerUsage: { 'UtilKeyName': 'brokerUsageInitiator', 'KeyDesc': '', 'KeyCode': '' },
      });
      this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').get('brokerUsage').disable();
      this.cdr.detectChanges();
    }
  }

  resetInviteeDetails() {
    if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') && this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').patchValue({ inviteeGrid: null });
      this.cdr.detectChanges();
    }
    this.commonService.changeFilAttendeeList([]);
  }

  resetThirdPArtyAttendeeDetails() {
    if (this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').patchValue({
        thirdPartyAttendeeGrid: null,
        meetingExecutive: ''
      });
      this.cdr.detectChanges();
    }
  }



  setMeetingDetails(response) {
    // this.fetchMeetingDateInLocal(response);
    //  this.actualMeetingForm.meetingDate = response.meetingDate ? response['meetingDateInLocal'] : '';

    this.actualMeetingForm.meetingDate = response.meetingDate ? response.meetingDate.substring(0, 10) : ''
    this.actualMeetingForm.meetingType = response.meetingType;
    this.actualMeetingForm.emailSendingReason = '';
    this.actualMeetingForm.meetingState = '';
    this.actualMeetingForm.businessUnit = response.businessUnit ? response.businessUnit : '';
    this.actualMeetingForm.brokerLocationIndicator = response.brokerLocationIndicator ? response.brokerLocationIndicator : 'N';
    this.actualMeetingForm.executiveInvited = response.executiveInvited ? response.executiveInvited : 'N';
    this.actualMeetingForm.emailSubject = response.emailSubject ? response.emailSubject : '';
    if (response.meetingType !== 'Broker') {
      this.actualMeetingForm.meetingSubType.meetingSubTypeCode = response.meetingSubTypeCode ? response.meetingSubTypeCode : '';
      this.actualMeetingForm.meetingSubType.meetingSubTypeDescription = response.meetingSubTypeDescription ? response.meetingSubTypeDescription : '';
      this.actualMeetingForm.meetingSubType.meetingFormat.meetingFormatCode = response.meetingFormatCode ? response.meetingFormatCode : '';
      this.actualMeetingForm.meetingSubType.meetingFormat.meetingFormatDescription = response.meetingFormatDescription ? response.meetingFormatDescription : '';

    }
    this.actualMeetingForm.meetingInitiator.meetingInitiatorCode = response.meetingInitiatorCode ? response.meetingInitiatorCode : '';
    this.actualMeetingForm.meetingInitiator.meetingInitiatorDescription = response.meetingInitiatorDescription ? response.meetingInitiatorDescription : '';
    this.actualMeetingForm.arrangementContact.brokerUsageInitiator = response.brokerUsageInitiator ? response.brokerUsageInitiator : '';
    this.actualMeetingForm.meetingDuration = response.meetingDuration ? response.meetingDuration : '';
    this.actualMeetingForm.meetingTimezone = response.meetingTimezone ? response.meetingTimezone : '';
    this.actualMeetingForm.additionalNotes = response.additionalNotes ? response.additionalNotes : '';
    this.actualMeetingForm.country.countryDescription = response.countryDescription ? response.countryDescription : '';
    this.actualMeetingForm.country.countryCode = response.countryCode ? response.countryCode : '';
    this.actualMeetingForm.meetingCity = response.meetingCity ? response.meetingCity : '';
    this.actualMeetingForm.meetingRegion = response.meetingRegion ? response.meetingRegion : '';
    this.actualMeetingForm.privateMeetingFlag = response.privateMeetingFlag ? response.privateMeetingFlag : '';
    this.actualMeetingForm.meetingCreator.corporateId = response.meetingCreator ? response.meetingCreator.corporateId : '';
    this.actualMeetingForm.meetingCreator.creatorName = response.meetingCreator ? convertToTitleCase(response.meetingCreator.name) : '';
    this.actualMeetingForm.meetingTopic = response.meetingTopic ? response.meetingTopic : '';
    //   this.actualMeetingForm.meetingOwnerCorporateId = response.meetingOwner ? response.meetingOwner : '';
    // this.actualMeetingForm.dialIn = response.dialIn? response.dialIn: '';
    this.actualMeetingForm.dialIn.dialInNumber = response.dialIn && response.dialIn.dialInNumber ? response.dialIn.dialInNumber : '';
    this.actualMeetingForm.dialIn.dialInAccessCode = response.dialIn && response.dialIn.dialInAccessCode ? response.dialIn.dialInAccessCode : '';
    this.actualMeetingForm.meetingLocation.locationType = response.locationType ? response.locationType : '';
    this.actualMeetingForm.meetingLocation.externalLocationAddress = response.externalLocationAddress ? response.externalLocationAddress : '';
    this.actualMeetingForm.meetingLocation.internalLocationRoom = response.internalLocationRoom ? response.internalLocationRoom : '';
    this.actualMeetingForm.meetingLocation.internalLocationRoomOther = response.internalLocationRoomOther ? response.internalLocationRoomOther : '';
    this.actualMeetingForm.securityDetail = response.securityDetail && response.meetingType === 'Company' ?
      new SecurityDetails(response.securityDetail.instrumentLongName ? response.securityDetail.instrumentLongName : '', '', '', '', '', '', '', '', '', response.securityDetail.ticker ? response.securityDetail.ticker : '',
        response.securityDetail.bbCode ? response.securityDetail.bbCode : '',
        '', response.securityDetail.tseIdentifier ? response.securityDetail.tseIdentifier : '', '', response.securityDetail.tradableEntId ? response.securityDetail.tradableEntId : '') :
      new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

    // this.actualMeetingForm.associatedEventDetail = response.associatedEventDetail? response.associatedEventDetail: '';
    // this.actualMeetingForm.fidelityInvitees = response.fidelityInvitees? response.fidelityInvitees: '';
    // this.actualMeetingForm.thirdPartyAttendee = response.thirdPartyAttendee? response.thirdPartyAttendee: '';
    // this.actualMeetingForm.meetingCreator =  response.meetingCreator? response.meetingCreator: '';
    this.actualMeetingForm.meetingOwnerCorporateId = response.meetingOwner ? response.meetingOwner.corporateId : '';
    // this.actualMeetingForm.meetingLastUpdatedBy = response.meetingLastUpdatedBy? response.meetingLastUpdatedBy: '';
    // this.actualMeetingForm.meetingLastUpdatedDateTime = response.meetingLastUpdatedDateTime? response.meetingLastUpdatedDateTime: '';
    this.actualMeetingForm.meetingTimeInGMT = response.meetingTimeInGMT ? response.meetingTimeInGMT : '';

    this.actualMeetingForm.hostCorporateId = response.hostCorporateId ? response.hostCorporateId : '';
    // this.actualMeetingForm.meetingStatus = response.meetingStatus
    //   ? response.meetingStatus
    //   : (response.meetingState ? convertToTitleCase(response.meetingState) : '');
    this.actualMeetingForm.meetingStatus = response.meetingStatus ? response.meetingStatus : (response.meetingState === 'CONFIRMED' ? 'Confirmed' : '');
    this.actualMeetingForm.delayedByMins = response.delayedByMins ? response.delayedByMins : 0;
    this.actualMeetingForm.arrangementContact = response.arrangementContact ?
      new ArrangementContact(response.arrangementContact.organizedThrough ? response.arrangementContact.organizedThrough === 'Other' ? 'Others' : response.arrangementContact.organizedThrough : 'Company',
        response.arrangementContact.organizerContactId ? response.arrangementContact.organizerContactId : '',
        response.arrangementContact.organizerName ? response.arrangementContact.organizerName : '',
        response.arrangementContact.organizerCompany ? response.arrangementContact.organizerCompany : '',
        response.arrangementContact.organizerPhone ? response.arrangementContact.organizerPhone : '',
        response.arrangementContact.organizerEmail ? response.arrangementContact.organizerEmail : '',
        response.arrangementContact.organizerPosition ? response.arrangementContact.organizerPosition : '',
        response.arrangementContact.brokerUsageInitiator ? response.arrangementContact.brokerUsageInitiator : '') : new ArrangementContact('Company', '', '', '', '', '', '', '');
    this.actualMeetingForm.meetingId = response.meetingId ? response.meetingId : '';
    this.actualMeetingForm.meetingUpdateDetails.meetingLastUpdatedByCorporateId = '';
    this.actualMeetingForm.meetingUpdateDetails.meetingLastUpdatedByName = '';
    this.actualMeetingForm.meetingUpdateDetails.meetingUpdatedMethod = '';
    this.actualMeetingForm.meetingUpdateDetails.meetingUpdatedReason = ''
    this.actualMeetingForm.meetingCancellationReason = response.meetingCancellationReason ? response.meetingCancellationReason : '';
    this.actualMeetingForm.debtTickerDetail.debtTicker = response.debtTickerDetail && response.debtTickerDetail.debtTicker ? response.debtTickerDetail.debtTicker : '';
    this.actualMeetingForm.debtTickerDetail.analystCorporateId = response.debtTickerDetail && response.debtTickerDetail.analystCorporateId ? response.debtTickerDetail.analystCorporateId : '';
    this.actualMeetingForm.businessEntity = response.businessEntity ? response.businessEntity : '';
    this.actualMeetingForm.debtTickerDetail.analystName = response.debtTickerDetail && response.debtTickerDetail.analystName ? response.debtTickerDetail.analystName : '';
    this.actualMeetingForm.brokerDetail.brokerFirmId = (response.brokerDetail && response.brokerDetail.brokerFirmId) ? response.brokerDetail.brokerFirmId : '';
    this.actualMeetingForm.brokerDetail.brokerFirmName = (response.brokerDetail && response.brokerDetail.brokerFirmName) ? response.brokerDetail.brokerFirmName : '';
    this.actualMeetingForm.meetingTimeInLocalTimezone = ((response.meetingTimeInGMT) ? (this.getMeetngDateInLocalTime(response))['time'].replace(':', '') : '');
    response.fidelityInvitees.forEach((item) => {
      let filInvitee = new FidelityInvitees(item.corporateId ? item.corporateId : '',
        item.name ? convertToTitleCase(item.name.replace(' (Host)', '')) : '',
        item.isCallIn ? item.isCallIn : '',
        item.isInviteRequired ? item.isInviteRequired : '',
        item.isInfoPackRequired ? item.isInfoPackRequired : '',
        item.isInviteForInfoOnly ? item.isInviteForInfoOnly : '',
        item.inviteeResponse ? item.inviteeResponse : '');

      if (this.actualMeetingForm.meetingType === 'Other' || this.actualMeetingForm.meetingType === 'Broker') {
        delete filInvitee['isInfoPackRequired'];
      }
      this.actualMeetingForm.fidelityInvitees.push(filInvitee);
    });
    if (response.thirdPartyAttendee && response.thirdPartyAttendee.length > 0) {

      response.thirdPartyAttendee.forEach((item) => {
        let thirdPartyAttendee = new ThirdPartyAttendee(
          item.externalContactName ? convertToTitleCase(item.externalContactName) : '',
          item.externalContactId ? item.externalContactId : '',
          item.email ? item.email : '',
          item.position ? item.position : '',
          item.notes ? item.notes : '');

        if (thirdPartyAttendee.externalContactId) {
          this.actualMeetingForm.thirdPartyAttendee.push(thirdPartyAttendee);
        }
      });
    }

  }

  checkFormChanges(uri) {
    if (this.meetingType === 'Conference') {
      if (this.currentAction === 'create') {
        this.resetConferenceFormUpdate(uri);
      } else if (this.currentAction === 'update') {
        this.checkConferenceFormUpdate(uri);
      }
    } else {
      if (this.currentAction === 'create') {
        this.resetFormUpdate(true, uri);
      } else if (this.currentAction === 'update') {
        this.checkFormUpdate(true, uri);
      }
    }
  }

  backNavigationToMainScreen() {
    if (this.meetingType === 'Conference') {
      if (this.currentAction === 'create') {
        this.resetConferenceFormUpdate('/events/meeting');
      } else if (this.currentAction === 'update') {
        this.checkConferenceFormUpdate('/events/meeting');
      }
    } else {
      if (this.currentAction === 'create') {
        this.resetFormUpdate(true, '/events/meeting');
      } else if (this.currentAction === 'update') {
        this.checkFormUpdate(true, '/events/meeting');
      }
    }
  }

  checkConferenceFormUpdate(uri: string) {
    console.log('CheckFormUpdate URI: ', uri);
  }
  resetConferenceFormUpdate(uri: string) {
    this.conferenceDetail = this.meetingForm.get('dynamicForm').get('conferences').get('conference-details').value;
    this.brokerDetail = this.meetingForm.get('dynamicForm').get('conferences').get('broker-details').value;
    this.insertConferenceMeetingValues();
    let newForm: any;
    let oldForm: any;
    newForm = JSON.stringify(this.conferenceMeeting);
    oldForm = JSON.stringify(this.emptyConferenceMeetingForm);
    if (newForm === oldForm) {
      if (uri === '/events/meeting') {
        this.router.navigate([uri], { skipLocationChange: true });
        this.cdr.detectChanges();
      } else {
        if (uri === '/meeting/create') {
          this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
        } else {
          this.router.navigate([uri], { skipLocationChange: true });
        }
      }
    } else {
      this.messageHeading = 'Confirm Navigation';
      this.draftConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
      this.imageStatus = 'alert';
      this.isModalShown = true;
      this.showNoButton = true;
      this.confirmButton = 'YES';
      if (uri === '/events/meeting') {
        this.routeCase = 'meetingRouteToView'
      } else if (uri === '/contacts') {
        this.routeCase = 'meetingRouteToContacts'
      } else {
        this.routeCase = 'meetingRouteToCreate'
      }
      this.cdr.detectChanges();
    }
  }
  insertConferenceMeetingValues() {
    this.conferenceMeeting.website = this.conferenceDetail.websiteLink ? this.conferenceDetail.websiteLink : '';
    this.conferenceMeeting.brokerDetail.brokerFirmId = this.brokerDetail.brokerFirmId ? this.brokerDetail.brokerFirmId : '';
    this.conferenceMeeting.brokerDetail.brokerFirmName = this.brokerDetail.brokerFirmName ? this.brokerDetail.brokerFirmName : '';
    ({ GRD_COUNTRY_CD: this.conferenceMeeting.country.countryCode, Country: this.conferenceMeeting.country.countryDescription, Cities: this.conferenceMeeting.city }
      = this.conferenceDetail.cityCountry);
    this.conferenceMeeting.eventLastUpdateDetails.corporateId = this.meetingForm.get('meetingLastUpdatedByCorporateId').value;
    this.conferenceMeeting.eventLastUpdateDetails.name = this.meetingForm.get('meetingLastUpdatedByName').value;
    // this.conferenceMeeting.eventLastUpdateDetails.meetingUpdatedMethod = this.meetingForm.get('meetingUpdatedMethod').value.trim();
    this.conferenceMeeting.eventLastUpdateDetails.updateReason = this.meetingForm.get('meetingUpdatedReason').value.trim();
    this.conferenceMeeting.eventCreator.name = this.meetingForm.get('creatorName').value;
    this.conferenceMeeting.eventCreator.corporateId = this.meetingForm.get('creatorCorporateId').value;
    this.conferenceMeeting.businessUnit = this.conferenceDetail.businessUnit.KeyCode;
    ({ KeyCode: this.conferenceMeeting.eventInitiator.eventInitiatorCode, KeyDesc: this.conferenceMeeting.eventInitiator.eventInitiatorDescription }
      = this.brokerDetail.meetingInitiator);
    // this.conferenceMeeting.eventInitiator.brokerUsageInitiator = this.brokerDetail.brokerUsageInitiator ? this.brokerDetail.brokerUsageInitiator.KeyDesc : '';
    this.conferenceMeeting.venue = this.conferenceDetail.venue ? this.conferenceDetail.venue : '';
    this.conferenceMeeting.eventName = this.conferenceDetail.conferenceName ? this.conferenceDetail.conferenceName : '';
    this.conferenceMeeting.meetingRegistrationDeadline = this.conferenceDetail.meetingRegistrationDeadline ? this.conferenceDetail.meetingRegistrationDeadline : '';
    this.conferenceMeeting.meetingRequestDeadline = this.conferenceDetail.meetingRequestDeadline ? this.conferenceDetail.meetingRequestDeadline : '';
    this.conferenceMeeting.startDate = this.conferenceDetail.dateRange ? this.conferenceDetail.dateRange[0] : '';
    this.conferenceMeeting.endDate = this.conferenceDetail.dateRange ? this.conferenceDetail.dateRange[1] : '';
    this.conferenceMeeting.eventOwner.corporateId = this.meetingForm.get('ownerCorporateId').value;
    this.conferenceMeeting.eventOwner.name = this.meetingForm.get('ownerName').value;
    this.conferenceMeeting.eventType = 'Conference';
    this.conferenceMeeting.eventRegion = '';
    this.conferenceMeeting.eventState = this.meetingState.toUpperCase() === 'NEW' ? 'CONFIRMED' : this.meetingState;
    this.conferenceMeeting.eventTimezone = this.conferenceDetail.timezone ? this.conferenceDetail.timezone : '';
    this.conferenceMeeting.arrangementContact = new ArrangementContact(this.arrangementContactDetails.organizedThrough,
      this.arrangementContactDetails.organizerContactId, this.arrangementContactDetails.organizerName, this.arrangementContactDetails.organizerCompany,
      this.arrangementContactDetails.organizerPhone, this.arrangementContactDetails.organizerEmail, this.arrangementContactDetails.organizerPosition,
      this.arrangementContactDetails.brokerUsageInitiator);
  }

  checkFormUpdate(response, uri) {
    this.eventDetails = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').value;
    this.meetingDetails = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').value;
    this.inviteeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value;
    this.thirdPartyAttendeeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').value;
    // this.thirdPartyAttendees = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').get('thirdPartyAttendeeGrid').value;
    this.organizerDetails = this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').value;
    this.insertMeetingValues();
    const newForm = JSON.stringify(this.meeting);
    const oldForm = JSON.stringify(this.actualMeetingForm);

    if (this.pastMeeting) {
      if (uri === '/events/meeting') {
        this.pastMeeting = false;
        this.router.navigate([uri], { skipLocationChange: true });
        this.cdr.detectChanges();
      } else {
        this.pastMeeting = false;
        this.meetingForm.enable();
        this.initialiseInvites();
        if (uri === '/meeting/create') {
          this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
        } else {
          this.router.navigate([uri], { skipLocationChange: true });
        }
        this.cdr.detectChanges();
      }
    } else {
      if (newForm === oldForm) {
        if (uri === '/events/meeting') {
          this.router.navigate([uri], { skipLocationChange: true });
          this.cdr.detectChanges();
        } else {
          this.initialiseInvites();
          if (uri === '/meeting/create') {
            this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
          } else {
            this.router.navigate([uri], { skipLocationChange: true });
          }
          this.cdr.detectChanges();
        }

      } else {
        if (this.errorService.isError ||
          (this.formParam === 'update' && !this.commonService.getLoggedInUserRoles().includes('mercury-update-company-meeting') && uri === '/meeting/create')) {
          this.initialiseInvites();
          this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
          this.cdr.detectChanges();
        } else {
          this.messageHeading = 'Confirm Navigation';
          this.draftConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
          this.imageStatus = 'alert';
          this.isModalShown = true;
          this.showNoButton = true;
          this.confirmButton = 'YES';
          if (uri === '/events/meeting') {
            this.routeCase = 'meetingRouteToView'
          } else if (uri === '/contacts') {
            this.routeCase = 'meetingRouteToContacts'
          } else {
            this.routeCase = 'meetingRouteToCreate'
          }
          this.cdr.detectChanges();
        }
      }
    }

  }

  resetFormUpdate(response, uri) {
    this.eventDetails = this.meetingForm.get('dynamicForm').get('meetings').get('event-details').value;
    this.meetingDetails = this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').value;
    this.inviteeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('invitee-details').get('inviteeGrid').value;
    this.thirdPartyAttendeeDetails = this.meetingForm.get('dynamicForm').get('meetings').get('third-party-attendee').value;
    this.organizerDetails = this.meetingForm.get('dynamicForm').get('meetings').get('organizer-details').value;
    this.insertMeetingValues();
    let newForm: any;
    let oldForm: any;
    if (this.meetingType === 'Company') {
      newForm = JSON.stringify(this.meeting);
      oldForm = JSON.stringify(this.emptyCompanyMeetingForm);

    } else if (this.meetingType === 'Other') {
      newForm = JSON.stringify(this.meeting);
      oldForm = JSON.stringify(this.emptyOtherMeetingForm);

    } else if (this.meetingType === 'Broker') {
      newForm = JSON.stringify(this.meeting);
      oldForm = JSON.stringify(this.emptyBrokerMeetingForm);

    }
    if (newForm === oldForm && !this.meetingForm.get('dynamicForm').get('meetings').get('event-details').get('dailin').value) {
      if (uri === '/events/meeting') {
        this.router.navigate([uri], { skipLocationChange: true });
        this.cdr.detectChanges();
      } else {
        this.initialiseInvites();
        if (uri === '/meeting/create') {
          this.commonService.sectorOfSecurity.next('');
          this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
        } else {
          this.router.navigate([uri], { skipLocationChange: true });
        }
      }
    } else {
      this.messageHeading = 'Confirm Navigation';
      this.draftConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
      this.imageStatus = 'alert';
      this.isModalShown = true;
      this.showNoButton = true;
      this.confirmButton = 'YES';
      if (uri === '/events/meeting') {
        this.routeCase = 'meetingRouteToView'
      } else if (uri === '/contacts') {
        this.routeCase = 'meetingRouteToContacts'
      } else {
        this.routeCase = 'meetingRouteToCreate'
      }
      this.cdr.detectChanges();
    }

  }


  initialiseInvites() {
    this.mtgSubtypelist = [];
    this.roomDataList = [''];
    this.resetEventDetails();
    this.resetInviteeDetails();
    this.resetMeetingDetails();
    this.resetOrganizerDetails();
    this.resetThirdPArtyAttendeeDetails();
    this.resetClashes();
    this.meetingForm.get('dynamicForm').get('meetings').get('additional-notes').patchValue({
      additionalNotes: ''
    });
    this.isModifiedByVisible = false;
    this.isModifiedOnVisible = false;
    this.modifiedBy = '';
    this.modifiedOn = '';
    this.meetingState = 'NEW';
    this.commonService.setSecurityDetails([], 'create');
    this.commonService.resetMeetingDetailsSubject.next(true);
    this.confirmButtonLabel = 'Confirm';
    //For hiding draft and invite
    this.saveButtonLabel = 'Draft';
    //
    this.roomDataList = this.defaultCityRoomDataList;
    if (this.commonService.getMeetingType() === 'Company') {
      this.meeting = JSON.parse(JSON.stringify(this.emptyCompanyMeetingForm));
      this.mtgSubtypelist = this.eqMeetingSubtypes;
    } else if (this.commonService.getMeetingType() === 'Other') {
      this.meeting = JSON.parse(JSON.stringify(this.emptyOtherMeetingForm));
    } else if (this.commonService.getMeetingType() === 'Broker') {
      this.meeting = JSON.parse(JSON.stringify(this.emptyBrokerMeetingForm));
    }
    this.meetingForm.patchValue({
      'creatorCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
      'creatorName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
      'ownerCorporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
      'ownerName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
      'meetingRegion': this.commonService.getLoggedInUserInfo().getRegionVal(),
      'meetingLastUpdatedByCorporateId': '',
      'meetingLastUpdatedByName': '',
      'meetingUpdatedMethod': '',
      'meetingUpdatedReason': '',
      'meetingCancellationReason': ''
    });
    this.cdr.detectChanges();
  }

  checkIfUserAuthorized() {
    if ((!this.errorService.isError && this.formParam === 'create' && this.commonService.getLoggedInUserRoles().includes('mercury-create-company-meeting'))
      || (!this.errorService.isError && this.formParam === 'update' && this.commonService.getLoggedInUserRoles().includes('mercury-update-company-meeting'))) {
      return false;
    }
    else {
      return true;
    }
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.pastMeeting = true;
      this.meetingForm.disable();
    }
    else {
      if (this.actualMeetingForm.meetingType === 'Company' && this.actualMeetingForm.businessEntity === 'EQ') {
        delete this.actualMeetingForm.securityDetail['securityName'];
      }
    }
  }

  resetMeetingDetailsOnSecurityTypeChange() {
    if (this.meetingForm.get('dynamicForm') && this.meetingForm.get('dynamicForm').get('meetings') && this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details')) {
      this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').patchValue({
        hostName: '',
        securityName: '',
        securityTradableEntityId: '',
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: '',
        mtgSubtype: { 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' },
        meetingBusUnit: this.defaultMeetingBusUnit,
        meetingInitiator: {
          'ActiveInd': 'Y',
          'MeetingTypeCode': 'BRK',
          'KeyCode': 'COMP',
          'KeyDesc': 'Company',
          'UtilKeyName': 'meetingInitiatorType'
        },

        subjectLine: '',
        meetingNotes: '',
        hostCorpId: '',
        meetingTopic: '',
        debtTicker: '',
        analystName: '',
        analystCorporateId: '',
        meetingFormat: { 'ActiveInd': '', 'KeyCode': '', 'KeyDesc': '', 'UtilKeyName': '' }
      });
      // if (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityType')) {
      //   this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityType').enable();
      // }
      // if (this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('debtTicker')) {
      // this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('debtTicker').enable();
      // }
      // if(this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityName')) {
      // this.meetingForm.get('dynamicForm').get('meetings').get('meeting-details').get('securityName').enable();
      // }
    }
  }

  navigateToModule(meetingType: string) {
    this.commonService.setMeetingType(meetingType);
    this.commonService.setTargetUrl('/meeting/create');
    if (this.meetingType === 'Conference') {
      this.resetConferenceFormUpdate('/meeting/create');
    } else {
      this.resetFormUpdate(true, '/meeting/create');
    }
    this.cdr.detectChanges();
  }

  fetchMeetingDateInLocal(mtgDetailResponse) {
    if (mtgDetailResponse.meetingDate) {
      const splitMeetingTimeInGMT = (mtgDetailResponse.meetingTimeInGMT) ? mtgDetailResponse.meetingTimeInGMT.match(/.{1,2}/g) : '';
      let dateArrray = moment(mtgDetailResponse.meetingDate).format('YYYY-MM-DD');
      let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
      let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
      mtgDetailResponse['meetingDateInLocal'] = moment(localTime.substring(0, 10)).format('YYYY-MM-DD');
    }
  }

  getMeetngDateLocal(meetingData): Object {
    const splitMeetingTimeInGMT = (meetingData.meetingTimeInGMT) ? meetingData.meetingTimeInGMT.match(/.{1,2}/g) : '';
    // time conversion into user's Region
    let dateArrray = moment(meetingData.meetingDate).format('YYYY-MM-DD');
    let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
    let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    let dateFormat = localTime.substring(0, 10);
    let isoFormat = new Date(dateFormat);
    let dateToDisplay = this.datePipe.transform(isoFormat, 'dd MMM yyyy');
    let returnDate = dateToDisplay + ' ' + localTime.substring(11, 13) + ':' + localTime.substring(14, 16);
    return returnDate;
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        let utilData = message;
        this.fiMeetingSubtypes = utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Company');
        this.eqMeetingSubtypes = utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Company' && element.SubtypeEntity !== 'FI');
        // this.fiMeetingSubtypes = utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Company');
        // this.eqMeetingSubtypes = utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Company' && element.SubtypeEntity !== 'FI');

        let cityCountryList = utilData.filter(element => element.UtilKeyName === 'country-city-map');
        let buList = utilData.filter(element => element.UtilKeyName === 'businessUnits');
        let roomList = utilData.filter(element => element.UtilKeyName === 'meetingRooms');
        this.utilDataCountries = utilData.filter(element => element.UtilKeyName === 'countries');
        for (const item of this.utilDataCountries) {
          item['KeyDesc'] = convertToTitleCase(item['KeyDesc']);
        }
        this.commonService.setUtilCountries(this.utilDataCountries);
        roomList.unshift({
          KeyCode: '',
          KeyDesc: ''
        });
        for (const item of cityCountryList) {
          item['cityCountryVal'] = item.Cities + ', ' + item.Country;
        }
        let cityValue = cityCountryList.filter(element => element.cityCountryVal === this.userDefaultCityCountry);
        let buValue = buList.filter(element => element.KeyCode === this.userDefaultBU);
        this.emptyCompanyMeetingForm.businessUnit = this.userDefaultBU;
        this.emptyBrokerMeetingForm.businessUnit = this.userDefaultBU;
        this.emptyOtherMeetingForm.businessUnit = this.userDefaultBU;
        this.emptyConferenceMeetingForm.businessUnit = this.userDefaultBU;
        if (cityValue[0]) {
          cityValue[0]['cityCountryVal'] = cityValue[0].Cities + ', ' + cityValue[0].Country;
          let timezone = this.populateTimeZone(cityValue[0]);
          // if(this.meetingType === 'Company') {
          this.emptyCompanyMeetingForm.country.countryCode = cityValue[0]['GRD_COUNTRY_CD'];
          this.emptyCompanyMeetingForm.country.countryDescription = cityValue[0]['Country'];
          this.emptyCompanyMeetingForm.meetingCity = cityValue[0]['Cities'];
          this.emptyCompanyMeetingForm.meetingTimezone = timezone;
          this.emptyConferenceMeetingForm.country.countryCode = cityValue[0]['GRD_COUNTRY_CD'];
          this.emptyConferenceMeetingForm.country.countryDescription = cityValue[0]['Country'];
          this.emptyConferenceMeetingForm.city = cityValue[0]['Cities'];
          this.emptyConferenceMeetingForm.eventTimezone = timezone;
          //  } else if(this.meetingType === 'Broker') {
          this.emptyBrokerMeetingForm.country.countryCode = cityValue[0]['GRD_COUNTRY_CD'];
          this.emptyBrokerMeetingForm.country.countryDescription = cityValue[0]['Country'];
          this.emptyBrokerMeetingForm.meetingCity = cityValue[0]['Cities'];

          this.emptyBrokerMeetingForm.meetingTimezone = timezone;
          // } else if(this.meetingType === 'Other') {
          this.emptyOtherMeetingForm.country.countryCode = cityValue[0]['GRD_COUNTRY_CD'];
          this.emptyOtherMeetingForm.country.countryDescription = cityValue[0]['Country'];
          this.emptyOtherMeetingForm.meetingCity = cityValue[0]['Cities'];

          this.emptyOtherMeetingForm.meetingTimezone = timezone;
          //  }
          this.defaultCityCountry = cityValue[0];
        }
        if (cityValue[0] && cityValue[0]['GRD_COUNTRY_CD']) {
          let roomData = roomList.filter(roomItem => roomItem['Country'] === cityValue[0]['GRD_COUNTRY_CD'] || roomItem['KeyDesc'].toUpperCase().includes('OTHER'));
          // roomData.push({
          //   KeyCode: 'Other',
          //   KeyDesc: 'Other'
          // });
          roomData.unshift({
            KeyCode: '',
            KeyDesc: ''
          });
          this.defaultCityRoomDataList = Object.assign([], roomData);
        } else {
          this.defaultCityRoomDataList = roomList;
        }
        if (buValue[0]) {
          this.defaultMeetingBusUnit = buValue[0];
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }


  populateTimeZone(event: {
    Cities: string, Country: string, GRD_COUNTRY_CD: string, ISO_COUNTRY_CD: string,
    KeyCode: string, UtilKeyName: string, cityCountryVal: string, timezoneVal: string
  }): string {
    let timezoneOfCityCountry = ''
    if (event) {
      const cityDescription = cityTimezones.lookupViaCity(event['Cities']);
      let timeZoneDesc = null;
      if (cityDescription.length !== 0) {
        if (cityDescription.length > 1) {
          const filteredCity = cityDescription.filter(element => element.iso2 === event['ISO_COUNTRY_CD']);
          if (filteredCity.length !== 0) {
            timeZoneDesc = filteredCity[0].timezone;
          } else {
            timeZoneDesc = null;
            //  this.nocitycountrymap.push(event)
          }
        } else {
          timeZoneDesc = cityDescription[0]['timezone'];
        }

        if (timeZoneDesc !== null) {
          const date = new Date().toLocaleString('en-US', { timeZone: timeZoneDesc, timeZoneName: 'short' });
          const indexOfOpenBracket = date.indexOf('GMT');
          if (indexOfOpenBracket !== -1) {
            // this.correcttimezone.push(event)

            timezoneOfCityCountry = timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length)

          } else {

            timezoneOfCityCountry = timeZoneDesc + ' ' + date.substring(date.length - 3, date.length)
            //   this.wrongtimezone.push(event);
          }
        }
      } else {
        // this.notimezone.push(event);

        timezoneOfCityCountry = event['timezoneVal'] ? event['timezoneVal'] : ''

      }
    }
    return timezoneOfCityCountry;
  }

  handleUpdateContactError() {
    this.draftConfirmMessage = 'Contact details could not be updated. Please try again.';
    this.messageHeading = 'Error';
    this.updatedReason = '';
    this.updateMethod = '';
    this.imageStatus = 'alert';
    this.isModalShown = true;
    this.isUpdateModalShown = false;
  }

}
