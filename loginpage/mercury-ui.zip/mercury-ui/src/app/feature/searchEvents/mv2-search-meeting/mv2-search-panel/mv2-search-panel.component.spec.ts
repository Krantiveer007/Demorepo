import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Mv2SearchPanelComponent } from './mv2-search-panel.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { CommonService } from 'src/app/core/http/common.service';
import { of, throwError } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { AgGridModule } from 'ag-grid-angular';
import { ConfigMultiselectComponent } from 'src/app/shared/components/config-multiselect/config-multiselect.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { MultiSelectModule } from '@syncfusion/ej2-angular-dropdowns';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';
declare var jquery: any;
declare var $: any;

describe('Mv2SearchPanelComponent', () => {
  let component: Mv2SearchPanelComponent;
  let fixture: ComponentFixture<Mv2SearchPanelComponent>;
  let datePipe: DatePipe;
  const service: CommonService = null;
  const peopleData =
    [{ 'corpId': 'A482682', 'displayName': 'SHEVADEKAR, SAPAN' },
    { 'corpId': 'A366680', 'displayName': 'MAINI, PANKAJ' },
    { 'corpId': 'A497865', 'displayName': 'GANDHI, PANKAJ' },
    { 'corpId': 'A501403', 'displayName': 'YADAV, PANKAJ' },
    { 'corpId': 'A498527', 'displayName': 'GUPTA, SAPAN' }
    ];

  const manipulatePeopleData = [
    'Shevadekar, Sapan' + ' &lt;' + 'A482682' + '&gt;',
    'Maini, Pankaj' + ' &lt;' + 'A366680' + '&gt;',
    'Gandhi, Pankaj' + ' &lt;' + 'A497865' + '&gt;',
    'Yadav, Pankaj' + ' &lt;' + 'A501403' + '&gt;',
    'Gupta, Sapan' + ' &lt;' + 'A498527' + '&gt;'
  ];

  const utilData = [
    { UtilKeyName: 'businessUnits', KeyCode: 'FI - TOK', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - HKG', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - LON', ActiveInd: 'Y' },
    { UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' },
  ];


  const securitiesMock = [
    {
      instrumentLongName: 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARA INVESTMENTS CO'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARGON OIL & GAS LTD'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
    }
    , {
      instrumentLongName: 'ZARDOYA OTIS SA'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARDOYA OTIS SA (TEMP)'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
    }
    , {
      instrumentLongName: 'ZAR SOVEREIGN CAPITAL FUND PROPRIETY LTD 3.903% 06/24/2020 144A'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZAR SOVEREIGN CAPITAL FUND PROPRIETY LTD 3.903% 06/24/2020 REGS'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARDOYA OTIS SA (TEMP LINE)'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'EQUITY'
    }
    , {
      instrumentLongName: 'ZARDOYA OTIS SA (TEMP)'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'BOND'
    }];

  const securitiesMock2 = [
    {
      instrumentLongName: 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201'
      , ticker: undefined
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201123213'
      , ticker: null
      , country: 'JAPAN'
      , searchedIn: 'instrumentLongName'
      , assetType: 'BOND'
    }
    , {
      instrumentLongName: 'ZARGON OIL & GAS LTD'
      , ticker: null
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
    },
    {
      instrumentLongName: 'ZARGON OIL & GAS LTD123'
      , ticker: null
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
    }];
  const event: TypeaheadMatch = new TypeaheadMatch('Yadav, Pankaj &lt;A501403&gt;', 'Yadav, Pankaj &lt;A501403&gt;', false);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        HttpClientModule,
        CommonModule,
        BrowserModule,
        NgSelectModule,
        AgGridModule.withComponents([]),
        MultiSelectModule
      ],
      declarations: [Mv2SearchPanelComponent, Mv2MeetingListComponent, ConfigMultiselectComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, DatePipe],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2SearchPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Host name and Attendee test cases
  it('should return list of people when 3 or more characters are typed in Meeting Host search box', () => {
    component.searchPanelForm.patchValue({ 'hostname': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData('MeetingHost');
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulatePeopleData);
    });
  });

  it('should return list of people when 3 or more characters are typed in Meeting Attendee search box', () => {
    component.searchPanelForm.patchValue({ 'attendee': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData('Attendee');
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulatePeopleData);
    });
  });

  it('should throw error while fetching data from service', () => {
    component.searchPanelForm.patchValue({ 'hostname': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(throwError);
    fixture.detectChanges();
    component.getPeopleData('MeetingHost');
    fixture.detectChanges();
    component.peopleDataSource.subscribe((response) => { },
      (error) => {
        //  expect(component.peopledataSource).toBeNull;
      });
  });

  it('should return only name on typeheadselect for Meeting Host', () => {
    component.typeaheadOnPeopleSelect(event, 'MeetingHost');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('hostname').value).toEqual('Yadav, Pankaj');
    expect(component.searchPanelForm.get('hostCorporateId').value).toEqual('A501403');
    expect(component.isValidHost).toEqual(true);
  });

  it('should return only name on typeheadselect for Meeting Owner', () => {
    component.typeaheadOnPeopleSelect(event, 'Attendee');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('attendee').value).toEqual('Yadav, Pankaj');
    expect(component.searchPanelForm.get('employeeId').value).toEqual('A501403');
    expect(component.isValidAttendee).toEqual(true);
  });

  it('should show error on person search if the searched results are not found', () => {
    component.typeaheadNoPeopleResults(true, 'Attendee');
    expect(component.attendeeErrorResponse).toEqual(true);
  });
  it('should show error on person search if the searched results are not found', () => {
    component.typeaheadNoPeopleResults(false, 'MeetingHost');
    expect(component.hostErrorResponse).toEqual(false);
  });

  it('should catch boolean event and show loader on people search', () => {
    component.changeTypeaheadPeopleLoading(true, 'MeetingHost');
    expect(component.hostTypeaheadLoading).toEqual(true);
  });
  it('should catch boolean event and show loader on people search', () => {
    component.changeTypeaheadPeopleLoading(false, 'Attendee');
    expect(component.attendeeTypeaheadLoading).toEqual(false);
  });

  it('should remove text typed in host field if host value is not selected and cursor is moved out of field focus', () => {
    component.onBlurMethod();
    component.isValidHost = false;
    expect(component.searchPanelForm.get('hostname').value).toEqual('');
    expect(component.searchPanelForm.get('hostCorporateId').value).toEqual('');
  });

  it('should remove text typed in attendee field if attendee value is not selected and cursor is moved out of field focus', () => {
    component.onBlurMethod();
    component.isValidAttendee = false;
    expect(component.searchPanelForm.get('attendee').value).toEqual('');
    expect(component.searchPanelForm.get('employeeId').value).toEqual('');
  });

  // Meeting Type Test cases

  it('meeting type should be All Meetings and companyBroker name field should be disabled', () => {
    expect(component.searchPanelForm.get('meetingType').value).toEqual('All Meetings');
    expect(component.searchPanelForm.get('securityName').disabled).toEqual(true);
  });

  it('should disable company/broker name field if meeting type is all meetings', () => {
    component.searchPanelForm.patchValue({ 'meetingType': 'All Meetings' });
    component.selectMeet();
    fixture.detectChanges();
    expect(component.searchPanelForm.get('securityName').disabled).toEqual(true);
  });
  it('should enable company/broker name field if meeting type is  not all meetings', () => {
    component.searchPanelForm.patchValue({ 'meetingType': 'Company' });
    component.selectMeet();
    fixture.detectChanges();
    expect(component.searchPanelForm.get('securityName').disabled).toEqual(false);
  });

  // Security Search Test Cases

  // Under Progress
  it('should get security data if three character are passed in the security service', () => {
    const service = TestBed.get(CommonService);
    component.searchPanelForm.patchValue({ securityName: 'zar' });
    const securities = [];
    for (let i = 0; i < securitiesMock.length; i++) {
      if (securitiesMock[i].assetType === 'BOND') {
        securities[i] = securitiesMock[i].instrumentLongName + '&lt;' + securitiesMock[i].ticker + '&gt;' + '(' + 'FI' + ')';
      } else if (securitiesMock[i].assetType === 'EQUITY') {
        securities[i] = securitiesMock[i].instrumentLongName + '&lt;' + securitiesMock[i].ticker + '&gt;' + '(' + 'EQ' + ')';
      }
    }
    const spy = spyOn(service, 'getSecurities').and.returnValue(of(securitiesMock));
    component.getSecurities();
    fixture.detectChanges();
    component.dataSource.subscribe((response) => {
      expect(response).toEqual(securities);
    });
  });

  it('should throw error when security data not found in the security service', () => {
    const service = TestBed.get(CommonService);
    component.searchPanelForm.patchValue({ securityName: 'ZAR' });
    component.asyncSelected = 'ZAR';
    spyOn(service, 'getSecurities').and.returnValue(throwError('Error Thrown'));
    component.getSecurities();
    fixture.detectChanges();
    component.dataSource.subscribe((response) => { 
      expect(response).toEqual([]);
    },
      (error) => {
        // expect(component.typeaheadLoading).toBeTruthy();
        // expect(component.errorResponse).toEqual(true)});
      });
  });

  it('should select a FI security from drop down', () => {
    const service = TestBed.get(CommonService);
    const item = {
      instrumentLongName: 'Zargon Oil & Gas Ltd New Conv 6.0% 06/30/201'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
      , securityVal: 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201<*ZOT>(FI)'
    };
    const selectedSecurity: TypeaheadMatch = new TypeaheadMatch(item
      , 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201<*ZOT>(FI)', true);
    const securitySelected = 'Zargon Oil & Gas Ltd New Conv 6.0% 06/30/201';
    // component.typeaheadOnSelect(selectedSecurity);
    expect(component.asyncSelected).toEqual(securitySelected);
    expect(component.searchPanelForm.get('securityName').value).toEqual(securitySelected);
    expect(component.isValidSecurity).toEqual(true);
  });

  it('should select a EQ security from drop down', () => {
    const service = TestBed.get(CommonService);
    const item = {
      instrumentLongName: 'Zargon Oil & Gas Ltd New Conv 6.0% 06/30/201'
      , ticker: '*ZOT'
      , country: 'JAPAN'
      , searchedIn: 'ticker'
      , assetType: 'EQUITY'
      , securityVal: 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201<*ZOT>(FI)'
    };
    const selectedSecurity: TypeaheadMatch = new TypeaheadMatch(item
      , 'ZARGON OIL & GAS LTD NEW CONV 6.0% 06/30/201&lt;*ZOT&gt;(EQ)', true);
    const securitySelected = 'Zargon Oil & Gas Ltd New Conv 6.0% 06/30/201';
    // component.typeaheadOnSelect(selectedSecurity);
    expect(component.asyncSelected).toEqual(securitySelected);
    expect(component.searchPanelForm.get('securityName').value).toEqual(securitySelected);
    expect(component.isValidSecurity).toEqual(true);
  });

  it('should catch boolean event and show loader on security search', () => {
    component.changeTypeaheadLoading(true);
    expect(component.typeaheadLoading).toEqual(true);
  });
  it('should show error on security search if the searched results are not found', () => {
    component.typeaheadNoResults(true);
    expect(component.errorResponse).toEqual(true);
  });

  it('should remove text typed in security name field if security value is not selected and cursor is moved out of field focus', () => {
    component.onSecurityBlur();
    component.isValidSecurity = false;
    expect(component.searchPanelForm.get('securityName').value).toEqual('');
    expect(component.searchPanelForm.get('securityTradableEntityId').value).toEqual('');
    expect(component.errorResponse).toEqual(false);
  });

  // Test cases for  from date picker
  it('should find jquery', () => {
    expect($).not.toBeNull();
  });

  it('should have default date as one month back date', () => {
    const datePipe = TestBed.get(DatePipe);
    let date = new Date();
    date.setMonth(date.getMonth() - 1);
    date = datePipe.transform(date, 'dd/MM/yyyy');
    component.checkInvalidDate('fromDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('fromDate').value).toEqual(date);
    expect(component.searchPanelForm.get('fromDate').errors).toBeNull;
    expect(component.checkInvalidDate('fromDate')).toEqual(false);
    expect($('#from').val()).toEqual(date);
  });

  it('should be able to select current date as meeting date', () => {
    $('#from').datepicker('setDate', new Date());
    $('#from').change();
    component.checkInvalidDate('fromDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('fromDate').value).toEqual($('#from').val());
    expect(component.searchPanelForm.get('fromDate').errors).toBeNull;
    expect(component.checkInvalidDate('fromDate')).toEqual(false);
  });


  it('should be able to select future date as meeting date', () => {
    $('#from').datepicker('setDate', '12/01/2026');
    $('#from').change();
    component.checkInvalidDate('fromDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('fromDate').value).toEqual($('#from').val());
    expect(component.searchPanelForm.get('fromDate').errors).toBeNull;
    expect(component.checkInvalidDate('fromDate')).toEqual(false);
  });

  it('should throw error if date is invalid', () => {
    component.searchPanelForm.patchValue({
      fromDate: '12/1254/1254789'
    });
    component.checkInvalidDate('fromDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('fromDate').errors.invalidDate).toEqual(true);
    expect(component.checkInvalidDate('fromDate')).toEqual(true);
  });

  // Test cases for  to date picker
  it('should have default date as one month in future', () => {
    const datePipe = TestBed.get(DatePipe);
    let date = new Date();
    date.setMonth(date.getMonth() + 1);
    date = datePipe.transform(date, 'dd/MM/yyyy');
    component.checkInvalidDate('toDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('toDate').value).toEqual(date);
    expect(component.searchPanelForm.get('toDate').errors).toBeNull;
    expect(component.checkInvalidDate('toDate')).toEqual(false);
    expect($('#to').val()).toEqual(date);
  });

  it('should be able to select current date as meeting date', () => {
    $('#to').datepicker('setDate', new Date());
    $('#to').change();
    component.checkInvalidDate('toDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('toDate').value).toEqual($('#to').val());
    expect(component.searchPanelForm.get('toDate').errors).toBeNull;
    expect(component.checkInvalidDate('toDate')).toEqual(false);
  });


  it('should be able to select future date as meeting date', () => {
    $('#to').datepicker('setDate', '12/01/2026');
    $('#to').change();
    component.checkInvalidDate('toDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('toDate').value).toEqual($('#to').val());
    expect(component.searchPanelForm.get('toDate').errors).toBeNull;
    expect(component.checkInvalidDate('toDate')).toEqual(false);
  });

  it('should throw error if date is invalid', () => {
    component.searchPanelForm.patchValue({
      toDate: '12/1254/1254789'
    });
    component.checkInvalidDate('toDate');
    fixture.detectChanges();
    expect(component.searchPanelForm.get('toDate').errors.invalidDate).toEqual(true);
    expect(component.checkInvalidDate('toDate')).toEqual(true);
  });

  it('should throw error if to date is less than from date', () => {
    component.searchPanelForm.patchValue({
      toDate: '12/04/2019',
      fromDate: '12/05/2019'
    });
    component.checkFromToDateDifference();
    fixture.detectChanges();
    expect(component.searchPanelForm.errors.fromDateExceedToDateError).toEqual(true);
    expect(component.checkFromToDateDifference()).toEqual(true);
  });


  it('should reset date if reset button is clicked', () => {
    const datePipe = TestBed.get(DatePipe);
    let fromdate = new Date();
    let date = new Date();
    fromdate.setMonth(fromdate.getMonth() - 1);
    fromdate = datePipe.transform(fromdate, 'dd/MM/yyyy');
    date.setMonth(date.getMonth() + 1);
    date = datePipe.transform(date, 'dd/MM/yyyy');
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    peopleDataService.resetSearchFiltersObservable = of(true);
    fixture.detectChanges();
    component.resetDate();
    fixture.detectChanges();
    expect(component.searchPanelForm.get('fromDate').value).toEqual(fromdate);
    expect(component.searchPanelForm.get('fromDate').errors).toBeNull;
    expect(component.checkInvalidDate('fromDate')).toEqual(false);
    expect($('#from').val()).toEqual(fromdate);
    expect(component.searchPanelForm.get('toDate').value).toEqual(date);
    expect(component.searchPanelForm.get('toDate').errors).toBeNull;
    expect(component.checkInvalidDate('toDate')).toEqual(false);
    expect($('#to').val()).toEqual(date);
  });
  // UtilData test cases

  it('should return list of utilData and should populate in respective placeholders', () => {
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    peopleDataService.utilMessageObservable = of(utilData);
    fixture.detectChanges();
    component.fetchUtilData();
    fixture.detectChanges();
    component.utilDataObservable.subscribe(response => {
      expect(response).toEqual(utilData);
      expect(component.businessUnitSource).toEqual([
        { UtilKeyName: 'businessUnits', KeyCode: 'FI - TOK', ActiveInd: 'Y' },
        { UtilKeyName: 'businessUnits', KeyCode: 'MA - HKG', ActiveInd: 'Y' },
        { UtilKeyName: 'businessUnits', KeyCode: 'MA - LON', ActiveInd: 'Y' },
        { UtilKeyName: 'businessUnits', KeyCode: 'MA - TOK', ActiveInd: 'Y' }]);
    });
  });

  it('should enable search button if form has no errors', () => {
    component.searchPanelForm.setErrors(null);
    component.searchPanelForm.get('fromDate').setErrors(null);
    component.searchPanelForm.get('toDate').setErrors(null);
    component.disableSearchButton();
    expect(component.disableSearchButton()).toEqual(false);
  });

  it('should disable serach button if form has errors', () => {
    component.searchPanelForm.setErrors(null);
    component.searchPanelForm.get('fromDate').setErrors({ invalidDate: true });
    component.searchPanelForm.get('toDate').setErrors(null);
    component.disableSearchButton();
    expect(component.disableSearchButton()).toEqual(true);
  });
});
