import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { ConfigSignupComponent } from 'src/app/shared/components/config-signup/config-signup.component';
import { ConfigActionsComponent } from 'src/app/shared/components/config-actions/config-actions.component';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router/src/router_state';
import { Router } from '@angular/router';
import { dateComparator } from 'src/app/shared/utils/ag-grid.utility';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'mv2-mv2-meeting-list',
  templateUrl: './mv2-meeting-list.component.html',
  styleUrls: ['./mv2-meeting-list.component.css']
})
export class Mv2MeetingListComponent implements OnInit {
  gridOptions: GridOptions;
  columnDefs: any[];
  meetings = [];
  rowData = [];
  hostCordIds = [];
  overlayNoRowsTemplate: any;
  gridApi: any;
  columnApi: any;
  meetingId: any;
  searchMeetingsCount: any;
  constructor(private commonService: CommonService, private datePipe: DatePipe, private router: Router) { }
  ngOnInit() {
    this.commonService.searchMeetingsDataObservable.subscribe((response) => {
      if (response !== null && response !== undefined) {
        this.meetings = response;
        this.searchMeetingsCount = this.meetings.length;
        this.rowData = this.meetings ? this.meetings : [];
        this.meetings.forEach((rowNode, Index) => {
          this.rowData[Index].meetingState = (this.meetings[Index].meetingState) ? convertToTitleCase(this.meetings[Index].meetingState) : '';
          this.rowData[Index].meetingType = (this.meetings[Index].meetingType) ? (this.meetings[Index].meetingType) === 'Company' && this.meetings[Index].businessEntity ? (this.meetings[Index].meetingType) + ' - ' + (this.meetings[Index].businessEntity) : (this.meetings[Index].meetingType) : '';
          this.rowData[Index].meetingTime = ((this.meetings[Index].meetingDate)
            ? this.datePipe.transform((this.getMeetngDateInLocalTime(this.meetings[Index]))['date'], 'dd MMM yyyy')
            : '')
            + ' ' + ((this.meetings[Index].meetingTimeInGMT) ? (this.getMeetngDateInLocalTime(this.meetings[Index]))['time'] : '');
          this.rowData[Index].emailSubject = (this.meetings[Index].emailSubject)
            ? this.meetings[Index].emailSubject
            : '';
          this.rowData[Index].mtgSubtype = (this.meetings[Index].meetingSubTypeDescription)
            ? (this.meetings[Index].meetingSubTypeDescription)
            : '';
          this.rowData[Index].businessUnit = (this.meetings[Index].businessUnit) ? (this.meetings[Index].businessUnit) : '';
          this.rowData[Index].bloombergTicker = (this.meetings[Index].bloombergTicker) ? (this.meetings[Index].bloombergTicker) : '';
          this.rowData[Index].dialInNumber = (this.meetings[Index].dialInNumber) ? (this.meetings[Index].dialInNumber) : '';
          this.rowData[Index].dialInAccessCode = (this.meetings[Index].dialInAccessCode) ? (this.meetings[Index].dialInAccessCode) : '';
          this.rowData[Index].meetingCreatorName = (this.meetings[Index].meetingCreatorName) ? convertToTitleCase(this.meetings[Index].meetingCreatorName) : '';
          this.rowData[Index].meetingOwnerName = (this.meetings[Index].meetingOwnerName) ? convertToTitleCase(this.meetings[Index].meetingOwnerName) : '';
          this.rowData[Index].hostName = (this.meetings[Index].hostName) ? convertToTitleCase(this.meetings[Index].hostName) : '';
          this.rowData[Index].meetingSubTypeDescription = (this.meetings[Index].meetingSubTypeDescription)
            ? this.meetings[Index].meetingSubTypeDescription
            : '';
          this.rowData[Index].meetingRegion = (this.meetings[Index].meetingRegion)
            ? this.meetings[Index].meetingRegion
            : '';
          this.rowData[Index].mtgCreationDate = this.meetings[Index].insertedTimestamp
            ? this.datePipe.transform(this.meetings[Index].insertedTimestamp.split("T")[0], 'dd MMM yyyy')
            : '';
          if (this.meetings[Index].meetingState === 'DRAFTINVITE') {
            this.meetings[Index].meetingState = 'Draft & Invite';
          }
        });
      }
    });


    this.gridOptions = <GridOptions>{
      headerHeight: 40,
      rowHeight: 32,
      rowBuffer: 200,
      suppressNoRowsOverlay: false,
      suppressCellSelection: true,
      resizable: true,
      // toolPanelSuppressSideButtons: true,
      onGridReady: function (params) {
        this.gridApi = params.api;
        this.columnApi = params.columnApi;
        this.gridApi.hideOverlay();
      },
      suppressMovableColumns: true
    };
    this.columnDefs = [
      {
        headerName: 'State',
        field: 'meetingState',
        resizable: true,
        sortable: true,
        cellStyle: this.styleMeetingState,
        width: 130,
        filter: true,
        cellRenderer: this.meetingStateRenderer,
        pinned: 'left'
      },
      {
        headerName: 'Meeting Type',
        field: 'meetingType',
        resizable: true,
        sortable: true,
        width: 130,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Date & Time',
        field: 'meetingTime',
        resizable: true,
        sort: 'desc',
        sortingOrder: ['desc', 'asc', null],
        sortable: true,
        width: 150,
        comparator: dateComparator,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Email Subject',
        field: 'emailSubject',
        resizable: true,
        sortable: true,
        width: 481,
        cellStyle: { 'text-align': 'left!important', 'font-weight': 'bold' }, cellRenderer: this.tooltipRenderer,
      },
      {
        headerName: 'Host',
        field: 'hostName',
        resizable: true,
        sortable: true,
        width: 180,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Meeting Sub-Type',
        field: 'meetingSubTypeDescription',
        resizable: true,
        sortable: true,
        width: 190,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Business Unit',
        field: 'businessUnit',
        resizable: true,
        sortable: true,
        width: 130,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Bloomberg Ticker',
        field: 'bloombergTicker',
        resizable: true,
        sortable: true,
        width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Creator Region',
        field: 'meetingRegion',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Meeting Creator',
        field: 'meetingCreatorName',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Meeting Owner',
        field: 'meetingOwnerName',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Dial-In Pin',
        field: 'dialInNumber',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Access Code',
        field: 'dialInAccessCode',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Created Date',
        field: 'mtgCreationDate',
        resizable: true,
        sortingOrder: ['desc', 'asc', null],
        sortable: true,
        // width: 150,
        comparator: dateComparator,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Sign Up', field: 'SignUpMeeting', resizable: true, cellRendererFramework: ConfigSignupComponent,
        headerClass: 'mv2-headerCenterAlign',
        cellStyle: { 'text-align': 'center!important', 'cursor': 'pointer!important' }, width: 100,
        pinned: 'right'
      },
      // {
      //   headerName: 'Actions', field: 'MeetingActions', cellRendererFramework: ConfigActionsComponent,
      //   cellStyle: { 'text-align': 'center!important', 'cursor': 'pointer!important' }, width: 120,
      //   headerClass: 'mv2-headerCenterAlign',
      //   pinned: 'right'
      // },
    ];
    this.gridOptions.getRowStyle = function (params) {
      if (params.data.meetingState.toUpperCase() === 'Cancelled') {
        return {
          background: '#eeeff0!important'
        };
      }
    };
    this.gridOptions.rowSelection = 'single';
    this.overlayNoRowsTemplate =
      '<div style=\"font-size: 18px;color: #747c89;\">No meetings to display.<br> Use the search filters above to see results.</div>';
  }
  styleMeetingState(params) {
    if (params.value === 'Draft' || params.value === 'Confirmed' || params.value === 'Draft & Invite') {
      return {
        'text-align': 'left!important',
        'font-size': '13px',
        'font-family': 'Neuzeit Grotesk Regular!important',

      };
    } else if (params.value === 'Cancelled') {
      return {
        color: '#414956',
        'text-align': 'left!important',
        'font-size': '13px',
        'font-family': 'Neuzeit Grotesk Regular!important',

      };
    }
  }

  meetingStateRenderer(params) {
    if (params.value === 'Draft' || params.value === 'Draft & Invite') {
      return '<span class="draftIdentifier">' + params.value + '</span>';
    } else if (params.value === 'Confirmed') {
      return '<span class="confirmIdentifier">' + params.value + '</span>';
    } else if (params.value === 'Cancelled') {
      return '<span class="cancelIdentifier">' + params.value + '</span>';
    }
  }
  tooltipRenderer = function (params) {
    if (params.value === null) {
      return undefined;
    } else {
      return '<span title="' + params.value + '">' + params.value + '</span>';
    }
  };

  rowDoubleClicked(params) {
    // this.commonService.updateMtgDtlsChange("");
    // this.router.navigate(['/meeting/update', { id: params.data.meetingId, type: params.data.meetingType, source: true }], { skipLocationChange: true });
    // if (params.data.meetingType !== 'Company - FI') {
    this.commonService.getMtgDetailsForMtgId(params.data.meetingId, params.data.meetingType).subscribe((response) => {
      if (response.statusCode === 200) {
        this.router.navigate(['/meeting/update'], { skipLocationChange: true });
        this.commonService.updateMtgDtlsChange(response.body);
      } else {
        console.log('No Response', response.errorMessage);
      }
    });
    // }
  }

  getMeetngDateInLocalTime(meetingData): Object {
    const splitMeetingTimeInGMT = (meetingData.meetingTimeInGMT) ? meetingData.meetingTimeInGMT.match(/.{1,2}/g) : '';
    // time conversion into user's Region
    // let dateArrray = moment(meetingData.meetingDate).format('YYYY-MM-DD');
    let dateArrray = meetingData.meetingDate.substring(0, 10);
    let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
    let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    return {
      'date': moment(localTime.substring(0, 10)).format('DD MMM YYYY'),
      'time': localTime.substring(11, 13) + ':' + localTime.substring(14, 16)
    }
  }
}
