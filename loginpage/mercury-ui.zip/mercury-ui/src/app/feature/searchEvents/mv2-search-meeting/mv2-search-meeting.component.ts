import { Component, OnInit, TemplateRef, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { Observable, Observer, EMPTY, combineLatest } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, FormControl, ValidationErrors, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { first, take, distinctUntilChanged } from 'rxjs/operators';
import { SearchMeetingForm } from 'src/app/shared/models/searchMeetingForm.model';
import { SearchPanelForm } from 'src/app/shared/models/searchPanelForm.model';
import { SidePaneSearchPanelForm } from 'src/app/shared/models/sidePaneSearchPanelForm.model';
@Component({
  selector: 'mv2-search-meeting',
  templateUrl: './mv2-search-meeting.component.html',
  styleUrls: ['./mv2-search-meeting.component.css']
})
export class Mv2SearchMeetingComponent implements OnInit, OnDestroy, AfterViewInit {
  // showSidePanel = false;
  modalRef: BsModalRef;
  searchForm = this.fb.group({});
  // sidePaneOpenObservable = new Observable();
  meetingFromdate: Date;
  meetingTodate: Date;
  meetingTypes: string;
  bu = [];
  countries = [];
  regions = [];
  tradableEntityId = '';
  searchFlag = false;
  previousSidePanelSearchForm = this.fb.group({});
  resetFlag = false;
  val = 0;
  userDefaultBU = '';
  // searchMeetingFlag: Observable<any>;

  @ViewChild('template') template: TemplateRef<any>;
  constructor(private commonService: CommonService, private modalService: BsModalService, private fb: FormBuilder, private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
    this.resetFilters();

  }

  ngOnDestroy() {

    // this.commonService.resetSearchFilters.next(true);
    this.commonService.searchMeetings.next(false);


  }


  ngAfterViewInit() {
    if (this.commonService.getSearchMeetingForm() && !this.searchForm.get('sidePaneSearchPanelForm')) {

      let form = this.commonService.getSearchMeetingForm();
      if (form.get('sidePaneSearchPanelForm')) {
        let sidePaneSearchPanelFormmValues = form.get('sidePaneSearchPanelForm')['value'];
        let sideFormGroup = this.fb.group({});
        for (let key in sidePaneSearchPanelFormmValues) {
          if (!sideFormGroup.get(key)) {
            sideFormGroup.addControl(key, new FormControl(''));
          }
          sideFormGroup.get(key).patchValue(sidePaneSearchPanelFormmValues[key])
        }

        this.searchForm.addControl('sidePaneSearchPanelForm', sideFormGroup);
      }
    } else { }
    this.fetchMeetingData();
  }
  formSubmit(event: FormControl, formName: string) {
    this.searchForm.setControl(formName, event);
  }

  fetchMeetingData() {
    //  this.setSearchFormWithPrevSelectedCriteria();

    const queryString = this.createQueryStringForsearch();
    const serachMeetingData = this.commonService.getMeetings(queryString.substr(0, queryString.length - 1));
    serachMeetingData.subscribe((response) => {
      if (response) {
        if (this.searchForm.get('searchPanelForm').get('meetingType').value === 'All Meetings') {
          let combinedMeetingResult = [];
          response.forEach((responseArray) => {
            if (responseArray['body'] && responseArray['body'].length > 0) {
              responseArray['body'].forEach((element) => {
                combinedMeetingResult.push(element);
              })
            }
          });
          this.commonService.searchMeetingsData.next(combinedMeetingResult);
        } else {
          this.commonService.searchMeetingsData.next(response['body']);
        }
      }
    },
      (error) => { console.log(error); });
  }

  resetFilters() {

    const resetFilterFlag = this.commonService.resetSearchFiltersObservable;
    resetFilterFlag.subscribe((response) => {
      if (response) {
        if (this.searchForm.get('searchPanelForm')) {
          const fromdate = new Date();
          const todate = new Date();
          fromdate.setMonth(fromdate.getMonth() - 1);
          todate.setMonth(todate.getMonth() + 1);
          this.searchForm.get('searchPanelForm').patchValue({
            meetingType: 'All Meetings',
            meetingSubTypeCode: [],
            securityName: '',
            securityTradableEntityId: '',
            fromDate: this.datePipe.transform(fromdate, 'dd/MM/yyyy'),
            //  toDate: this.datePipe.transform(todate, 'dd/MM/yyyy'),
            toDate: '',
            hostname: '',
            hostCorporateId: '',
            attendee: '',
            employeeId: '',
            businessUnit: this.userDefaultBU ? [this.userDefaultBU] : [],
            insertedTimestamp: '',
            businessEntity: 'Equity',
            debtTicker: ''

          });
        }

        if (this.searchForm.get('sidePaneSearchPanelForm')) {
          this.searchForm.get('sidePaneSearchPanelForm').patchValue({
            meetingRegion: [],
            countryCode: [],
            meetingCreatorName: '',
            meetingCreator: '',
            meetingOwner: '',
            meetingOwnerCorporateId: '',
            tseIdentifier: '',
            bloombergTicker: '',
            locationType: '',
            position: '',
            meetingState: ''
          });
        }
        if (this.searchForm.get('searchPanelForm')) {
          if (this.searchForm.get('searchPanelForm').get('securityName')) {
            this.searchForm.get('searchPanelForm').get('securityName').disable();
          }
          this.searchForm.get('searchPanelForm').get('businessEntity').disable();
        }
        this.commonService.resetSearchFilters.next(false);
        if (this.resetFlag) {
          // this.commonService.searchMeetings.next(true);
          this.fetchMeetingData();
          this.resetFlag = false;
        }

      }
    },
      (error) => {
        console.log('Error resetting filters');
      });

  }

  resetFilterData() {
    this.commonService.setSearchMeetingForm(null);
    this.resetFlag = true;
    this.commonService.resetSearchFilters.next(true);
  }

  searchMeetings() {
    this.searchFlag = true;
    // this.commonService.searchMeetings.next(true);
    let form = new FormGroup({});
    let sideForm = this.fb.group({});
    let mainForm = this.fb.group({});
    if (this.searchForm.get('searchPanelForm')) {
      let searchPanelFormValues = this.searchForm.get('searchPanelForm').value;
      for (let key in searchPanelFormValues) {
        mainForm.setControl(key, new FormControl(''));
        mainForm.get(key).patchValue(searchPanelFormValues[key])
      }
      form.setControl('searchPanelForm', mainForm);
    }
    if (this.searchForm.get('sidePaneSearchPanelForm')) {
      let sidePaneSearchPanelFormValues = this.searchForm.get('sidePaneSearchPanelForm').value;
      for (let key in sidePaneSearchPanelFormValues) {
        sideForm.setControl(key, new FormControl(''));
        sideForm.get(key).patchValue(sidePaneSearchPanelFormValues[key])
      }
      form.setControl('sidePaneSearchPanelForm', sideForm);
    }
    this.commonService.setSearchMeetingForm(form);
    this.fetchMeetingData();
    this.modalRef.hide();
  }

  cancelSearch() {
    this.updateSidePanelSearchToPreviousValues();
    this.modalRef.hide();
    this.modalRef = null;
  }

  createQueryStringForsearch(): string {

    let queryString = '';
    if (this.searchForm.get('searchPanelForm')) {
      const obj = this.searchForm.get('searchPanelForm').value;
      for (const item in obj) {
        if (this.searchForm.get('searchPanelForm').value[item].length !== 0
          && this.searchForm.get('searchPanelForm').value[item] !== ''
          && item !== 'hostname' && item !== 'attendee' && item !== 'securityName') {
          if (item === 'meetingType' && this.searchForm.get('searchPanelForm').value[item] === 'All Meetings') {
          } else if (item === 'fromDate' || item === 'toDate' || item === 'insertedTimestamp') {
            queryString += item + '=' + this.convertDateToStandardFormat(this.searchForm.get('searchPanelForm').value[item]) + '&';
          } else if (item === 'businessEntity') {
            queryString += item + '=' + (this.searchForm.get('searchPanelForm').value[item] === 'Equity' ? 'EQ' : 'FI') + '&';
          } else if (item === 'businessUnit') {
            if (this.searchForm.get('searchPanelForm').value[item]) {
              queryString += item + '=' + this.searchForm.get('searchPanelForm').value[item] + '&';
            }
          } else {
            queryString += item + '=' + this.searchForm.get('searchPanelForm').value[item] + '&';
          }
        } else {
          if (item === 'toDate' && !this.searchForm.get('searchPanelForm').value[item]) {
            let currDate = new Date();
            currDate.setMonth(currDate.getMonth() + 12);
            let toDateInQString = this.datePipe.transform(currDate, 'dd/MM/yyyy');

            queryString += item + '=' + this.convertDateToStandardFormat(toDateInQString) + '&';
          }

        }
      }
    }
    if (this.searchForm.get('sidePaneSearchPanelForm')) {
      const obj = this.searchForm.get('sidePaneSearchPanelForm').value;
      for (const item in obj) {
        if (this.searchForm.get('sidePaneSearchPanelForm').value[item].length !== 0
          && this.searchForm.get('sidePaneSearchPanelForm').value[item] !== ''
          && item !== 'meetingCreatorName' && item !== 'meetingOwner') {
          if (item === 'meetingState') {
            if (this.searchForm.get('sidePaneSearchPanelForm').value[item]) {
              queryString += item + '=' + this.searchForm.get('sidePaneSearchPanelForm').value[item].toUpperCase() + '&';
            }
          } else {
            queryString += item + '=' + this.searchForm.get('sidePaneSearchPanelForm').value[item] + '&';
          }
        }
      }
      this.previousSidePanelSearchForm = this.fb.group({});
      Object.assign(this.previousSidePanelSearchForm, this.searchForm.get('sidePaneSearchPanelForm'));
    }
    return queryString;

  }

  convertDateToStandardFormat(date: string): string {
    let dateArray = date.split('/');
    let newDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
    return newDate;
  }

  checkForBackDropClick(reason: string) {
    if (reason === 'backdrop-click') {
      this.updateSidePanelSearchToPreviousValues();
      let form = new FormGroup({});
      let sideForm = this.fb.group({});
      let mainForm = this.fb.group({});
      if (this.searchForm.get('searchPanelForm')) {
        let searchPanelFormValues = this.searchForm.get('searchPanelForm').value;
        for (let key in searchPanelFormValues) {
          mainForm.setControl(key, new FormControl(''));
          mainForm.get(key).patchValue(searchPanelFormValues[key])
        }
        form.setControl('searchPanelForm', mainForm);
      }
      if (this.searchForm.get('sidePaneSearchPanelForm')) {
        let sidePaneSearchPanelFormValues = this.searchForm.get('sidePaneSearchPanelForm').value;
        for (let key in sidePaneSearchPanelFormValues) {
          sideForm.setControl(key, new FormControl(''));
          sideForm.get(key).patchValue(sidePaneSearchPanelFormValues[key])
        }
        form.setControl('sidePaneSearchPanelForm', sideForm);
      }
      this.commonService.setSearchMeetingForm(form);
    }
  }

  updateSidePanelSearchToPreviousValues() {
    if (this.searchForm.get('sidePaneSearchPanelForm') && this.previousSidePanelSearchForm) {
      const sidePaneValue = this.searchForm.get('sidePaneSearchPanelForm').value;
      const previousValue = this.previousSidePanelSearchForm.value;
      for (const key in previousValue) {
        if (sidePaneValue[key] !== previousValue[key]) {
          if (key === 'meetingRegion' || key === 'countryCode' || key === 'locationType') {
            this.searchForm.get('sidePaneSearchPanelForm').get(key).patchValue([]);
          }
          this.searchForm.get('sidePaneSearchPanelForm').get(key).patchValue(previousValue[key]);
        }
      }
    }
  }

  disableSearchButton() {
    if (this.searchForm.get('searchPanelForm').errors === null
      && this.searchForm.get('searchPanelForm').get('fromDate').errors === null
      && this.searchForm.get('searchPanelForm').get('toDate').errors === null) {
      return false;
    }
    return true;
  }

  showSideFilters(event: boolean) {
    if (event) {
      if (this.modalService.getModalsCount() === 0) {
        this.modalRef = this.modalService.show(this.template);
        this.modalService.onHide.subscribe((reason) => {
          this.checkForBackDropClick(reason);
        });
      }
    }
  }

  resetFormEmit(event: boolean) {
    this.resetFlag = event;
  }

  searchFilterMeeting(event) {
    if (event) {
      let form = new FormGroup({});
      let sideForm = this.fb.group({});
      let mainForm = this.fb.group({});
      if (this.searchForm.get('searchPanelForm')) {
        let searchPanelFormValues = this.searchForm.get('searchPanelForm').value;
        for (let key in searchPanelFormValues) {
          mainForm.setControl(key, new FormControl(''));
          mainForm.get(key).patchValue(searchPanelFormValues[key])
        }
        form.setControl('searchPanelForm', mainForm);
      }
      if (this.searchForm.get('sidePaneSearchPanelForm')) {
        let sidePaneSearchPanelFormValues = this.searchForm.get('sidePaneSearchPanelForm').value;
        for (let key in sidePaneSearchPanelFormValues) {
          sideForm.setControl(key, new FormControl(''));
          sideForm.get(key).patchValue(sidePaneSearchPanelFormValues[key])
        }
        form.setControl('sidePaneSearchPanelForm', sideForm);
      }
      this.commonService.setSearchMeetingForm(form);
      this.fetchMeetingData();
    }
  }

}
