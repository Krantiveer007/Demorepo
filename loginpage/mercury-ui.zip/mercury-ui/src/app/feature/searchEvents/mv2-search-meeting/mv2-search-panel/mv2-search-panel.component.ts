import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, NgZone } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { MEETINGTYPE } from 'src/app/shared/app-constant/meeting.constants';
import { Observable, Observer, EMPTY } from 'rxjs';
import { Security } from 'src/app/shared/models/security.model';
import { Subscription } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
declare var jquery: any;
declare var $: any;
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { filterSecuritydata, filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';


@Component({
  selector: 'mv2-search-panel',
  templateUrl: './mv2-search-panel.component.html',
  styleUrls: ['./mv2-search-panel.component.css'],
})
export class Mv2SearchPanelComponent implements OnInit {
  searchPanelForm = this.fb.group({
    meetingType: ['All Meetings'],
    meetingSubTypeCode: [[]],
    securityName: [''],
    securityTradableEntityId: [''],
    fromDate: ['', MeetingFieldValidations.InvalidDateValidator],
    toDate: ['', MeetingFieldValidations.InvalidDateValidator],
    insertedTimestamp: ['', MeetingFieldValidations.InvalidDateValidator],
    hostname: [''],
    hostCorporateId: [''],
    attendee: [''],
    employeeId: [''],
    businessUnit: [[]],
    businessEntity: ['Equity']
  }, { validators: MeetingFieldValidations.FromToDate });
  isValidSecurity = false;
  toggleFiltersText = 'MORE FILTERS';
  showMoreFilters = false;
  meetingType = MEETINGTYPE;
  selectedMeetingType = 'All Meetings';
  isMtgSubTypeDisabled = false;
  securitiesDataSource: Observable<any>;
  debtTickerDataSource: Observable<any>;
  brokerFirmDataSource: Observable<any>;
  peopleDataSource: Observable<any>;
  businessUnitSource = [];
  meetingSubtypeDescription = [];
  // securitySubscription: Subscription;
  errorResponse = false;
  selectedParameter: string;
  typeaheadLoading: boolean;
  fromDate: Date = new Date();
  // createdFromDate: Date = new Date();
  toDate: Date = new Date();
  toDateErrorResponse = false;
  utilDataObservable: Observable<any>;
  securityResponse = [];
  isValidHost = false;
  isValidAttendee = false;
  peopleDataSubscription: Subscription;
  hostErrorResponse = false;
  peopleData: any[] = [];
  hostTypeaheadLoading: boolean;
  attendeeTypeaheadLoading: boolean;
  debtTickerTypeaheadLoading: boolean;
  brokerFirmTypeaheadLoading: boolean;
  attendeeErrorResponse = false;
  creatorSelected = '';
  creatorSelectedId = '';
  ownerSelected = '';
  ownerSelectedId = '';
  businessEntity = ['Equity', 'Fixed Income'];
  securitySubscription: Subscription;
  searchNameType = 'Company';
  placeholderForCompanySearch = 'Filter By company';
  isValidDebtTicker = false;
  isValidBrokerFirm = false;
  debtTickerErrorResponse = false;
  brokerFirmErrorResponse = false;
  userDefaultBU = '';
  companyMeetingSubtypeDescription = [];
  otherMeetingSubtypeDescription = [];
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);

  @Output() formEmit = new EventEmitter<any>();
  @Output() resetFlagEmitter = new EventEmitter<boolean>(false);
  @Output() searchMeeting = new EventEmitter<boolean>(false);
  @Output() showSideFilters = new EventEmitter<boolean>(false);

  constructor(private commonService: CommonService, private ngZone: NgZone, private fb: FormBuilder, private datePipe: DatePipe) { }

  ngOnInit() {


    this.formEmit.emit(this.searchPanelForm);
    this.fetchUtilData();

  if (this.commonService.getSearchMeetingForm()) {
    let form = this.commonService.getSearchMeetingForm();
    let searchPanelFormValues = form.get('searchPanelForm')['value']
    // this.searchPanelForm['controls'] = form.get('searchPanelForm')['controls'];
    for (let key in searchPanelFormValues) {
      if (!this.searchPanelForm.get(key)) {
        this.searchPanelForm.addControl(key, new FormControl(''));
      }
      this.searchPanelForm.get(key).patchValue(searchPanelFormValues[key])
      
    }
      if (this.searchPanelForm.get('meetingType').value === 'Other') {
      this.meetingSubtypeDescription = this.otherMeetingSubtypeDescription;
    }
    if (this.searchPanelForm.get('meetingType').value === 'All Meetings') {
      this.allMtgSubtype();
    }
    if (this.searchPanelForm.get('meetingType').value === 'Company') {
      this.meetingSubtypeDescription = this.companyMeetingSubtypeDescription;
    }
    if (this.searchPanelForm.get('hostCorporateId') && this.searchPanelForm.get('hostCorporateId').value) {
      this.isValidHost = true;
    }
    if (this.searchPanelForm.get('employeeId') && this.searchPanelForm.get('employeeId').value) {
      this.isValidAttendee = true;
    }
    if (this.searchPanelForm.get('businessEntity') && this.searchPanelForm.get('businessEntity').value) {
      if (this.searchPanelForm.get('businessEntity').value === 'Equity') {
        this.securityLabelChange('Equity');
        if (this.searchPanelForm.get('debtTicker')) {
          this.searchPanelForm.removeControl('debtTicker');
        }
      }
      if (this.searchPanelForm.get('businessEntity').value === 'Fixed Income') {
        this.securityLabelChange('DebtTicker');
        if (this.searchPanelForm.get('securityName')) {
          this.searchPanelForm.removeControl('securityName');
          this.searchPanelForm.removeControl('securityTradableEntityId');
        }
      }
    }
    if (this.searchPanelForm.get('securityTradableEntityId') && this.searchPanelForm.get('securityTradableEntityId').value) {
      this.isValidSecurity = true;
        this.securityLabelChange('Equity');
      if (this.searchPanelForm.get('debtTicker')) {
        this.searchPanelForm.removeControl('debtTicker');
      }
    }
    if (this.searchPanelForm.get('brokerFirmId') && this.searchPanelForm.get('brokerFirmId').value) {
      this.isValidBrokerFirm = true;
    }
    if (this.searchPanelForm.get('debtTicker') && this.searchPanelForm.get('debtTicker').value) {
      this.isValidDebtTicker = true;
      this.securityLabelChange('DebtTicker');
      if (this.searchPanelForm.get('securityName')) {
        this.searchPanelForm.removeControl('securityName');
        this.searchPanelForm.removeControl('securityTradableEntityId');
      }
    }
    this.fromDate = this.searchPanelForm.get('fromDate').value;
    if (this.searchPanelForm.get('meetingType').value === 'Broker') {
      this.searchPanelForm.get('meetingSubTypeCode').disable();
      this.isMtgSubTypeDisabled = true;
    }
    if (this.searchPanelForm.get('meetingType').value === 'Other' || this.searchPanelForm.get('meetingType').value === 'All Meetings') {
      this.searchPanelForm.get('securityName').disable();
      this.searchPanelForm.get('businessEntity').disable();
    }
  } else {
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
      if (this.userDefaultBU) {
    this.searchPanelForm.patchValue({
      'businessUnit': [this.userDefaultBU]
    })
    }
    this.searchPanelForm.get('securityName').disable();
    this.searchPanelForm.get('businessEntity').disable();
    this.fromDate.setMonth(this.fromDate.getMonth() - 1);
    this.searchPanelForm.patchValue({
      'fromDate': this.datePipe.transform(this.fromDate, 'dd/MM/yyyy'),
     // 'toDate': this.datePipe.transform(this.toDate, 'dd/MM/yyyy')
      //  'insertedTimestamp': this.datePipe.transform(this.createdFromDate, 'dd/MM/yyyy')
    });
  }


    $(() => {
      const dateFormat = 'mm/dd/yy',
        from = $('#from')
          .datepicker({
            numberOfMonths: 2,
            showButtonPanel: false,
            dateFormat: 'dd/mm/yy'
          })
          .on('change', () => {
            if ($('#from').val() === '') {
              $('#from').datepicker('setDate', this.fromDate);
            }
            this.ngZone.run(() => {
              this.searchPanelForm.patchValue({
                fromDate: $('#from').val()
              });
            });
          }),
        to = $('#to').datepicker({
          numberOfMonths: 2,
          showButtonPanel: false,
          dateFormat: 'dd/mm/yy'
        })
          .on('change', () => {
            if ($('#to').val() === '') {
            //  $('#to').datepicker('setDate', this.toDate);
            }
            this.ngZone.run(() => {
              this.searchPanelForm.patchValue({
                toDate: $('#to').val()
              });
            });
          }),
        createdFrom = $('#createdFrom')
          .datepicker({
            numberOfMonths: 2,
            showButtonPanel: false,
            dateFormat: 'dd/mm/yy'
          })
          .on('change', () => {
            if ($('#createdFrom').val() === '') {
              //     $('#createdFrom').datepicker('setDate', this.createdFromDate);
            }
            this.ngZone.run(() => {
              this.searchPanelForm.patchValue({
                insertedTimestamp: $('#createdFrom').val()
              });
            });
          });
      $('#from').datepicker('setDate', this.fromDate);
     // $('#to').datepicker('setDate', this.toDate);
      //     $('#createdFrom').datepicker('setDate', this.createdFromDate);
    });
    this.resetDate();
  }

  getSecurities() {
    let typeaheadData: TypeaheadData;
    this.isValidSecurity = false;
    const searchedValue = this.searchPanelForm.get('securityName').value;
    typeaheadData = this.typeaheadDataSource.getSecurities(searchedValue);
    this.securitiesDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
  }

  getDebtTicker() {
    let typeaheadData: TypeaheadData;
    this.isValidDebtTicker = false;
    const searchedValue = this.searchPanelForm.get('debtTicker').value;
    typeaheadData = this.typeaheadDataSource.getDebtTicker(searchedValue);
    this.debtTickerDataSource = typeaheadData.dataSource;
    this.debtTickerErrorResponse = typeaheadData.isResponseError;
  }

  typeaheadOnSecuritySelect(event: TypeaheadMatch): void {
    if (this.searchPanelForm.get('businessEntity').value === 'Equity') {
      const selectedSecurityInstance = event.item;
      this.selectedParameter = event.item.itemValue;
      this.selectedParameter = this.selectedParameter.split('&lt;').join('<').split('&gt;').join('>');
      this.searchPanelForm.patchValue({
        securityName: convertToTitleCase(selectedSecurityInstance.instrumentLongName),
        securityTradableEntityId: selectedSecurityInstance.tradableEntId ? selectedSecurityInstance.tradableEntId : ''
      });
      this.isValidSecurity = true;
    } else {
      this.searchPanelForm.patchValue({
        debtTicker: event.item.debtTicker
      });
      this.isValidDebtTicker = true;
    }
  }


  changeTypeaheadLoading(e: boolean): void {
    if (this.searchPanelForm.get('meetingType').value === 'Company') {
      if (this.searchPanelForm.get('businessEntity').value === 'Equity') {
        this.typeaheadLoading = e;
      } else {
        this.debtTickerTypeaheadLoading = e;
      }
    } else if (this.searchPanelForm.get('meetingType').value === 'Broker') {
      this.brokerFirmTypeaheadLoading = e;
    }
  }

  typeaheadNoResults(event: boolean): void {
    if (this.searchPanelForm.get('meetingType').value === 'Company') {
      if (this.searchPanelForm.get('businessEntity').value === 'Equity') {
        this.errorResponse = event;
      }
      else {
        this.debtTickerErrorResponse = event
      }
    } else if (this.searchPanelForm.get('meetingType').value === 'Broker') {
      this.brokerFirmErrorResponse = event;
    }
  }

  onSecurityBlur() {
    if (this.searchPanelForm.get('businessEntity').value === 'Equity') {
      if (!this.isValidSecurity) {
        this.searchPanelForm.patchValue({
          securityName: '',
          securityTradableEntityId: ''
        });
        if (this.securitySubscription) {
          this.securitySubscription.unsubscribe();
        }
        this.getSecurities();
        this.typeaheadLoading = false;
      }
    }
    if (this.searchPanelForm.get('businessEntity').value === 'Fixed Income') {
      if (!this.isValidDebtTicker) {
        this.searchPanelForm.patchValue({
          debtTicker: '',
        });
        this.getDebtTicker();
        this.debtTickerTypeaheadLoading = false;
      }
    }
  }

  getBrokerFirm() {
    let typeaheadData: TypeaheadData;
    this.isValidBrokerFirm = false;
    const searchedValue = this.searchPanelForm.get('brokerFirmName').value;
    typeaheadData = this.typeaheadDataSource.getBrokerFirms(searchedValue);
    this.brokerFirmDataSource = typeaheadData.dataSource;
    this.brokerFirmErrorResponse = typeaheadData.isResponseError;
  }

  typeaheadOnBrokerFirmSelect(event: TypeaheadMatch) {
    this.searchPanelForm.patchValue({
      brokerFirmName: convertToTitleCase(event.item.firmName),
      brokerFirmId: event.item.firmId
    });
    this.commonService.setBrokerFirmDetails({
      brokerFirmName: this.searchPanelForm.get('brokerFirmName').value,
      brokerFirmId: this.searchPanelForm.get('brokerFirmId').value,
    });
    this.isValidBrokerFirm = true;
  }
  onBrokerFirmBlur() {
    if (!this.isValidBrokerFirm) {
      this.searchPanelForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.brokerFirmTypeaheadLoading = false;
      this.getBrokerFirm();
    }
  }


  showFilters() {
    this.showSideFilters.emit(true);
  }

  selectMeet() {
    //company
    this.isMtgSubTypeDisabled = false;
    if (this.searchPanelForm.get('meetingType').value === 'Other') {
      this.meetingSubtypeDescription = this.otherMeetingSubtypeDescription;
    }
    if (this.searchPanelForm.get('meetingType').value === 'All Meetings') {
      this.allMtgSubtype();
    }
    if (this.searchPanelForm.get('meetingType').value === 'Company') {
      this.meetingSubtypeDescription = this.companyMeetingSubtypeDescription;
      if (!this.searchPanelForm.get('securityName')) {
        this.searchPanelForm.addControl('securityName', new FormControl(''));
        this.searchPanelForm.addControl('securityTradableEntityId', new FormControl(''));
      }
      this.searchPanelForm.get('securityName').enable();
      this.searchPanelForm.get('businessEntity').enable();
      this.securityLabelChange('Equity');
    } else {
      if (this.searchPanelForm.get('securityName')) {
        this.searchPanelForm.get('securityName').disable();
      }
      if (this.searchPanelForm.get('debtTicker')) {
        this.searchPanelForm.get('debtTicker').disable();
      }
      this.searchPanelForm.get('businessEntity').disable();
      this.searchPanelForm.patchValue({
        'securityName': '',
        'securityTradableEntityId': '',
        'debtTicker': '',
        'businessEntity': 'Equity'
      });
      if (this.searchPanelForm.get('meetingType').value === 'Broker') {
        this.placeholderForCompanySearch = 'Filter By Broker Firm';
        this.searchPanelForm.addControl('brokerFirmName', new FormControl(''));
        this.searchPanelForm.addControl('brokerFirmId', new FormControl(''));
        this.searchPanelForm.patchValue({
          'meetingSubTypeCode': ''
        });
        this.isMtgSubTypeDisabled = true;
      } else {
        this.placeholderForCompanySearch = 'Filter By Company';
        this.searchNameType = 'Company';
      }
    }
  }

  getPeopleData(formControlName: string): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.searchPanelForm.get(formControlName).value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    if (formControlName === 'hostname') {
      this.isValidHost = false;
      this.hostErrorResponse = typeaheadData.isResponseError;
    }
    if (formControlName === 'attendee') {
      this.isValidAttendee = false;
      this.attendeeErrorResponse = typeaheadData.isResponseError;
    }
  }

  changeTypeaheadPeopleLoading(e: boolean, formControlName: string): void {
    if (formControlName === 'hostname') {
      this.hostTypeaheadLoading = e;
    } else if (formControlName === 'attendee') {
      this.attendeeTypeaheadLoading = e;
    }
  }

  typeaheadOnPeopleSelect(event, formControlName: string) {
    const selectedName = convertToTitleCase(event.item.name);
    if (formControlName === 'hostname') {
      this.isValidHost = true;
      this.searchPanelForm.patchValue({
        hostname: selectedName,
        hostCorporateId: event.item.corporateId
      });
    }
    if (formControlName === 'attendee') {
      this.isValidAttendee = true;
      this.searchPanelForm.patchValue({
        attendee: selectedName,
        employeeId: event.item.corporateId
      });
    }
  }

  typeaheadNoPeopleResults(event: boolean, formControlName: string): void {
    if (formControlName === 'hostname') {
      this.hostErrorResponse = event;
    }
    if (formControlName === 'attendee') {
      this.attendeeErrorResponse = event;
    }
  }
  onBlurMethod() {
    if (!this.isValidHost) {
      this.hostTypeaheadLoading = false;
      this.searchPanelForm.patchValue({
        hostname: '',
        hostCorporateId: ''
      });
      this.getPeopleData('hostname');
    }
    if (!this.isValidAttendee) {
      this.attendeeTypeaheadLoading = false;
      this.searchPanelForm.patchValue({
        attendee: '',
        employeeId: ''
      });
      this.getPeopleData('attendee');
    }
    
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        const utilData = message;
        this.businessUnitSource = utilData.filter(element => element.UtilKeyName === 'businessUnits');
        this.companyMeetingSubtypeDescription = utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Company');
        this.otherMeetingSubtypeDescription = utilData.filter(element => element.UtilKeyName === 'newMeetingSubtypes.Other');

        // this.companyMeetingSubtypeDescription = utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Company');
        // this.otherMeetingSubtypeDescription = utilData.filter(element => element.UtilKeyName === 'meetingSubtypes.Other');
        this.allMtgSubtype();
        }
    },
      (error) => {
        console.log(error);
      });
  }

  checkInvalidDate(dateType: string): boolean {
    if (this.searchPanelForm.get(dateType).errors !== null && this.searchPanelForm.get(dateType).errors.invalidDate) {
      return true;
    }
    return false;
  }

  searchMeetings() {
    this.searchMeeting.emit(true);
  }

  resetFilters() {
    this.commonService.setSearchMeetingForm(null);
    this.isMtgSubTypeDisabled = false;
    this.resetFlagEmitter.emit(true);
    this.commonService.resetSearchFilters.next(true);
  }

  resetDate() {
    const resetFilterFlag = this.commonService.resetSearchFiltersObservable;
    resetFilterFlag.subscribe((response) => {
      if (response) {
        if (this.searchPanelForm.get('meetingType').value === 'Other') {
      this.meetingSubtypeDescription = this.otherMeetingSubtypeDescription;
    }
    if (this.searchPanelForm.get('meetingType').value === 'All Meetings') {
      this.allMtgSubtype();
    }
    if (this.searchPanelForm.get('meetingType').value === 'Company') {
      this.meetingSubtypeDescription = this.companyMeetingSubtypeDescription;
    }
        $('#from').datepicker('setDate', this.fromDate);
        $('#createdFrom').datepicker('setDate', '');
       // $('#to').datepicker('setDate', this.toDate);
        this.placeholderForCompanySearch = 'Filter By Company';
        this.searchNameType = 'Company';
      }
    },
      (error) => {
        console.log('Error resetting filters');
      });
  }

  checkFromToDateDifference(): boolean {
    if (this.searchPanelForm.errors !== null && this.searchPanelForm.errors.fromDateExceedToDateError
      && this.searchPanelForm.get('fromDate').errors === null
      && this.searchPanelForm.get('toDate').errors === null
      && this.searchPanelForm.get('insertedTimestamp').errors === null) {
      return true;
    }
    return false;
  }

  disableSearchButton() {
    if (this.searchPanelForm.errors === null
      && this.searchPanelForm.get('fromDate').errors === null
      && this.searchPanelForm.get('toDate').errors === null
      && this.searchPanelForm.get('insertedTimestamp').errors === null) {
      return false;
    }
    return true;
  }

  securityLabelChange(event) {
    if (event === 'Equity') {
      this.searchNameType = 'Company';
      this.placeholderForCompanySearch = 'Filter By Company';
      this.searchPanelForm.addControl('securityName', new FormControl(''));

      this.searchPanelForm.addControl('securityTradableEntityId', new FormControl(''));
      if (this.searchPanelForm.get('debtTicker')) {
        this.searchPanelForm.removeControl('debtTicker');
      }

    } else {
      this.searchNameType = 'Debt Ticker';
      this.placeholderForCompanySearch = 'Filter By Debt Ticker';
      this.searchPanelForm.addControl('debtTicker', new FormControl(''));

      if (this.searchPanelForm.get('securityName')) {
        this.searchPanelForm.removeControl('securityName');
        this.searchPanelForm.removeControl('securityTradableEntityId');
      }
    }
  }

  allMtgSubtype() {
    let meetingSubtypeDescription = JSON.parse(JSON.stringify(this.companyMeetingSubtypeDescription));
    let meetingSubTypeDescArr = [];
    for (let item of meetingSubtypeDescription) {
      meetingSubTypeDescArr.push(item['KeyDesc'])
    }
    let uniqueOtherSubtype = [];
    uniqueOtherSubtype = this.otherMeetingSubtypeDescription.filter((item) => { return !meetingSubTypeDescArr.includes(item['KeyDesc']) });
    this.meetingSubtypeDescription = meetingSubtypeDescription.concat(uniqueOtherSubtype);
  }
}
