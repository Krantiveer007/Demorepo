import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgSelectModule } from '@ng-select/ng-select';
import { SideNavSearchFiltersComponent } from './side-nav-search-filters.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs';
import { of, throwError } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { AgGridModule } from 'ag-grid-angular';
import { ConfigMultiselectComponent } from 'src/app/shared/components/config-multiselect/config-multiselect.component';
import { MultiSelectModule } from '@syncfusion/ej2-angular-dropdowns';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';

describe('SideNavSearchFiltersComponent', () => {
  let component: SideNavSearchFiltersComponent;
  let fixture: ComponentFixture<SideNavSearchFiltersComponent>;
  const utilData = [
    { KeyDesc: 'Algeria', KeyCode: 'ALGR', UtilKeyName: 'countries', Region: 'OT' },
    { KeyDesc: 'Angola', KeyCode: 'ANGL', UtilKeyName: 'countries', Region: 'OT' },
    { KeyDesc: 'Antigua & Barbuda', KeyCode: 'ANTG', UtilKeyName: 'countries', Region: 'OT' },
    { KeyCode: 'AME', KeyDesc: 'Americas', UtilKeyName: 'regions' },
    { KeyCode: 'APxJ', KeyDesc: 'Asia Pacific', UtilKeyName: 'regions' },
    { KeyCode: 'CAN', KeyDesc: 'Canada', UtilKeyName: 'regions' },
    { KeyCode: 'EUR', KeyDesc: 'Europe', UtilKeyName: 'regions' }
  ];

  const peopleData =
    [{ 'corpId': 'A482682', 'displayName': 'SHEVADEKAR, SAPAN' },
    { 'corpId': 'A366680', 'displayName': 'MAINI, PANKAJ' },
    { 'corpId': 'A497865', 'displayName': 'GANDHI, PANKAJ' },
    { 'corpId': 'A501403', 'displayName': 'YADAV, PANKAJ' },
    { 'corpId': 'A498527', 'displayName': 'GUPTA, SAPAN' }
    ];

  const manipulatePeopleData = [
    'Shevadekar, Sapan' + ' &lt;' + 'A482682' + '&gt;',
    'Maini, Pankaj' + ' &lt;' + 'A366680' + '&gt;',
    'Gandhi, Pankaj' + ' &lt;' + 'A497865' + '&gt;',
    'Yadav, Pankaj' + ' &lt;' + 'A501403' + '&gt;',
    'Gupta, Sapan' + ' &lt;' + 'A498527' + '&gt;'
  ];

  const event: TypeaheadMatch = new TypeaheadMatch('Yadav, Pankaj &lt;A501403&gt;', 'Yadav, Pankaj &lt;A501403&gt;', false);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        HttpClientModule,
        CommonModule,
        BrowserModule,
        RouterTestingModule,
        NgSelectModule,
        AgGridModule.withComponents([]),
        MultiSelectModule
      ],
      declarations: [SideNavSearchFiltersComponent, Mv2MeetingListComponent, ConfigMultiselectComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, [FormBuilder]],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideNavSearchFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // UtilData test cases

  it('should return list of utilData and should populate in respective placeholders', () => {
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    // const spy = spyOn(peopleDataService, 'utilMessageObservable').and.returnValue(of(utilData));
    peopleDataService.utilMessageObservable = of(utilData);
    fixture.detectChanges();
    component.fetchUtilData();
    fixture.detectChanges();
    component.utilDataObservable.subscribe(response => {
      expect(response).toEqual(utilData);
      expect(component.countries).toEqual([
       
        { KeyDesc: 'Algeria', KeyCode: 'ALGR', UtilKeyName: 'countries', Region: 'OT' },
        { KeyDesc: 'Angola', KeyCode: 'ANGL', UtilKeyName: 'countries', Region: 'OT' },
        { KeyDesc: 'Antigua & Barbuda', KeyCode: 'ANTG', UtilKeyName: 'countries', Region: 'OT' }]);
      expect(component.regions).toEqual([
       
        { KeyCode: 'AME', KeyDesc: 'Americas', UtilKeyName: 'regions' },
        { KeyCode: 'APxJ', KeyDesc: 'Asia Pacific', UtilKeyName: 'regions' },
        { KeyCode: 'CAN', KeyDesc: 'Canada', UtilKeyName: 'regions' },
        { KeyCode: 'EUR', KeyDesc: 'Europe', UtilKeyName: 'regions' }]);

    });
  });

  // Meeting Location

  it('should have four values for meeting location', () => {
    expect(component.meetingLocations).toEqual([
      'Conference Call', 'In-house', 'External', 'Video Call'
    ]);
  });

  // Meeting creator and meeting owner test cases
  it('should return list of people when 3 or more characters are typed in Meeting creator search box', () => {
    component.sidePaneSearchPanelForm.patchValue({ 'meetingCreatorName': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData('MeetingCreator');
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulatePeopleData);
    });
  });

  it('should return list of people when 3 or more characters are typed in Meeting owner search box', () => {
    component.sidePaneSearchPanelForm.patchValue({ 'meetingOwner': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData('MeetingOwner');
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulatePeopleData);
    });
  });

  it('should throw error while fetching data from service', () => {
    component.sidePaneSearchPanelForm.patchValue({ 'meetingCreatorName': 'pan' });
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(throwError);
    fixture.detectChanges();
    component.getPeopleData('MeetingCreator');
    fixture.detectChanges();
    component.peopleDataSource.subscribe((response) => { },
      (error) => {
        //  expect(component.peopledataSource).toBeNull;
      });
  });

  it('should return only name on typeheadselect for Meeting Creator', () => {
    component.typeaheadOnSelect(event, 'MeetingCreator');
    fixture.detectChanges();
    expect(component.sidePaneSearchPanelForm.get('meetingCreatorName').value).toEqual('Yadav, Pankaj');
    expect(component.sidePaneSearchPanelForm.get('meetingCreator').value).toEqual('A501403');
    expect(component.isValidCreator).toEqual(true);
  });

  it('should return only name on typeheadselect for Meeting Owner', () => {
    component.typeaheadOnSelect(event, 'MeetingOwner');
    fixture.detectChanges();
    expect(component.sidePaneSearchPanelForm.get('meetingOwner').value).toEqual('Yadav, Pankaj');
    expect(component.sidePaneSearchPanelForm.get('meetingOwnerCorporateId').value).toEqual('A501403');
    expect(component.isValidOwner).toEqual(true);
  });

  it('should show error on person search if the searched results are not found', () => {
    component.typeaheadNoResults(true, 'MeetingCreator');
    expect(component.errorResponse).toEqual(true);
  });
  it('should show error on person search if the searched results are not found', () => {
    component.typeaheadNoResults(false, 'MeetingOwner');
    expect(component.ownerErrorResponse).toEqual(false);
  });

  it('should catch boolean event and show loader on people search', () => {
    component.changeTypeaheadLoading(true, 'MeetingCreator');
    expect(component.typeaheadLoading).toEqual(true);
  });
  it('should catch boolean event and show loader on people search', () => {
    component.changeTypeaheadLoading(false, 'MeetingOwner');
    expect(component.ownerTypeaheadLoading).toEqual(false);
  });

  it('should remove text typed in creator field if creator value is not selected and cursor is moved out of field focus', () => {
    component.onBlurMethod();
    component.isValidCreator = false;
    expect(component.sidePaneSearchPanelForm.get('meetingCreatorName').value).toEqual('');
    expect(component.sidePaneSearchPanelForm.get('meetingCreator').value).toEqual('');
  });

  it('should remove text typed in owner field if owner value is not selected and cursor is moved out of field focus', () => {
    component.onBlurMethod();
    component.isValidOwner = false;
    expect(component.sidePaneSearchPanelForm.get('meetingOwner').value).toEqual('');
    expect(component.sidePaneSearchPanelForm.get('meetingOwnerCorporateId').value).toEqual('');
  });
});
