import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mv2EventsSearchComponent } from './mv2-events-search.component';

describe('Mv2EventsSearchComponent', () => {
  let component: Mv2EventsSearchComponent;
  let fixture: ComponentFixture<Mv2EventsSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mv2EventsSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2EventsSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
