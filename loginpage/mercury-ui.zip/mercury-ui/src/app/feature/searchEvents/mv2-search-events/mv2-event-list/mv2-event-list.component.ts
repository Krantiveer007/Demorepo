import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { ConfigSignupComponent } from 'src/app/shared/components/config-signup/config-signup.component';
import { ConfigActionsComponent } from 'src/app/shared/components/config-actions/config-actions.component';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router/src/router_state';
import { Router } from '@angular/router';
import { dateComparator } from 'src/app/shared/utils/ag-grid.utility';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'mv2-mv2-event-list',
  templateUrl: './mv2-event-list.component.html',
  styleUrls: ['./mv2-event-list.component.css']
})
export class Mv2EventListComponent implements OnInit {
  gridOptions: GridOptions;
  columnDefs: any[];
  events = [];
  rowData = [];
  hostCordIds = [];
  overlayNoRowsTemplate: any;
  gridApi: any;
  columnApi: any;
  meetingId: any;
  searchEventsCount: any;
  constructor(private commonService: CommonService, private datePipe: DatePipe, private router: Router) { }
  ngOnInit() {
    this.commonService.searchEventsDataObservable.subscribe((response) => {
      if (response !== null && response !== undefined) {
        this.events = response;
        this.searchEventsCount = this.events.length;
        this.rowData = this.events ? this.events : [];
        this.events.forEach((rowNode, Index) => {
          this.rowData[Index].conferenceStatus = (this.events[Index].conferenceStatus) ? convertToTitleCase(this.events[Index].conferenceStatus) : '';
          this.rowData[Index].eventState = this.events[Index].eventState ? (this.events[Index].eventState === 'NEW'? 'Confirmed': convertToTitleCase(this.events[Index].eventState)): 'Confirmed';
          // this.rowData[Index].meetingType = (this.events[Index].meetingType) ? (this.events[Index].meetingType) === 'Company' && this.events[Index].businessEntity ? (this.events[Index].meetingType) + ' - ' + (this.events[Index].businessEntity) : (this.events[Index].meetingType) : '';
          this.rowData[Index].eventInterval = ((this.events[Index].startDate)
            ? this.datePipe.transform((this.getMeetngDateInLocalTime(this.events[Index].startDate)), 'dd MMM yyyy')
            : '') + ' - ' +
            ((this.events[Index].endDate)
            ? this.datePipe.transform(this.getMeetngDateInLocalTime(this.events[Index].endDate), 'dd MMM yyyy')
            : '');
            this.rowData[Index].location = ((this.events[Index].city)
            ? this.events[Index].city
            : '') + ' ,' +
            ((this.events[Index].countryDescription)
            ? this.events[Index].countryDescription
            : '');
          // this.rowData[Index].emailSubject = (this.events[Index].emailSubject)
          //   ? this.events[Index].emailSubject
          //   : '';
          // this.rowData[Index].mtgSubtype = (this.events[Index].meetingSubTypeDescription)
          //   ? (this.events[Index].meetingSubTypeDescription)
          //   : '';
          // this.rowData[Index].businessUnit = (this.events[Index].businessUnit) ? (this.events[Index].businessUnit) : '';
          // this.rowData[Index].bloombergTicker = (this.events[Index].bloombergTicker) ? (this.events[Index].bloombergTicker) : '';
          this.rowData[Index].eventCreatorName = (this.events[Index].eventCreator && this.events[Index].eventCreator.name) ? convertToTitleCase(this.events[Index].eventCreator.name) : '';
          this.rowData[Index].eventOwnerName = (this.events[Index].eventOwner && this.events[Index].eventOwner.name) ? convertToTitleCase(this.events[Index].eventOwner.name) : '';
          // this.rowData[Index].hostName = (this.events[Index].hostName) ? convertToTitleCase(this.events[Index].hostName) : '';
          // this.rowData[Index].meetingSubTypeDescription = (this.events[Index].meetingSubTypeDescription)
          //   ? this.events[Index].meetingSubTypeDescription
          //   : '';
          // this.rowData[Index].meetingRegion = (this.events[Index].meetingRegion)
          //   ? this.events[Index].meetingRegion
          //   : '';
          // this.rowData[Index].mtgCreationDate = this.events[Index].insertedTimestamp
          //   ? this.datePipe.transform(this.events[Index].insertedTimestamp.split("T")[0], 'dd MMM yyyy')
          //   : '';
          // if (this.events[Index].meetingState === 'DRAFTINVITE') {
          //   this.events[Index].meetingState = 'Draft & Invite';
          // }
        });
      }
    });


    this.gridOptions = <GridOptions>{
      headerHeight: 40,
      rowHeight: 32,
      rowBuffer: 200,
      suppressNoRowsOverlay: false,
      suppressCellSelection: true,
      resizable: true,
      // toolPanelSuppressSideButtons: true,
      onGridReady: function (params) {
        this.gridApi = params.api;
        this.columnApi = params.columnApi;
        this.gridApi.hideOverlay();
        this.gridApi.sizeColumnsToFit();
      },
      suppressMovableColumns: true
    };
    this.columnDefs = [
      {
        headerName: 'State',
        field: 'eventState',
        resizable: true,
        sortable: true,
        width: 130,
        cellStyle: { 'text-align': 'left!important' },
        pinned: 'left'
      },
      {
        headerName: 'Start Date - End Date',
        field: 'eventInterval',
        resizable: true,
        sort: 'desc',
        sortingOrder: ['desc', 'asc', null],
        sortable: true,
        width: 250,
        comparator: dateComparator,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Event Name',
        field: 'eventName',
        resizable: true,
        sortable: true,
        width: 280,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Event Type',
        field: 'eventType',
        resizable: true,
        sortable: true,
        width: 130,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Website Link',
        field: 'website',
        resizable: true,
        sortable: true,
        width: 200,
        cellStyle: { 'text-align': 'left!important' }, cellRenderer: this.tooltipRenderer,
      },
      {
        headerName: 'Location',
        field: 'location',
        resizable: true,
        sortable: true,
        width: 170,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Business Unit',
        field: 'businessUnit',
        resizable: true,
        sortable: true,
        // width: 170,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Creator',
        field: 'eventCreatorName',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      },
      {
        headerName: 'Owner',
        field: 'eventOwnerName',
        resizable: true,
        sortable: true,
        // width: 150,
        cellStyle: { 'text-align': 'left!important' }
      }
      // {
      //   headerName: 'Actions', field: 'MeetingActions', cellRendererFramework: ConfigActionsComponent,
      //   cellStyle: { 'text-align': 'center!important', 'cursor': 'pointer!important' }, width: 120,
      //   headerClass: 'mv2-headerCenterAlign',
      //   pinned: 'right'
      // },
    ];
    // this.gridOptions.getRowStyle = function (params) {
    //   if (params.data.meetingState.toUpperCase() === 'Cancelled') {
    //     return {
    //       background: '#eeeff0!important'
    //     };
    //   }
    // };
    this.gridOptions.rowSelection = 'single';
    this.overlayNoRowsTemplate =
      '<div style=\"font-size: 18px;color: #747c89;\">No meetings to display.<br> Use the search filters above to see results.</div>';
  }
  // styleMeetingState(params) {
  //   if (params.value === 'Draft' || params.value === 'Confirmed' || params.value === 'Draft & Invite') {
  //     return {
  //       'text-align': 'left!important',
  //       'font-size': '13px',
  //       'font-family': 'Neuzeit Grotesk Regular!important',
    
  //     };
  //   } else if (params.value === 'Cancelled') {
  //     return {
  //       color: '#414956',
  //       'text-align': 'left!important',
  //       'font-size': '13px',
  //       'font-family': 'Neuzeit Grotesk Regular!important',
    
  //     };
  //   }
  // }

  // eventStateRenderer(params) {
  //   if (params.value === 'Draft' || params.value === 'Draft & Invite') {
  //     return '<span class="draftIdentifier">' + params.value + '</span>';
  //   } else if (params.value === 'Confirmed') {
  //     return '<span class="confirmIdentifier">' + params.value + '</span>';
  //   } else if (params.value === 'Cancelled') {
  //     return '<span class="cancelIdentifier">' + params.value + '</span>';
  //   }
  // }
  tooltipRenderer = function (params) {
    if (params.value === null) {
      return undefined;
    } else {
      return '<span title="' + params.value + '">' + params.value + '</span>';
    }
  };

  rowDoubleClicked(params) {
    // this.commonService.updateMtgDtlsChange("");
    // this.router.navigate(['/meeting/update', { id: params.data.meetingId, type: params.data.meetingType, source: true }], { skipLocationChange: true });
    // if (params.data.meetingType !== 'Company - FI') {
    // this.commonService.getMtgDetailsForMtgId(params.data.meetingId, params.data.meetingType).subscribe((response) => {
      // if (response.statusCode === 200) {
        this.commonService.setMeetingType('Conference');
        this.router.navigate(['/conference/update', {eventId: params.data.eventId} ], { skipLocationChange: true });
        // this.commonService.updateMtgDtlsChange(response.body);
    //   } else {
    //     console.log('No Response', response.errorMessage);
    //   }
    // });
    // }
  }

  getMeetngDateInLocalTime(eventDate): Object {
    // const splitMeetingTimeInGMT = (meetingData.meetingTimeInGMT) ? meetingData.meetingTimeInGMT.match(/.{1,2}/g) : '';
    // time conversion into user's Region
    return moment(eventDate).format('DD MMM YYYY');
    // let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
    // let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    // return {
    //   'date': moment(localTime.substring(0, 10)).format('DD MMM YYYY'),
    //   'time': localTime.substring(11, 13) + ':' + localTime.substring(14, 16)
    // }
  }
}
