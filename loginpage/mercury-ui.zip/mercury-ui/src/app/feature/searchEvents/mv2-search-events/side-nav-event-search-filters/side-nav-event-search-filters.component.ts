import { Component, OnInit, NgZone, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { Observable, Subscription, Observer, EMPTY } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { LOCATIONS, MEETINGSTATE } from 'src/app/shared/app-constant/meeting.constants';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';

@Component({
  selector: 'mv2-side-nav-event-search-filters',
  templateUrl: './side-nav-event-search-filters.component.html',
  styleUrls: ['./side-nav-event-search-filters.component.css']
})
export class SideNavEventSearchFiltersComponent implements OnInit, OnChanges {
  sidePaneSearchPanelForm = this.fb.group({
    meetingRegion: [[]],
    countryCode: [[]],
    meetingCreatorName: [''],
    meetingCreator: [''],
    meetingOwner: [''],
    meetingOwnerCorporateId: [''],
    tseIdentifier: [''],
    bloombergTicker: [''],
    locationType: [''],
    position: [''],
    meetingState: ['']
  });
  utilDataObservable: Observable<any>;
  regions = [];
  countries = [];
  meetingLocations = LOCATIONS;
  peopleDataSource: Observable<any>;
  isValidCreator = false;
  isValidOwner = false;
  peopleDataSubscription: Subscription;
  errorResponse = false;
  typeaheadLoading: boolean;
  ownerTypeaheadLoading: boolean;
  ownerErrorResponse = false;
  public meetingState = MEETINGSTATE;
  @Input() searchForm;
  @Input() searchFlag;
  @Output() formEmit = new EventEmitter<any>();
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);

  constructor(private commonService: CommonService, private ngZone: NgZone, private fb: FormBuilder) { }

  ngOnInit() {
    this.peopleDataSource = EMPTY;
    this.fetchUtilData();
    this.formEmit.emit(this.sidePaneSearchPanelForm);
  }

  ngOnChanges() {
    if (this.searchForm.get('sidePaneSearchPanelForm') && this.searchFlag === true) {
      this.sidePaneSearchPanelForm = this.searchForm.get('sidePaneSearchPanelForm');
    }
    if (this.searchForm.get('searchPanelForm')
      && (this.searchForm.get('searchPanelForm').get('meetingType').value === 'Broker'
      || this.searchForm.get('searchPanelForm').get('meetingType').value === 'All Meetings'
        || this.searchForm.get('searchPanelForm').get('meetingType').value === 'Other')) {
          this.sidePaneSearchPanelForm.patchValue({
            'tseIdentifier': '',
            'bloombergTicker': ''
          })
      this.sidePaneSearchPanelForm.get('tseIdentifier').disable();
      this.sidePaneSearchPanelForm.get('bloombergTicker').disable();
    } else {
      this.sidePaneSearchPanelForm.get('tseIdentifier').enable();
      this.sidePaneSearchPanelForm.get('bloombergTicker').enable();
    }
  }

  getPeopleData(formControlName: string): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.sidePaneSearchPanelForm.get(formControlName).value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    if (formControlName === 'meetingCreatorName') {
      this.isValidCreator = false;
      this.errorResponse = typeaheadData.isResponseError;
    }
    if (formControlName === 'meetingOwner') {
      this.isValidOwner = false;
      this.ownerErrorResponse = typeaheadData.isResponseError;
    }
  }

  changeTypeaheadLoading(e: boolean, formControlName: string): void {
    if (formControlName === 'meetingCreatorName') {
      this.typeaheadLoading = e;
    } else if (formControlName === 'meetingOwner') {
      this.ownerTypeaheadLoading = e;
    }
  }

  typeaheadOnSelect(event, formControlName: string) {
    const selectedName = convertToTitleCase(event.item.name);
    if (formControlName === 'meetingCreatorName') {
      this.isValidCreator = true;
      this.sidePaneSearchPanelForm.patchValue({
        meetingCreatorName: selectedName,
        meetingCreator: event.item.corporateId
      });
    }
    if (formControlName === 'meetingOwner') {
      this.isValidOwner = true;
      this.sidePaneSearchPanelForm.patchValue({
        meetingOwner: selectedName,
        meetingOwnerCorporateId: event.item.corporateId
      });
    }
  }

  typeaheadNoResults(event: boolean, filterType: string): void {
    if (filterType === 'meetingCreatorName') {
      this.errorResponse = event;
    }
    if (filterType === 'meetingOwner') {
      this.ownerErrorResponse = event;
    }
  }
  onBlurMethod() {
    if (!this.isValidCreator) {
      this.typeaheadLoading = false;
      this.sidePaneSearchPanelForm.patchValue({
        meetingCreatorName: '',
        meetingCreator: ''
      });
      this.getPeopleData('meetingCreatorName');
    }
    if (!this.isValidOwner) {
      this.ownerTypeaheadLoading = false;
      this.sidePaneSearchPanelForm.patchValue({
        meetingOwner: '',
        meetingOwnerCorporateId: ''
      });
      this.getPeopleData('meetingOwner');
    }
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        const utilData = message;
        this.regions = utilData.filter(element => element.UtilKeyName === 'regions');
        this.countries = utilData.filter(element => element.UtilKeyName === 'countries');
        for (const item of this.countries) {
          item['KeyDesc'] = convertToTitleCase(item['KeyDesc']);
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }
}
