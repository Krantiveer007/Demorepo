import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, NgZone } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { EVENTTYPE, EVENTSTATE } from 'src/app/shared/app-constant/meeting.constants';
import { Observable, Observer, EMPTY } from 'rxjs';
import { Security } from 'src/app/shared/models/security.model';
import { Subscription } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
declare var jquery: any;
declare var $: any;
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { filterSecuritydata, filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';


@Component({
  selector: 'mv2-event-search-panel',
  templateUrl: './mv2-event-search-panel.component.html',
  styleUrls: ['./mv2-event-search-panel.component.css'],
})
export class Mv2EventSearchPanelComponent implements OnInit {
  currentDate = new Date();
  searchPanelForm = this.fb.group({
    dateRange: [
      [this.currentDate, new Date()]
    ],
    insertedTimestamp: ['', MeetingFieldValidations.InvalidDateValidator],
    eventType: ['All Events'],
    eventStatus: ['All States'],
    businessUnit: [[]],
    countryCode: [[]],
    eventCreator: [''],
    eventOwner: [''],
    eventCreatorName: [''],
    eventOwnerName: [''],
    eventName: [''],
    relativeDate: ['']
  });
  isValidSecurity = false;
  toggleFiltersText = 'MORE FILTERS';
  countries = [];
  isValidCreator = false;
  isValidOwner = false;
  ownerErrorResponse = false;
  showMoreFilters = false;
  eventTypes = EVENTTYPE;
  eventStates = EVENTSTATE;
  selectedMeetingType = 'All Meetings';
  isMtgSubTypeDisabled = false;
  securitiesDataSource: Observable<any>;
  debtTickerDataSource: Observable<any>;
  brokerFirmDataSource: Observable<any>;
  peopleDataSource: Observable<any>;
  businessUnitSource = [];
  meetingSubtypeDescription = [];
  ownerTypeaheadLoading: boolean;

  // securitySubscription: Subscription;
  errorResponse = false;
  selectedParameter: string;
  typeaheadLoading: boolean;
  fromDate: Date = new Date();
  // createdFromDate: Date = new Date();
  toDate: Date = new Date();
  toDateErrorResponse = false;
  utilDataObservable: Observable<any>;
  securityResponse = [];
  isValidHost = false;
  isValidAttendee = false;
  peopleDataSubscription: Subscription;
  hostErrorResponse = false;
  peopleData: any[] = [];
  hostTypeaheadLoading: boolean;
  attendeeTypeaheadLoading: boolean;
  debtTickerTypeaheadLoading: boolean;
  brokerFirmTypeaheadLoading: boolean;
  attendeeErrorResponse = false;
  creatorSelected = '';
  creatorSelectedId = '';
  ownerSelected = '';
  ownerSelectedId = '';
  businessEntity = ['Equity', 'Fixed Income'];
  securitySubscription: Subscription;
  searchNameType = 'Company';
  placeholderForCompanySearch = 'Filter By company';
  isValidDebtTicker = false;
  isValidBrokerFirm = false;
  debtTickerErrorResponse = false;
  brokerFirmErrorResponse = false;
  userDefaultBU = '';
  relatives = [
    { key: "Custom Date", desc: "0" },
    { key: "Next 90 Days", desc: "+90" },
    { key: "Next 30 Days", desc: "+30" },
    { key: "Next 7 Days", desc: "+7" },
    { key: "Tomorrow", desc: "+1" },
    { key: "Today", desc: "+0" },
    { key: "Yesterday", desc: "-1" },
    { key: "Last 7 Days", desc: "-7" },
    { key: "Last 30 Days", desc: "-30" },
    { key: "Last 90 Days", desc: "-90" }
  ]
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);

  @Output() formEmit = new EventEmitter<any>();
  @Output() resetFlagEmitter = new EventEmitter<boolean>(false);
  @Output() searchMeeting = new EventEmitter<boolean>(false);
  @Output() showSideFilters = new EventEmitter<boolean>(false);

  constructor(private commonService: CommonService, private ngZone: NgZone, private fb: FormBuilder, private datePipe: DatePipe) { }

  ngOnInit() {
    this.userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
    if (this.userDefaultBU) {
      this.searchPanelForm.patchValue({
        'businessUnit': [this.userDefaultBU]
      });
    }
    let endDate = new Date();
    endDate.setDate(this.currentDate.getDate() + 365);
    this.searchPanelForm.patchValue({
      'dateRange': [
        this.currentDate,
        endDate
      ]
    });

    this.searchPanelForm.patchValue({
      'relativeDate': this.relatives[0].desc
    });
    this.formEmit.emit(this.searchPanelForm);
    $(() => {
      const dateFormat = 'mm/dd/yy',
        createdFrom = $('#createdFrom')
          .datepicker({
            numberOfMonths: 2,
            showButtonPanel: false,
            dateFormat: 'dd/mm/yy'
          })
          .on('change', () => {
            if ($('#createdFrom').val() === '') {
              //     $('#createdFrom').datepicker('setDate', this.createdFromDate);
            }
            this.ngZone.run(() => {
              this.searchPanelForm.patchValue({
                insertedTimestamp: $('#createdFrom').val()
              });
            });
          });
    });
    this.fetchUtilData();
  }

  typeaheadNoResults(event: boolean, filterType: string): void {
    if (filterType === 'eventCreatorName') {
      this.errorResponse = event;
    }
    if (filterType === 'eventOwnerName') {
      this.ownerErrorResponse = event;
    }
  }

  changeTypeaheadLoading(e: boolean, formControlName: string): void {
    if (formControlName === 'eventCreatorName') {
      this.typeaheadLoading = e;
    } else if (formControlName === 'eventOwnerName') {
      this.ownerTypeaheadLoading = e;
    }
  }

  selectRelativeDate(relativeDate) {
    console.log(relativeDate.desc.substring(1) + ' ' + relativeDate.desc.substring(0, 1));
    let endDate = new Date();
    if (relativeDate.desc.substring(0, 1) === '-') {
      endDate.setDate(this.currentDate.getDate() - +relativeDate.desc.substring(1));
      this.searchPanelForm.patchValue({
        'dateRange': [
          endDate,
          this.currentDate
        ]
      });
    } else if (relativeDate.desc.substring(0, 1) === '+') {
      endDate.setDate(this.currentDate.getDate() + +relativeDate.desc.substring(1));
      this.searchPanelForm.patchValue({
        'dateRange': [
          this.currentDate,
          endDate

        ]
      });
    } else {
      this.searchPanelForm.patchValue({
        'dateRange': [
          endDate,
          this.currentDate
        ]
      });
    }
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        const utilData = message;
        this.businessUnitSource = utilData.filter(element => element.UtilKeyName === 'businessUnits');
        this.countries = utilData.filter(element => element.UtilKeyName === 'countries');
        for (const item of this.countries) {
          item['KeyDesc'] = convertToTitleCase(item['KeyDesc']);
        }
        this.commonService.setUtilCountries(this.countries);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  getPeopleData(formControlName: string): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.searchPanelForm.get(formControlName).value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    if (formControlName === 'eventCreatorName') {
      this.isValidCreator = false;
      this.errorResponse = typeaheadData.isResponseError;
    }
    if (formControlName === 'eventOwnerName') {
      this.isValidOwner = false;
      this.ownerErrorResponse = typeaheadData.isResponseError;
    }
  }

  typeaheadOnSelect(event, formControlName: string) {
    const selectedName = convertToTitleCase(event.item.name);
    if (formControlName === 'eventCreatorName') {
      this.isValidCreator = true;
      this.searchPanelForm.patchValue({
        eventCreatorName: selectedName,
        eventCreator: event.item.corporateId
      });
    }
    if (formControlName === 'eventOwnerName') {
      this.isValidOwner = true;
      this.searchPanelForm.patchValue({
        eventOwnerName: selectedName,
        eventOwner: event.item.corporateId
      });
    }
  }

  searchMeetings() {
    this.searchMeeting.emit(true);
  }

  resetFilters() {
    this.isMtgSubTypeDisabled = false;
    this.resetFlagEmitter.emit(true);
    this.commonService.resetSearchFilters.next(true);
  }

  resetDate() {
    const resetFilterFlag = this.commonService.resetSearchFiltersObservable;
    resetFilterFlag.subscribe((response) => {
      if (response) {

      }
    },
      (error) => {
        console.log('Error resetting filters');
      });
  }

  onBlurMethod() {
    if (!this.isValidCreator) {
      this.typeaheadLoading = false;
      this.searchPanelForm.patchValue({
        eventCreatorName: '',
        eventCreator: ''
      });
      this.getPeopleData('eventCreatorName');
    }
    if (!this.isValidOwner) {
      this.ownerTypeaheadLoading = false;
      this.searchPanelForm.patchValue({
        eventOwnerName: '',
        eventOwner: ''
      });
      this.getPeopleData('eventOwnerName');
    }
  }

  disableSearchButton() {
    return false;
  }

}
