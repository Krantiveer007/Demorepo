import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { Mv2SearchMeetingComponent } from './mv2-search-meeting.component';
import { CommonService } from 'src/app/core/http/common.service';
import { UrlHandlerService } from 'src/app/shared/services/url-handler.service';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule, BsModalService, ModalBackdropComponent } from 'ngx-bootstrap';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, FormBuilder } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { DatePipe } from '@angular/common';

import { of, throwError } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ConfigMultiselectComponent } from 'src/app/shared/components/config-multiselect/config-multiselect.component';
import { MultiSelectModule } from '@syncfusion/ej2-angular-dropdowns';
import { Mv2SearchPanelComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-panel/mv2-search-panel.component';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
describe('Mv2SearchMeetingComponent', () => {
  let component: Mv2SearchMeetingComponent;
  let fixture: ComponentFixture<Mv2SearchMeetingComponent>;
  let fb: FormBuilder;
  const searchMeetingsData = [
    {
      businessUnit: '',
      dialIn: 'Y',
      dialInAccessCode: '3533',
      dialInNumber: '8739',
      hostCorporateId: 'A535076',
      insertedBy: 'A535076',
      insertedTimestamp: '2019-05-02T11:36:07.000Z',
      internalLocationRoom: 'CORONA',
      locationType: 'Internal',
      meetingCreator: 'A98999',
      meetingDate: '2019-04-30T11:36:07.680Z',
      meetingDuration: 60,
      meetingId: '2019-05-02T11:36:07.000Z-f7576eff-a32b-457e-8ad9-73ef08950da2',
      meetingInitiatorCode: 'COMP',
      meetingInitiatorDescription: 'Company',
      meetingState: 'DRAFT',
      meetingSubTypeCode: 'GEN',
      meetingSubTypeDescription: 'General',
      meetingTime: '30 Apr 2019 0630',
      meetingTimeInGMT: '0630',
      meetingTimezone: 'GMT+5.5',
      meetingType: 'Company',
      securityTradableEntityId: 487954121,
      emailSubject: 'VODAFONE PLC LTD.-Company-Amit Pandey'
    },
    {
      businessUnit: '',
      dialIn: 'Y',
      dialInAccessCode: '3533',
      dialInNumber: '8739',
      hostCorporateId: 'A535076',
      insertedBy: 'A535076',
      insertedTimestamp: '2019-05-02T11:36:12.000Z',
      internalLocationRoom: 'CORONA',
      locationType: 'Internal',
      meetingCreator: 'A98999',
      meetingDate: '2019-04-30T11:36:12.844Z',
      meetingDuration: 60,
      meetingId: '2019-05-02T11:36:12.000Z-733941ec-5f78-47e9-8e65-4b3134d80f77',
      meetingInitiatorCode: 'COMP',
      meetingInitiatorDescription: 'Company',
      meetingState: 'DRAFT',
      meetingSubTypeCode: 'GEN',
      meetingSubTypeDescription: 'General',
      meetingTime: '30 Apr 2019 0630',
      meetingTimeInGMT: '0630',
      meetingTimezone: 'GMT+5.5',
      meetingType: 'Company',
      securityTradableEntityId: 487954121,
      emailSubject: 'VODAFONE PLC LTD.-Company-Amit Pandey'
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        HttpClientModule,
        RouterTestingModule,
        CommonModule,
        BrowserModule,
        NgSelectModule,
        AgGridModule.withComponents([]),
        MultiSelectModule
      ],
      declarations: [Mv2SearchMeetingComponent,
      Mv2SearchPanelComponent,
      Mv2MeetingListComponent,
      SideNavSearchFiltersComponent,
      ConfigMultiselectComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, BsModalService, DatePipe],schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      // .overrideModule(BrowserDynamicTestingModule, {
      //   set: {
      //     entryComponents: [ModalBackdropComponent ],
      //   }
      // })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2SearchMeetingComponent);
    component = fixture.componentInstance;
    fb = new FormBuilder();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open side panel for more filters if click on more filters button', () => {
    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'sidePanelObservable').and.returnValue(of(true));
    fixture.detectChanges();
    expect(component.modalRef).not.toBeNull;
  });

  it('should be able to search meetings', () => {
    const searchPanelForm = fb.group({
      meetingType: 'Company',
      securityName: 'Zara',
      securityTradableEntityId: '123456',
      fromDate: '07/04/2019',
      toDate: '07/06/2019',
      hostname: 'Sharma, Kanika',
      hostCorporateId: 'A608245',
      attendee: 'Sehrawat, Krantiveer',
      employeeId: 'A595905',
      businessUnit: ['EQ-AUS']
    });
    const sidePaneSearchPanelForm = fb.group({
      meetingRegion: ['APxJ'],
      countryCode: ['AUS'],
      meetingCreatorName: 'Sharma, Kanika',
      meetingCreator: 'A608245',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: 'ABC'
    });

    component.searchForm.setControl('searchPanelForm', searchPanelForm);
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm);
    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'searchMeetingsObservable').and.returnValue(of(true));
    const searchSpy = spyOn(commonService, 'getMeetings').and.returnValue(of(searchMeetingsData));
    component.fetchMeetingData();
    fixture.detectChanges();
    // expect(commonService.searchMeetingsData.getValue()).toEqual(searchMeetingsData);
    expect(commonService.searchMeetings.getValue()).toEqual(false);
    // component.serachMeetingData.subscribe((resposne) => {
    //   expect(commonService.searchMeetingsData.getValue()).toEqual(searchMeetingsData)
    // })

  });

  it('should be able to reset filter criteria', () => {
    const searchPanelForm1 = fb.group({
      meetingType: 'Company',
      securityName: 'Zara',
      securityTradableEntityId: '123456',
      fromDate: '07/04/2019',
      toDate: '07/06/2019',
      hostname: 'Sharma, Kanika',
      hostCorporateId: 'A608245',
      attendee: 'Sehrawat, Krantiveer',
      employeeId: 'A595905',
      businessUnit: ['EQ-AUS']
    });

    const sidePaneSearchPanelForm1 = fb.group({
      meetingRegion: ['APxJ'],
      countryCode: ['AUS'],
      meetingCreatorName: 'Sharma, Kanika',
      meetingCreator: 'A608245',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      bloombergTicker: '123',
      locationType: 'Internal',
      position: 'ABC'
    });

    component.searchForm.setControl('searchPanelForm', searchPanelForm1);
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm1);
    const fromdate = new Date();
    const todate = new Date();
    fromdate.setMonth(fromdate.getMonth() - 1);
    todate.setMonth(todate.getMonth() + 1);
    const datepipe = fixture.debugElement.injector.get(DatePipe);
    const searchPanelForm = fb.group({
      meetingType: ['All Meetings'],
     // securityName: [''],
      securityTradableEntityId: [''],
      fromDate: [datepipe.transform(fromdate, 'dd/MM/yyyy')],
      toDate: [datepipe.transform(todate, 'dd/MM/yyyy')],
      hostname: [''],
      hostCorporateId: [''],
      attendee: [''],
      employeeId: [''],
      businessUnit: [[]]
    });

    const sidePaneSearchPanelForm = fb.group({
      meetingRegion: [[]],
      countryCode: [[]],
      meetingCreatorName: [''],
      meetingCreator: [''],
      meetingOwner: [''],
      meetingOwnerCorporateId: [''],
      bloombergTicker: [''],
      locationType: [''],
      position: ['']
    });

    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'resetSearchFiltersObservable').and.returnValue(of(true));
    commonService.resetSearchFilters.next(true);
    component.resetFilters();
    fixture.detectChanges();
    expect(component.searchForm.get('searchPanelForm').value).toEqual(searchPanelForm.value);
    expect(component.searchForm.get('sidePaneSearchPanelForm').value).toEqual(sidePaneSearchPanelForm.value);
    expect(commonService.resetSearchFilters.getValue()).toEqual(false);
  //  expect(commonService.searchMeetings.getValue()).toEqual(true);
    // expect(component.searchForm.controls.searchPanelForm.controls.securityName.disabled).toEqual(true);
  });

  // fit('should hide side panel of more filters if click on Search button of more filters panel', () => {
  //   const commonService = fixture.debugElement.injector.get(CommonService);
  //   const spy = spyOn(commonService, 'sidePanelObservable').and.returnValue(of(true));
  //   fixture.detectChanges();
  //   expect(component.modalRef).not.toBeNull;
  //   component.searchMeetings();
  //    fixture.detectChanges();
  //  expect(component.modalRef).toBeNull;
  // //  expect(component.searchFlag).toEqual(true)
  // });


  // ---------------------------------------------------------------------------check
  xit('should reset updated filters on more filters panel if click on cancel button of more filters panel', () => {
    const sidePaneSearchPanelForm1 = fb.group({
      meetingRegion: ['APxJ'],
      countryCode: ['AUS'],
      meetingCreatorName: 'Sharma, Kanika',
      meetingCreator: 'A608245',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: 'ABC'
    });
    const previousSidePaneSearchPanelForm1 = fb.group({
      meetingRegion: [],
      countryCode: [],
      meetingCreatorName: '',
      meetingCreator: '',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: ''
    });
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm1);
    component.previousSidePanelSearchForm = previousSidePaneSearchPanelForm1;
    const commonService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(commonService, 'sidePanelObservable').and.returnValue(of(true));
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.modalRef).toBeNull();
    // component.cancelSearch();
    fixture.detectChanges();
    //  expect(component.searchForm.get('sidePaneSearchPanelForm').value).toEqual(component.previousSidePanelSearchForm.value);
    //   expect(component.modalRef).not.toBeNull;
    //   component.searchMeetings();
    //    fixture.detectChanges();
    //  expect(component.modalRef).toBeNull;
    //  expect(component.searchFlag).toEqual(true)
  });
  // ------------------------------------------------------------------------------------------------------
  it('should reset updated filters on more filters panel', () => {
    const sidePaneSearchPanelForm1 = fb.group({
      meetingRegion: ['APxJ'],
      countryCode: ['AUS'],
      meetingCreatorName: 'Sharma, Kanika',
      meetingCreator: 'A608245',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: 'ABC'
    });
    const previousSidePaneSearchPanelForm1 = fb.group({
      meetingRegion: [],
      countryCode: [],
      meetingCreatorName: '',
      meetingCreator: '',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: ''
    });
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm1);
    component.previousSidePanelSearchForm = previousSidePaneSearchPanelForm1;
    component.updateSidePanelSearchToPreviousValues();
    fixture.detectChanges();
    expect(component.searchForm.get('sidePaneSearchPanelForm').value).toEqual(component.previousSidePanelSearchForm.value);
  });

  it('should reset updated filters on more filters panel for backdrop click on side search panel', () => {
    const sidePaneSearchPanelForm1 = fb.group({
      meetingRegion: ['APxJ'],
      countryCode: ['AUS'],
      meetingCreatorName: 'Sharma, Kanika',
      meetingCreator: 'A608245',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: 'ABC'
    });
    const previousSidePaneSearchPanelForm1 = fb.group({
      meetingRegion: [],
      countryCode: [],
      meetingCreatorName: '',
      meetingCreator: '',
      meetingOwner: 'Sehrawat, Krantiveer',
      meetingOwnerCorporateId: 'A595905',
      tickerBloomBergCode: '123',
      locationType: 'Internal',
      position: ''
    });
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm1);
    component.previousSidePanelSearchForm = previousSidePaneSearchPanelForm1;
    component.checkForBackDropClick('backdrop-click');
    fixture.detectChanges();
    expect(component.searchForm.get('sidePaneSearchPanelForm').value).toEqual(component.previousSidePanelSearchForm.value);
  });

  it('should be able to create query string for search meeting according to filter criteria ', () => {
    const searchPanelForm1 = fb.group({
      meetingType: ['Company'],
      securityName: ['Zara'],
      securityTradableEntityId: ['123456'],
      fromDate: ['07/04/2019'],
      toDate: ['07/06/2019'],
      hostname: ['Sharma, Kanika'],
      hostCorporateId: ['A608245'],
      attendee: ['Sehrawat, Krantiveer'],
      employeeId: ['A595905'],
      businessUnit: [['EQ-AUS', 'EQ-EUR']]
    });
    const sidePaneSearchPanelForm1 = fb.group({
      meetingRegion: [['APxJ']],
      countryCode: [['AUS']],
      meetingCreatorName: ['Sharma, Kanika'],
      meetingCreator: ['A608245'],
      meetingOwner: ['Sehrawat, Krantiveer'],
      meetingOwnerCorporateId: ['A595905'],
      tickerBloomBergCode: ['123'],
      locationType: ['Internal'],
      position: ['ABC']
    });
    component.searchForm.setControl('searchPanelForm', searchPanelForm1);
    component.searchForm.setControl('sidePaneSearchPanelForm', sidePaneSearchPanelForm1);
    component.createQueryStringForsearch();
    expect(component.createQueryStringForsearch()).toEqual('meetingType=Company&securityTradableEntityId=123456&fromDate=07/04/2019' +
      '&toDate=07/06/2019&hostCorporateId=A608245&employeeId=A595905&businessUnit=EQ-AUS,EQ-EUR&meetingRegion=APxJ&countryCode=AUS' +
      '&meetingCreator=A608245&meetingOwnerCorporateId=A595905&tickerBloomBergCode=123&locationType=Internal&position=ABC&');
  });

  it('should enable search button if form has no errors', () => {
    component.searchForm.controls['searchPanelForm'].setErrors(null);
    component.searchForm.controls['searchPanelForm'].get('fromDate').setErrors(null);
    component.searchForm.controls['searchPanelForm'].get('toDate').setErrors(null);
    component.disableSearchButton();
    expect(component.disableSearchButton()).toEqual(false);
  });

  it('should disable serach button if form has errors', () => {
    component.searchForm.controls['searchPanelForm'].setErrors(null);
    component.searchForm.controls['searchPanelForm'].get('fromDate').setErrors({ invalidDate: true });
    component.searchForm.controls['searchPanelForm'].get('toDate').setErrors(null);
    component.disableSearchButton();
    expect(component.disableSearchButton()).toEqual(true);
  });
});

