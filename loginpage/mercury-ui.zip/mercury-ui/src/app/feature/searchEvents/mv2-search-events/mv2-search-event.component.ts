import { Component, OnInit, TemplateRef, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { Observable, Observer, EMPTY, combineLatest } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, FormControl, ValidationErrors, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { first, take, distinctUntilChanged } from 'rxjs/operators';
@Component({
  selector: 'mv2-search-event',
  templateUrl: './mv2-search-event.component.html', 
  styleUrls: ['./mv2-search-event.component.css']
})
export class Mv2SearchEventComponent implements OnInit, OnDestroy, AfterViewInit {
  // showSidePanel = false;
  modalRef: BsModalRef;
  searchForm = this.fb.group({});
  currentDate = new Date();
  // sidePaneOpenObservable = new Observable();
  meetingFromdate: Date;
  meetingTodate: Date;
  meetingTypes: string;
  bu = [];
  countries = [];
  regions = [];
  tradableEntityId = '';
  searchFlag = false;
  previousSidePanelSearchForm = this.fb.group({});
  resetFlag = false;
  val = 0;
  // searchMeetingFlag: Observable<any>;

  @ViewChild('template') template: TemplateRef<any>;
  constructor(private commonService: CommonService, private modalService: BsModalService, private fb: FormBuilder, private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.resetFilters();
  }

  ngOnDestroy() {
    // this.commonService.resetSearchFilters.next(true);
    this.commonService.searchMeetings.next(false);
  }


  ngAfterViewInit() {
    this.fetchEvents();
  }
  formSubmit(event: FormControl, formName: string) {
    this.searchForm.setControl(formName, event);
  }

  fetchEvents() {
    const queryString = this.createQueryStringForsearch();
    const serachMeetingData = this.commonService.getEvents(queryString.substr(0, queryString.length - 1));
    serachMeetingData.subscribe((response) => {
      if (response) {
        // if (this.searchForm.get('searchPanelForm').get('meetingType').value === 'All Meetings') {
        let combinedMeetingResult = [];
        if (response['body'] && response['body'].length > 0) {
          response['body'].forEach((element) => {
            combinedMeetingResult.push(element);
          })
        }
        this.commonService.searchEventsData.next(combinedMeetingResult);
        // } else {
        //   this.commonService.searchEventsData.next(response['body']);
        // }
      }
    },
      (error) => { console.log(error); });
  }

  resetFilters() {
    const resetFilterFlag = this.commonService.resetSearchFiltersObservable;
    resetFilterFlag.subscribe((response) => {
      if (response) {
        if (this.searchForm.get('searchPanelForm')) {
          this.searchForm.get('searchPanelForm').patchValue({
            dateRange:
              [this.currentDate, new Date()]
            ,
            insertedTimestamp: '',
            eventType: 'All Events',
            eventStatus: 'All States',
            businessUnit: [],
            countryCode: [],
            eventCreator: '',
            eventOwner: '',
            eventCreatorName: '',
            eventOwnerName: '',
            eventName: '',
            relativeDate: 'Custom Date'
          });
          const userDefaultBU = this.commonService.getLoggedInUserInfo().getDefaultBU();
          if (userDefaultBU) {
            this.searchForm.get('searchPanelForm').patchValue({
              'businessUnit': [userDefaultBU]
            });
          }
          const relatives = [
            { key: "Custom Date", desc: "0" }
          ];

          this.searchForm.get('searchPanelForm').patchValue({
            'relativeDate': relatives[0].desc
          });
          let endDate = new Date();
          endDate.setDate(this.currentDate.getDate() + 365);
          this.searchForm.get('searchPanelForm').patchValue({
            'dateRange': [
              this.currentDate,
              endDate
            ]
          });
        }
        this.commonService.resetSearchFilters.next(false);
        if (this.resetFlag) {
          // this.commonService.searchMeetings.next(true);
          this.fetchEvents();
          this.resetFlag = false;
        }

      }
    },
      (error) => {
        console.log('Error resetting filters');
      });

  }

  resetFilterData() {
    this.resetFlag = true;
    this.commonService.resetSearchFilters.next(true);
  }

  searchMeetings() {
    this.searchFlag = true;
    // this.commonService.searchMeetings.next(true);
    this.fetchEvents();
    this.modalRef.hide();
  }

  cancelSearch() {
    this.updateSidePanelSearchToPreviousValues();
    this.modalRef.hide();
    this.modalRef = null;
  }

  createQueryStringForsearch(): string {
    let queryString = '';
    if (this.searchForm.get('searchPanelForm')) {
      const obj = this.searchForm.get('searchPanelForm').value;
      for (const item in obj) {
        if (this.searchForm.get('searchPanelForm').value[item].length !== 0
          && this.searchForm.get('searchPanelForm').value[item] !== '' && item !== 'eventCreateName' && item !== 'eventOwnerName') {
          if (item === 'dateRange') {
            queryString += 'fromDate=' + this.convertDateToStandardFormat(this.searchForm.get('searchPanelForm').value[item][0]) + '&';
            queryString += 'toDate=' + this.convertDateToStandardFormat(this.searchForm.get('searchPanelForm').value[item][1]) + '&';
          } else if (item === 'businessEntity') {
            queryString += item + '=' + (this.searchForm.get('searchPanelForm').value[item] === 'Equity' ? 'EQ' : 'FI') + '&';
          } else if (item === 'eventType' && this.searchForm.get('searchPanelForm').value[item] === 'All Events') {
            queryString += item + '=' + 'Conference' + '&';
          } else if (item === 'insertedTimestamp') {
            queryString += item + '=' + this.convertDateToStandardFormat1(this.searchForm.get('searchPanelForm').value[item]) + '&';
          } else if (item === 'eventStatus' && this.searchForm.get('searchPanelForm').value[item] === 'All States') {

          } else if (item === 'eventName' && this.searchForm.get('searchPanelForm').value[item]) {
           queryString += 'eventNameLowerCase=' + this.searchForm.get('searchPanelForm').value[item].toLowerCase() + '&';
        }    else {
            queryString += item + '=' + this.searchForm.get('searchPanelForm').value[item] + '&';
          }
        }
      }
    }
    return queryString;
  }

  convertDateToStandardFormat(date: Date): string {
    return moment(date).format('YYYY-MM-DD');
  }

  convertDateToStandardFormat1(date: string): string {
    let dateArray = date.split('/');
    let newDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
    return newDate;
  }

  checkForBackDropClick(reason: string) {
    if (reason === 'backdrop-click') {
      this.updateSidePanelSearchToPreviousValues();
    }
  }

  updateSidePanelSearchToPreviousValues() {
    if (this.searchForm.get('sidePaneSearchPanelForm') && this.previousSidePanelSearchForm) {
      const sidePaneValue = this.searchForm.get('sidePaneSearchPanelForm').value;
      const previousValue = this.previousSidePanelSearchForm.value;
      for (const key in previousValue) {
        if (sidePaneValue[key] !== previousValue[key]) {
          this.searchForm.get('sidePaneSearchPanelForm').get(key).patchValue(previousValue[key]);
        }
      }
    }
  }

  disableSearchButton() {
    if (this.searchForm.get('searchPanelForm').errors === null
      && this.searchForm.get('searchPanelForm').get('fromDate').errors === null
      && this.searchForm.get('searchPanelForm').get('toDate').errors === null) {
      return false;
    }
    return true;
  }

  showSideFilters(event: boolean) {
    if (event) {
      if (this.modalService.getModalsCount() === 0) {
        this.modalRef = this.modalService.show(this.template);
        this.modalService.onHide.subscribe((reason) => {
          this.checkForBackDropClick(reason);
        });
      }
    }
  }

  resetFormEmit(event: boolean) {
    this.resetFlag = event;
  }

  searchFilterMeeting(event) {
    if (event) {
      this.fetchEvents();
    }
  }

}
