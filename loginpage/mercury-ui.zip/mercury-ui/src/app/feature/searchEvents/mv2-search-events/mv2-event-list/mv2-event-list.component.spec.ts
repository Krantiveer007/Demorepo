import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap';
import { SidenavPanelComponent } from 'src/app/shared/components/sidenav-panel/sidenav-panel.component';
import { DatePipe } from '@angular/common';
import { MeetingManagementComponent } from 'src/app/feature/meeting-management/meeting-management.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Mv2SearchPanelComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-search-panel/mv2-search-panel.component';
import { SideNavSearchFiltersComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/side-nav-search-filters/side-nav-search-filters.component';
import { Mv2MeetingListComponent } from 'src/app/feature/searchEvents/mv2-search-meeting/mv2-meeting-list/mv2-meeting-list.component';

describe('Mv2eVENTListComponent', () => {
  let component: Mv2MeetingListComponent;
  let fixture: ComponentFixture<Mv2MeetingListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        ReactiveFormsModule,
        RouterTestingModule,
        TypeaheadModule.forRoot()],
      declarations: [
        Mv2MeetingListComponent,
        Mv2SearchPanelComponent,
        SidenavPanelComponent,
        SideNavSearchFiltersComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, DatePipe],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2MeetingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
