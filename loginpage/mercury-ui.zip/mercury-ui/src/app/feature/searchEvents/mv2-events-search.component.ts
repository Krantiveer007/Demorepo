import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'mv2-events-search',
  templateUrl: './mv2-events-search.component.html',
  styleUrls: ['./mv2-events-search.component.css']
})
export class Mv2EventsSearchComponent implements OnInit {

  selectedTab = 'meeting';
  utilDataObservable: Observable<any>;
  conferenceFeatureFlag: any;
  isConferenceVisible = false;
  utilData: any[];

  constructor(private router: Router, private commonService: CommonService) { }

  ngOnInit() {
    this.fetchUtilData();
    this.router.navigate([`/events/${this.selectedTab}`], { skipLocationChange: true });
  }

  navigateToModule(selectedTab) {
    this.selectedTab = selectedTab;
    this.router.navigate([`/events/${selectedTab}`], { skipLocationChange: true });
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.utilData = message;
        this.conferenceFeatureFlag = this.utilData.filter(element => element.UtilKeyName === 'isInterfaceVisible');
        //this.conferenceFeatureFlag[0].KeyDesc = true;
        this.isConferenceVisible = this.conferenceFeatureFlag[0].KeyDesc;
        this.commonService.setConferenceVisibility(this.conferenceFeatureFlag[0]);
        // console.log('conference: ', this.conferenceFeatureFlag);
        // if (this.conferenceFeatureFlag[0]['KeyDesc']) {
        //   this.selectedTab = 'all';
        // } else {
        //    this.selectedTab = 'meeting';
        // }
      }
    },
      (error) => {
        console.log(error);
        this.conferenceFeatureFlag = {
          "KeyCode": "Conference",
          "KeyDesc": true,
          "UtilKeyName": "isInterfaceVisible"
        };
        this.isConferenceVisible = this.conferenceFeatureFlag[0].KeyDesc;
        this.commonService.setConferenceVisibility(this.conferenceFeatureFlag[0]);
      });
  }
}
