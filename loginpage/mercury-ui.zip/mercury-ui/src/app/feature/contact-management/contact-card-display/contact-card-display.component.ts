import { Component, OnInit, OnChanges, SimpleChanges, ViewChild, OnDestroy } from '@angular/core';
import { Input } from '@angular/core';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CommonService } from 'src/app/core/http/common.service';
import { CompanyContact } from 'src/app/shared/models/companyContact.model';
import { ContactMapper } from 'src/app/shared/models/contactMapper.model';
import { Contact } from 'src/app/shared/models/contact.model';
import { BrokerContact } from 'src/app/shared/models/brokerContact.model';
import { OtherContact } from 'src/app/shared/models/otherContact.model';
import { InternalContact } from 'src/app/shared/models/internalContact.model';
import { LocalLanguage } from 'src/app/shared/models/localLanguage.model';
import { BrokerFirm } from 'src/app/shared/models/brokerFirm.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Observable, Observer, EMPTY, Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'mv2-contact-card-display',
  templateUrl: './contact-card-display.component.html',
  styleUrls: ['./contact-card-display.component.css']
})
export class ContactCardDisplayComponent implements OnInit, OnChanges {
  messageHeading = '';
  modalRef: BsModalRef;
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  firmData = [];
  modalTitle = '';
  isAssitantInfo = false;
  isSuccessModalShown = false;
  successMessageHeading = '';
  imageStatusSuccess = '';
  successConfirmMessage = '';
  confirmActionLabel = '';
  selectedContact = {};
  isModalShown = false;
  selectedContactInstance = {};
  meetingsData = [];
  markInactiveSubscription: Subscription;
  deleteFirmSubscription: Subscription;
  contactMapper: ContactMapper = new ContactMapper('',
    new CompanyContact(new Contact('', '', '', null, '', '', '', null, '', '', null, '', '', '', '', '', '', '', '', null,
      '', null, '', null, '', null, new LocalLanguage('', '', '')), '', '', '', '', ''),
    new BrokerContact(new Contact('', '', '', null, '', '', '', null, '', '', null, '', '', '', '', '', '', '', '', null,
      '', null, '', null, '', null, new LocalLanguage('', '', '')),
      new BrokerFirm('', null, '', '', '', '', '', '', '', '', null, '', null, null)),
    new OtherContact(new Contact('', '', '', null, '', '', '', null, '', '', null, '', '', '', '', '', '', '', '', null,
      '', null, '', null, '', null, new LocalLanguage('', '', '')), '', ''));
  // @Input() contactData: any;
  imageStatus = '';
  confirmMessage = '';
  brokerFirm: BrokerFirm = new BrokerFirm('', null, '', '', '', '', '', '', '', '', null, '', null, null);
  internalContact = new InternalContact('', '', '', '', '', '', '', '', 0, '', '');
  @Input('contactData') contactData: any;
  @ViewChild('contactModal') contactModal: ModalDirective;
  @ViewChild('successModal') successModal: ModalDirective;
  @ViewChild('popTemplate') popTemplate: TemplateRef<any>;



  hideTemplateFlag = true;
  firmDataResult = [];
  constructor(private modalService: BsModalService, private commonService: CommonService, private router: Router) { }

  ngOnChanges(changes: any) {
    ///console.log("changes", changes)
    // this.firmDataResult = changes['firmData'].currentValue;
    
  }

  ngOnInit() { }

  ngOnDestroy() {
    if (this.markInactiveSubscription) {
      this.markInactiveSubscription.unsubscribe();
    }
    if (this.deleteFirmSubscription) {
      this.deleteFirmSubscription.unsubscribe();
    }
  }

  checkForNewAttendeeEntry(templateNested: TemplateRef<any>) {
    this.modalRef.hide();
  }
  contactInformation(template: TemplateRef<any>, selectedContact) {
    this.meetingsData = [];
    this.selectedContactInstance = selectedContact;    
    this.modalTitle = 'Contact Information';
    this.modalRef = this.modalService.show(template, this.config);
    this.hideTemplateFlag = true;
    this.commonService.getExternalContactMtgs(selectedContact.externalId).subscribe((response) => {
      if (response['body'].length > 0) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        response['body'].forEach(element => {
          let meetingInfoObj: any = {};
          meetingInfoObj.hostName = convertToTitleCase(element.hostDisplayName);
          const newDate = new Date(element.meetingDate);
          meetingInfoObj.date = newDate.getDate().toString();
          meetingInfoObj.month = months[newDate.getMonth()];
          if (element.meetingDuration >= 60) {
            meetingInfoObj.duration = this.durationConvert(element.meetingDuration) + ' Hrs';
          } else {
            meetingInfoObj.duration = element.meetingDuration + ' Min';
          }
          meetingInfoObj.subjectLine = convertToTitleCase(element.emailSubject);
          this.meetingsData.push(meetingInfoObj);
        });
      } else {
        this.meetingsData = [];
      }
    },
      (error) => {
        this.meetingsData = [];
      })
  }
  private durationConvert(mins) {
    var hours = (mins / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return rhours + (rminutes ? "." + rminutes : '');
  }

  markContactAsInactive(contact) {
    // console.log(this.popTemplate)
    // console.log(this.popTemplate.elementRef)
    // this.popTemplate.elementRef.hide();
    this.hideTemplateFlag = true;
    this.messageHeading = 'Mark Inactive';
    this.confirmActionLabel = 'Yes, Mark Inactive';
    this.imageStatus = 'alert';
    this.selectedContact = contact;

    this.confirmMessage = 'Are you sure you want to mark the contact as inactive';
    this.isModalShown = true;
  }

  deleteContact(contact) {
    this.hideTemplateFlag = true;
    if (contact.firmName) {
      this.messageHeading = 'Delete Firm';
      this.confirmActionLabel = 'Yes, Delete';
      this.imageStatus = 'alert';
      this.selectedContact = contact;
      if (contact.brokerGroupFlag === 'Y') {
      this.confirmMessage = `All the broker firms linked to ${contact.firmName} will be unlinked. Are you sure you want to delete the firm`;
      } else {
      this.confirmMessage = 'Are you sure you want to delete the firm';
      }
      this.isModalShown = true;
    }
  }

  onHiddenSuccess() {
    this.successModal.hide();
    this.isSuccessModalShown = false;
  }

  confirmOK() {
    if (this.selectedContact['firmName']) {
      let index = this.contactData.indexOf(this.selectedContact);
      if (index > -1) {
        this.contactData.splice(index, 1);
      }
    }
    this.successModal.hide();
    this.isSuccessModalShown = false;
  }
  onHidden(): void {
    this.contactModal.hide();
    this.isModalShown = false;
  }

  hideModalBox() {
    this.isModalShown = false;
    this.messageHeading = '';
    this.confirmActionLabel = '';
    this.imageStatus = '';
    this.selectedContact = {}
  }

  confirmModal() {

    if (this.messageHeading === 'Mark Inactive') {
      this.markContactAsInactiveInDB();
    } else if (this.messageHeading === 'Delete Firm') {
      this.deleteFirmInDB();
    }
  }

  showTemplate() {
    this.hideTemplateFlag = false;
  }

  markContactAsInactiveInDB() {
    if (this.selectedContact['contactType'] === 'Internal') {
      this.internalContact.updateId = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
      this.internalContact.deleteContactFlag = 'N';
      this.internalContact.extIntFlag = 'Internal';
      this.internalContact.corpId = this.selectedContact['corpId'].toLowerCase();
      this.internalContact.oldVersionNumber = this.selectedContact['versionNo'];
      this.markInactiveSubscription = this.commonService.markInternalContactAsInActive(this.internalContact).subscribe(
        (response) => {
          this.successMessageHeading = 'Contact Marked Inactive';
        this.successConfirmMessage = 'Contact has been marked as Inactive';
        this.imageStatusSuccess = 'success';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.contactModal.hide();
        if (!this.selectedContact['inactiveRecordRequired']) {
          let index = this.contactData.indexOf(this.selectedContact);
          if (index > -1) {
            this.contactData.splice(index, 1);
          }
        }
        console.log('marked inactive');
        },
        (error) => {
          this.successMessageHeading = 'Error';
        this.successConfirmMessage = 'The contact could not be marked as inactive. Please try again';
        this.imageStatusSuccess = 'alert';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.isModalShown = false;
        this.messageHeading = '';
        this.confirmActionLabel = '';
        this.imageStatus = '';
        this.selectedContact = {}
        this.contactModal.hide();
        console.log('error');
        }
        
      );


    } else {
    this.selectedContact['contactStatus'] = 'Inactive';
    this.contactMapper.contactType = this.selectedContact['contactType']
    if (this.selectedContact['contactType'] === 'BC') {
      this.contactMapper.brokerContact.contact.externalId = this.selectedContact['externalId'];
      this.contactMapper.brokerContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
      this.contactMapper.brokerContact.contact.versionNo = this.selectedContact['versionNumber'];
      this.contactMapper.companyContact = null;
      this.contactMapper.otherContact = null;
    } else if (this.selectedContact['contactType'] === 'CC') {
      this.contactMapper.companyContact.contact.externalId = this.selectedContact['externalId'];
      this.contactMapper.companyContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
      this.contactMapper.companyContact.contact.versionNo = this.selectedContact['versionNumber'];
      this.contactMapper.brokerContact = null;
      this.contactMapper.otherContact = null;
    } else if (this.selectedContact['contactType'] === 'OC') {
      this.contactMapper.otherContact.contact.externalId = this.selectedContact['externalId'];
      this.contactMapper.otherContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
      this.contactMapper.otherContact.contact.versionNo = this.selectedContact['versionNumber']
      this.contactMapper.brokerContact = null;
      this.contactMapper.companyContact = null;
    }
    console.log("contact json", this.contactMapper)

    this.markInactiveSubscription = this.commonService.markContactAsInactive(this.contactMapper).subscribe(
      (response) => {
        this.successMessageHeading = 'Contact Marked Inactive';
        this.successConfirmMessage = 'Contact has been marked as Inactive';
        this.imageStatusSuccess = 'success';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.contactModal.hide();
        if (!this.selectedContact['inactiveRecordRequired']) {
          let index = this.contactData.indexOf(this.selectedContact);
          if (index > -1) {
            this.contactData.splice(index, 1);
          }
        }
        console.log('marked inactive');
      }, (error) => {
        this.successMessageHeading = 'Error';
        this.successConfirmMessage = 'The contact could not be marked as inactive. Please try again';
        this.imageStatusSuccess = 'alert';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.isModalShown = false;
        this.messageHeading = '';
        this.confirmActionLabel = '';
        this.imageStatus = '';
        this.selectedContact = {}
        this.contactModal.hide();
        console.log('error')
      });
    }
  }


  deleteFirmInDB() {
    this.brokerFirm.firmId = this.selectedContact['firmId'];
    this.brokerFirm.updateID = this.commonService.getLoggedInUserInfo().getCorporateId();
    this.brokerFirm.versionNumber = this.selectedContact['versionNumber'];
    this.deleteFirmSubscription = this.commonService.deleteBrokerFirm(this.brokerFirm).subscribe(
      (response) => {

        this.successMessageHeading = 'Broker Firm Deleted';
        this.successConfirmMessage = 'Broker Firm has been deleted successfully';
        this.imageStatusSuccess = 'success';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.messageHeading = '';
        this.confirmActionLabel = '';
        this.imageStatus = '';
        this.contactModal.hide();

        console.log("firm deleted")
      }, (error) => {
        this.successMessageHeading = 'Error';
        this.successConfirmMessage = 'The broker firm could not be deleted. Please try again';
        this.imageStatusSuccess = 'alert';
        this.isSuccessModalShown = true;
        this.isModalShown = false;
        this.messageHeading = '';
        this.confirmActionLabel = '';
        this.imageStatus = '';
        this.selectedContact = {}
        this.contactModal.hide();
        console.log('error')
      });
  }


  routeToUpdateScreen(contact: Object) {
    console.log("contact on route screen", contact)
    let contactType = '';
    if (contact['contactType'] === 'BC') {
      contactType = 'Broker';
    } else if (contact['contactType'] === 'CC') {
      contactType = 'Company';
    } else if (contact['contactType'] === 'OC') {
      contactType = 'Other';
    } else if (contact.hasOwnProperty('firmName')) {
      contactType = 'Broker Firm';
      contact['contactType'] = contactType;
    } else if (contact['contactType'] === 'Internal') {
      contactType = 'Internal';
      contact['contactType'] = 'Internal';
    }
    this.router.navigate(['contacts/update', { contactToBeUpdated: JSON.stringify(contact), contactType: contactType}], {skipLocationChange: true});
   }

   brokerGroupInfo(template: TemplateRef<any>, selectedContact) {
     if (selectedContact.brokerGroupFlag === 'Y') {
       this.firmData = [];
        this.selectedContactInstance = selectedContact;
        this.modalTitle = 'Broker Group Information';
        this.modalRef = this.modalService.show(template, this.config);
        this.hideTemplateFlag = true;
        this.commonService.getBrokerFirmsForBrokerGroup(selectedContact.firmId).subscribe((response) => {
        if (response.length > 0) {
          console.log("linked firms", response)
        // const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        response.forEach(element => {         
          element.firmName = convertToTitleCase(element.firmName);
          this.firmData.push(element);
        });
      } else {
        this.firmData = [];
      }
    },
      (error) => {
        this.firmData = [];
      })
     } else {
       //do nothing
     }
   }
}


