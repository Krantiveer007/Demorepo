import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactCardDisplayComponent } from './contact-card-display.component';

describe('ContactCardDisplayComponent', () => {
  let component: ContactCardDisplayComponent;
  let fixture: ComponentFixture<ContactCardDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactCardDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactCardDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
