import { Component, OnInit, NgZone, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { SEARCHTYPE } from 'src/app/shared/app-constant/meeting.constants';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Observable, Subscription, EMPTY } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { filterSecuritydata, filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { Router } from '@angular/router';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
declare var jquery: any;
declare var $: any;
import { DatePipe } from '@angular/common';

@Component({
  selector: 'mv2-contact-management',
  templateUrl: './contact-management.component.html',
  styleUrls: ['./contact-management.component.css']
})
export class ContactManagementComponent implements OnInit, OnDestroy {

  contactSearchPanelForm = this.fb.group({
    searchType: ['All Contacts'],
    firstName: ['', Validators.minLength(1)],
    lastName: ['', Validators.minLength(1)],
    email: ['', [Validators.minLength(1), Validators.email]],
    createdBy: [''],
    createdById: [''],
    createdDate: ['', MeetingFieldValidations.CheckForPastDate],
    inactiveContactsRequired: [false]
  });
  //Include Internal to show in below contacts when backend integration is complete
  contactTypes = ['Broker', 'Broker Firm', 'Company', 'Internal', 'Other']

  firmData = [];

  test = [];

  dateError = '';
  invalidEmail = false;
  // isSubmitDisabled = false;
  placeholderText = 'Search security name...';
  invalidEmailMsg = 'Please enter valid Email, example: jsmith@example.com';
  peopleDataSource: Observable<any>;
  peopleData: any[] = [];
  invalidBrokerFirmId = false;
  peopleDataSubscription: Subscription;
  searchTypeInputForm = '';
  securityTicker = ''
  dataSortingType = 'Asc';
  sortTypes = ['Asc', 'Desc'];
  contactData = [];
  isValidBrokerFirm = false;
  errorResponse = false;
  isValidSecurity = false;
  selectedParameter: string;
  brokerFirmSelectedParameter: string;
  typeaheadLoading: boolean;
  brokerFirmTypeaheadLoading; boolean
  createdByTypeaheadLoading: boolean;
  asyncSelected = '';
  brokerFirmAsyncSelected = '';
  dataSource: Observable<any>;
  brokerFirmDataSource: Observable<any>;
  brokerFirmSubscription: Subscription;
  securitySubscription: Subscription;
  isValidCreator = false;
  contactServiceSubscription: Subscription;
  createdByErrorResponse = false;
  brokerFirmErrorResponse = false;
  brokerFirmResultId = '';
  
  securitySelected: any;
  searchType = SEARCHTYPE;

  constructor(private fb: FormBuilder, private commonService: CommonService, private ngZone: NgZone, private datePipe: DatePipe, private router: Router) { }
  ngOnInit() {
        $(() => {
      const dateFormat = 'mm/dd/yy',
        createdDate = $('#createdDate')
          .datepicker({
            numberOfMonths: 2,
            showButtonPanel: false,
            dateFormat: 'dd/mm/yy'
          })
          .on('change', () => {
            
            this.ngZone.run(() => {
              this.contactSearchPanelForm.patchValue({
                createdDate: $('#createdDate').val()
              });
            });
          })
    });

    if (this.commonService.getSearchContactForm()) {
      let form = this.commonService.getSearchContactForm();
      let contactFormValues = form['value'];
      if (contactFormValues['searchType']) {
        this.selectSearchType(contactFormValues['searchType']);
      }
      for (let key in contactFormValues) {
        if (!this.contactSearchPanelForm.get(key)) {
          this.contactSearchPanelForm.addControl(key, new FormControl(''));
        }
        this.contactSearchPanelForm.get(key).patchValue(contactFormValues[key]);
        if (key === 'brokerFirm' && contactFormValues[key]) {
          this.brokerFirmAsyncSelected = contactFormValues['brokerFirm'];
          this.isValidBrokerFirm = true;
        }
        if (key === 'securityName' && contactFormValues[key]) {
          this.asyncSelected = contactFormValues['securityName'];
          this.isValidSecurity = true;
        }
        if (key === 'createdBy' && contactFormValues[key]) {
          this.isValidCreator = true;
        }
      }
    
      if (this.contactSearchPanelForm.get('searchType').value === 'Company Contact' && this.contactSearchPanelForm.get('securityTicker') && this.contactSearchPanelForm.get('securityTicker').value) {
        this.securitySelected = {
          'instrumentLongName': contactFormValues['securityName'],
          'ticker': contactFormValues['securityTicker']
        }
      } else if (this.contactSearchPanelForm.get('searchType').value === 'Broker Contact' && this.contactSearchPanelForm.get('brokerFirmResultId') && this.contactSearchPanelForm.get('brokerFirmResultId').value) {
        this.securitySelected = {
          'firmName': contactFormValues['brokerFirm'],
          'firmId': contactFormValues['brokerFirmResultId']
        }
      } else if (this.contactSearchPanelForm.get('searchType').value === 'Other Contact' && this.contactSearchPanelForm.get('otherCompany') && this.contactSearchPanelForm.get('otherCompany').value) {
        this.securitySelected = contactFormValues['otherCompany'];
      } else {
        this.securitySelected = '';
      }
      console.log('security passed param', this.securitySelected);
    this.onSubmit();
    } else {

    }
    // configuration for datepicker

   
    // if (this.contactSearchPanelForm.get('searchType').value === 'All Contacts') {
    //   this.contactSearchPanelForm.get('firstName').disable();
    //   this.contactSearchPanelForm.get('lastName').disable();
    //   this.contactSearchPanelForm.get('email').disable();
    //   this.contactSearchPanelForm.get('createdBy').disable();
    //   this.contactSearchPanelForm.get('createdDate').disable();
    // }
  }
  selectSearchType(event) {
    this.securitySelected = '';
    this.contactSearchPanelForm.patchValue({
      firstName: '',
      lastName: '',
      email: '',
      createdBy: '',
      createdById: '',
      createdDate: '',
      securityName: '',
      securityTicker: '',
      brokerFirm: '',
      brokerFirmResultId: '',
      brokerFirmId: '',
      otherCompany: '',
      inactiveContactsRequired: false
    });
    this.selectedParameter = '';
    if (this.contactSearchPanelForm.get('createdDate')) {
      $('#createdDate').datepicker('setDate', this.contactSearchPanelForm.get('createdDate').value);
    }
    this.contactData = [];
    this.removeFormControls(event);
    this.addFormControls(event);

  }
  addFormControls(searchType: string) {
    if (searchType === 'Broker Firm') {
      this.placeholderText = 'Search broker firm...';
      this.contactSearchPanelForm.addControl('brokerFirm', new FormControl(''));
      this.contactSearchPanelForm.addControl('brokerFirmResultId', new FormControl(''));
      this.contactSearchPanelForm.addControl('brokerFirmId', new FormControl(''));
      this.contactSearchPanelForm.get('brokerFirmId').setValidators(Validators.pattern("^[0-9]*$"));
      // this.contactSearchPanelForm.get('brokerFirm').disable();
      // this.contactSearchPanelForm.get('brokerFirmId').disable();
    } else {

      this.contactSearchPanelForm.addControl('firstName', new FormControl('', Validators.minLength(1)));
      this.contactSearchPanelForm.addControl('lastName', new FormControl('', Validators.minLength(1)));
      this.contactSearchPanelForm.patchValue({ 'lastName': '' });
      this.contactSearchPanelForm.addControl('createdBy', new FormControl(''));
      this.contactSearchPanelForm.addControl('createdById', new FormControl(''));
      this.contactSearchPanelForm.get('lastName').enable();
      //   this.contactSearchPanelForm.addControl('createdDate', new FormControl(''));
      //   this.contactSearchPanelForm.get('createdDate').enable();

      // this.contactSearchPanelForm.get('firstName').disable();
      // this.contactSearchPanelForm.get('createdBy').disable();
      // this.contactSearchPanelForm.get('createdDate').disable();
      if (searchType === 'Internal Contact') {
        this.contactSearchPanelForm.addControl('corpId', new FormControl('', Validators.minLength(3)));
        this.contactSearchPanelForm.get('corpId').enable();
        //   this.contactSearchPanelForm.get('lastName').disable();
      } else {
        this.contactSearchPanelForm.addControl('email', new FormControl('', [Validators.minLength(3), Validators.email]));
        //  this.contactSearchPanelForm.get('email').disable();
        this.contactSearchPanelForm.get('lastName').enable();
        if (searchType === 'Broker Contact') {
          this.placeholderText = 'Search broker firm...';
          this.contactSearchPanelForm.addControl('brokerFirm', new FormControl(''));
          this.contactSearchPanelForm.addControl('brokerFirmResultId', new FormControl(''));

          // this.contactSearchPanelForm.get('brokerFirm').disable();
        } else if (searchType === 'Company Contact') {
          this.placeholderText = 'Search security name...';
          this.contactSearchPanelForm.addControl('securityName', new FormControl(''));
          this.contactSearchPanelForm.addControl('securityTicker', new FormControl(''));
          //   this.contactSearchPanelForm.get('securityName').disable();
        } else if (searchType === 'Other Contact') {
          this.placeholderText = 'Search Company name...';
          this.contactSearchPanelForm.addControl('otherCompany', new FormControl('', Validators.minLength(1)));
          // this.contactSearchPanelForm.get('otherCompany').disable();
        } else {
          //  this.contactSearchPanelForm.get('lastName').disable();
        }
      }
    }
  }
  removeFormControls(searchType: string) {
    if (searchType === 'Broker Firm' || searchType === 'Broker Contact') {
      this.contactSearchPanelForm.removeControl('corpId');
      if (searchType === 'Broker Firm') {
        this.contactSearchPanelForm.removeControl('firstName');
        this.contactSearchPanelForm.removeControl('lastName');
        this.contactSearchPanelForm.removeControl('email');
        this.invalidEmail = false;
        this.invalidEmail = false;
        this.contactSearchPanelForm.removeControl('createdBy');
        this.contactSearchPanelForm.removeControl('createdById');
        //    this.contactSearchPanelForm.removeControl('createdDate');
      } else {
        this.contactSearchPanelForm.removeControl('securityName');
        this.contactSearchPanelForm.removeControl('securityTicker');
        this.contactSearchPanelForm.removeControl('otherCompany');
        this.contactSearchPanelForm.removeControl('brokerFirmId');
      }
    } else {
      if (searchType === 'All Contacts' || searchType === 'Company Contact') {
        this.contactSearchPanelForm.removeControl('brokerFirm');
        this.contactSearchPanelForm.removeControl('brokerFirmResultId');

        this.contactSearchPanelForm.removeControl('brokerFirmId');
        this.contactSearchPanelForm.removeControl('otherCompany');
        this.contactSearchPanelForm.removeControl('corpId');
        if (searchType === 'All Contacts') {
          this.contactSearchPanelForm.removeControl('securityName');
          this.contactSearchPanelForm.removeControl('securityTicker');
        }
      } else if (searchType === 'Other Contact' || searchType === 'Internal Contact') {
        this.contactSearchPanelForm.removeControl('brokerFirm');
        this.contactSearchPanelForm.removeControl('brokerFirmResultId');
        this.contactSearchPanelForm.removeControl('brokerFirmId');
        this.contactSearchPanelForm.removeControl('securityName');
        this.contactSearchPanelForm.removeControl('securityTicker');
        //  this.contactSearchPanelForm.removeControl('lastName');
        if (searchType === 'Other Contact') {
          this.contactSearchPanelForm.removeControl('corpId');
        } else {
          this.contactSearchPanelForm.removeControl('email');
          this.invalidEmail = false;
          this.invalidEmailMsg = '';
          this.contactSearchPanelForm.removeControl('otherCompany');
        }
      }
    }
  }
  getSecurities() {
    this.dataSource = EMPTY;
    this.asyncSelected = this.contactSearchPanelForm.get('securityName').value;
    this.isValidSecurity = false;
    this.contactSearchPanelForm.patchValue({

      securityTicker: ''
    });
    if (this.asyncSelected.length >= 3) {
      this.dataSource = new Observable((observer) => {
        if (this.asyncSelected.length >= 3) {
          this.securitySubscription = this.commonService.getSecurities(this.asyncSelected).subscribe((response) => {
            if (response['status'] === 200 && response['data']['status'] !== 404) {
              this.errorResponse = false;
              this.ngZone.run(() => observer.next(filterSecuritydata(response['data'])));
            } else {
              this.errorResponse = true;
              this.selectedParameter = '';
              observer.next([]);
              this.typeaheadLoading = false;
              this.typeaheadNoResults(true, 'Security');
            }
          },
            (error) => {
              if (this.asyncSelected.length >= 3) {
                this.errorResponse = true;
                this.selectedParameter = '';
                observer.next([]);
                this.typeaheadLoading = false;
                this.typeaheadNoResults(true, 'Security');
              }
            });
        }
      });
    } else {
      this.securityTicker = '';
      if (this.dataSource !== EMPTY) {
        this.securitySubscription.unsubscribe();
      }
      this.selectedParameter = '';
    }
  }

  typeaheadOnSelect(event: TypeaheadMatch, formControl): void {

    if (formControl === 'Security') {
      const selectedSecurityInstance = event.item;
      this.selectedParameter = event.item.itemValue;
      this.selectedParameter = this.selectedParameter.split('&lt;').join('<').split('&gt;').join('>');
      this.securityTicker = selectedSecurityInstance.ticker ? selectedSecurityInstance.ticker : '';
      this.asyncSelected = convertToTitleCase(selectedSecurityInstance.instrumentLongName);      
      this.contactSearchPanelForm.patchValue({
        securityName: this.asyncSelected,
        securityTicker: this.securityTicker
      });
      this.securitySelected = event.item;
      // this.isSubmitDisabled = true;
      this.isValidSecurity = true;
    }

    if (formControl === 'createdBy') {
      this.contactSearchPanelForm.patchValue({
        'createdBy': convertToTitleCase(event.item.name),
        'createdById': event.item.corporateId,
      });
      // this.isSubmitDisabled = true;
      this.isValidCreator = true;
    }

    if (formControl === 'BrokerFirm') {
      this.brokerFirmResultId = event.item.firmId;
      this.brokerFirmAsyncSelected = convertToTitleCase(event.item.firmName);
      this.contactSearchPanelForm.patchValue({
        brokerFirm: this.brokerFirmAsyncSelected,
        brokerFirmResultId: this.brokerFirmResultId
      });
      this.securitySelected = event.item;
      // this.isSubmitDisabled = true;
      this.isValidBrokerFirm = true;
    }
  }


  changeTypeaheadLoading(e: boolean, formControl): void {
    if (formControl === 'Security') {
      this.typeaheadLoading = e;
    }
    if (formControl === 'createdBy') {
      this.createdByTypeaheadLoading = e;
    }

    if (formControl === 'BrokerFirm') {
      this.brokerFirmTypeaheadLoading = e;
    }
  }

  typeaheadNoResults(event: boolean, formControl): void {
    if (formControl === 'Security') {
      this.errorResponse = event;
    }
    if (formControl === 'createdBy') {
      this.createdByErrorResponse = event;
    }
    if (formControl === 'BrokerFirm') {
      this.brokerFirmErrorResponse = event;
    }
  }

  onSecurityBlur() {
    if (!this.isValidSecurity) {
      this.contactSearchPanelForm.patchValue({
        securityName: '',
        securityTicker: ''
      });
      this.errorResponse = false;
      if (this.securitySubscription) {
        this.securitySubscription.unsubscribe();
      }
      this.dataSource = EMPTY;
      this.typeaheadLoading = false;
    }
  }

  onBrokerFirmBlr() {
    if (!this.isValidBrokerFirm) {
      this.contactSearchPanelForm.patchValue({
        brokerFirm: '',
        brokerFirmResultId: ''
      });
      this.brokerFirmErrorResponse = false;
      if (this.brokerFirmSubscription) {
        this.brokerFirmSubscription.unsubscribe();
      }
      this.brokerFirmDataSource = EMPTY;
      this.brokerFirmTypeaheadLoading = false;
    }
  }

  onBlurMethod() {
    if (!this.isValidCreator) {
      this.contactSearchPanelForm.patchValue({
        createdBy: '',
        createdById: ''
      });
      this.createdByErrorResponse = false;
    }
  }

  retainContactSearchCriteria() {
    let form = this.fb.group({});
    let searchValues = this.contactSearchPanelForm.value;
    for ( let key in searchValues) {
      form.setControl(key, new FormControl(''));
      form.get(key).patchValue(searchValues[key]);
    }
    this.commonService.setSearchContactForm(form);
    this.onSubmit();
  }

  onSubmit() {
    this.firmData = [];
    this.contactData = [];
    let queryString = '';
    let searchValues = this.contactSearchPanelForm.value;   

        if (this.contactSearchPanelForm.get('searchType').value === 'Broker Firm') {

      if (this.contactSearchPanelForm.get('brokerFirmId').value) {
        queryString += 'brokerFirmId=' + this.contactSearchPanelForm.get('brokerFirmId').value + '&'
      }
      if (this.contactSearchPanelForm.get('brokerFirm').value) {
        queryString += 'brokerFirmId=' + this.contactSearchPanelForm.get('brokerFirmResultId').value + '&'
      }

      this.contactServiceSubscription = this.commonService.getBrokerFirm(queryString.substring(0, queryString.length - 1))
        .subscribe((response) => {
          if (response.length > 0) {
            this.filterFirmdata(response);
            // this.contactInfoData = {
            //               firmDataList: Object.assign([], this.firmData)
            // }

          } else {
            this.firmData = [];
          }
        },
        (error) => {
          console.log('error')
        })
    } else if (this.contactSearchPanelForm.get('searchType').value === 'Internal Contact') {
      for (let key in searchValues) {
        if (key === 'firstName' || key === 'lastName') {
            if (searchValues[key].length > 0) {
              searchValues[key] = searchValues[key].replace('&', '%26');
            }
          }
        if (key === 'createdBy' || key === 'searchType') {
          // do nothing
        } else if (key === 'inactiveContactsRequired') {
          queryString += 'inactiveContactsRequired=' + (searchValues['inactiveContactsRequired'] ? 'Y&' : 'N&')
        } else if (key === 'createdDate' && searchValues[key]) {
          let dateArray = searchValues[key].split('/');
          let date = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0]
          queryString += 'createdDate=' + date + '&'
        } else {
          queryString += key + '=' + encodeURIComponent(searchValues[key]) + '&'
        }
      }

      this.contactServiceSubscription = this.commonService.getInternalContacts(queryString.substring(0, queryString.length - 1))
        .subscribe((response) => {
          if (response.length > 0) {
            this.filterInternalContactData(response);
          } else {
            this.firmData = [];
          }
        },
        (error) => {
          console.log('error')
        })

    } else {
      for (let key in searchValues) {
        if (key === 'firstName' || key === 'lastName' || key === 'email' || key === 'otherCompany') {
            if (searchValues[key].length > 0) {
              searchValues[key] = searchValues[key].replace('&', '%26');
            }
          }
        if (key === 'searchType') {          
          if (searchValues[key] === 'Company Contact') {
            queryString += 'contactType=CC&'
          } else if (searchValues[key] === 'Other Contact') {
            queryString += 'contactType=OC&'
          } else if (searchValues[key] === 'Broker Contact') {
            queryString += 'contactType=BC&'
          } else if (searchValues[key] === 'Internal Contact') {
            queryString += 'contactType=CC&'
          }
        } else if (key === 'createdById' && searchValues[key]) {
          queryString += 'createdBy=' + encodeURIComponent(searchValues[key]) + '&'
        } else if (key === 'createdBy' || key === 'securityName' || key === 'brokerFirm') {
          // do nothing
        } else if (key === 'securityTicker' && searchValues[key]) {
          queryString += 'companyName=' + encodeURIComponent(searchValues[key]) + '&'
        } else if (key === 'otherCompany' && searchValues[key]) {
          queryString += 'companyName=' + encodeURIComponent(searchValues[key]) + '&'
        } else if (key === 'brokerFirmResultId' && searchValues[key]) {
          queryString += 'brokerFirmId=' + encodeURIComponent(searchValues[key]) + '&'
        } else if (key === 'createdDate' && searchValues[key]) {
          let dateArray = searchValues[key].split('/');
          let date = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0]
          queryString += 'createdDate=' + date + '&'
        } else {
          if (searchValues[key]) {
            queryString += key + '=' + encodeURIComponent(searchValues[key]) + '&'
          }
        }
      }
      let qString = queryString.substring(0, queryString.length - 1)
      this.contactServiceSubscription = this.commonService.getExternalContactsForSearch(qString)
        .subscribe((response) => {
          if (response['statusCode'] = 200 && response['body'].length > 0) {
            this.filterContactData(response['body']);

            // this.contactInfoData = this.contactData;

          } else {
            this.contactData = [];
          }
        },
        (error) => {
          this.contactData = [];
          console.log(error)
        });
    }
  }


  sortContacts(sortBy: string) {
    let attributeName: string;
    if (this.contactSearchPanelForm.get('searchType').value === 'Internal Contact') {
      attributeName = 'fullName';
    } else {
      attributeName = 'name';
    }
    this.dataSortingType = sortBy;
    if (this.dataSortingType === 'Asc') {
      var sortAsc = function (a, b) {
        if (a[attributeName] < b[attributeName]) {
          return -1;
        }
        if (a[attributeName] > b[attributeName]) {
          return 1;
        }
        return 0;
      };

      this.contactData.sort(sortAsc);

    } else if (this.dataSortingType === 'Desc') {
      var sortDesc = function (a, b) {
        if (b[attributeName] < a[attributeName]) {
          return -1;
        }
        if (b[attributeName] > a[attributeName]) {
          return 1;
        }
        return 0;
      };

      this.contactData.sort(sortDesc);

    }
  }

  getPeopleData() {
    this.peopleDataSource = EMPTY;
    let user: any;
    this.isValidCreator = false;
    this.contactSearchPanelForm.get('createdBy').setErrors({ 'invalidCreator': true });
    user = this.contactSearchPanelForm.get('createdBy').value;
    if (user.length >= 3) {
      this.peopleDataSource = new Observable((observer: any) => {
        this.peopleDataSubscription = this.commonService.getPeopleData(user).subscribe((response) => {
          this.createdByErrorResponse = false;
          if (response['status'] === 200) {
            if (response['data'].length > 0) {
              this.peopleData = response['data'];
              this.ngZone.run(() => {
                observer.next(filterPeopleResponse(response['data']));
              });
            } else {
              this.typeaheadNoResults(true, 'createdBy');
              observer.next([]);
              this.createdByErrorResponse = true;
              this.createdByTypeaheadLoading = false;

            }
          } else {
            this.typeaheadNoResults(true, 'createdBy');
            observer.next([]);

            this.createdByErrorResponse = true;
            this.createdByTypeaheadLoading = false;
          }
        },
          (error) => {
            this.typeaheadNoResults(true, 'createdBy');
            observer.next([]);
            this.createdByErrorResponse = true;
            this.createdByTypeaheadLoading = false;
            this.contactSearchPanelForm.get('createdBy').setErrors({ 'incorrect': true });
          });
      });
    } else {
      if (user.length > 0) {
        this.contactSearchPanelForm.get('createdBy').setErrors({ 'minLength': true });
      }
      if (this.peopleDataSource !== EMPTY) {
        this.peopleDataSubscription.unsubscribe();
      }

    }

  }

  checkInvalidDate(): boolean {
    if (this.contactSearchPanelForm.get('createdDate') && this.contactSearchPanelForm.get('createdDate').errors !== null && this.contactSearchPanelForm.get('createdDate').errors.invalidDate) {
      this.dateError = 'Please enter valid Date';
      return true;
    }
    return false;
  }

  checkFutureDate(): boolean {
    if (this.contactSearchPanelForm.get('createdDate') && this.contactSearchPanelForm.get('createdDate').errors !== null && this.contactSearchPanelForm.get('createdDate').errors.futureDate) {
      this.dateError = 'Please select past date';
      return true;
    }
    return false;
  }


  ngOnDestroy() {
    if (this.contactServiceSubscription) {
      this.contactServiceSubscription.unsubscribe();
    }
  }

  disableSearchButton() {

    if (this.contactSearchPanelForm.status === 'VALID') {
      if ((this.contactSearchPanelForm.get('firstName') && this.contactSearchPanelForm.get('firstName').value !== '')
        || (this.contactSearchPanelForm.get('lastName') && this.contactSearchPanelForm.get('lastName').value !== '')
        || (this.contactSearchPanelForm.get('email') && this.contactSearchPanelForm.get('email').value !== '')
        || (this.contactSearchPanelForm.get('createdById') && this.contactSearchPanelForm.get('createdById').value !== '')
        || (this.contactSearchPanelForm.get('securityTicker') && this.contactSearchPanelForm.get('securityTicker').value !== '')
        || (this.contactSearchPanelForm.get('brokerFirmResultId') && this.contactSearchPanelForm.get('brokerFirmResultId').value !== '')
        || (this.contactSearchPanelForm.get('brokerFirmId') && this.contactSearchPanelForm.get('brokerFirmId').value !== '')
        || (this.contactSearchPanelForm.get('otherCompany') && this.contactSearchPanelForm.get('otherCompany').value !== '')
        || (this.contactSearchPanelForm.get('corpId') && this.contactSearchPanelForm.get('corpId').value !== '')
        || (this.contactSearchPanelForm.get('createdDate') && this.contactSearchPanelForm.get('createdDate').value !== '')) {
        return false
      } else {
        return true
      }
    }
    else {
      return true
    }
  }

  checkEmail() {
    if (this.contactSearchPanelForm.get('email') && this.contactSearchPanelForm.get('email').errors !== null && this.contactSearchPanelForm.get('email').errors.email) {
      this.invalidEmail = true;
      console.log(this.contactSearchPanelForm.get('email'));
      if (this.contactSearchPanelForm.get('email').value.includes('@')
        && this.contactSearchPanelForm.get('email').value.split('')[this.contactSearchPanelForm.get('email').value.length - 1] === '@') {
        this.invalidEmailMsg = `Please enter a part following '@'. '` + this.contactSearchPanelForm.get('email').value + `' is incomplete.`;
      } else if (!this.contactSearchPanelForm.get('email').value.includes('@')) {
        this.invalidEmailMsg = `Please include an '@' in the email address. '` + this.contactSearchPanelForm.get('email').value + `' is missing an '@'.`;
      }
    } else {
      this.invalidEmail = false;
    }
  }

  addContact(selectedContactType: string) {
    this.router.navigate(['/contacts/add', { contactType: selectedContactType, selectedSecurity: this.securitySelected? JSON.stringify(this.securitySelected): '' }], { skipLocationChange: true });
  }

  showDateSelector() {
    if (this.contactSearchPanelForm.get('searchType') && this.contactSearchPanelForm.get('searchType').value === 'Broker Firm') {
      $("#createdDate").datepicker("destroy");
      $("#createdDate").hide();
      return false
    } else {
      if (this.contactSearchPanelForm.get('email')) {
        this.contactSearchPanelForm.get('email').setValidators([Validators.minLength(3), Validators.email]);
      }
      $("#createdDate").show();
      $("#createdDate").datepicker({
        numberOfMonths: 2,
        showButtonPanel: false,
        dateFormat: 'dd/mm/yy'
      }).on('change', () => {

        this.ngZone.run(() => {
          this.contactSearchPanelForm.patchValue({
            createdDate: $('#createdDate').val()
          });
        });
      });
      return true
    }
  }


  getBrokerFirm() {
    this.brokerFirmDataSource = EMPTY;
    this.brokerFirmAsyncSelected = this.contactSearchPanelForm.get('brokerFirm').value;
    this.isValidBrokerFirm = false;
    this.contactSearchPanelForm.patchValue({
      brokerFirmResultId: ''
    });
    if (this.brokerFirmAsyncSelected.length >= 3) {
      this.brokerFirmDataSource = new Observable((observer) => {
        if (this.brokerFirmAsyncSelected.length >= 3) {
          this.brokerFirmSubscription = this.commonService.getBrokerFirm("brokerFirmName=" + this.brokerFirmAsyncSelected).subscribe((response) => {
            if (response) {
              this.brokerFirmErrorResponse = false;
              this.ngZone.run(() => observer.next(this.filterFirmdataResults(response)));
            } else {
              this.brokerFirmErrorResponse = true;
              this.brokerFirmSelectedParameter = '';
              observer.next([]);
              this.brokerFirmTypeaheadLoading = false;
              this.typeaheadNoResults(true, 'BrokerFirm');
            }
          },
            (error) => {
              if (this.brokerFirmAsyncSelected.length >= 3) {
                this.brokerFirmErrorResponse = true;
                this.brokerFirmSelectedParameter = '';
                observer.next([]);
                this.brokerFirmTypeaheadLoading = false;
                this.typeaheadNoResults(true, 'BrokerFirm');
              }
            });
        }
      });
    } else {
      this.brokerFirmResultId = '';
      if (this.brokerFirmDataSource !== EMPTY) {
        this.brokerFirmSubscription.unsubscribe();
      }
      this.brokerFirmSelectedParameter = '';
    }
  }


  filterFirmdata(data) {

    data.forEach((item) => {
      item['firmName'] = convertToTitleCase(item['firmName']);
      item['name'] = item['firmName'];
      item['insertTimestamp'] = item['insertTimestamp'] ? this.datePipe.transform(item['insertTimestamp'], 'dd MMM yyyy') : 'Not Available';
      item['updateID'] = item['updateID'] ? item['updateID'] : 'Not Available';
      item['insertID'] = item['insertID'] ? item['insertID'] : 'Not Available';

      this.ngZone.run(() => {
        this.contactData.push(item);
        this.sortContacts('Asc');
      })
      console.log(this.contactData)

    })


  }

  filterContactData(contactDataVal) {
    contactDataVal.forEach((element) => {
      let contactDetail: any = {};
      contactDetail.title = element.contactTypeObj.contact.title ? element.contactTypeObj.contact.title : '';
      contactDetail.firstName = element.contactTypeObj.contact.firstName ? element.contactTypeObj.contact.firstName : '';
      contactDetail.lastName = element.contactTypeObj.contact.lastName ? element.contactTypeObj.contact.lastName : '';
      contactDetail.mobileNumber = element.contactTypeObj.contact.mobileNumber ? element.contactTypeObj.contact.mobileNumber : '';
      contactDetail.notes = element.contactTypeObj.contact.notes ? element.contactTypeObj.contact.notes : '';
      contactDetail.officeAddress = element.contactTypeObj.contact.officeAddress ? element.contactTypeObj.contact.officeAddress : '';
      contactDetail.country = element.contactTypeObj.contact.country ? element.contactTypeObj.contact.country : '';
      contactDetail.localLanguageTitle = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.title ? element.contactTypeObj.contact.localLanguage.title : '';
      contactDetail.localLanguageLastName = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.lastName ? element.contactTypeObj.contact.localLanguage.lastName : '';
      contactDetail.localLanguageFirstName = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.firstName ? element.contactTypeObj.contact.localLanguage.firstName : '';
      contactDetail.name = convertToTitleCase(element.contactTypeObj.contact.fullName);
      contactDetail.position = element.contactTypeObj.contact.position ? element.contactTypeObj.contact.position : 'Not Available';
      contactDetail.telephone = element.contactTypeObj.contact.telephone ? element.contactTypeObj.contact.telephone : 'Not Available';
      contactDetail.emailId = element.contactTypeObj.contact.email ? element.contactTypeObj.contact.email : 'Not Available';
      contactDetail.externalId = element.contactTypeObj.contact.externalId ? element.contactTypeObj.contact.externalId : '';
      contactDetail.creatorName = element.contactTypeObj.contact.insertID ? element.contactTypeObj.contact.insertID : 'Not Available';
      contactDetail.createdOn = element.contactTypeObj.contact.insertTimestamp ? this.datePipe.transform(element.contactTypeObj.contact.insertTimestamp, 'dd MMM yyyy') : 'Not Available';
      contactDetail.lastUpdatedOn = element.contactTypeObj.contact.updateID ? element.contactTypeObj.contact.updateID : 'Not Available';
      contactDetail.assistantName = element.contactTypeObj.contact.assistant ? element.contactTypeObj.contact.assistant : 'Not Available';
      contactDetail.assistantPhoneNo = element.contactTypeObj.contact.assistantTelephone ? element.contactTypeObj.contact.assistantTelephone : 'Not Available';
      contactDetail.assistantEmail = element.contactTypeObj.contact.assistantEmail ? element.contactTypeObj.contact.assistantEmail : 'Not Available';
      contactDetail.contactStatus = element.contactTypeObj.contact.activeIndicator ? element.contactTypeObj.contact.activeIndicator === 'Y' ? 'Active' : 'Inactive' : '';
      contactDetail.versionNumber = element.contactTypeObj.contact.versionNo ? element.contactTypeObj.contact.versionNo : '';
      contactDetail.contactType = element.contactType;
      contactDetail.mailingContact = element.contactTypeObj.contact.mailingContact ? element.contactTypeObj.contact.mailingContact : 'N';
      contactDetail.inactiveRecordRequired = this.contactSearchPanelForm.get('inactiveContactsRequired').value;
      if (element.contactType === 'BC') {
        contactDetail.contactTypeDescription = 'Broker Contact';
        contactDetail.company = element.contactTypeObj.brokerFirm ? convertToTitleCase(element.contactTypeObj.brokerFirm.firmName) : 'Not Available';
        contactDetail.companyId = element.contactTypeObj.brokerFirm ? element.contactTypeObj.brokerFirm.firmId : '';
      } else if (element.contactType === 'CC') {
        contactDetail.contactTypeDescription = 'Company Contact';
        contactDetail.company = element.contactTypeObj.companyName ? convertToTitleCase(element.contactTypeObj.companyName) : 'Not Available';
        contactDetail.companyId = element.contactTypeObj.companyTicker ? element.contactTypeObj.companyTicker : '';
      } else if (element.contactType === 'OC') {
        contactDetail.contactTypeDescription = 'Other Contact';
        contactDetail.company = element.contactTypeObj.companyName ? convertToTitleCase(element.contactTypeObj.companyName) : 'Not Available';
      }
      this.contactData.push(contactDetail);
      this.sortContacts('Asc');
    });
  }

  checkFirm() {
    if (this.contactSearchPanelForm.get('brokerFirmId') && this.contactSearchPanelForm.get('brokerFirmId').errors !== null && this.contactSearchPanelForm.get('brokerFirmId').errors.pattern) {
      this.invalidBrokerFirmId = true;
    } else {
      this.invalidBrokerFirmId = false;
    }
  }

  filterFirmdataResults(firmData) {
    firmData.forEach((item) => {
      item['firmName'] = convertToTitleCase(item['firmName']);
      item['firmNameAndId'] = item['firmName'] + ' &lt;' + item['firmId'] + '&gt;'
    });
    return firmData;
  }

  filterInternalContactData(contactDataVal) {
    contactDataVal.forEach((element) => {
      let contactDetail: any = {};
      contactDetail.contactType = element.contactType;
      contactDetail.corpId = element.corpId ? element.corpId.toUpperCase() : '';
      contactDetail.firstName = element.firstName ? convertToTitleCase(element.firstName) : '';
      contactDetail.lastName = element.lastName ? convertToTitleCase(element.lastName) : '';
      contactDetail.fullName = element.fullName ? convertToTitleCase(element.fullName) : '';
      contactDetail.dialInNo = element.dialInNo ? element.dialInNo : 'Not Available';
      contactDetail.dialInPin = element.dialInPin ? element.dialInPin : 'Not Available';
      contactDetail.notes = element.notes ? element.notes : '';
      contactDetail.updateID = element.updateID ? element.updateID : 'Not Available';
      contactDetail.versionNo = element.versionNo ? element.versionNo : '';
      contactDetail.updateTS = element.updateTS ? element.updateTS : 'Not Available';
      contactDetail.insertID = element.insertID ? element.insertID : 'Not Available';
      contactDetail.insertTimestamp = element.insertTimestamp ? element.insertTimestamp : 'Not Available';
      contactDetail.contactStatus = element.activeIndicator === 'Y' ? 'Active' : 'Inactive';
      contactDetail.inactiveRecordRequired = this.contactSearchPanelForm.get('inactiveContactsRequired').value;
      this.contactData.push(contactDetail);
      this.sortContacts('Asc');
    });
  }

  onOtherCompanySelection() {
    if (this.contactSearchPanelForm.get('otherCompany') && this.contactSearchPanelForm.get('otherCompany').value) {
    this.securitySelected = this.contactSearchPanelForm.get('otherCompany').value;
    }
  }

}
