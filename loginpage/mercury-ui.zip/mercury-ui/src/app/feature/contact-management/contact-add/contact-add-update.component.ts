import { Component, OnInit, NgZone, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription, EMPTY } from 'rxjs';
import { CommonService } from 'src/app/core/http/common.service';
import { filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { ModalDirective } from 'ngx-bootstrap';
import { ChangeDetectorRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Contacts } from 'src/app/shared/models/contacts.model';
import { CompanyContact } from 'src/app/shared/models/companyContact.model';
import { ContactMapper } from 'src/app/shared/models/contactMapper.model';
import { Contact } from 'src/app/shared/models/contact.model';
import { BrokerContact } from 'src/app/shared/models/brokerContact.model';
import { OtherContact } from 'src/app/shared/models/otherContact.model';
import { InternalContact } from 'src/app/shared/models/internalContact.model';
import { BrokerFirm } from 'src/app/shared/models/brokerFirm.model';
import { LocalLanguage } from 'src/app/shared/models/localLanguage.model';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';
import { DatePipe } from '@angular/common';
import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';

@Component({
  selector: 'mv2-contact-add-update',
  templateUrl: './contact-add-update.component.html',
  styleUrls: ['./contact-add-update.component.css']
})
export class ContactAddUpdateComponent implements OnInit {

  contactType = ['Broker', 'Company', 'Other'];

  contactMapper: ContactMapper = new ContactMapper('',
    new CompanyContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', '', '', '', ''),
    new BrokerContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')),
      new BrokerFirm('', '', '', '', '', '', '', '', '', '', null, '', null, '')),
    new OtherContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', ''));

  oldContactMapper: ContactMapper = new ContactMapper('',
    new CompanyContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', '', '', '', ''),
    new BrokerContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')),
      new BrokerFirm('', '', '', '', '', '', '', '', '', '', null, '', null, '')),
    new OtherContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', ''));

  emptyContactMapper: ContactMapper = new ContactMapper('',
    new CompanyContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', '', '', '', ''),
    new BrokerContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')),
      new BrokerFirm('', '', '', '', '', '', '', '', '', '', null, '', null, '')),
    new OtherContact(new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      '', '', '', null, '', null, new LocalLanguage('', '', '')), '', ''));

  addUpdateContact: Contact = new Contact('', '', '', '', '', 'N', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', null, '', null, new LocalLanguage('', '', ''));

  internalContact = new InternalContact('', '', '', '', '', '', '', '', 0, '', '');
  emptyInternalContact = new InternalContact('', '', '', '', '', '', this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase(), '', 0, '', '');
  oldInternalContact = new InternalContact('', '', '', '', '', '', '', '', 0, '', '');

  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  actionType = 'Add New ';
  actionButton = 'Add';
  isValidSecurity = false;
  isValidBrokerGroup = false;
  contactToUpdate = {};
  selectedContactType = '';
  currentAction = '';
  orgTypeName = '';
  titleType = ['', 'Dr', 'Mr.', 'Mrs.', 'Ms.', 'NA'];
  orgTypeFormControlName = '';
  isAdditionalInfo = false;
  config = {
    ignoreBackdropClick: false
  };
  @ViewChild('saveDialogModal') saveDialogModal: ModalDirective;
  imageStatus = '';
  isModalShown = false;
  showNoButton = false;
  isDisableCheckRequired = true;
  popUpModalMessage = '';
  contactAddUpdateForm = this.fb.group({
    notes: ['']
  });
  peopleDataSource: Observable<any>;
  securityDataSource: Observable<any>;
  brokerGroupNameDataSource: Observable<any>;  
  peopleDataLoading: boolean;
  securityDataLoading: boolean;
  brokerGroupNameDataLoading: boolean;
  isValidInternalPersonName = false;
  peopleDataSubscription: Subscription;
  checkContactFormSubscription: Subscription;
  peopleDataErrResponse = false;
  securityDataErrResponse = false;
  brokerGroupNameDataErrResponse = false;
  messageHeading = '';
  targetUrl = ''
  checkContactFormChanges = false;
  invalidBrokerFirmId = false
  invalidEmail = false;
  invalidAsstEmail = false;
  invalidAsstMobileNo = false;
  invalidMobileNo = false;
  invalidPhoneNo = false;
  invalidLengthnotes = false;
  invalidLengthbrokerFirmDesc = false;
  invalidEmailMsg = `Invalid email format, please include an '@' in the email address.`;
  invalidFirmIdMsg = 'Only numbers are allowed.';
  invalidLengthMsg = 'Max Length of 1800 characters exceeded.';
  utilDataObservable: Observable<any>;
  countries = [];
  contactUpdateFromCreate = false;
  disbaleBG = false;
  selectedSecurity: any;
  @Input() contactTypeVal: string
  @Input() actionForContact: string
  @Input('selectedCompanyForContactCreation') selectedCompanyForContactCreation: any;
  @Input('contactToBeUpdated') contactToBeUpdated: any;
  @Output('hideContactAddUpdateModal') hideContactAddUpdateModal = new EventEmitter<boolean>();
  @Output('hideContactDiscardModal') hideContactDiscardModal = new EventEmitter<boolean>();
  constructor(private route: ActivatedRoute
    , private router: Router
    , private fb: FormBuilder
    , private commonService: CommonService
    , private ngZone: NgZone
    , private cdr: ChangeDetectorRef
    , private datePipe: DatePipe
  ) { }

  ngOnChanges() {
    this.selectedContactType = this.contactTypeVal;
    this.contactUpdateFromCreate = true;
    if (this.contactTypeVal === 'Company') {
      this.contactAddUpdateForm.patchValue({
        'companyName': this.selectedCompanyForContactCreation.instrumentLongName !== '-' ? convertToTitleCase(this.selectedCompanyForContactCreation.instrumentLongName) : '',
        'companyTicker': this.selectedCompanyForContactCreation.ticker !== '-' ? this.selectedCompanyForContactCreation.ticker : ''
      });
      this.emptyContactMapper.companyContact.companyName = this.contactAddUpdateForm.get('companyName') ? this.contactAddUpdateForm.get('companyName').value : '';
      this.emptyContactMapper.companyContact.ticker = this.contactAddUpdateForm.get('companyTicker') ? this.contactAddUpdateForm.get('companyTicker').value : '';
    } else if (this.contactTypeVal === 'Broker') {
      this.contactAddUpdateForm.patchValue({
        'brokerFirmName': this.selectedCompanyForContactCreation.firmName ? convertToTitleCase(this.selectedCompanyForContactCreation.firmName) : '',
        'brokerFirmId': this.selectedCompanyForContactCreation.firmId ? this.selectedCompanyForContactCreation.firmId : ''
      });
      this.emptyContactMapper.brokerContact.brokerFirm.firmName = this.contactAddUpdateForm.get('brokerFirmName') ? this.contactAddUpdateForm.get('brokerFirmName').value : '';
      this.emptyContactMapper.brokerContact.brokerFirm.firmId = this.contactAddUpdateForm.get('brokerFirmId') ? this.contactAddUpdateForm.get('brokerFirmId').value : '';
    } else if (this.contactTypeVal === 'Other') {
       this.contactAddUpdateForm.patchValue({
        'oraganizationName': convertToTitleCase(this.selectedCompanyForContactCreation)
      });
      this.emptyContactMapper.otherContact.companyName = this.contactAddUpdateForm.get('oraganizationName') ? this.contactAddUpdateForm.get('oraganizationName').value : '';
    }
    if (this.actionForContact === 'add') {
      this.actionType = 'Add New';
    } else {
      this.actionType = 'Update';
    }

  }

  ngOnInit() {
    this.fetchUtilData();
    this.route.params.subscribe((event) => {
      if (event.action === 'add') {
      this.currentAction = event.action;
      } else if (event.action === 'update' && event.contactToBeUpdated) {
      this.currentAction = event.action;
      }
      if (event.contactType) {
        this.selectedContactType = event.contactType;
      }
      if (event.selectedSecurity) {
        console.log("event security", event)
        this.selectedSecurity = JSON.parse(event.selectedSecurity);
        console.log("security val", this.selectedSecurity);
      }

      this.contactToUpdate = event.contactToBeUpdated ? JSON.parse(event.contactToBeUpdated) : {};
      if (this.selectedContactType === 'Broker Firm') {
        this.contactAddUpdateForm = this.fb.group({
          brokerFirmName: ['', Validators.maxLength(50)],
          // /[!@#$%^&*_\=\[\]{};':"\\|,.<>\/?]/
          // Validators.pattern(`^[0-9- !@#$%&*()^_=+.,<>'":;{}/|?]*$`)
          // \[]~`
          brokerFirmId: ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(30)]],
          phoneNumber: ['', Validators.maxLength(25)],
          website: ['', Validators.maxLength(300)],
          brokerFirmDesc: ['', Validators.maxLength(300)],
          officeAddress: ['', Validators.maxLength(300)],
          country: [''],
          brokerGroupFlag: [''],
          brokerGroupName: [''],
          brokerGroupId: ['']
        });
        this.orgTypeName = 'Broker Firm Name';
        this.orgTypeFormControlName = 'brokerFirmName';
        
        this['emptyContactMapper'].brokerContact.brokerFirm['brokerGroupFlag'] = 'N';
        this['emptyContactMapper'].brokerContact.brokerFirm['brokerGroup'] = {};
        this['emptyContactMapper'].brokerContact.brokerFirm['brokerGroup']['brokerGroupName'] = '';
        this['emptyContactMapper'].brokerContact.brokerFirm['brokerGroup']['brokerGroupId'] = '';
      } else if (this.selectedContactType === 'Internal') {
        this.contactAddUpdateForm = this.fb.group({
          internalPersonName: [''],
          corporateId: [''],
          dialIn: ['', Validators.maxLength(100)],
          accessCode: ['', Validators.maxLength(50)],
          notes: ['', Validators.maxLength(1800)]
        });
      } else {
        this.contactAddUpdateForm = this.fb.group({
          title: [''],
          firstName: ['', Validators.maxLength(50)],
          lastName: ['', Validators.maxLength(50)],
          phoneNumber: ['', Validators.maxLength(25)],
          mobileNumber: ['', Validators.maxLength(15)],
          email: ['', [Validators.email, Validators.maxLength(250)]],
          mailingContact: [''],
          notes: ['', Validators.maxLength(1800)],
          officeAddress: ['', Validators.maxLength(300)],
          country: [''],
          assistantFullName: ['', Validators.maxLength(100)],
          assistantMobileNumber: ['', Validators.maxLength(25)],
          assistantEmail: ['', [Validators.email, Validators.maxLength(250)]],
          localTitle: [''],
          localFirstName: ['', Validators.maxLength(200)],
          localLastName: ['', Validators.maxLength(200)]
        });
        if (this.selectedContactType === 'Broker') {
          this.contactAddUpdateForm.addControl('brokerFirmName', new FormControl(''));
          this.contactAddUpdateForm.addControl('brokerFirmId', new FormControl(''));
          this.contactAddUpdateForm.addControl('jobPosition', new FormControl(''));
          this.orgTypeName = 'Broker Firm Name';
          this.orgTypeFormControlName = 'brokerFirmName';
          if (this.selectedCompanyForContactCreation) {

            this.contactAddUpdateForm.patchValue({
              'brokerFirmName': this.selectedCompanyForContactCreation.firmName ? convertToTitleCase(this.selectedCompanyForContactCreation.firmName) : '',
              'brokerFirmId': this.selectedCompanyForContactCreation.firmId ? this.selectedCompanyForContactCreation.firmId : ''
            });
            this.emptyContactMapper.brokerContact.brokerFirm.firmName = this.contactAddUpdateForm.get('brokerFirmName') ? this.contactAddUpdateForm.get('brokerFirmName').value : '';
            this.emptyContactMapper.brokerContact.brokerFirm.firmId = this.contactAddUpdateForm.get('brokerFirmId') ? this.contactAddUpdateForm.get('brokerFirmId').value : '';
          }

          if (this.selectedSecurity) {
            this.contactAddUpdateForm.patchValue({
              'brokerFirmName': this.selectedSecurity['firmName'] ? convertToTitleCase(this.selectedSecurity['firmName']) : '',
              'brokerFirmId': this.selectedSecurity['firmId'] ? this.selectedSecurity['firmId'] : ''
            });
            this.emptyContactMapper.brokerContact.brokerFirm.firmName = this.contactAddUpdateForm.get('brokerFirmName') ? this.contactAddUpdateForm.get('brokerFirmName').value : '';
            this.emptyContactMapper.brokerContact.brokerFirm.firmId = this.contactAddUpdateForm.get('brokerFirmId') ? this.contactAddUpdateForm.get('brokerFirmId').value : '';
          }
        } else {
          this.contactAddUpdateForm.addControl('jobPosition', new FormControl(''));
          if (this.selectedContactType === 'Company') {
            this.contactAddUpdateForm.addControl('companyName', new FormControl(''));
            this.contactAddUpdateForm.addControl('companyTicker', new FormControl(''));
            this.orgTypeName = 'Company Name';
            this.orgTypeFormControlName = 'companyName';
            if (this.selectedCompanyForContactCreation) {

              this.contactAddUpdateForm.patchValue({
                'companyName': this.selectedCompanyForContactCreation.instrumentLongName !== '-' ? convertToTitleCase(this.selectedCompanyForContactCreation.instrumentLongName) : '',
                'companyTicker': this.selectedCompanyForContactCreation.ticker !== '-' ? this.selectedCompanyForContactCreation.ticker : ''
              });
              this.emptyContactMapper.companyContact.companyName = this.contactAddUpdateForm.get('companyName') ? this.contactAddUpdateForm.get('companyName').value : '';
              this.emptyContactMapper.companyContact.ticker = this.contactAddUpdateForm.get('companyTicker') ? this.contactAddUpdateForm.get('companyTicker').value : '';
            }

            if (this.selectedSecurity) {
              this.contactAddUpdateForm.patchValue({
                'companyName': this.selectedSecurity['instrumentLongName']? convertToTitleCase(this.selectedSecurity['instrumentLongName']) : '',
                'companyTicker': this.selectedSecurity['ticker']? this.selectedSecurity['ticker'] : ''
              });
              this.emptyContactMapper.companyContact.companyName = this.contactAddUpdateForm.get('companyName') ? this.contactAddUpdateForm.get('companyName').value : '';
              this.emptyContactMapper.companyContact.ticker = this.contactAddUpdateForm.get('companyTicker') ? this.contactAddUpdateForm.get('companyTicker').value : '';
            }
          } else if (this.selectedContactType === 'Other') {
            this.contactAddUpdateForm.addControl('oraganizationName', new FormControl(''));
            this.orgTypeName = 'Organization Name';
            this.orgTypeFormControlName = 'oraganizationName';
            if (this.selectedCompanyForContactCreation) {
              this.contactAddUpdateForm.patchValue({
                'oraganizationName': convertToTitleCase(this.selectedCompanyForContactCreation)
              });
              this.emptyContactMapper.otherContact.companyName = this.contactAddUpdateForm.get('oraganizationName') ? this.contactAddUpdateForm.get('oraganizationName').value : '';
            }
            if (this.selectedSecurity) {
              
              if (typeof(this.selectedSecurity) === 'string') {
              this.contactAddUpdateForm.patchValue({
                'oraganizationName': convertToTitleCase(this.selectedSecurity)
              });
              this.emptyContactMapper.otherContact.companyName = this.contactAddUpdateForm.get('oraganizationName') ? this.contactAddUpdateForm.get('oraganizationName').value : '';
              }
            }
          }
        }
      }
    });

    if (this.currentAction === 'update' || (this.actionForContact === 'update' && this.contactToBeUpdated)) {
      this.actionType = 'Update ';
      this.actionButton = 'Update';
      if (this.actionForContact === 'update' && this.contactToBeUpdated) {
        let con = JSON.parse(JSON.stringify(this.contactToBeUpdated))[0];
        this.contactToUpdate = this.filterContactData(con);
      }
      // let format = /[!@#$%^&*_\=\[\]{};':"\\|,.<>\/?]/;
      //excluding symbols :  + space () -  ::>>>>>full Format : /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
      if (this.contactToUpdate['contactType'] === 'Broker Firm') {
        
        this.contactAddUpdateForm.patchValue({
          brokerFirmName: this.contactToUpdate['firmName'] && this.contactToUpdate['firmName'] !== 'Not Available' ? this.contactToUpdate['firmName'] : '',
          brokerFirmId: this.contactToUpdate['firmId'] ? this.contactToUpdate['firmId'] : '',
          phoneNumber: this.contactToUpdate['telephone'] ? this.contactToUpdate['telephone'] : '',
          website: this.contactToUpdate['brokerFirmWebsite'] ? this.contactToUpdate['brokerFirmWebsite'] : '',
          brokerFirmDesc: this.contactToUpdate['brokerFirmDescription'] ? this.contactToUpdate['brokerFirmDescription'] : '',
          officeAddress: this.contactToUpdate['brokerFirmAddress'] ? this.contactToUpdate['brokerFirmAddress'] : '',
          country: this.contactToUpdate['country'] && this.contactToUpdate['country'] !== 'Not Available' ? this.getCountryForContacts(this.contactToUpdate['country'], this.contactToUpdate['contactType']) : '',
          brokerGroupFlag: this.contactToUpdate['brokerGroupFlag'] && this.contactToUpdate['brokerGroupFlag'] === 'Y' ? true : false,
          brokerGroupName: this.contactToUpdate['brokerGroup'] && this.contactToUpdate['brokerGroup']['brokerGroupName'] ? convertToTitleCase(this.contactToUpdate['brokerGroup']['brokerGroupName']) : '',
          brokerGroupId: this.contactToUpdate['brokerGroup'] && this.contactToUpdate['brokerGroup']['brokerGroupId'] ? this.contactToUpdate['brokerGroup']['brokerGroupId'] : ''
        });
        if (this.contactAddUpdateForm.get('brokerFirmId').value) {
          this.contactAddUpdateForm.get('brokerFirmId').disable();
        }
        if (this.contactToUpdate['brokerGroupFlag'] === 'Y') {
          this.contactAddUpdateForm.get('brokerGroupName').disable();
          this.contactAddUpdateForm.get('brokerGroupFlag').disable();
          this.disbaleBG = true;
        } else {
          if (this.contactToUpdate['brokerGroup'] && this.contactToUpdate['brokerGroup']['brokerGroupId']) {
          this.isValidBrokerGroup = true;
          }
          this.contactAddUpdateForm.get('brokerGroupName').enable();
        } 
        
        // if (format.test(this.contactAddUpdateForm.get('phoneNumber').value)) {
        //   this.invalidPhoneNo = true;
        // }
      } else if (this.contactToUpdate['contactType'] === 'Internal') {
        this.contactAddUpdateForm.patchValue({
          internalPersonName: this.contactToUpdate['fullName'],
          corporateId: this.contactToUpdate['corpId'].toUpperCase(),
          dialIn: this.contactToUpdate['dialInNo'],
          accessCode: this.contactToUpdate['dialInPin'],
          notes: this.contactToUpdate['notes']
        });
        this.contactAddUpdateForm.get('internalPersonName').disable();
        this.contactAddUpdateForm.get('corporateId').disable();
      } else {
        if (this.contactToUpdate['contactType'] === 'BC') {
          this.contactAddUpdateForm.patchValue({
            brokerFirmName: this.contactToUpdate['company'] && this.contactToUpdate['company'] !== 'Not Available' ? this.contactToUpdate['company'] : '',            
            brokerFirmId: this.contactToUpdate['companyId'] ? this.contactToUpdate['companyId'] : '',
            jobPosition: this.contactToUpdate['position'] && this.contactToUpdate['position'] !== 'Not Available' ? this.contactToUpdate['position'] : ''
          });
          this.contactAddUpdateForm.get('brokerFirmName').disable();
        } else if (this.contactToUpdate['contactType'] === 'CC') {
          this.contactAddUpdateForm.patchValue({
            companyName: this.contactToUpdate['company'] && this.contactToUpdate['company'] !== 'Not Available' ? this.contactToUpdate['company'] : '',
            companyTicker: this.contactToUpdate['companyId'].replace((this.contactToUpdate['company']).toUpperCase(), ''),
            // companyTicker: this.contactToUpdate['companyId'] ? this.contactToUpdate['companyId'] : '',
            // companyTicker:  '',
            jobPosition: this.contactToUpdate['position'] && this.contactToUpdate['position'] !== 'Not Available' ? this.contactToUpdate['position'] : ''
          });
          this.contactAddUpdateForm.get('companyName').disable();
        } else if (this.contactToUpdate['contactType'] === 'OC') {
          this.contactAddUpdateForm.patchValue({
            oraganizationName: this.contactToUpdate['company'] && this.contactToUpdate['company'] !== 'Not Available' ? this.contactToUpdate['company'] : '',
            jobPosition: this.contactToUpdate['position'] && this.contactToUpdate['position'] !== 'Not Available' ? this.contactToUpdate['position'] : ''
          });
          this.contactAddUpdateForm.get('oraganizationName').disable();
        }
        this.contactAddUpdateForm.patchValue({
          title: this.contactToUpdate['title'] && this.contactToUpdate['title'] !== 'Not Available' ? this.contactToUpdate['title'] : '',
          firstName: this.contactToUpdate['firstName'] && this.contactToUpdate['firstName'] !== 'Not Available' ? this.contactToUpdate['firstName'] : '',
          lastName: this.contactToUpdate['lastName'] && this.contactToUpdate['lastName'] !== 'Not Available' ? this.contactToUpdate['lastName'] : '',
          phoneNumber: this.contactToUpdate['telephone'] && this.contactToUpdate['telephone'] !== 'Not Available' ? this.contactToUpdate['telephone'] : '',
          mobileNumber: this.contactToUpdate['mobileNumber'] && this.contactToUpdate['mobileNumber'] !== 'Not Available' ? this.contactToUpdate['mobileNumber'] : '',
          email: this.contactToUpdate['emailId'] && this.contactToUpdate['emailId'] !== 'Not Available' ? this.contactToUpdate['emailId'] : '',
          mailingContact: this.contactToUpdate['mailingContact'] && this.contactToUpdate['mailingContact'] === 'Y' ? true : false,
          officeAddress: this.contactToUpdate['officeAddress'] && this.contactToUpdate['officeAddress'] !== 'Not Available' ? this.contactToUpdate['officeAddress'] : '',
          country: this.contactToUpdate['country'] && this.contactToUpdate['country'] !== 'Not Available' ? this.getCountryForContacts(this.contactToUpdate['country'], this.contactToUpdate['contactType']) : '',
          assistantFullName: this.contactToUpdate['assistantName'] && this.contactToUpdate['assistantName'] !== 'Not Available' ? this.contactToUpdate['assistantName'] : '',
          assistantMobileNumber: this.contactToUpdate['assistantPhoneNo'] && this.contactToUpdate['assistantPhoneNo'] !== 'Not Available' ? this.contactToUpdate['assistantPhoneNo'] : '',
          assistantEmail: this.contactToUpdate['assistantEmail'] && this.contactToUpdate['assistantEmail'] !== 'Not Available' ? this.contactToUpdate['assistantEmail'] : '',
          localTitle: this.contactToUpdate['localLanguageTitle'] && this.contactToUpdate['localLanguageTitle'] !== 'Not Available' ? this.contactToUpdate['localLanguageTitle'] : '',
          localFirstName: this.contactToUpdate['localLanguageFirstName'] && this.contactToUpdate['localLanguageFirstName'] !== 'Not Available' ? this.contactToUpdate['localLanguageFirstName'] : '',
          localLastName: this.contactToUpdate['localLanguageLastName'] && this.contactToUpdate['localLanguageLastName'] !== 'Not Available' ? this.contactToUpdate['localLanguageLastName'] : '',
          notes: this.contactToUpdate['notes'] && this.contactToUpdate['notes'] !== 'Not Available' ? this.contactToUpdate['notes'] : ''
        });
        // if (format.test(this.contactAddUpdateForm.get('phoneNumber').value)) {
        //   this.invalidPhoneNo = true;
        // }
        // if (format.test(this.contactAddUpdateForm.get('mobileNumber').value)) {
        //   this.invalidMobileNo = true;
        // }
        // if (format.test(this.contactAddUpdateForm.get('assistantMobileNumber').value)) {
        //   this.invalidAsstMobileNo = true;
        // }
      }
      if (this.selectedContactType === 'Internal') {
        this.setOldInternalContact();
      } else {
        this.insertContacts('oldContactMapper', 'updateContact');
      }
    }
    this.checkContactFormSubscription = this.commonService.checkContactFormChanges.subscribe((response) => {
      if (response) {
        this.checkFormChanges(this.commonService.getTargetUrl());
      }
    });
  }

  confirm(): void {
    this.isModalShown = false;
    // this.isDisableCheckRequired = false;
    if (this.popUpModalMessage !== 'Unable to create new contact. Please try again.'
      && this.popUpModalMessage !== 'Unable to create new contact. A contact with same email id already exists.'
      && this.popUpModalMessage !== 'Unable to create new contact. A contact with same id already exists.'
      && this.popUpModalMessage !== 'Unable to create new contact. A similar contact already exists.'
      && !this.popUpModalMessage.includes('Unable to update contact.')
      && this.popUpModalMessage !== 'Unable to create new Firm. Firm with similar Firm Id already exists.') {

      if (!this.contactUpdateFromCreate) {
        this.contactAddUpdateForm = this.fb.group({});
        this.router.navigate([this.commonService.getTargetUrl(), { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
      } else {
        this.hideContactAddUpdateModal.emit(true);
      }
    }
    // this.cdr.detectChanges();
  }
  ngOnDestroy(): void {
    if (this.checkContactFormSubscription) {
      this.checkContactFormSubscription.unsubscribe();
    }
  }
  decline() {
    if (!this.contactUpdateFromCreate) {
      this.commonService.setTargetUrl('/contacts');
    }
    this.saveDialogModal.hide();
    this.isModalShown = false;
  }
  onHidden() {
    this.saveDialogModal.hide();
    this.isModalShown = false;
  }
  changeContact(event) {
    this.selectedContactType = event;
  }
  isAddDisabled(): boolean {
    if (this.isDisableCheckRequired) {
      if (this.selectedContactType === 'Broker Firm') {
        if (this.contactAddUpdateForm.status === 'VALID' && this.contactAddUpdateForm.get('brokerFirmName') && this.contactAddUpdateForm.get('brokerFirmName').value !== '' &&
          this.contactAddUpdateForm.get('brokerFirmId') && this.contactAddUpdateForm.get('brokerFirmId').value !== '') {
          return false;
        }
      } else if (this.selectedContactType === 'Internal') {
        if (this.contactAddUpdateForm.status === 'VALID' && this.contactAddUpdateForm.get('internalPersonName') && this.contactAddUpdateForm.get('internalPersonName').value !== '' &&
          this.contactAddUpdateForm.get('dialIn') && this.contactAddUpdateForm.get('dialIn').value !== '' && this.contactAddUpdateForm.get('accessCode') && this.contactAddUpdateForm.get('accessCode').value !== '') {
          return false;
        }
      } else {
        if (this.contactAddUpdateForm.status === 'VALID' && this.contactAddUpdateForm.get(this.orgTypeFormControlName) && this.contactAddUpdateForm.get(this.orgTypeFormControlName).value !== '' &&
          this.contactAddUpdateForm.get('firstName') && this.contactAddUpdateForm.get('firstName').value !== '' && this.contactAddUpdateForm.get('lastName') && this.contactAddUpdateForm.get('lastName').value !== '') {
          if (this.selectedContactType === 'Broker') {
            return false;
          } else {
            if (this.selectedContactType === 'Company' || this.selectedContactType === 'Other') {
              if (this.contactAddUpdateForm.get('jobPosition') && this.contactAddUpdateForm.get('jobPosition').value !== '') {
                return false;
              }
            }
          }
        }
      }
      return true;
    } else {
      return true;
    }
  }
  addContact() {
    this.insertContacts('contactMapper', 'addContact');
    let contactInsertValues: any;
    if (this.selectedContactType === 'Internal') {
      contactInsertValues = this.internalContact
    } else {
      contactInsertValues = this.contactMapper;
    }
    if (this.contactUpdateFromCreate) {
      this.currentAction = this.actionForContact;
    }
    this.commonService.insertNewContact(contactInsertValues, this.currentAction).subscribe((response) => {
      if (response) {
        this.showNoButton = false;
        if (this.currentAction === 'add') {
          this.popUpModalMessage = 'Contact created successfully.';
          this.messageHeading = 'Confirmation';
        } else {
          this.popUpModalMessage = 'Contact updated successfully.';
          this.messageHeading = 'Confirmation';
        }
        this.isModalShown = true;
        this.imageStatus = 'success';
      }
    },
      (error) => {

        if (this.currentAction === 'add') {
          if (error.error['message'].includes('already exists')) {
            if (error.error['message'] === 'Failed to Insert. A contact with same email id already exists.') {
              this.popUpModalMessage = 'Unable to create new contact. A contact with same email id already exists.';
            } else if (error.error['message'] === 'Internal Contact already exists. Please check your entry and try again') {
              this.popUpModalMessage = 'Unable to create new contact. A contact with same id already exists.';
            } else if (error.error['message'] === 'Failed to Insert. A similar contact already exists.') {
              this.popUpModalMessage = 'Unable to create new contact. A similar contact already exists.';
            } else if (error.error['message'].includes('Firm Id')) {
              this.popUpModalMessage = 'Unable to create new Firm. Firm with similar Firm Id already exists.';
            }
          }
          else {
            this.popUpModalMessage = 'Unable to create new contact. Please try again.';
          }
        } else if (this.currentAction === 'update') {
            if (error.error['message'] === 'Failed to Update. Another user has updated this contact. Please select latest version to update.') {
              this.popUpModalMessage = 'Unable to update contact. Another user has updated this contact.';
            } else if (error.error['message'] === 'Failed to Update. Updated email id already exists for some other contact. Please select a different email id.') {
              this.popUpModalMessage = 'Unable to update contact. A contact with same email id already exists.';
            } else if (error.error['message'] === 'Failed to Update. A similar contact already exists.') {
              this.popUpModalMessage = 'Unable to update contact. A similar contact already exists.';
            } else {
              this.popUpModalMessage = 'Unable to update contact. Please try again.';
        }
        }

        this.messageHeading = 'Error';
        this.isModalShown = true;
        this.imageStatus = 'alert';
      })
  }
  discardContact() {
    this.contactAddUpdateForm = this.fb.group({});
    if (!this.contactUpdateFromCreate) {
      this.router.navigate(['/contacts'], { skipLocationChange: true });
    } else {
      this.hideContactDiscardModal.emit(true);
    }
  }

  insertContacts(mapperType: string, actionType: string) {
    if (this.selectedContactType === 'Broker Firm') {
      if (mapperType === 'contactMapper') {
        if (actionType !== 'checkForm') {
          this[mapperType].brokerContact.brokerFirm.insertID = this.commonService.getLoggedInUserInfo().getCorporateId();
          this[mapperType].brokerContact.brokerFirm.insertTimestamp = new Date();
        }
        if (this.currentAction === 'update' && actionType !== 'checkForm') {
          this[mapperType].brokerContact.brokerFirm.versionNumber = this.contactToUpdate['versionNumber'];
          this[mapperType].brokerContact.brokerFirm.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
          this[mapperType].brokerContact.brokerFirm.updatedTimestamp = new Date();
        }
      }
      this[mapperType].contactType = this.selectedContactType;
      this[mapperType].brokerContact.brokerFirm.firmName = this.contactAddUpdateForm.get('brokerFirmName').value ? this.contactAddUpdateForm.get('brokerFirmName').value : '';
      this[mapperType].brokerContact.brokerFirm.firmId = this.contactAddUpdateForm.get('brokerFirmId').value ? this.contactAddUpdateForm.get('brokerFirmId').value : '';
      this[mapperType].brokerContact.brokerFirm.telephone = this.contactAddUpdateForm.get('phoneNumber').value ? this.contactAddUpdateForm.get('phoneNumber').value.trim() : '';
      this[mapperType].brokerContact.brokerFirm.brokerFirmWebsite = this.contactAddUpdateForm.get('website').value ? this.contactAddUpdateForm.get('website').value : '';
      this[mapperType].brokerContact.brokerFirm.brokerFirmAddress = this.contactAddUpdateForm.get('officeAddress').value ? this.contactAddUpdateForm.get('officeAddress').value : '';
      this[mapperType].brokerContact.brokerFirm.brokerFirmDescription = this.contactAddUpdateForm.get('brokerFirmDesc').value ? this.contactAddUpdateForm.get('brokerFirmDesc').value.trim() : '';
      this[mapperType].brokerContact.brokerFirm.country = this.contactAddUpdateForm.get('country').value ? this.contactAddUpdateForm.get('country').value['KeyCode'] : 'OT';
      this[mapperType].brokerContact.brokerFirm['brokerGroupFlag'] = this.contactAddUpdateForm.get('brokerGroupFlag')? (this.contactAddUpdateForm.get('brokerGroupFlag').value ? 'Y' : 'N') : 'N';
      this[mapperType].brokerContact.brokerFirm['brokerGroup'] = {};
      this[mapperType].brokerContact.brokerFirm['brokerGroup']['brokerGroupName'] = this.contactAddUpdateForm.get('brokerGroupName')? this.contactAddUpdateForm.get('brokerGroupName').value: '';
      this[mapperType].brokerContact.brokerFirm['brokerGroup']['brokerGroupId'] = this.contactAddUpdateForm.get('brokerGroupId')? this.contactAddUpdateForm.get('brokerGroupId').value: '';
    } else if (this.selectedContactType === 'Internal') {
      this.internalContact.dialInNumber = this.contactAddUpdateForm.get('dialIn').value.trim();
      this.internalContact.dailInPin = this.contactAddUpdateForm.get('accessCode').value.trim();
      this.internalContact.notes = this.contactAddUpdateForm.get('notes').value.trim();
      this.internalContact.firstName = this.contactAddUpdateForm.get('internalPersonName') ? this.contactAddUpdateForm.get('internalPersonName').value.trim() : '';
      if (this.currentAction === 'add') {
        this.internalContact.insertId = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
      }
      this.internalContact.corpId = this.contactAddUpdateForm.get('corporateId') ? this.contactAddUpdateForm.get('corporateId').value.toLowerCase() : '';
      if (this.currentAction === 'update' && actionType !== 'checkForm') {
        //   this.internalContact.insertId = this.contactToUpdate['insertID'].toLowerCase();
        this.internalContact.oldVersionNumber = this.contactToUpdate['versionNo'];
        this.internalContact.deleteContactFlag = 'N';
        this.internalContact.extIntFlag = 'Internal';
        this.internalContact.updateId = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase().toLowerCase();
      }
    } else {
      this.addUpdateContact.title = this.contactAddUpdateForm.get('title').value;
      this.addUpdateContact.lastName = this.contactAddUpdateForm.get('lastName').value;
      this.addUpdateContact.firstName = this.contactAddUpdateForm.get('firstName').value;
      this.addUpdateContact.telephone = this.contactAddUpdateForm.get('phoneNumber') ? this.contactAddUpdateForm.get('phoneNumber').value.trim() : '';
      this.addUpdateContact.email = this.contactAddUpdateForm.get('email') ? this.contactAddUpdateForm.get('email').value : '';
      this.addUpdateContact.mailingContact = this.contactAddUpdateForm.get('mailingContact')
        ? (this.contactAddUpdateForm.get('mailingContact').value ? 'Y' : 'N') : 'N';
      this.addUpdateContact.mobileNumber = this.contactAddUpdateForm.get('mobileNumber') ? this.contactAddUpdateForm.get('mobileNumber').value.trim() : '';
      this.addUpdateContact.position = this.contactAddUpdateForm.get('jobPosition') ? this.contactAddUpdateForm.get('jobPosition').value : '';
      this.addUpdateContact.assistant = this.contactAddUpdateForm.get('assistantFullName') ? this.contactAddUpdateForm.get('assistantFullName').value : '';
      this.addUpdateContact.assistantTelephone = this.contactAddUpdateForm.get('assistantMobileNumber') ? this.contactAddUpdateForm.get('assistantMobileNumber').value.trim() : '';
      this.addUpdateContact.assistantEmail = this.contactAddUpdateForm.get('assistantEmail') ? this.contactAddUpdateForm.get('assistantEmail').value : '';
      this.addUpdateContact.officeAddress = this.contactAddUpdateForm.get('officeAddress') ? this.contactAddUpdateForm.get('officeAddress').value : '';
      this.addUpdateContact.country = this.contactAddUpdateForm.get('country').value ? this.contactAddUpdateForm.get('country').value['KeyCode'] : '';
      this.addUpdateContact.notes = this.contactAddUpdateForm.get('notes') ? this.contactAddUpdateForm.get('notes').value : '';
      let formFullName = '';
      if (this.contactAddUpdateForm.get('lastName').value) {
        formFullName = this.contactAddUpdateForm.get('lastName').value;
      }
      if (this.contactAddUpdateForm.get('firstName').value) {
        formFullName = (formFullName ? (formFullName + ', ') : '') + this.contactAddUpdateForm.get('firstName').value;
      }
      this.addUpdateContact.fullName = formFullName;
      if (actionType !== 'checkForm') {
        this.addUpdateContact.insertID = this.commonService.getLoggedInUserInfo().getCorporateId();
      }
      this.addUpdateContact.localLanguage.title = this.contactAddUpdateForm.get('localTitle') ? this.contactAddUpdateForm.get('localTitle').value : '';
      this.addUpdateContact.localLanguage.firstName = this.contactAddUpdateForm.get('localFirstName') ? this.contactAddUpdateForm.get('localFirstName').value : '';
      this.addUpdateContact.localLanguage.lastName = this.contactAddUpdateForm.get('localLastName') ? this.contactAddUpdateForm.get('localLastName').value : '';

      if (this.selectedContactType === 'Broker') {
        this[mapperType].contactType = 'BC';
        this[mapperType].brokerContact.brokerFirm.firmName = this.contactAddUpdateForm.get('brokerFirmName').value;
        this[mapperType].brokerContact.brokerFirm.firmId = this.contactAddUpdateForm.get('brokerFirmId').value;
        this[mapperType].brokerContact.contact = Object.assign({}, this.addUpdateContact);
        if (mapperType === 'contactMapper') {
          if ((this.currentAction === 'update' || (this.actionForContact === 'update' && this.contactToBeUpdated && this.contactUpdateFromCreate)) && actionType !== 'checkForm') {
            this[mapperType].brokerContact.contact.externalId = this.contactToUpdate['externalId'];
            this[mapperType].brokerContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
            this[mapperType].brokerContact.contact.versionNo = this.contactToUpdate['versionNumber'];
          }
        }
      } else if (this.selectedContactType === 'Company') {
        this[mapperType].contactType = 'CC';
        this[mapperType].companyContact.companyName = this.contactAddUpdateForm.get('companyName').value;
        this[mapperType].companyContact.ticker = this.contactAddUpdateForm.get('companyTicker').value;
        this[mapperType].companyContact.contact = Object.assign({}, this.addUpdateContact);
        if (mapperType === 'contactMapper') {
          if ((this.currentAction === 'update' || (this.actionForContact === 'update' && this.contactToBeUpdated && this.contactUpdateFromCreate)) && actionType !== 'checkForm') {
            this[mapperType].companyContact.contact.externalId = this.contactToUpdate['externalId'];
            this[mapperType].companyContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
            this[mapperType].companyContact.contact.versionNo = this.contactToUpdate['versionNumber'];
          }
        }
      } else if (this.selectedContactType === 'Other') {
        this[mapperType].contactType = 'OC';
        this[mapperType].otherContact.companyName = this.contactAddUpdateForm.get('oraganizationName').value;
        this[mapperType].otherContact.contact = Object.assign({}, this.addUpdateContact);
        if (mapperType === 'contactMapper') {
          if ((this.currentAction === 'update' || (this.actionForContact === 'update' && this.contactToBeUpdated && this.contactUpdateFromCreate)) && actionType !== 'checkForm') {
            this[mapperType].otherContact.contact.externalId = this.contactToUpdate['externalId'];
            this[mapperType].otherContact.contact.updateID = this.commonService.getLoggedInUserInfo().getCorporateId().toLowerCase();
            this[mapperType].otherContact.contact.versionNo = this.contactToUpdate['versionNumber'];
          }
        }
      }
    }
    // else if (this.selectedContactType === 'Internal') {
    //   this.contact.internalPersonName = this.contactAddUpdateForm.get('internalPersonName').value ? this.contactAddUpdateForm.get('internalPersonName').value : '';
    //   this.contact.corporateId = this.contactAddUpdateForm.get('corporateId').value ? this.contactAddUpdateForm.get('corporateId').value : '';
    //   this.contact.dialIn = this.contactAddUpdateForm.get('dialIn').value ? this.contactAddUpdateForm.get('dialIn').value : '';
    //   this.contact.accessCode = this.contactAddUpdateForm.get('accessCode').value ? this.contactAddUpdateForm.get('accessCode').value : '';
    // }
  }

  getPeopleData(): void {
    let typeaheadData: TypeaheadData;
    this.isValidInternalPersonName = false;
    const searchedValue = this.contactAddUpdateForm.get('internalPersonName').value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    this.peopleDataErrResponse = typeaheadData.isResponseError;
  }

  getSecurities(orgTypeFormControlName: string): void {
    let typeaheadData: TypeaheadData;
    let searchedValue = this.contactAddUpdateForm.get(this.orgTypeFormControlName).value;    
    if (orgTypeFormControlName === 'companyName') {
      this.isValidSecurity = false;
      typeaheadData = this.typeaheadDataSource.getSecurities(searchedValue);
      this.securityDataSource = typeaheadData.dataSource;
      this.securityDataErrResponse = typeaheadData.isResponseError;
    } else if (orgTypeFormControlName === 'brokerFirmName') {
      this.isValidSecurity = false;
      typeaheadData = this.typeaheadDataSource.getBrokerFirms(searchedValue);
      this.securityDataSource = typeaheadData.dataSource;
      this.securityDataErrResponse = typeaheadData.isResponseError;
    } else if (orgTypeFormControlName === 'brokerGroupName') {
      searchedValue = this.contactAddUpdateForm.get(orgTypeFormControlName).value;
      this.isValidBrokerGroup = false;
      typeaheadData = this.typeaheadDataSource.gerBrokerGroups(searchedValue);
      this.brokerGroupNameDataSource = typeaheadData.dataSource;
      this.brokerGroupNameDataErrResponse = typeaheadData.isResponseError;
    }

    
  }

  typeaheadOnSelect(event, filterType: string): void {
    if (filterType === 'internalPersonName') {
      this.contactAddUpdateForm.patchValue({
        internalPersonName: convertToTitleCase(event.item.name),
        corporateId: event.item.corporateId
      });
      this.isValidInternalPersonName = true;
    } else if (filterType === 'companyName') {
      this.contactAddUpdateForm.patchValue({
        companyName: convertToTitleCase(event.item.instrumentLongName),
        companyTicker: event.item.ticker
      });
      this.isValidSecurity = true;
    } else if (filterType === 'brokerFirmName') {
      this.contactAddUpdateForm.patchValue({
        brokerFirmName: convertToTitleCase(event.item.firmName),
        brokerFirmId: event.item.firmId
      });
      this.isValidSecurity = true;
    } else if (filterType === 'brokerGroupName') {
      this.contactAddUpdateForm.patchValue({
        brokerGroupName: convertToTitleCase(event.item.firmName),
        brokerGroupId: event.item.firmId
      });
      this.isValidBrokerGroup = true;
    }
  }
  changeTypeaheadLoading(e: boolean, filterType: string): void {
    if (filterType === 'internalPersonName') {
      this.peopleDataLoading = e;
    } else if (filterType === 'brokerGroupName') {
      this.brokerGroupNameDataLoading = e;
    } else if (filterType === 'companyName' || 'brokerFirmName') {
      this.securityDataLoading = e;
    } 
  }

  typeaheadNoResults(event: boolean, filterType: string): void {
    if (filterType === 'internalPersonName') {
      this.peopleDataErrResponse = event;
    } else if (filterType === 'brokerGroupName') {
      this.brokerGroupNameDataErrResponse = event;
    } else if (filterType === 'companyName' || 'brokerFirmName') {
      this.securityDataErrResponse = event;
    } 
  }
  onBlurMethod(fieldName: string) {
    if (fieldName === 'internalPersonName' && !this.isValidInternalPersonName) {
      this.peopleDataErrResponse = false;
      this.contactAddUpdateForm.patchValue({
        internalPersonName: '',
        corporateId: ''
      });
    } else if ((fieldName === 'companyName') && !this.isValidSecurity) {
      this.contactAddUpdateForm.patchValue({
        companyName: '',
        companyTicker: ''
      });
      this.getSecurities(fieldName);
      this.securityDataLoading = false;
    } else if ((fieldName === 'brokerFirmName') && !this.isValidSecurity) {
      this.contactAddUpdateForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.getSecurities(fieldName);
      this.securityDataLoading = false;
    } else if ((fieldName === 'brokerGroupName') && !this.isValidBrokerGroup) {
      this.contactAddUpdateForm.patchValue({
        brokerGroupName: '',
        brokerGroupId: ''
      });
      this.getSecurities(fieldName);
      this.brokerGroupNameDataLoading = false;
    }
  }

  checkInvalidEmail(fieldName: string) {
    if (fieldName === 'email') {
      if (this.contactAddUpdateForm.get('email') && this.contactAddUpdateForm.get('email').errors !== null && this.contactAddUpdateForm.get('email').errors.email) {
        this.invalidEmail = true;
      } else {
        this.invalidEmail = false;
      }
    } else if (fieldName === 'assistantEmail') {
      if (this.contactAddUpdateForm.get('assistantEmail') && this.contactAddUpdateForm.get('assistantEmail').errors !== null && this.contactAddUpdateForm.get('assistantEmail').errors.email) {
        this.invalidAsstEmail = true;
      } else {
        this.invalidAsstEmail = false;
      }
    }
  }
  checkInvalidNumber(fieldName: string) {
    if (fieldName === 'phoneNumber') {
      if (this.contactAddUpdateForm.get('phoneNumber') && this.contactAddUpdateForm.get('phoneNumber').errors !== null && this.contactAddUpdateForm.get('phoneNumber').errors.pattern) {
        this.invalidPhoneNo = true;
      } else {
        this.invalidPhoneNo = false;
        this.validateTextLength(fieldName);
      }
    } else if (fieldName === 'mobileNumber') {
      if (this.contactAddUpdateForm.get('mobileNumber') && this.contactAddUpdateForm.get('mobileNumber').errors !== null && this.contactAddUpdateForm.get('mobileNumber').errors.pattern) {
        this.invalidMobileNo = true;
      } else {
        this.invalidMobileNo = false;
        this.validateTextLength(fieldName);
      }
    } else if (fieldName === 'assistantMobileNumber') {
      if (this.contactAddUpdateForm.get('assistantMobileNumber') && this.contactAddUpdateForm.get('assistantMobileNumber').errors !== null && this.contactAddUpdateForm.get('assistantMobileNumber').errors.pattern) {
        this.invalidAsstMobileNo = true;
      } else {
        this.invalidAsstMobileNo = false;
        this.validateTextLength(fieldName);
      }
    }
  }
  checkInvalidBrokerFirmId(fieldName: string) {
    if (fieldName === 'brokerFirmId') {
      if (this.contactAddUpdateForm.get('brokerFirmId') && this.contactAddUpdateForm.get('brokerFirmId').errors !== null && this.contactAddUpdateForm.get('brokerFirmId').errors.pattern) {
        this.invalidBrokerFirmId = true;
      } else {
        this.invalidBrokerFirmId = false;
        this.validateTextLength(fieldName);
      }
    }
  }
  private fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        const utilData = message;
        this.countries = utilData.filter(element => element.UtilKeyName === 'countries');
        for (const item of this.countries) {
          item['KeyDesc'] = convertToTitleCase(item['KeyDesc']);
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }
  validateTextLength(fieldName: string) {
    if (this.contactAddUpdateForm.get(fieldName) && this.contactAddUpdateForm.get(fieldName).errors !== null && this.contactAddUpdateForm.get(fieldName).errors.maxlength) {
      let invalidFieldName = 'invalidLength' + fieldName;
      this[invalidFieldName] = true;
    } else {
      let invalidFieldName = 'invalidLength' + fieldName;
      this[invalidFieldName] = false;
    }
  }

  checkFormChanges(uri) {
    this.commonService.setTargetUrl(uri);
    if (this.selectedContactType === 'Internal') {
      this.checkFormChangesForInternalForm(uri)
    } else {
      let newForm: any;
      let oldForm: any;
      this.insertContacts('contactMapper', 'checkForm');
      newForm = JSON.stringify(this.contactMapper);
      if (this.currentAction === 'update' || (this.actionForContact === 'update' && this.contactToBeUpdated)) {
        oldForm = JSON.stringify(this.oldContactMapper);
      } else {
        if (this.selectedContactType === 'Broker Firm') {
          this.emptyContactMapper.brokerContact.brokerFirm.country = 'OT';
          
        }
        this.emptyContactMapper.contactType = (this.selectedContactType === 'Broker'
          ? 'BC'
          : (this.selectedContactType === 'Company'
            ? 'CC'
            : (this.selectedContactType === 'Other'
              ? 'OC'
              : 'Broker Firm')));
        oldForm = JSON.stringify(this.emptyContactMapper);
      }
  
      if (newForm === oldForm) {
        // this.cdr.detectChanges();
        if (this.contactUpdateFromCreate && (this.actionForContact === 'add' || this.actionForContact === 'update')) {
          this.hideContactDiscardModal.emit(true);
        } else if (uri === '/meetings' || uri === '/contacts') {
          this.router.navigate([uri], { skipLocationChange: true });
        } else {
          if (uri.includes('/meeting/create')) {
            this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
          } else {
            this.router.navigate([uri], { skipLocationChange: true });
          }
        }
      } else {
        this.messageHeading = 'Confirm Navigation';
        this.popUpModalMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
        this.imageStatus = 'alert';
        this.isModalShown = true;
        this.showNoButton = true;
        // this.cdr.detectChanges();
      }
    }
  }
  getCountryForContacts(countryVal: string, contactType: string): Object {
    let countryObj: Object;
    this.countries.forEach((element) => {
      if ((contactType === 'Broker Firm') && (element['KeyDesc'].toUpperCase() === countryVal.toUpperCase())) {
        countryObj = element;
      } else if ((contactType !== 'Broker Firm') && element['KeyCode'].toUpperCase() === countryVal.toUpperCase()) {
        countryObj = element;
      }
    });
    return countryObj;
  }

  checkFormChangesForInternalForm(uri) {
    let newForm: any;
    let oldForm: any;
    this.insertContacts('contactMapper', 'checkForm');
    newForm = JSON.stringify(this.internalContact);
    if (this.currentAction === 'update') {
      oldForm = JSON.stringify(this.oldInternalContact);
    } else {
      oldForm = JSON.stringify(this.emptyInternalContact);
    }
    if (newForm === oldForm) {
      // this.cdr.detectChanges();
      if (uri === '/meetings' || uri === '/contacts') {
        this.router.navigate([uri], { skipLocationChange: true });
      } else {
        if (uri.includes('/meeting/create')) {
          this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
        } else {
          this.router.navigate([uri], { skipLocationChange: true });
        }
      }
    } else {
      this.messageHeading = 'Confirm Navigation';
      this.popUpModalMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
      this.imageStatus = 'alert';
      this.isModalShown = true;
      this.showNoButton = true;
      // this.cdr.detectChanges();
    }
  }

  setOldInternalContact() {
    this.oldInternalContact.dialInNumber = this.contactAddUpdateForm.get('dialIn').value.trim();
    this.oldInternalContact.dailInPin = this.contactAddUpdateForm.get('accessCode').value.trim();
    this.oldInternalContact.notes = this.contactAddUpdateForm.get('notes').value.trim();
    this.oldInternalContact.firstName = this.contactAddUpdateForm.get('internalPersonName') ? this.contactAddUpdateForm.get('internalPersonName').value.trim() : '';
    // this.oldInternalContact.insertId = this.contactToUpdate['insertID'].toLowerCase();
    this.oldInternalContact.corpId = this.contactAddUpdateForm.get('corporateId') ? this.contactAddUpdateForm.get('corporateId').value.toLowerCase() : '';
  }


  filterContactData(element) {

    let contactDetail: any = {};
    contactDetail.title = element.contactTypeObj.contact.title ? element.contactTypeObj.contact.title : '';
    contactDetail.firstName = element.contactTypeObj.contact.firstName ? element.contactTypeObj.contact.firstName : '';
    contactDetail.lastName = element.contactTypeObj.contact.lastName ? element.contactTypeObj.contact.lastName : '';
    contactDetail.mobileNumber = element.contactTypeObj.contact.mobileNumber ? element.contactTypeObj.contact.mobileNumber : '';
    contactDetail.notes = element.contactTypeObj.contact.notes ? element.contactTypeObj.contact.notes : '';
    contactDetail.officeAddress = element.contactTypeObj.contact.officeAddress ? element.contactTypeObj.contact.officeAddress : '';
    contactDetail.country = element.contactTypeObj.contact.country ? element.contactTypeObj.contact.country : '';
    contactDetail.localLanguageTitle = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.title ? element.contactTypeObj.contact.localLanguage.title : '';
    contactDetail.localLanguageLastName = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.lastName ? element.contactTypeObj.contact.localLanguage.lastName : '';
    contactDetail.localLanguageFirstName = element.contactTypeObj.contact.localLanguage && element.contactTypeObj.contact.localLanguage.firstName ? element.contactTypeObj.contact.localLanguage.firstName : '';
    contactDetail.name = convertToTitleCase(element.contactTypeObj.contact.fullName);
    contactDetail.position = element.contactTypeObj.contact.position ? convertToTitleCase(element.contactTypeObj.contact.position) : 'Not Available';
    contactDetail.telephone = element.contactTypeObj.contact.telephone ? element.contactTypeObj.contact.telephone : 'Not Available';
    contactDetail.emailId = element.contactTypeObj.contact.email ? element.contactTypeObj.contact.email : 'Not Available';
    contactDetail.externalId = element.contactTypeObj.contact.externalId ? element.contactTypeObj.contact.externalId : '';
    contactDetail.creatorName = element.contactTypeObj.contact.insertID ? element.contactTypeObj.contact.insertID : 'Not Available';
    contactDetail.createdOn = element.contactTypeObj.contact.insertTimestamp ? this.datePipe.transform(element.contactTypeObj.contact.insertTimestamp, 'dd MMM yyyy') : 'Not Available';
    contactDetail.lastUpdatedOn = element.contactTypeObj.contact.updateID ? element.contactTypeObj.contact.updateID : 'Not Available';
    contactDetail.assistantName = element.contactTypeObj.contact.assistant ? element.contactTypeObj.contact.assistant : 'Not Available';
    contactDetail.assistantPhoneNo = element.contactTypeObj.contact.assistantTelephone ? element.contactTypeObj.contact.assistantTelephone : 'Not Available';
    contactDetail.assistantEmail = element.contactTypeObj.contact.assistantEmail ? element.contactTypeObj.contact.assistantEmail : 'Not Available';
    contactDetail.contactStatus = element.contactTypeObj.contact.activeIndicator ? element.contactTypeObj.contact.activeIndicator === 'Y' ? 'Active' : 'Inactive' : '';
    contactDetail.versionNumber = element.contactTypeObj.contact.versionNo ? element.contactTypeObj.contact.versionNo : '';
    contactDetail.contactType = element.contactType;
    contactDetail.mailingContact = element.contactTypeObj.contact.mailingContact ? element.contactTypeObj.contact.mailingContact : 'N';
    // contactDetail.inactiveRecordRequired = this.contactSearchPanelForm.get('inactiveContactsRequired').value;
    if (element.contactType === 'BC') {
      contactDetail.contactTypeDescription = 'Broker Contact';
      contactDetail.company = element.contactTypeObj.brokerFirm ? convertToTitleCase(element.contactTypeObj.brokerFirm.firmName) : 'Not Available';
      contactDetail.companyId = element.contactTypeObj.brokerFirm ? element.contactTypeObj.brokerFirm.firmId : '';
    } else if (element.contactType === 'CC') {
      contactDetail.contactTypeDescription = 'Company Contact';
      contactDetail.company = element.contactTypeObj.companyName ? convertToTitleCase(element.contactTypeObj.companyName) : 'Not Available';
      contactDetail.companyId = element.contactTypeObj.companyTicker ? element.contactTypeObj.companyTicker : '';
    } else if (element.contactType === 'OC') {
      contactDetail.contactTypeDescription = 'Other Contact';
      contactDetail.company = element.contactTypeObj.companyName ? convertToTitleCase(element.contactTypeObj.companyName) : 'Not Available';
    }
    return contactDetail;
  }

  disableBrokerGroup() {
    if (this.contactAddUpdateForm.get('brokerGroupFlag').value) {
      this.contactAddUpdateForm.patchValue({
        brokerGroupName: '',
        brokerGroupId: ''
      });
      this.contactAddUpdateForm.get('brokerGroupName').disable();
    } else {
      this.contactAddUpdateForm.patchValue({
        brokerGroupName: '',
        brokerGroupId: ''
      });
      this.contactAddUpdateForm.get('brokerGroupName').enable();
    }
  }
}
