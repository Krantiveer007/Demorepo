import { Component } from "@angular/core";
import { ICellRendererAngularComp, AgEditorComponent } from "ag-grid-angular";
import { Output } from "@angular/core";
import { EventEmitter, OnInit, AfterViewInit } from "@angular/core";

@Component({
  selector: "attendee-cell-renderer",
  styleUrls: ['./attendee-renderer.component.css'],
  template: `<div class="row align-items-center" style="height: 100%; font-size:15px;">  
    <div *ngIf = "viewType === 'company'" class="col-md-6 pl-0">
    <label class="container">{{attendee.name}}
        <input type="checkbox" name="selectedAttendee" [(ngModel)]="selectedAttendee" [checked]="selectedAttendee"
          (change)="selectAttendee($event)">
        <span class="checkmark1" style="top: 7px;"></span>
    </label>
  </div>
    <div *ngIf = "viewType === 'attendee'" class="col-md-7 pl-0">
    <label class="container">{{attendee.name}}
        <input type="radio" name="selectedAttendee" [value]="selectedAttendee" [checked]="selectedAttendee"
           (change)="selectAttendee($event)">
        <span class="checkmark"></span>
    </label>
  </div>
    <div class="ml-auto col-auto">
      {{attendee.corporateId}}
    </div>
    <div *ngIf = "viewType === 'company'" class="col-auto">
    <label class="container">Host
        <input type="radio" name="selectedHost" [value]="selectedHost" [checked]="selectedHost"
           (change)="selectHost($event)">
        <span class="checkmark"></span>
    </label>
  </div>
</div>`
})
export class AttendeeRendererComponent implements ICellRendererAngularComp {
  public params: any;
  attendee: any;
  viewType;
  selectedHost: boolean = false;
  selectedAttendee: boolean = false;
  // subTypes = ["1:1", "Group"];
  // selectedSubType;
  
  agInit(params: any): void {
    this.params = params;
    this.params.data["selectedHost"] = false;
    this.params.data["selectedAttendee"] = false;
    this.viewType = this.params.context.componentParent.viewType;
    this.params.data["host"] = false;
    // this.selectedSubType = this.params.context.componentParent.selectedType.keyCode;
    if (params.value === null) {
      return undefined;
    } else {
      this.attendee = params.data;
    }
  }

  // public onManage(e, p) {
  //   this.params.context.componentParent.managePortfolios(e, this.params);
  // }

  selectHost(event) {
    // this.params.node.setSelected(event.currentTarget.checked);
    this.params.data["host"] = event.currentTarget.checked;
    this.params.data["selectedHost"] = event.currentTarget.checked;
    this.selectedHost = event.currentTarget.checked;;
    this.params.api.forEachNode((node, index) => {
      if (node.data.corporateId !== this.params.data.corporateId) {
        // node.setDataValue('host', false);
        node.data.host = false;
        node.data["selectedHost"] = false;
      }
    });
  }

  selectAttendee(event) {
    this.params.node.setSelected(event.currentTarget.checked);
    this.params.data["selectedAttendee"] = event.currentTarget.checked; 
    if (this.viewType === "attendee") {
      const gridOptions = this.params.context.componentParent.gridOptions;
      // gridOptions.api.setRowData(this.params.context.componentParent.allCompanies);
      const attendeeSchedules = this.params.context.componentParent.attendeeSchedules;
      const selectedAttendeeSchedule = attendeeSchedules.filter((attendeeSchedule) => (attendeeSchedule.corporateId === this.params.data.corporateId));
      if (selectedAttendeeSchedule.length) {
        selectedAttendeeSchedule[0].companies.forEach(company => {
          gridOptions.api.forEachNode((node, index) => {
            if (node.data.scheduleId === company.scheduleId) {
              node.data.isSelected = true;
              node.data.selectedCompany = true;
              node.data.selectedHost = company.isHost;
              node.setDataValue('selectedCompany', true);
              node.setDataValue('selectedHost', company.isHost);
              node.setSelected(true);
            }
          });
        });
        gridOptions.api.forEachNode((node, index) => {
          if (!node.data.isSelected) {
            node.data.selectedCompany = false;
            node.data.selectedHost = false;
            node.setDataValue('selectedCompany', false);
            node.setDataValue('selectedHost', false);
            node.setSelected(false);
          } else {
            delete node.data.isSelected;
          }
        });
        gridOptions.api.refreshCells({
          force: true
        });
      } else {
        gridOptions.api.forEachNode((node, index) => {
          if (!node.data.isSelected) {
            node.data.selectedCompany = false;
            node.data.selectedHost = false;
            node.setDataValue('selectedCompany', false);
            node.setDataValue('selectedHost', false);
            node.setSelected(false);
          } else {
            delete node.data.isSelected;
          }
        });
        gridOptions.api.refreshCells({
          force: true
        });
      }
    }
  }

  removeAttendee(event) {
    this.params.api.updateRowData({ remove: [this.params.data] });
    this.params.context.componentParent.removeAttendee(this.params.data);
  }

  isPopup() {
    return true;
  }
  
  refresh(): boolean {
    this.selectedAttendee = this.params.data["selectedAttendee"];
    this.selectedHost = this.params.data["selectedHost"];
    this.params.data["host"] = this.params.data["selectedHost"];
    return true;
  }
}
