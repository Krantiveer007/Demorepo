import { Component, OnInit } from '@angular/core';
import { dateComparator } from 'src/app/shared/utils/ag-grid.utility';
import { Router } from '@angular/router';
import { ConfigSignupComponent } from 'src/app/shared/components/config-signup/config-signup.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { DetailCellRendererComponent } from 'src/app/shared/components/detail-cellrenderer/detail-cellrenderer.component';
import { Meeting } from 'src/app/shared/models/meeting.model';
import { EventLastUpdateDetails } from 'src/app/shared/models/eventLastUpdateDetails.model';
import { MeetingSubtype } from 'src/app/shared/models/meetingsubtype.model';
import { MeetingInitiator } from 'src/app/shared/models/meetinginitiator.model';
import { Country } from 'src/app/shared/models/country.model';
import { DialIn } from 'src/app/shared/models/dialin.model';
import { MeetingLocation } from 'src/app/shared/models/meetinglocation.model';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
import { AssociatedEventDetail } from 'src/app/shared/models/associatedeventdetail.model';
import { SecurityDetails } from 'src/app/shared/models/securitydetails.model';
import { MeetingCreator } from 'src/app/shared/models/meetingcreator.model';
import { DebtTickerDetail } from 'src/app/shared/models/debtTickerDetail.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { ConferenceSchedule } from 'src/app/shared/models/conferenceSchedule.model';
import { CommonService } from 'src/app/core/http/common.service';
import { Input } from '@angular/core';
import { SimpleChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { FormGroup } from '@angular/forms';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { ControlValueAccessor } from '@angular/forms';
import { AfterViewInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
// import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import { ConfigDropDownComponent } from 'src/app/shared/components/config-drop-down/config-drop-down.component';
import { ConfigDaterendererComponent } from 'src/app/shared/components/config-daterenderer/config-daterenderer.component';
import { ConfigTimerendererComponent } from 'src/app/shared/components/config-timerenderer/config-timerenderer.component';
// import { RowselectionheaderComponent } from 'src/app/shared/components/rowselectionheader/rowselectionheader.component';
import { GridOptions } from 'ag-grid-community';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
// import { ConfigDurationComponent } from 'src/app/shared/components/config-duration/config-duration.component';


@Component({
  selector: 'mv2-master-grid',
  templateUrl: './master-grid.component.html',
  styleUrls: ['./master-grid.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MasterGridComponent),
      multi: true
    }
  ]
})
export class MasterGridComponent implements OnInit, ControlValueAccessor, AfterViewInit {

  gridOptions: GridOptions;
  columnDefs: any[];
  rowData = [];
  overlayNoRowsTemplate: any;
  gridApi: any;
  columnApi: any;
  detailCellRendererParams: any;
  detailCellRenderer: any;
  frameworkComponents: any;
  touched = false;
  // isAllRowsSelected = false;
  value: any[] = [];
  conferenceScedule: any;
  // isRowSelectable;
  autoHeight = false;
  isEditableFieldsEnabled = false;

  @Input() conferencScheduleDtls: any;
  onModelChange: Function = (value: any[]) => {
  }

  onModelTouched: Function = (): boolean => {
    return this.touched;
  }

  writeValue(value: any): void {
    if (value) {
      this.value = value;
    }
  }
  registerOnChange(fn: Function): void {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onModelTouched = fn;
  }
  constructor(private cdr: ChangeDetectorRef, private commonService: CommonService) { }

  ngOnInit() {
    this.gridOptions = <GridOptions>{
      headerHeight: 40,
      rowHeight: 32,
      rowBuffer: 200,
      suppressNoRowsOverlay: false,
      suppressCellSelection: true,
      resizable: true,
      context: {
        componentParent: this
      },
      // toolPanelSuppressSideButtons: true,
      onGridReady: function (params) {
        this.gridApi = params.api;
        this.columnApi = params.columnApi;
        this.gridApi.hideOverlay();
      },
      suppressMovableColumns: true
    };
    this.columnDefs = [
      {
        headerName: '',
        field: 'meetingState',
        resizable: true,
        width: 60,
        cellStyle: this.styleMeetingState,
        cellRenderer: "agGroupCellRenderer"
      },
      // {
      //   headerName: '',
      //   field: 'selection',
      //   resizable: true,
      //   width: 70,
      //   headerCheckboxSelection: true,
      //   checkboxSelection: (params) => {
      //     // return (params.data.meetingDate && params.data.meetingTime)
      //     return true
      //   },
      //   cellStyle: { 'color': '#eeeff0' },
      //   // headerComponentFramework: RowselectionheaderComponent,
      //   // cellRendererFramework: ConfigRowSelectionComponent,
      // },
      {
        headerName: 'Security/Debt Ticker/Broker Firm/Topic',
        field: 'companyName',
        resizable: true,
        sortable: true,
        width: 370,
        cellClass: this.getCompanyNameClass,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' },
        cellRenderer: this.tooltipRenderer,
      },
      {
        headerName: 'No. Of Attendees',
        field: 'attendeeCount',
        resizable: true,
        width: 230,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      {
        headerName: 'Meeting Type',
        field: 'meetingType',
        resizable: true,
        sortable: true,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      {
        headerName: 'Meeting Sub-Type',
        field: 'mtgSubType',
        resizable: true,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      {
        headerName: 'Meeting Status (Broker)',
        field: 'eventScheduleStatus',
        cellRendererFramework: ConfigDropDownComponent,
        resizable: true,
        width: 250,
        cellClass: ['action-dropDown-cell'],
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      {
        headerName: 'State',
        field: 'meetingState',
        resizable: true,
        // width: 270,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' },
        cellRenderer: this.stateStyleRenderer,
      },
      {
        headerName: 'Date *',
        field: 'meetingDate',
        resizable: true,
        sortingOrder: ['desc', 'asc', null],
        sortable: true,
        comparator: dateComparator,
        cellRendererFramework: ConfigDaterendererComponent,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      {
        headerName: 'Time *',
        field: 'meetingTime',
        resizable: true,
        width: 280,
        cellRendererFramework: ConfigTimerendererComponent,
        cellStyle: { 'text-align': 'left!important', 'font-size': '14px' }
      },
      // {
      //   headerName: 'Duration',
      //   field: 'duration',
      //   resizable: true,
      //   sortable: true,
      //   width: 300,
      //   // cellRendererFramework: ConfigDurationComponent,
      //   cellStyle: { 'text-align': 'left!important' }
      // },
      {
        headerName: 'Action',
        field: 'action',
        cellRendererFramework: ConfigDeleteComponent,
        resizable: true,
        width: 120,
        headerClass: 'mv2-headerCenterAlign',
        cellStyle: { 'text-align': 'center!important' }
      }
      // {
      //   headerName: 'Action', field: 'SignUpMeeting', resizable: true, cellRendererFramework: ConfigSignupComponent,
      //   headerClass: 'mv2-headerCenterAlign',
      //   cellStyle: { 'text-align': 'center!important', 'cursor': 'pointer!important' }, width: 100,
      //   pinned: 'right'
      // },
    ];
    this.detailCellRenderer = "myDetailCellRenderer";
    this.frameworkComponents = { myDetailCellRenderer: DetailCellRendererComponent };
    // this.gridOptions.rowSelection = 'single';
    this.gridOptions.suppressRowClickSelection = true;
    // this.gridOptions.onSelectionChanged = this.onSelectionChanged;
    // this.gridOptions.isRowSelectable = function (node) {
    //   return node.data ? (node.data.meetingDate && node.data.meetingTime) : false;
    // };
    this.overlayNoRowsTemplate =
      '<div style=\"font-size: 18px;color: #747c89;\">No meetings to display.<br> Schedule the meetings to see the meetings.</div>';
    this.gridOptions.getRowStyle = function (params) {
      return { background: '#eeeff0', overflow: 'visible' };
    };
    this.commonService.redrawMasterGrid.subscribe((element) => {
      if (element && this.gridOptions.api) {
        this.isEditableFieldsEnabled = false;
        this.rowData = [];
        this.gridOptions.rowData.length = 0;
        this.gridOptions.api.setRowData([]);
        this.value = [];
        this.onModelChange(this.value);
        this.onModelTouched();
        // this.gridOptions.api.redrawRows();
        // this.gridOptions.api.forEachNode((node) => {
        //   this.gridOptions.api.refreshCells({
        //     rowNodes: [node],
        //     force: true
        //   });
        // });
      }
    });
    this.cdr.detectChanges();
    const conferenceSceduleDtls = this.commonService.getConferenceSchedule();
    if (conferenceSceduleDtls.eventId) {
      this.setRowData(conferenceSceduleDtls);
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    this.setRowData(changes.conferencScheduleDtls.currentValue);
  }

  setRowData(conferenceSchedule: any) {
    if (this.gridOptions && conferenceSchedule) {
      // console.log('change: ', changes.conferencScheduleDtls.currentValue);
      this.conferenceScedule = conferenceSchedule;
      const eventMtgDtls: any = conferenceSchedule['eventMeetings'];
      // this.commonService.rowSelectHeaderDisable.next(eventMtgDtls.length === 0);
      eventMtgDtls.forEach((meeting) => {
        meeting['fidelityInvitees'].forEach(element => {
          element.isCallIn = (typeof (element.isCallIn) === 'string') ? false : element.isCallIn;
          element.isInviteRequired = (typeof (element.isInviteRequired) === 'string') ? true : element.isInviteRequired;
          element.isInfoPackRequired = (typeof (element.isInfoPackRequired) === 'string') ? false : element.isInfoPackRequired;
          element.isInviteForInfoOnly = (typeof (element.isInviteForInfoOnly) === 'string') ? false : element.isInviteForInfoOnly;
        });
      });
      eventMtgDtls.forEach((meeting) => {
        if (meeting.hasOwnProperty('hostCorporateId')
          && !meeting.hostCorporateId) {
          meeting.fidelityInvitees.forEach(element => {
            if (element.hasOwnProperty('host') && element.host) {
              meeting.hostCorporateId = element.corporateId;
            }
          });
        }
        let companyName = '';
        let companyId = '';
        let ticker = '';
        if (meeting.meetingType === 'Company' && meeting.businessEntity === 'EQ') {
          companyName = meeting.securityDetail ? meeting.securityDetail.securityName : '';
          companyId = meeting.securityDetail ? meeting.securityDetail.securityTradableEntityId : '';
          ticker = meeting.securityDetail ? meeting.securityDetail.ticker : '';
        } else if (meeting.meetingType === 'Company' && meeting.businessEntity === 'FI') {
          companyName = meeting.debtTickerDetail ? meeting.debtTickerDetail.debtTicker : '';
          companyId = meeting.debtTickerDetail ? meeting.debtTickerDetail.debtTicker : '';
        } else if (meeting.meetingType === 'Broker') {
          companyName = meeting.brokerDetail ? meeting.brokerDetail.brokerFirmName : '';
          companyId = meeting.brokerDetail ? meeting.brokerDetail.brokerFirmId : '';
        } else if (meeting.meetingType === 'Other') {
          companyName = meeting.meetingTopic ? meeting.meetingTopic : '';
          companyId = meeting.meetingTopic ? meeting.meetingTopic : '';
        }
        // console.log('meeting: ', meeting);
        this.rowData.push({
          'meetingState': meeting.meetingState ? meeting.meetingState.toUpperCase() : 'NEW',
          // 'selection': false,
          'companyName': companyName,
          'companyId': companyId,
          'attendeeCount': this.getAttendeeCount(meeting),
          'meetingType': (meeting.meetingType === 'Company')
            ? (meeting.meetingType + ' - ' + meeting.businessEntity) : meeting.meetingType,
          'eventScheduleStatus': meeting.eventScheduleStatus ? meeting.eventScheduleStatus : '',
          'meetingStatus': meeting.meetingStatus
            ? (meeting.meetingState === 'CANCELLED') ? '' : convertToTitleCase(meeting.meetingStatus)
            : '',
          'meetingDate': meeting.meetingDate ? meeting.meetingDate : '',
          'meetingTime': meeting.meetingTimeInGMT ? meeting.meetingTimeInGMT : '',
          'scheduleId': meeting.scheduleId ? meeting.scheduleId : '',
          // 'duration': meeting.meetingDuration ? meeting.meetingDuration : '',
          'action': '',
          'callRecordsFilAttendee': meeting.fidelityInvitees.length > 0 ? meeting.fidelityInvitees : [],
          'callRecordsThirdPartyAttendee': (meeting.thirdPartyAttendee.length > 0 && (Object.keys(meeting.thirdPartyAttendee[0]).length > 0))
            ? meeting.thirdPartyAttendee : [],
          'eventTimezone': this.commonService.getConferenceMeetingDtls().eventTimezone ? this.commonService.getConferenceMeetingDtls().eventTimezone : '',
          'hostCorporateId': meeting.hostCorporateId,
          'ticker': ticker,
          'meetingTimeInGMT': meeting.meetingTimeInGMT ? meeting.meetingTimeInGMT : '',
          'meetingTimeInLocalTimezone': meeting.meetingTimeInLocalTimezone ? meeting.meetingTimeInLocalTimezone : '',
          'mtgSubType': meeting.meetingSubType.meetingSubTypeCode
            ? meeting.meetingSubType.meetingSubTypeCode.toUpperCase().includes('GROUP') ? 'Group Meeting' : 'Conference 1:1'
            : '',
          'meetingId': meeting.meetingId ? meeting.meetingId : ''
        });
      });
      if (this.gridOptions.api) {
        // this.gridOptions.isRowSelectable = function (node) {
        //   return node.data ? (node.data.meetingDate && node.data.meetingTime) : false;
        // };
        this.gridOptions.api.setRowData(this.rowData);
        this.gridOptions.rowData = this.rowData;
        if (window.screen.availWidth > 1366) {
          this.gridOptions.api.sizeColumnsToFit();
        }
        // this.holdersMaxHeight = false;
        if (this.gridOptions.rowData.length > 0) {
          this.autoHeight = true;
          this.gridOptions.api.setDomLayout('autoHeight');
        } else {
          this.autoHeight = false;
          this.gridOptions.api.setDomLayout('normal');
        }
      }
      this.value = Object.assign({}, this.gridOptions.rowData);
      this.onModelChange(this.value);
      this.onModelTouched();
      this.cdr.detectChanges();
    }
  }
  // onSelectionChanged = (): void => {
  //   const selectedRows: any[] = this.gridOptions.api.getSelectedRows();
  //   if (selectedRows.length === 0) {
  //     this.gridOptions.getRowStyle = function (params) {
  //       if (params.data.selection === 'false') {
  //         return { background: '#eeeff0' };
  //       }
  //     };
  //   } else {
  //     selectedRows.forEach((rowNode) => {
  //       rowNode.selection = true;
  //       this.gridOptions.api.refreshCells({
  //         rowNodes: [rowNode],
  //         force: true
  //       });
  //       this.gridOptions.rowData.forEach((rowNodeGridOptions) => {
  //         if (rowNodeGridOptions.hostCorporateId
  //           && rowNodeGridOptions.companyId === rowNode.companyId) {
  //           rowNode.hostCorporateId = rowNodeGridOptions.hostCorporateId;
  //         }
  //       });
  //     });
  //   }
  //   console.log('masterData: ', this.gridOptions.rowData);
  //   // this.gridOptions.api.setRowData(this.gridOptions.rowData);
  //   // this.commonService.selectedConfMtgs.next(selectedRows);
  //   // this.touched = true;
  //   // this.onModelChange(this.value);
  //   // this.onModelTouched();
  //   // this.cdr.detectChanges();
  // }

  onFirstDataRendered(params) {
    if (window.screen.availWidth > 1366) {
      this.gridOptions.api.sizeColumnsToFit();
    }
    setTimeout(function () {
      // params.api.getDisplayedRowAtIndex(0).setExpanded(true);
      console.log('params: ', params);
    }, 0);
  }

  tooltipRenderer = function (params) {
    if (params.value === null) {
      return undefined;
    } else if (!params.data.hostCorporateId) {
      return '<span title="Host is mandatory, please select a host">' + params.value + '</span>';
    } else {
      return params.value;
    }
  };

  stateStyleRenderer = function (params) {
    if (params.value === null || params.value.toUpperCase() === 'NEW') {
      return undefined;
    } else {
      return convertToTitleCase(params.value);
    }
  };

  getAttendeeCount(meeting: any) {
    let attendeeTotalCount = '';
    let filAttendeeCount = 0;
    let thirdPartyAttendeeCount = 0;
    if (meeting.fidelityInvitees && meeting.fidelityInvitees.length > 0) {
      meeting.fidelityInvitees.forEach((invitee) => {
        if (invitee.name) {
          filAttendeeCount++;
        }
      })
    }
    if (meeting.thirdPartyAttendee && meeting.thirdPartyAttendee.length > 0) {
      meeting.thirdPartyAttendee.forEach((invitee) => {
        if (invitee.companyAttendee) {
          thirdPartyAttendeeCount++;
        }
      })
    }
    attendeeTotalCount = 'FIL : ' + filAttendeeCount + ', ' + 'Company : ' + thirdPartyAttendeeCount;
    return attendeeTotalCount;
  }
  ngAfterViewInit() {
    this.onModelChange(this.gridOptions.rowData);
    this.cdr.detectChanges();
  }

  styleMeetingState(params) {
    if (params.data.meetingState === 'NEW') {
      return {
        'color': '#eeeff0',
        'border-right': '4px solid #0bd2d2',
        'border-radius': '2px',
        'text-overflow': 'inherit'
      };
    } else if (params.data.meetingState === 'CONFIRMED') {
      return {
        'color': '#eeeff0',
        'border-right': '4px solid #82c823',
        'border-radius': '2px',
        'text-overflow': 'inherit'
      };
    } else if (params.data.meetingState === 'DRAFT') {
      return {
        'color': '#eeeff0',
        'border-right': '4px solid #ffc24d',
        'border-radius': '2px',
        'text-overflow': 'inherit'
      };
    } else if (params.data.meetingState === 'CANCELLED') {
      return {
        'color': '#414956',
        'border-right': '4px solid #e51e17',
        'text-overflow': 'inherit'
      };
    }
  }
  onRemoveClicked(params: any) {
    //Remove from Grid Row Data
    if (params.node.rowIndex !== -1) {
      this.rowData.splice(params.node.rowIndex, 1);
    }
    this.refreshGrid();
    if (this.gridOptions.rowData.length === 0) {
      this.autoHeight = false;
      this.gridOptions.api.setDomLayout('normal');
    }
    // this.commonService.rowSelectHeaderDisable.next(this.rowData.length === 0);
    this.value = Object.assign({}, this.gridOptions.rowData);
    this.touched = true;
    this.onModelChange(this.value);
    this.onModelTouched();
    //Remove from Conference Schedule
    const removedCompanyId = params.data.companyId;
    let removedCompanyRowIndexInSchedule: any;
    let conferenceSchedule = Object.assign({}, this.commonService.getConferenceSchedule());
    conferenceSchedule.eventMeetings.forEach((meeting, index) => {
      if (meeting.securityDetail.securityTradableEntityId === removedCompanyId) {
        removedCompanyRowIndexInSchedule = index;
      }
    });
    // console.log('removedCompanyRowIndexInSchedule: ', removedCompanyRowIndexInSchedule);
    // console.log('conferenceScheduleeventMeetings: ', conferenceSchedule.eventMeetings);
    conferenceSchedule.eventMeetings.splice(removedCompanyRowIndexInSchedule, 1);
    this.commonService.setConferenceSchedule(conferenceSchedule);
    this.cdr.detectChanges();
  }
  private refreshGrid() {
    this.rowData.forEach((rowNode, index) => {
      rowNode.index = index + 1;
    });
    this.gridOptions.api.setRowData(this.rowData);
  }
  refreshCellsForSelectedHost(rowIndex: any, callLocation: string) {
    this.gridOptions.api.forEachNode((node) => {
      if (node.rowIndex === rowIndex) {
        // if (callLocation === 'radioButton') {
        this.gridOptions.api.refreshCells({
          rowNodes: [node],
          force: true
        });
        // }
      }
    });
  }
  getCompanyNameClass(params) {
    if (!params.data.hostCorporateId) {
      return ['infoIconCompanyName'];
    } else {
      return ['removeIcon']
    }
  }

  enableEditableFields(isEnable: boolean, rowIndex) {
    this.isEditableFieldsEnabled = isEnable;
    if (isEnable) {
      this.gridOptions.api.forEachNode((node) => {
        if (node.rowIndex === rowIndex) {
          node.setSelected(true);
        }
      });
      this.gridOptions.api.getDisplayedRowAtIndex(rowIndex).setExpanded(true);
    } else {
      this.gridOptions.api.forEachNode((node) => {
        if (node.rowIndex === rowIndex) {
          node.setSelected(false);
        }
      });
      this.gridOptions.api.getDisplayedRowAtIndex(rowIndex).setExpanded(false);
    }
    this.gridOptions.api.forEachNode((node) => {
      if (node.rowIndex === rowIndex) {
        this.gridOptions.api.refreshCells({
          rowNodes: [node],
          force: true
        });
      }
    });
  }
  // resetRowSelections() {
  //   console.log(this.gridOptions.rowData);
  //   this.gridOptions.isRowSelectable = function (node) {
  //     console.log('adasdsadasdsakjdnsjandkajsd: ', node);
  //     return node.data ? (node.data.meetingDate && node.data.meetingTime) : false;;
  //   };
  //   this.gridOptions.api.setRowData(this.gridOptions.rowData);
  // }
}
