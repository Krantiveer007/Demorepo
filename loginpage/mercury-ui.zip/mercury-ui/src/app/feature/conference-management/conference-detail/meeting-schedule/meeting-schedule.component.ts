import { Component, OnInit, NgZone, Input } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TypeaheadData, TypeaheadDataSource } from 'src/app/shared/utils/typeahead.utility';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable, EMPTY } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { CompanyRendererComponent } from 'src/app/feature/conference-management/conference-detail/meeting-schedule/company-renderer/company-renderer.component';
import { TitleCasePipe } from '@angular/common';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { AttendeeRendererComponent } from 'src/app/feature/conference-management/conference-detail/meeting-schedule/attendee-renderer/attendee-renderer.component';
import { Router } from '@angular/router';
import { ConferenceSchedule } from 'src/app/shared/models/conferenceSchedule.model';
import { Meeting } from "src/app/shared/models/meeting.model";
import { MeetingSubtype } from 'src/app/shared/models/meetingsubtype.model';
import { Country } from 'src/app/shared/models/country.model';
import { SecurityDetails } from 'src/app/shared/models/securitydetails.model';
import { AssociatedEventDetail } from 'src/app/shared/models/associatedeventdetail.model';
import { MeetingCreator } from 'src/app/shared/models/meetingcreator.model';
import { DebtTickerDetail } from 'src/app/shared/models/debtTickerDetail.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
import { DialIn } from 'src/app/shared/models/dialin.model';
import { MeetingLocation } from 'src/app/shared/models/meetinglocation.model';
import { MeetingInitiator } from 'src/app/shared/models/meetinginitiator.model';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { GridOptions } from 'ag-grid-community';
import * as moment from 'moment';



@Component({
  selector: 'mv2-meeting-schedule',
  templateUrl: './meeting-schedule.component.html',
  styleUrls: ['./meeting-schedule.component.css']
})
export class MeetingScheduleComponent implements OnInit {

  companyTypes = [
    { keyDesc: 'Equity', keyCode: 'EQ', label: "Security Name" },
    { keyDesc: 'Fixed Income', keyCode: 'FI', label: "Debt Ticker" },
    { keyDesc: 'Broker', keyCode: 'Broker', label: "Broker Firm" },
    { keyDesc: 'Other', keyCode: 'Other', label: "Meeting Topic" }
  ]

  viewType = 'attendee';

  selectedType = { keyDesc: 'Equity', keyCode: 'EQ', label: "Security Name" };

  meetingScheduleForm = this.fb.group({
    attendeeName: [''],
    attendeeCorpId: [''],
    securityName: '',
    securityTradableEntityId: '',
    securityBBTicker: '',
    securityTicker: '',
    securityTseCode: '',
    companyType: ['EQ'],
    debtTicker: [''],
    brokerFirmName: [''],
    brokerFirmId: [''],
    companyName: [''],
    analystName: [''],
    analystCorporateId: ['']
  });
  securityLoading: boolean;
  selectedSecurityDetail: any;
  selectedParameter: string;
  isValidSecurity = false;
  errorResponse = false;
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  securityDataSource: Observable<any>;
  bbCodeDataObservable: Observable<any>;
  debtTickerDataSource: Observable<any>;
  isValidDebtTicker = false;

  peopleDataSource: Observable<any>;
  isValidHost = false;
  hostErrorResponse = false;
  typeaheadLoading: boolean;

  debtTickerErrorResponse = false;
  debtTickerTypeaheadLoading: boolean;
  brokerFirmTypeaheadLoading: boolean;


  brokerFirmDataSource: Observable<any>;
  isValidBrokerFirm = false;
  brokerFirmErrorResponse = false;


  allCompanies = [];
  frameworkComponents;
  searchTerm = '';
  gridOptions: GridOptions;
  columnDefs;

  allAttendees = [];
  attendeesframeworkComponents;
  attendeesSearchTerm = '';
  attendeesGridOptions: GridOptions;
  attendeesColumnDefs;

  companySchedules = [];
  attendeeSchedules = [];
  scheduleId = 0;
  existingCompanies = [];
  existingAttendees = [];


  constructor(private fb: FormBuilder, private router: Router, private commonService: CommonService, private ngZone: NgZone, private titleCase: TitleCasePipe) { }

  ngOnInit() {
    this.populateMappings();
    this.gridOptions = <GridOptions>{
      defaultColDef: {
        suppressMenu: true,

      },
      context: {
        componentParent: this
      },
      enableColResize: false,
      enableSorting: true,
      suppressDragLeaveHidesColumns: true,
      toolPanelSuppressSideButtons: true,
      rowSelection: 'single',
      suppressCellSelection: true,
      suppressRowClickSelection: true,
      suppressHorizontalScroll: true,
      headerHeight: 0,
      rowHeight: 45,
      rowClass: ['regular-text-cell', 'alpha-background-transparent'],
      onGridReady: (params) => {
        params.api.sizeColumnsToFit();
        params.api.hideOverlay();
      },
      // getRowNodeId: function (data) {
      //   return data.shortName;
      // }
    };

    if (this.viewType === 'attendee') {
      this.gridOptions.rowSelection = 'multiple'
    }

    // this.frameworkComponents = {
    //   cellRendererFramework: CompanyRendererComponent
    // };
    this.createGridColumns();

    this.attendeesGridOptions = <GridOptions>{
      defaultColDef: {
        suppressMenu: true,
        resizable: true
      },
      context: {
        componentParent: this
      },
      enableColResize: false,
      enableSorting: true,
      suppressDragLeaveHidesColumns: true,
      toolPanelSuppressSideButtons: true,
      rowSelection: 'multiple',
      suppressRowClickSelection: true,
      suppressCellSelection: true,
      suppressHorizontalScroll: true,
      headerHeight: 0,
      rowHeight: 45,
      rowClass: ['regular-text-cell', 'alpha-background-transparent'],
      onGridReady: (params) => {
        params.api.sizeColumnsToFit();
        params.api.hideOverlay();
      },
      // getRowNodeId: function (data) {
      //   return data.shortName;
      // }
    };

    if (this.viewType === 'attendee') {
      this.attendeesGridOptions.rowSelection = 'single'
    }

    // this.attendeesframeworkComponents = {
    //   cellRendererFramework: AttendeeRendererComponent
    // };
    this.createAttendeesGridColumns();
  }

  createGridColumns() {
    // if (this.viewType === "company") {
    this.columnDefs = [
      {
        headerName: "", field: "name", headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: { "padding-left": "10px", "padding-right": 0 }, cellRendererFramework: CompanyRendererComponent,
        suppressMovable: true
      }
    ]
    // } else {
    //   this.columnDefs = [
    //     {
    //       headerName: "", field: "", width: 20, headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: {"padding-left": "10px", "padding-right": 0, "line-height": 3.5},
    //       suppressMovable: true, checkboxSelection:true
    //     },
    //     {
    //       headerName: "", field: "name", width: 350, headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: {"padding-left": 0, "padding-right": 0}, cellRendererFramework: CompanyRendererComponent,
    //       suppressMovable: true
    //     }
    //   ]
    // }
  }

  createAttendeesGridColumns() {
    // if (this.viewType === "company") {  
    //   this.attendeesColumnDefs = [
    //     {
    //       headerName: "", field: "", width: 20, headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: {"padding-left": "10px", "padding-right": 0, "line-height": 3.5},
    //       suppressMovable: true, checkboxSelection:true
    //     },
    //     {
    //       headerName: "", field: "name", width: 350, headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: {"padding-left": 0, "padding-right": 0}, cellRendererFramework: AttendeeRendererComponent,
    //       suppressMovable: true
    //     }
    //   ];
    // } else {
    this.attendeesColumnDefs = [
      {
        headerName: "", field: "name", headerClass: 'alpha-hide-element', cellClass: 'alpha-row-cell alpha-cell', cellStyle: { "padding-left": "10px", "padding-right": 0 }, cellRendererFramework: AttendeeRendererComponent,
        suppressMovable: true
      }
    ];
    // }
  }

  populateMappings() {
    let conferenceSchedule = this.commonService.getConferenceSchedule();
    let meetings = conferenceSchedule ? conferenceSchedule.eventMeetings : [];
    if (meetings.length > 0) {
      meetings.forEach((meeting) => {
        let scheduleCompObj = {};
        this.setNameAndIdForSchedule(scheduleCompObj, meeting);
        scheduleCompObj["ticker"] = meeting.securityDetail.ticker ? meeting.securityDetail.ticker : '';;
        scheduleCompObj["subType"] = meeting.meetingSubType.meetingSubTypeCode;
        scheduleCompObj["meetingType"] = this.getMeetingType(meeting);
        scheduleCompObj["scheduleId"] = meeting.scheduleId;
        this.allCompanies.push(scheduleCompObj);
        meeting.fidelityInvitees.forEach((invitee) => {
          if (this.allAttendees.filter((attendee) => (attendee.corporateId === invitee.corporateId)).length === 0) {
            this.existingAttendees.push(invitee.corporateId);
            let scheduleAttendeeObj = {};
            scheduleAttendeeObj["name"] = invitee.name;
            scheduleAttendeeObj["corporateId"] = invitee.corporateId;
            // scheduleAttendeeObj["host"] = invitee.host; -- attendee can be host in one company and not in another
            this.allAttendees.push(scheduleAttendeeObj);
          }
        });
        this.scheduleCompany(meeting, meeting.fidelityInvitees);
      });
      this.companySchedules.forEach((companySchedule) => {
        if (companySchedule.isExisting) {
          this.existingCompanies.push(companySchedule.scheduleId);
        }
      });
      this.transformToAtendeeSchedule();
      // this.scheduleMeetings(this.allCompanies, this.allAttendees);
    }
  }

  scheduleCompany(company, attendees) {
    let scheduleCompObj = {};
    this.setNameAndIdForSchedule(scheduleCompObj, company);
    scheduleCompObj["ticker"] = company.securityDetail.ticker ? company.securityDetail.ticker : '';
    scheduleCompObj["subType"] = company.meetingSubType.meetingSubTypeCode;
    scheduleCompObj["meetingType"] = this.getMeetingType(company);
    scheduleCompObj["scheduleId"] = company.scheduleId;
    scheduleCompObj["isExisting"] = true;
    scheduleCompObj["attendees"] = [];
    attendees.forEach((attendee) => {
      let scheduleAttendeeObj = {};
      scheduleAttendeeObj["name"] = attendee.name;
      scheduleAttendeeObj["corporateId"] = attendee.corporateId;
      scheduleAttendeeObj["isHost"] = (attendee.host || ((attendee.host === undefined) && attendee.corporateId === company.hostCorporateId));
      scheduleCompObj["attendees"].push(scheduleAttendeeObj);
    });
    this.companySchedules.unshift(scheduleCompObj);
    // this.companySchedules.push(scheduleCompObj);      
  }

  setNameAndIdForSchedule(schedule, company) {
    const meetingType = this.getMeetingType(company);
    if (meetingType === 'EQ') {
      schedule["name"] = company.securityDetail.securityName;
      schedule["companyId"] = company.securityDetail.securityTradableEntityId;
    } else if (meetingType === 'FI'){
      schedule["name"] = company.debtTickerDetail.debtTicker;
      schedule["companyId"] = company.debtTickerDetail.debtTicker;
    } else if (meetingType === 'Broker') {
      schedule["name"] = company.brokerDetail.brokerFirmName;
      schedule["companyId"] = company.brokerDetail.brokerFirmId;
    } else if (meetingType === 'Other') {
      schedule["name"] = company.meetingTopic;
      schedule["companyId"] = company.meetingTopic;
    }

  }
 
  getMeetingType(meeting) {
    if (meeting.meetingType.includes("Company")) {
      return meeting.businessEntity;
    } else {
      return meeting.meetingType;
    }
  }

  onTypeChange(event) {
    this.selectedType = event;
    this.resetMappings();
  }

  resetMappings() {
    this.meetingScheduleForm.patchValue({
      securityName: '',
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: '',
      brokerFirmName: '',
      brokerFirmId: '',
      attendeeName: '',
      attendeeCorpId: '',
      debtTicker: ''
    });
  }

  getSecurities(): void {
    let typeaheadData: TypeaheadData;
    this.isValidSecurity = false;
    this.meetingScheduleForm.patchValue({
      securityTradableEntityId: '',
      securityBBTicker: '',
      securityTicker: '',
      securityTseCode: ''
    });
    const searchedValue = this.meetingScheduleForm.get('securityName').value;
    typeaheadData = this.typeaheadDataSource.getSecurities(searchedValue);
    this.securityDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
    if (searchedValue.length < 3 || this.securityDataSource === EMPTY || this.errorResponse) {
      this.selectedParameter = '';
    }
  }

  getDebtTicker() {
    this.debtTickerDataSource = EMPTY;
    let typeaheadData: TypeaheadData;
    this.isValidDebtTicker = false;
    const searchedValue = this.meetingScheduleForm.get('debtTicker').value;
    typeaheadData = this.typeaheadDataSource.getDebtTicker(searchedValue);
    this.debtTickerDataSource = typeaheadData.dataSource;
    this.debtTickerErrorResponse = typeaheadData.isResponseError;
  }

  getPeopleData(): void {
    let typeaheadData: TypeaheadData;
    this.isValidHost = false;
    this.meetingScheduleForm.get('attendeeName').setErrors({ 'invalidHost': true });
    const searchedValue = this.meetingScheduleForm.get('attendeeName').value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    this.hostErrorResponse = typeaheadData.isResponseError;
    if (this.hostErrorResponse) {
      this.meetingScheduleForm.get('attendeeName').setErrors({ 'incorrect': true });
    }
    // if (searchedValue.length < 3) {
    //   let hostDetail = {
    //     'hostName': '',
    //     'hostCorpId': '',
    //     'hostPhoneNumber': '',
    //     'primaryAnalystName': '',
    //     'primaryAnalystId': ''
    //   }
    //   this.commonService.changeHostDetails(hostDetail);
    // }
  }

  getBrokerFirm() {
    this.brokerFirmDataSource = EMPTY;
    let typeaheadData: TypeaheadData;
    this.isValidBrokerFirm = false;
    const searchedValue = this.meetingScheduleForm.get('brokerFirmName').value;
    typeaheadData = this.typeaheadDataSource.getBrokerFirms(searchedValue);
    this.brokerFirmDataSource = typeaheadData.dataSource;
    this.brokerFirmErrorResponse = typeaheadData.isResponseError;
  }

  onSecurityBlur() {
    if (this.meetingScheduleForm.get('companyType').value === 'EQ') {
      if (!this.isValidSecurity) {
        this.meetingScheduleForm.patchValue({
          securityName: '',
          securityTradableEntityId: '',
          securityBBTicker: '',
          securityTicker: '',
          securityTseCode: ''
        });
        this.selectedParameter = '';
        this.securityLoading = false;
        this.getSecurities();
      }
    } else {
      if (!this.isValidDebtTicker) {
        this.meetingScheduleForm.patchValue({
          debtTicker: '',
        });
        this.debtTickerTypeaheadLoading = false;
        this.getDebtTicker();
      }
    }
  }

  typeaheadOnSelect(event: TypeaheadMatch, dropDownType: string): void {
    let attendeeDetail = {
      'attendeeName': '',
      'attendeeCorpId': '',
    }

    if (dropDownType === 'Security') {
      // this.isHostAlreadyAddedAsAttendee = false;
      // remove company if already Exist
      // this.removeCompany(event.item);
      this.isValidSecurity = true;
      const selectedSecurityInstance = event.item;
      selectedSecurityInstance["scheduleId"] = moment.utc().valueOf();
      selectedSecurityInstance["name"] = selectedSecurityInstance.instrumentLongName;
      selectedSecurityInstance["companyId"] = selectedSecurityInstance.tradableEntId;
      this.allCompanies.unshift(selectedSecurityInstance);
      // this.allCompanies.push(event.item);

      if (this.viewType === "company") {
        this.attendeesGridOptions.api.setRowData(this.allAttendees);
        this.gridOptions.api.setRowData(this.allCompanies);
      } else if (this.viewType === "attendee") {
        var res = this.gridOptions.api.updateRowData({
          add: [selectedSecurityInstance],
          addIndex: 0
        });
      }

      this.selectedSecurityDetail = selectedSecurityInstance;
      this.selectedParameter = event.item.itemValue;
      this.selectedParameter = this.selectedParameter.split('&lt;').join('<').split('&gt;').join('>');
      // this.commonService.changeMessage(selectedSecurityInstance.instrumentLongName);
      // this.commonService.searchedSecurityChange(selectedSecurityInstance.tradableEntId);
      // this.commonService.setSecurityDetails(selectedSecurityInstance, 'create');
      // this.meetingScheduleForm.patchValue({
      //   securityName: selectedSecurityInstance.instrumentLongName ? selectedSecurityInstance.instrumentLongName : '',
      //   securityTradableEntityId: selectedSecurityInstance.tradableEntId ? selectedSecurityInstance.tradableEntId : '',
      //   securityBBTicker: selectedSecurityInstance.bbCode ? selectedSecurityInstance.bbCode : '',
      //   securityTicker: selectedSecurityInstance.ticker ? selectedSecurityInstance.ticker : '',
      //   securityTseCode: selectedSecurityInstance['tseCode'] ? selectedSecurityInstance.tseCode : '',
      //   attendeeName: '',
      //   attendeeCorpId: ''
      // });

      // this.bbCodeDataObservable = this.commonService.getBBCodeForTradEntId(this.meetingScheduleForm.get('securityTradableEntityId').value);
      // this.bbCodeDataObservable.subscribe((response) => {
      //     this.meetingScheduleForm.patchValue({
      //     securityBBTicker: response.data[0].bbCode ? response.data[0].bbCode : '',
      //     securityTseCode: response.data[0].tseCode ? response.data[0].tseCode : '',
      //     securityTicker: response.data[0].ticker ? response.data[0].ticker : ''
      //   });
      // }, (error) => {
      //   console.log("error fetching bbcode")
      // });
      this.searchTerm = '';
      this.meetingScheduleForm.patchValue({
        securityName: '',
        securityTradableEntityId: '',
        securityBBTicker: '',
        securityTicker: '',
        securityTseCode: ''
      });
      this.securityLoading = false;
      this.gridOptions.api.setQuickFilter(this.searchTerm);
    } else if (dropDownType === 'Host') {
      // remove attendee if already Exist
      // this.removeAttendee(event.item);
      if (this.isAttendeeAdded(event.item)) {
        alert("Attendee already added. Please do quick search to find the same.");
      } else {
        this.allAttendees.unshift(event.item);
        if (this.viewType === "attendee") {
          this.gridOptions.api.setRowData(this.allCompanies);
          this.attendeesGridOptions.api.setRowData(this.allAttendees);
        } else if (this.viewType === "company") {
          var res = this.attendeesGridOptions.api.updateRowData({
            add: [event.item],
            addIndex: 0
          });
        }
      }
      this.isValidHost = true;
      // this.meetingScheduleForm.patchValue({
      //   'attendeeName': convertToTitleCase(event.item.name),
      //   'attendeeCorpId': event.item.corporateId,
      // });

      // this.allAttendees.push(event.item);

      attendeeDetail.attendeeName = this.meetingScheduleForm.get('attendeeName').value;
      attendeeDetail.attendeeCorpId = this.meetingScheduleForm.get('attendeeCorpId').value;
      this.attendeesSearchTerm = '';
      this.meetingScheduleForm.patchValue({
        attendeeName: '',
        attendeeCorpId: ''
      });
      this.typeaheadLoading = false;
      this.attendeesGridOptions.api.setQuickFilter(this.attendeesSearchTerm);
    } else if (dropDownType === 'DebtTicker') {
      // this.removeCompany(event.item);
      const selectedSecurityInstance = event.item;
      selectedSecurityInstance["scheduleId"] = moment.utc().valueOf();
      selectedSecurityInstance["name"] = selectedSecurityInstance.debtTicker;
      selectedSecurityInstance["companyId"] = selectedSecurityInstance.name;
      this.allCompanies.unshift(selectedSecurityInstance);
      // this.allCompanies.push(event.item);
      if (this.viewType === "company") {
        this.attendeesGridOptions.api.setRowData(this.allAttendees);
        this.gridOptions.api.setRowData(this.allCompanies);
      } else if (this.viewType === "attendee") {
        var res = this.gridOptions.api.updateRowData({
          add: [selectedSecurityInstance],
          addIndex: 0
        });
      }
      this.meetingScheduleForm.patchValue({
        debtTicker: ''
      });
      this.isValidDebtTicker = true;
    } else if (dropDownType === 'BrokerFirm') {
      // this.removeCompany(event.item);
      const selectedSecurityInstance = event.item;
      selectedSecurityInstance["scheduleId"] = moment.utc().valueOf();
      selectedSecurityInstance["name"] = selectedSecurityInstance.firmName;
      selectedSecurityInstance["companyId"] = selectedSecurityInstance.firmId;
      this.allCompanies.unshift(selectedSecurityInstance);
      // this.allCompanies.push(event.item);
      if (this.viewType === "company") {
        this.attendeesGridOptions.api.setRowData(this.allAttendees);
        this.gridOptions.api.setRowData(this.allCompanies);
      } else if (this.viewType === "attendee") {
        var res = this.gridOptions.api.updateRowData({
          add: [selectedSecurityInstance],
          addIndex: 0
        });
      }
      this.meetingScheduleForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.isValidBrokerFirm = true;
    }

  }

  addOtherMeeting() {
    const otherMeeting = {
      companyName: this.meetingScheduleForm.get('companyName').value
    }
    // this.removeCompany(otherMeeting);
    otherMeeting["scheduleId"] = moment.utc().valueOf();
    otherMeeting["name"] = this.meetingScheduleForm.get('companyName').value;
    otherMeeting["companyId"] = this.meetingScheduleForm.get('companyName').value;
    this.allCompanies.unshift(otherMeeting);
    // this.allCompanies.push(otherMeeting);
    if (this.viewType === "company") {
      this.attendeesGridOptions.api.setRowData(this.allAttendees);
      this.gridOptions.api.setRowData(this.allCompanies);
    } else if (this.viewType === "attendee") {
      var res = this.gridOptions.api.updateRowData({
        add: [otherMeeting],
        addIndex: 0
      });
    }
    this.meetingScheduleForm.patchValue({
      companyName: ''
    });
    this.isValidBrokerFirm = true;
  }

  removeAttendee(attendeeToBeRemove) {
    const attendeeToBeRemoveIndex = this.allAttendees.findIndex((attendee) => (attendee.corporateId === attendeeToBeRemove.corporateId));
    if (attendeeToBeRemoveIndex >= 0 && attendeeToBeRemoveIndex < this.allAttendees.length) {
      this.allAttendees.splice(attendeeToBeRemoveIndex, 1);
    }
  }

  isAttendeeAdded(attendeeToBeSearch) {
    const attendeeToBeRemoveIndex = this.allAttendees.findIndex((attendee) => (attendee.corporateId === attendeeToBeSearch.corporateId));
    if (attendeeToBeRemoveIndex >= 0 && attendeeToBeRemoveIndex < this.allAttendees.length) {
      return true;
    }
    return false;
  }

  // removeCompany(companyToBeRemove) {
  //   let companyToBeRemoveIndex;
  //   if (this.selectedType.keyCode === "EQ") {
  //     companyToBeRemoveIndex = this.allCompanies.findIndex((company) => (company.tradableEntId === companyToBeRemove.tradableEntId));
  //   } else if (this.selectedType.keyCode === "FI") {
  //     companyToBeRemoveIndex = this.allCompanies.findIndex((company) => (company.debtTicker === companyToBeRemove.debtTicker));
  //   } else if (this.selectedType.keyCode === "Broker") {
  //     companyToBeRemoveIndex = this.allCompanies.findIndex((company) => (company.firmId === companyToBeRemove.firmId));
  //   } else if (this.selectedType.keyCode === "Other") {
  //     companyToBeRemoveIndex = this.allCompanies.findIndex((company) => (company.companyName === companyToBeRemove.companyName));
  //   }

  //   if (companyToBeRemoveIndex >= 0 && companyToBeRemoveIndex < this.allCompanies.length) {
  //     this.allCompanies.splice(companyToBeRemoveIndex, 1);
  //   }
  // }

  typeaheadNoResults(event: boolean, dropDownType: string): void {
    if (dropDownType === 'Security') {
      this.errorResponse = event;
    }
    if (dropDownType === 'Host') {
      this.hostErrorResponse = event;
    }
    if (dropDownType === 'DebtTicker') {
      this.debtTickerErrorResponse = event;
    }
  }

  changeTypeaheadLoading(e: boolean, dropDownType: string): void {
    if (dropDownType === 'Security') {
      this.securityLoading = e;
    } else if (dropDownType === 'Host') {
      this.typeaheadLoading = e;
    } else if (dropDownType === 'DebtTicker') {
      this.debtTickerTypeaheadLoading = e;
    } else if (dropDownType === 'BrokerFirm') {
      this.brokerFirmTypeaheadLoading = e;
    }
  }

  onBlurMethod() {
    if (!this.isValidHost) {
      this.meetingScheduleForm.patchValue({
        attendeeName: ''
      });
      this.typeaheadLoading = false;
      this.getPeopleData();
    }
  }
  scheduleMeetings(companies?, attendees?) {

    if (companies === undefined) {
      companies = []; attendees = [];
      let selectedCompanies = this.gridOptions.api.getSelectedNodes();
      let selectedAttendees = this.attendeesGridOptions.api.getSelectedNodes();
      selectedCompanies.forEach((company) => {
        companies.push(company.data);
      });
      selectedAttendees.forEach((attendee) => {
        attendees.push(attendee.data);
      });
    }
    if (companies.length > 0 && attendees.length > 0) {
      if (this.viewType === 'company') {
        companies.forEach((company) => {
          this.removeDuplicateCompany(company);
          let scheduleCompObj = {};
          scheduleCompObj["name"] = company.name;
          scheduleCompObj["companyId"] = company.companyId;
          scheduleCompObj["ticker"] = company.ticker ? company.ticker : '';
          scheduleCompObj["subType"] = company.subType;
          scheduleCompObj["meetingType"] = company.meetingType;
          scheduleCompObj["scheduleId"] = company.scheduleId;
          if (this.existingCompanies.includes(company.scheduleId)) {
            scheduleCompObj["isExisting"] = true;
          }
          scheduleCompObj["attendees"] = [];
          attendees.forEach((attendee) => {
            let scheduleAttendeeObj = {};
            scheduleAttendeeObj["name"] = attendee.name;
            scheduleAttendeeObj["corporateId"] = attendee.corporateId;
            scheduleAttendeeObj["isHost"] = attendee.host;
            scheduleCompObj["attendees"].push(scheduleAttendeeObj);
          });
          this.companySchedules.unshift(scheduleCompObj);
          // this.companySchedules.push(scheduleCompObj);      
        });
        this.transformToAtendeeSchedule();
      }
      if (this.viewType === 'attendee') {
        attendees.forEach((attendee) => {
          this.removeDuplicateAttendee(attendee);
          let scheduleAttendeeObj = {};
          scheduleAttendeeObj["name"] = attendee.name;
          scheduleAttendeeObj["corporateId"] = attendee.corporateId;
          if (this.existingAttendees.includes(attendee.corporateId)) {
            scheduleAttendeeObj["isExisting"] = true;
          }
          scheduleAttendeeObj["companies"] = [];
          companies.forEach((company) => {
            let scheduleCompObj = {};
            scheduleCompObj["name"] = company.name;
            scheduleCompObj["companyId"] =  company.companyId;
            scheduleCompObj["ticker"] = company.ticker ? company.ticker : '';
            scheduleCompObj["subType"] = company.subType;
            scheduleCompObj["isHost"] = company.host;
            scheduleCompObj["meetingType"] = company.meetingType;
            scheduleCompObj["scheduleId"] = company.scheduleId;
            scheduleAttendeeObj["companies"].push(scheduleCompObj);
          });
          this.attendeeSchedules.unshift(scheduleAttendeeObj);
        });
        this.transformToCompanySchedule();
      }
      if (this.gridOptions) {
        this.gridOptions.api.setRowData(this.allCompanies);
        this.attendeesGridOptions.api.setRowData(this.allAttendees);
      }
    } else {
      alert("Please select company and attendee(s).");
    }

    // schedules = [
    //   {
    //     name: "Company 1",
    //     subType: "1:1 Meeting",
    //  meetingType: "EQ", 
    //     attendees: [
    //       {
    //         name: "Honey Satya",
    //         corpId: "A564512",
    //         isHost: false
    //       },
    //       {
    //         name: "Amit Pandey",
    //         corpId: "A562512",
    //         isHost: true
    //       }
    //     ]
    //   },
    //   {
    //     name: "Company 2",
    //     subType: "Group",
    //     attendees: [
    //       {
    //         name: "Honey Satya",
    //         corpId: "A564512",
    //         isHost: true
    //       }
    //     ]
    //   },
    //   ];
  }

  removeDuplicateAttendee(attendee) {
    const attendeeToBeRemoveIndex = this.attendeeSchedules.findIndex((attendeeSchedule) => (attendeeSchedule.corporateId === attendee.corporateId));
    if (attendeeToBeRemoveIndex >= 0 && attendeeToBeRemoveIndex < this.attendeeSchedules.length) {
      this.attendeeSchedules.splice(attendeeToBeRemoveIndex, 1);
    }
  }

  removeDuplicateCompany(company) {
    const companyToBeRemoveIndex = this.companySchedules.findIndex((companySchedule) => (companySchedule.scheduleId === company.scheduleId));
    if (companyToBeRemoveIndex >= 0 && companyToBeRemoveIndex < this.companySchedules.length) {
      this.companySchedules.splice(companyToBeRemoveIndex, 1);
    }
  }

  removeScheduledCompany(companyIndex) {
    this.companySchedules.splice(companyIndex, 1);
  }

  removeScheduledAttendee(attendeeIndex) {
    this.attendeeSchedules.splice(attendeeIndex, 1);
  }

  // removeScheduledAttendee(companyIndex, attendeeIndex) {
  //   this.companySchedules[companyIndex].attendees.splice(attendeeIndex, 1);
  //   if (this.companySchedules[companyIndex].attendees.length === 0) {
  //     this.companySchedules.splice(companyIndex, 1);
  //   }
  // }

  onCompanySearch(event) {
    this.searchTerm = event.target.value;
    this.gridOptions.api.setQuickFilter(event.target.value);
  }

  onAttendeeSearch(event) {
    this.attendeesSearchTerm = event.target.value;
    this.attendeesGridOptions.api.setQuickFilter(event.target.value);
  }

  onBrokerFirmBlur() {
    if (!this.isValidBrokerFirm) {
      this.meetingScheduleForm.patchValue({
        brokerFirmName: '',
        brokerFirmId: ''
      });
      this.brokerFirmTypeaheadLoading = false;
      this.getBrokerFirm();
    }
  }
  changeView(viewType) {
    this.viewType = viewType;

    if (viewType === "company") {
      this.gridOptions.rowSelection = 'single';
      this.attendeesGridOptions.rowSelection = 'multiple';
      this.transformToCompanySchedule();
    } else if (viewType === "attendee") {
      this.gridOptions.rowSelection = 'multiple';
      this.attendeesGridOptions.rowSelection = 'single';
      this.transformToAtendeeSchedule();
    }

    this.gridOptions.api.setRowData(this.allCompanies);
    this.attendeesGridOptions.api.setRowData(this.allAttendees);

    // this.gridOptions.api.setColumnDefs(this.columnDefs);
    // this.attendeesGridOptions.api.setColumnDefs(this.attendeesColumnDefs);
  }

  transformToCompanySchedule() {
     // existing companies
    this.companySchedules = [];
    this.attendeeSchedules.forEach(attendeeSchedule => {
      attendeeSchedule.companies.forEach(company => {
        let existingCompanySchedule = this.companySchedules.filter(companySchedule => (companySchedule.scheduleId === company.scheduleId));
        if (existingCompanySchedule.length > 0) {
          if (this.existingCompanies.includes(existingCompanySchedule[0].scheduleId)) {
            existingCompanySchedule[0]["isExisting"] = true;
          }
          let existingAttendee = existingCompanySchedule[0].attendees.filter(attendee => (attendeeSchedule.corporateId === attendee.corporateId));
          if (existingAttendee.length === 0) {
            let attendeeObj = {};
            attendeeObj["name"] = attendeeSchedule.name;
            attendeeObj["corporateId"] = attendeeSchedule.corporateId;
            attendeeObj["isHost"] = company.isHost;
            existingCompanySchedule[0].attendees.push(attendeeObj);
          }
        } else {
          let scheduleCompObj = {};
          scheduleCompObj["name"] = company.name;
          scheduleCompObj["companyId"] =  company.companyId;
          scheduleCompObj["ticker"] = company.ticker;
          scheduleCompObj["subType"] = company.subType;
          scheduleCompObj["meetingType"] = company.meetingType;
          scheduleCompObj["scheduleId"] = company.scheduleId;
          if (this.existingCompanies.includes(company.scheduleId)) {
            scheduleCompObj["isExisting"] = true;
          }
          scheduleCompObj["attendees"] = [];
          let scheduleAttendeeObj = {};
          scheduleAttendeeObj["name"] = attendeeSchedule.name;
          scheduleAttendeeObj["corporateId"] = attendeeSchedule.corporateId;
          scheduleAttendeeObj["isHost"] = company.isHost;
          scheduleCompObj["attendees"].push(scheduleAttendeeObj);
          this.companySchedules.unshift(scheduleCompObj);
        }
      });
    });
  }

  transformToAtendeeSchedule() {
    // existing attendees
    this.attendeeSchedules = [];
    this.companySchedules.forEach(companySchedule => {
      companySchedule.attendees.forEach(attendee => {
        let existingAttendeeSchedule = this.attendeeSchedules.filter(attendeeSchedule => (attendeeSchedule.corporateId === attendee.corporateId));
        if (existingAttendeeSchedule.length > 0) {
          if (this.existingAttendees.includes(existingAttendeeSchedule[0].corporateId)) {
            existingAttendeeSchedule[0]["isExisting"] = true;
          }
          let existingCompany = existingAttendeeSchedule[0].companies.filter(company => (companySchedule.scheduleId === company.scheduleId));
          if (existingCompany.length === 0) {
            let companyObj = {};
            companyObj["name"] = companySchedule.name;
            companyObj["companyId"] = companySchedule.companyId;
            companyObj["ticker"] = companySchedule.ticker;
            companyObj["subType"] = companySchedule.subType;
            companyObj["meetingType"] = companySchedule.meetingType;
            companyObj["scheduleId"] = companySchedule.scheduleId;
            companyObj["isHost"] = attendee.isHost;
            // if (companySchedule.isExisting) {
            //   existingAttendeeSchedule[0]["isExisting"] = companySchedule.isExisting;
            // }
            existingAttendeeSchedule[0].companies.push(companyObj);
          }
        } else {
          let scheduleAttendeeObj = {};
          scheduleAttendeeObj["name"] = attendee.name;
          scheduleAttendeeObj["corporateId"] = attendee.corporateId;
          if (this.existingAttendees.includes(attendee.corporateId)) {
            scheduleAttendeeObj["isExisting"] = true;
          }
          scheduleAttendeeObj["companies"] = [];
          let scheduleCompObj = {};
          scheduleCompObj["name"] = companySchedule.name;
          scheduleCompObj["companyId"] =  companySchedule.companyId;
          scheduleCompObj["ticker"] = companySchedule.ticker;
          scheduleCompObj["subType"] = companySchedule.subType;
          scheduleCompObj["isHost"] = attendee.isHost;
          scheduleCompObj["meetingType"] = companySchedule.meetingType;
          scheduleCompObj["scheduleId"] = companySchedule.scheduleId;
          scheduleAttendeeObj["companies"].push(scheduleCompObj);
          this.attendeeSchedules.unshift(scheduleAttendeeObj);
        }
      });
    });
  }

  cancelScheduleMettings() {
    let conferenceSchedule = this.commonService.getConferenceSchedule();
    this.router.navigate(['/conference/update', { eventId: conferenceSchedule.eventId }], { skipLocationChange: true });
  }

  saveToConference() {
    if (this.viewType === "attendee") {
      this.transformToCompanySchedule();
    }
    let conferenceSchedule = this.commonService.getConferenceSchedule();
    let meetings = conferenceSchedule ? conferenceSchedule.eventMeetings : [];
    // parse eventMeetings, and for each companySchedule (see above json that is created by mapping) Add company and it's attendees if not exist otherwise get the existing company 
    // and add fidelity attendee if not there to that existing company
    // console.log('Conferences: ', this.companySchedules);
    this.companySchedules.forEach((schedule) => {
      schedule['isCompanyAlreadyPresent'] = false;
      schedule.attendees.forEach((scheduleInvitee) => {
        scheduleInvitee['isAlreadyPresent'] = false;
      });
    });
    meetings.forEach(meeting => {
      this.companySchedules.forEach((schedule) => {
        if (meeting.scheduleId === schedule.scheduleId) {
          schedule['isCompanyAlreadyPresent'] = true;
          let filInviteeToPush = [];
          meeting.fidelityInvitees.forEach((mtgInvitee) => {
            schedule.attendees.forEach((scheduleInvitee) => {
              if (scheduleInvitee.corporateId.toUpperCase() === mtgInvitee.corporateId.toUpperCase()) {
                scheduleInvitee['isAlreadyPresent'] = true;
                mtgInvitee["host"] = scheduleInvitee.isHost ? scheduleInvitee.isHost : false
              }
            });
          });
          schedule.attendees.forEach((scheduleInvitee) => {
            if (!scheduleInvitee['isAlreadyPresent']) {
              filInviteeToPush.push({
                name: scheduleInvitee.name,
                corporateId: scheduleInvitee.corporateId,
                isCallIn: false,
                isInviteRequired: true,
                isInviteForInfoOnly: false,
                inviteeResponse: '',
                isInfoPackRequired: false,
                host: scheduleInvitee.isHost ? scheduleInvitee.isHost : false
              });
            }
            delete scheduleInvitee['isAlreadyPresent'];
          });
          filInviteeToPush.forEach((node) => {
            for (let i = (meeting.fidelityInvitees.length - 1); i > 0; i--) {
              if (meeting.fidelityInvitees[i].name.length === 0) {
                meeting.fidelityInvitees.pop();
              }
            }
            if (meeting.fidelityInvitees[meeting.fidelityInvitees.length - 1].name.length === 0 && meeting.fidelityInvitees.length > 0) {
              meeting.fidelityInvitees.pop();
            }
            meeting.fidelityInvitees.push(node);
          });
        }
      });
    });
    this.companySchedules.forEach((schedule) => {
      if (!schedule['isCompanyAlreadyPresent']) {
     
        let newMeeting = new Meeting('', '', '', '', '', '', '', new MeetingSubtype('', '', '', ''), new MeetingInitiator('', ''),
          '', '', '', '', new Country('', ''), '', '', '', new DialIn('', ''), new MeetingLocation('', '', '', ''),
          new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
          new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('', '', '', '', '', '', '', ''),
          [], [], new MeetingCreator('', ''), '', '', '', '', '', '', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
          '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), '', '');

       
        newMeeting.meetingType = (schedule.meetingType === 'EQ' || schedule.meetingType === 'FI')
          ? 'Company' : schedule.meetingType;
        newMeeting.businessEntity = (newMeeting.meetingType === 'Company')
        ? schedule.meetingType : '';
        if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'EQ') {
          newMeeting.securityDetail.securityName = schedule.name;
          newMeeting.securityDetail.securityTradableEntityId = schedule.companyId;
          newMeeting.securityDetail.ticker = schedule.ticker;
        } else if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'FI'){
          newMeeting.debtTickerDetail.debtTicker = schedule.name;
        } else if (newMeeting.meetingType === 'Broker') {
          newMeeting.brokerDetail.brokerFirmName = schedule.name;
          newMeeting.brokerDetail.brokerFirmId = schedule.companyId;
        } else if (newMeeting.meetingType === 'Other') {
          newMeeting.meetingTopic = schedule.name;
        }
        newMeeting.scheduleId = schedule.scheduleId;
        newMeeting.meetingSubType.meetingSubTypeCode = schedule.subType;
        schedule.attendees.forEach(element => {
          newMeeting['fidelityInvitees'].push({
            name: element.name,
            corporateId: element.corporateId,
            isCallIn: '',
            isInviteRequired: 'Y',
            isInviteForInfoOnly: '',
            inviteeResponse: '',
            isInfoPackRequired: '',
            host: element.isHost ? element.isHost : false
          });
          // newMeeting.fidelityInvitees.forEach((invitee) => {
          //   invitee['host'] = element.isHost ? element.isHost : false;
          // });
        });
        meetings.push(newMeeting);
        meetings.reverse();
      }
      delete schedule['isCompanyAlreadyPresent'];
    });
    this.commonService.setConferenceSchedule(conferenceSchedule);
    this.router.navigate(['/conference/update', { eventId: conferenceSchedule.eventId }], { skipLocationChange: true });
  }
}
