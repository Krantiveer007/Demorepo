import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendeeRendererComponent } from './attendee-renderer.component';

describe('AttendeeRendererComponent', () => {
  let component: AttendeeRendererComponent;
  let fixture: ComponentFixture<AttendeeRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendeeRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendeeRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
