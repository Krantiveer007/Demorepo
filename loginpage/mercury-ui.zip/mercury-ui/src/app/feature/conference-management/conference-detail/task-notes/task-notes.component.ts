import { Component, OnInit, AfterViewInit, TemplateRef, ViewChild, Input } from '@angular/core';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { CommonService } from '../../../../core/http/common.service';
import Utils from '../../../../shared/utils/common.utility';
import { not } from '@angular/compiler/src/output/output_ast';
import { FactoryOrValue } from 'rxjs';
import { utc } from 'moment';

const tasksTypes = [['advertiseConference', 'Advertise Conference and save the Date'], ['reminderSent', 'Reminder Sent'],
['sendMeetingSummaryToBroker', 'Send Meeting Summary to Broker'], ['conferenceSchedulePublished', 'Conference Schedule Published'], ['meetingCreated', 'Meeting Created']];

let eventDataCopy = {};
const sortNotesByDate = (a, b) => {
  return (new Date(b.updatedTimestamp).getTime() - new Date(a.updatedTimestamp).getTime());
}
@Component({
  selector: 'mv2-task-notes',
  templateUrl: './task-notes.component.html',
  styleUrls: ['./task-notes.component.css']
})
export class TaskNotesComponent implements OnInit, AfterViewInit {
  modalRef: BsModalRef;
  imageStatus: string = "";
  disableSave: boolean = true;
  isModalShown: boolean = false;
  subjectDuplicate: boolean = false;
  eventData: any;
  taskValueTuched: boolean = false;
  notesErrorMsg: any = { subject: false, text: false, sametext: false };
  editNotes: any = { 'subject': '', 'index': 0, 'text': '' };
  notesandTasks: any = { notes: [], tasks: [] };
  notesEditMode: Boolean = false;
  @Input() conferenceDetail: any;
  activityLogOrNotes: string = 'notes';
  newNotesFlag: boolean = false;
  messageHeading: string = "";
  draftConfirmMessage: string = "";
  @ViewChild('template') template: TemplateRef<any>;
  @ViewChild('saveDialogModal') saveDialogModal: ModalDirective;
  config = {
    ignoreBackdropClick: false
  };
  constructor(private modalService: BsModalService,
    private commonService: CommonService) { }

  ngOnInit() {

  }
  ngAfterViewInit() {
  }
  isRequestFail(res) {
    if (res.statusCode !== 200 || res.body === 'FAILURE') {
      return true;
    } else {
      return false;
    }
  }
  showConfirmMsg(isModalShown = true, imageStatus = "success", draftConfirmMessage, messageHeading) {
    this.isModalShown = true;
    this.imageStatus = imageStatus;
    this.draftConfirmMessage = draftConfirmMessage;
    this.messageHeading = messageHeading;
  }
  formatTaskNotesData(type, data, notesEditMode, eventData) {
    eventData = !Utils.isVoid(eventData) ? eventData : {};
    let updatedMeetingData = Object.assign(eventData);
    let logggedUserId = this.commonService.getLoggedInUserInfo().getCorporateId();
    updatedMeetingData.updatedBy = logggedUserId;
    if (type === 'Notes') {
      let notesObject = {};
      notesObject['subject'] = data.subject;
      notesObject['text'] = data.text;
      notesObject['updatedBy'] = logggedUserId;
      if (Utils.isVoid(updatedMeetingData.notes)) {
        updatedMeetingData.notes = [];
      }
      if (!notesEditMode) {
        updatedMeetingData.notes.unshift(notesObject);
      } else {
        updatedMeetingData.notes[data.index] = notesObject;
      }
    } else {
      let tasks = [];
      tasksTypes.forEach((value, index) => {
        let taskObj = {};
        if (data[index].isValue !== eventDataCopy['tasks'][value[0]].isValue) {
          taskObj[value[0]] = { isValue: data[index].isValue, updatedBy: logggedUserId };
        } else {
          taskObj[value[0]] = data[index];
        }
        tasks.push(taskObj);
      });
      updatedMeetingData.tasks = tasks;
    }
    return updatedMeetingData;
  }
  resetErrorMsg() {
    this.notesErrorMsg = { subject: false, text: false, sametext: false };
    this.subjectDuplicate = false;
  }
  resetTaskNotes() {
    this.notesandTasks = { notes: [], tasks: [] };
  }
  resetEditNotes() {
    this.editNotes = { 'subject': '', 'index': 0, 'text': '' };
  }
  showTasks(showModelBox) {
    if (Utils.isVoid(this.modalRef) || showModelBox) {
      this.modalRef = this.modalService.show(this.template);
    }

    this.newNotesFlag = false;
    this.resetTaskNotes();
    // https://62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev/event/conference?eventId=0288f86b-3f38-4eaa-b201-b89aa3ad086c
    //git sthis.conferenceDetail.eventId = '44acc805-a8fc-47cb-8b64-67e3eaaae947';
    if (Utils.isVoid(this.conferenceDetail) && Utils.isVoid(this.conferenceDetail.eventId)) {
      return;
    }
    this.commonService.getConferenceNotesAndTasks(this.conferenceDetail.eventId).subscribe((response) => {
      if (this.isRequestFail(response)) {
        this.showConfirmMsg(true, 'alert', 'Not able to get conference data.', 'Error');
      } else {
        eventDataCopy = JSON.parse(JSON.stringify(response['body'][0]));
        let meetingType = response['body'][0];
        this.eventData = meetingType;
        if (!Utils.isVoid(meetingType.notes)) {
          meetingType.notes.sort(sortNotesByDate);
        }
        this.notesandTasks.notes = meetingType.notes;
        if (!Utils.isVoid(meetingType.tasks)) {
          tasksTypes.forEach((v) => {
            let task = meetingType.tasks[v[0]];
            task.label = v[1];
            this.notesandTasks.tasks.push(task);
          })
        }
      }
    });
  }
  closeTasksModel() {
    this.modalRef.hide();
    this.modalRef = null;
    this.newNotesFlag = false;
  }
  toggleNav(val: string) {
    this.activityLogOrNotes = val;
  }
  addNewNotes() {
    this.resetErrorMsg();
    this.resetEditNotes();
    this.disableSave = true;
    this.newNotesFlag = true;
    this.notesEditMode = false;
  }
  cancelNotes() {
    this.newNotesFlag = false;
    this.resetEditNotes();
    this.resetErrorMsg();
  }
  saveNotes() {
    this.notesErrorMsg.subject = Utils.isVoid(this.editNotes.subject);
    this.notesErrorMsg.text = Utils.isVoid(this.editNotes.text);
    if (this.notesErrorMsg.subject || this.notesErrorMsg.text) {
      return;
    }
    let notesData = this.formatTaskNotesData('Notes', this.editNotes, this.notesEditMode, this.eventData);
    this.commonService.updateConferenceNotesAndTasks(notesData).subscribe((response) => {
      if (this.isRequestFail(response)) {
        this.showConfirmMsg(true, 'alert', 'Some issue in Saving notes.', 'Error');
      } else {
        this.showConfirmMsg(true, 'success', 'Notes saved successfully.', 'Notes Saved !');
        this.newNotesFlag = false;
        this.resetEditNotes();
        this.resetErrorMsg();
        this.showTasks(false);
      }

    });
  }
  editNote(note, index) {
    this.newNotesFlag = true;
    this.notesEditMode = true;
    this.editNotes.index = index;
    this.editNotes.text = note.text;
    this.editNotes.subject = note.subject;
    this.disableSave = true;
  }
  taskValueChanged() {
    this.taskValueTuched = true;
  }
  saveTasks() {
    if (this.taskValueTuched) {
      let taskData = this.formatTaskNotesData('Tasks', this.notesandTasks.tasks, this.notesEditMode, this.eventData);
      this.commonService.updateConferenceNotesAndTasks(taskData).subscribe((response) => {
        if (this.isRequestFail(response)) {
          this.showConfirmMsg(true, 'alert', 'Some issue in Saving Tasks.', 'Error');
        } else {
          this.taskValueTuched = false;
          this.showConfirmMsg(true, 'success', 'Tasks saved successfully.', 'Tasks Saved !');
          this.newNotesFlag = false;
          this.resetEditNotes();
          this.resetErrorMsg();
          this.showTasks(false);
        }
      });
    }
  }
  checkForDuplicateSubject() {
    if (this.notesEditMode === true) {
      return;
    }
    this.subjectDuplicate = false;
    if (Utils.isVoid(this.notesandTasks.notes)) {
      return;
    }
    for (let index = 0; index < this.notesandTasks.notes.length; index++) {
      if (!Utils.isVoid(this.editNotes.subject) && this.editNotes.subject.trim() === this.notesandTasks.notes[index].subject.trim()) {
        this.subjectDuplicate = true;
        break;
      }
    }
  }

  onHidden(operationType): void {
    this.saveDialogModal.hide();
  }
  confirm(): void {
    this.isModalShown = false;
  }
}



