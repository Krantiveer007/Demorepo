import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRendererComponent } from './company-renderer.component';

describe('CompanyRendererComponent', () => {
  let component: CompanyRendererComponent;
  let fixture: ComponentFixture<CompanyRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
