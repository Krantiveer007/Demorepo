import { Component } from "@angular/core";
import { ICellRendererAngularComp, AgEditorComponent } from "ag-grid-angular";
import { Output } from "@angular/core";
import { EventEmitter, OnInit, AfterViewInit } from "@angular/core";

@Component({
  selector: "company-cell-renderer",
  styleUrls: ['./company-renderer.component.css'],
  template: `<div class="row align-items-center" style="height: 100%; font-size:15px;">  
    <div *ngIf = "viewType === 'company'" class="col-md-6 pl-0 pr-0">
      <label class="container">
          <div style="overflow: hidden!important;text-overflow: ellipsis!important;" 
            tooltip="{{company.name}}" placement="bottom" tooltipFadeDuration="150">{{company.name}}</div>
          <input type="radio" name="selectedCompany" [value]="selectedCompany" [checked]="selectedCompany"
             (change)="selectCompany($event)" style="display:none">
          <span class="checkmark"></span>
      </label>
    </div>
    <div *ngIf = "viewType === 'attendee'" class="col-md-6 pl-0 pr-0">
    <label class="container">
    <div style="overflow: hidden!important;text-overflow: ellipsis!important;"
      tooltip="{{company.name}}" placement="bottom" tooltipFadeDuration="150">{{company.name}}</div>
        <input type="checkbox" name="selectedCompany" [(ngModel)] = "selectedCompany" [checked]="selectedCompany"
          (change)="selectCompany($event)" style="display:none">
        <span class="checkmark1" style="top: 7px;"></span>
    </label>
  </div>
  <div *ngIf = "viewType === 'attendee'" class="ml-auto col-auto pr-0">
      <label class="container">
          <input type="checkbox" name="selectedHost" [value]="selectedHost" [disabled] = "true" [checked]="selectedHost"
            (change)="selectHost($event)">
          <span title="Host" class="checkmark1"></span>
      </label>
    </div>
    <div class="ml-auto col-auto" style="height: 24px; border-radius: 16px; border: solid 1px #ffa800; line-height: 1.5;">
      {{selectedMeetingType}}
    </div>
    <div class="col-auto">
      <ng-select [disabled] = "viewType === 'attendee'" class="company-renderer" [clearable]="false" style="padding:0; width:100px;" [(ngModel)]="selectedSubType" [items]="subTypes" [searchable]="false" (change) = "selectSubType($event)"></ng-select>
    </div>
</div>`
})
export class CompanyRendererComponent implements ICellRendererAngularComp {
  public params: any;
  company: any;
  subTypes = ["1:1", "Group"];
  selectedSubType;
  selectedMeetingType;
  value: any;
  viewType;
  selectedCompany: boolean = false;
  selectedHost: boolean = false;


  agInit(params: any): void {
    this.params = params;
    this.params.data["selectedCompany"] = false;
    this.params.data["selectedHost"] = false;
    this.params.data["host"] = false;
    this.viewType = this.params.context.componentParent.viewType;
    if (this.params.data["meetingType"]) {
      this.selectedMeetingType = this.params.data["meetingType"];
      this.selectedSubType = this.params.data["subType"];
    } else {
      this.selectedMeetingType = this.params.context.componentParent.selectedType.keyCode;
      this.params.data["meetingType"] = this.selectedMeetingType;
      this.selectedSubType = this.subTypes[0];
      this.params.data["subType"] = this.selectedSubType;
    }


    // if (this.selectedMeetingType === "EQ") {
    //   this.params.data["name"] = this.params.data.instrumentLongName;
    //   this.params.data["id"] = this.params.data.tradableEntId;
    // } else if (this.selectedMeetingType === "FI") {
    //   this.params.data["name"] = this.params.data.debtTicker;
    //   this.params.data["id"] = this.params.data.debtTicker;
    // } else if (this.selectedMeetingType === "Broker") {
    //   this.params.data["name"] = this.params.data.firmName;
    //   this.params.data["id"] = this.params.data.firmId;
    // } else if (this.selectedMeetingType === "Other") {
    //   this.params.data["name"] = this.params.data.companyName;
    //   this.params.data["id"] = this.params.data.companyName;
    // }

    if (params.value === null) {
      return undefined;
    } else {
      this.company = this.params.data;
      this.value = params.value;
    }
  }

  // public onManage(e, p) {
  //   this.params.context.componentParent.managePortfolios(e, this.params);
  // }

  selectHost(event) {
    // this.params.node.setSelected(event.currentTarget.checked);
    this.params.data["host"] = event.currentTarget.checked;
    this.params.data["selectedHost"] = event.currentTarget.checked;
    this.params.api.forEachNode((node, index) => {
      if (node.data.corporateId !== this.params.data.corporateId) {
        // node.setDataValue('host', false);
        node.data.host = false;
        node.data["selectedHost"] = false;
      }
    });
  }

  // isHostAllowed() {
  //   const companySchedules = this.params.context.componentParent.companySchedules;
  //   const selectedCompanySchedule = companySchedules.filter((companySchedule) => (companySchedule.scheduleId === this.params.data.scheduleId));
  //   if (selectedCompanySchedule.length) {
  //     let selectedAttendees = this.params.context.componentParent.attendeesGridOptions.api.getSelectedNodes();
  //     if (selectedAttendees.length) {
  //       const existingHost = selectedCompanySchedule[0].attendees.filter((attendee) => (selectedAttendees[0].data.corporateId !== attendee.corporateId &&  attendee.isHost))
  //       if (existingHost.length) {
  //         return true;
  //       }
  //     }
  //   }
  //   return false;
  // }

  selectCompany(event) {
    this.params.node.setSelected(event.currentTarget.checked);
    this.params.data["selectedCompany"] = event.currentTarget.checked;
    if (this.viewType === "company") {
      const attendeesGridOptions = this.params.context.componentParent.attendeesGridOptions;
      const companySchedules = this.params.context.componentParent.companySchedules;
      const selectedCompanySchedule = companySchedules.filter((companySchedule) => (companySchedule.scheduleId === this.params.data.scheduleId));
      if (selectedCompanySchedule.length) {
        selectedCompanySchedule[0].attendees.forEach(attendee => {
          attendeesGridOptions.api.forEachNode((node, index) => {
            if (node.data.corporateId === attendee.corporateId) {
              node.data.isSelected = true;
              node.data.selectedAttendee = true;
              node.data.selectedHost = attendee.isHost;
              node.setDataValue('selectedAttendee', true);
              node.setDataValue('selectedHost', attendee.isHost);
              node.setSelected(true);
            }
          });
        }); 
        attendeesGridOptions.api.forEachNode((node, index) => {
          if (!node.data.isSelected) {
            node.data.selectedAttendee = false;
            node.data.selectedHost = false;
            node.setDataValue('selectedAttendee', false);
            node.setDataValue('selectedHost', false);
            node.setSelected(false);
          } else {
            delete node.data.isSelected;
          }
        });
        attendeesGridOptions.api.refreshCells({
          // rowNodes: attendeesGridOptions.api.getSelectedNodes(),
          force: true
        });
      } else {
        attendeesGridOptions.api.forEachNode((node, index) => {
          if (!node.data.isSelected) {
            node.data.selectedAttendee = false;
            node.data.selectedHost = false;
            node.setDataValue('selectedAttendee', false);
            node.setDataValue('selectedHost', false);
            node.setSelected(false);
          } else {
            delete node.data.isSelected;
          }
        });
        attendeesGridOptions.api.refreshCells({
          // rowNodes: attendeesGridOptions.api.getSelectedNodes(),
          force: true
        });
      }
    }
  }

  // removeCompany(event) {
  //   this.params.api.updateRowData({ remove: [this.params.data] });
  //   this.params.context.componentParent.removeCompany(this.params.data);
  // }

  selectSubType(event) {
    this.params.data["subType"] = event;
  }

  isPopup() {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  refresh(): boolean {
    this.selectedCompany = this.params.data["selectedCompany"];
    this.selectedHost = this.params.data["selectedHost"];
    this.params.data["host"] = this.params.data["selectedHost"];
    return true;
  }
}


// agInit(params): void {
//   this.params = params;
//   this.isChecked = params.node.selected;
//   if (this.params.node.selectable === false) {
//     this.enableCheckBox = true;
//     this.isChecked = true;
//   } else if (this.params.node.data.selection === true) {
//     this.isChecked = true;
//   }
// }
// onChange(event) {
//   this.params.node.setSelected(event.currentTarget.checked);
//   this.params.data[this.params.colDef.field] = event.currentTarget.checked;
// }
// refresh(): boolean {
//   r