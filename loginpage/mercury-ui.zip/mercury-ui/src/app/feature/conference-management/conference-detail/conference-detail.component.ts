import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Input } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Meeting } from 'src/app/shared/models/meeting.model';
import { FidelityInvitees } from 'src/app/shared/models/fidelityInvitees.model';


@Component({
  selector: 'mv2-conference-detail',
  templateUrl: './conference-detail.component.html',
  styleUrls: ['./conference-detail.component.css'],
})
export class ConferenceDetailComponent implements OnInit {

  conferenceScheduleForm: FormGroup;

  companyTotalCount = 0;
  // conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
  @Input() conferencScheduleDtls: any;
  @Output() formReady = new EventEmitter<FormGroup>();

  constructor(private router: Router, private cdr: ChangeDetectorRef, private fb: FormBuilder, private commonService: CommonService) { }

  ngOnInit() {
    this.conferenceScheduleForm = this.fb.group({
      conferenceDetailGrid: [null]
    });
    this.formReady.emit(this.conferenceScheduleForm);
    this.conferenceScheduleForm.get('conferenceDetailGrid').valueChanges.subscribe((element) => {
      this.companyTotalCount = element ? Object.keys(element).length : 0;
    });
    this.cdr.detectChanges();
  }

  // ngOnChanges(changes: SimpleChanges) {
  //   if (changes.conferencScheduleDtls.currentValue) {
  //     const eventMtgDtls: any = changes.conferencScheduleDtls.currentValue['eventMeetings'];
  //   }
  // }
  createMappings() {
    let eventMeetings: any = this.conferenceScheduleForm.get('conferenceDetailGrid').value;
    const conferenceSchedule = this.commonService.getConferenceSchedule();
    if (Object.values(eventMeetings).length > 0) {
      Object.values(eventMeetings).forEach((rowNode) => {
        conferenceSchedule.eventMeetings.forEach(element => {
          if (element.scheduleId === rowNode['scheduleId']) {
            element.meetingDate = rowNode['meetingDate'];
            element.meetingTimeInGMT = rowNode['meetingTimeInGMT'];
            element.eventScheduleStatus = rowNode['eventScheduleStatus'];
            rowNode['callRecordsFilAttendee'].forEach((gridInvitee) => {
              element.fidelityInvitees.forEach((filInvitee) => {
                if (filInvitee.corporateId.toUpperCase() === gridInvitee.corporateId.toUpperCase()) {
                  gridInvitee['alreadyPresent'] = true;
                  filInvitee.inviteeResponse = gridInvitee['inviteeResponse'];
                  filInvitee.isCallIn = gridInvitee['isCallIn'];
                  filInvitee.isInfoPackRequired = gridInvitee['isInfoPackRequired'];
                  filInvitee.isInviteForInfoOnly = gridInvitee['isInviteForInfoOnly'];
                  filInvitee.isInviteRequired = gridInvitee['isInviteRequired'];
                  filInvitee['host'] = gridInvitee['host'];
                }
              });
            });
            rowNode['callRecordsFilAttendee'].forEach((gridInvitee) => {
              if ((!gridInvitee['alreadyPresent']) && gridInvitee.corporateId) {
                let attendee: any = {};
                attendee['corporateId'] = gridInvitee.corporateId;
                attendee['name'] = gridInvitee.name;
                attendee['isCallIn'] = gridInvitee.isCallIn;
                attendee['isInviteRequired'] = gridInvitee.isInviteRequired;
                attendee['isInfoPackRequired'] = gridInvitee.isInfoPackRequired;
                attendee['isInviteForInfoOnly'] = gridInvitee.isInviteForInfoOnly;
                attendee['inviteeResponse'] = gridInvitee.inviteeResponse;
                attendee['host'] = gridInvitee['host'];
                element.fidelityInvitees.push(attendee);
              }
              delete gridInvitee['alreadyPresent'];
            });
            rowNode['callRecordsThirdPartyAttendee'].forEach((gridThirdPartyParticipant) => {
              element.thirdPartyAttendee.forEach((filThirdPartyParticipant) => {
                if (filThirdPartyParticipant['companyAttendeeId'] === gridThirdPartyParticipant.companyAttendeeId) {
                  gridThirdPartyParticipant['alreadyPresent'] = true;
                  // filThirdPartyParticipant.externalContactName = gridThirdPartyParticipant['companyAttendee'];
                  // filThirdPartyParticipant['company'] = gridThirdPartyParticipant['company']
                  // ? gridThirdPartyParticipant['company'] : '';
                  // filThirdPartyParticipant.email = gridThirdPartyParticipant['emailId']
                  // ? gridThirdPartyParticipant['emailId'] : '';
                  // filThirdPartyParticipant.position = gridThirdPartyParticipant['designation']
                  // ? gridThirdPartyParticipant['designation'] : '';
                }
              });
            });
            rowNode['callRecordsThirdPartyAttendee'].forEach((gridThirdPartyParticipant) => {
              if ((!gridThirdPartyParticipant['alreadyPresent']) && gridThirdPartyParticipant.companyAttendeeId) {
                let attendee: any = {};
                attendee['companyAttendeeId'] = gridThirdPartyParticipant.companyAttendeeId;
                attendee['companyAttendee'] = gridThirdPartyParticipant.companyAttendee;
                attendee['company'] = gridThirdPartyParticipant.company ? gridThirdPartyParticipant.company : '';
                attendee['emailId'] = gridThirdPartyParticipant.emailId ? gridThirdPartyParticipant.emailId : '';
                attendee['designation'] = gridThirdPartyParticipant.designation ? gridThirdPartyParticipant.designation : '';
                element.thirdPartyAttendee.push(attendee);
              }
              delete gridThirdPartyParticipant['alreadyPresent'];
            });
          }
        });
      });
    }
    this.router.navigate(['/editConference'], { skipLocationChange: true });
  }

}
