import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { ConferenceSchedule } from 'src/app/shared/models/conferenceSchedule.model';
import { EventLastUpdateDetails } from 'src/app/shared/models/eventLastUpdateDetails.model';
import { Meeting } from 'src/app/shared/models/meeting.model';
import { Country } from 'src/app/shared/models/country.model';
import { SecurityDetails } from 'src/app/shared/models/securitydetails.model';
import { AssociatedEventDetail } from 'src/app/shared/models/associatedeventdetail.model';
import { MeetingCreator } from 'src/app/shared/models/meetingcreator.model';
import { DebtTickerDetail } from 'src/app/shared/models/debtTickerDetail.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { ArrangementContact } from 'src/app/shared/models/arrangementcontact.model';
import { MeetingSubtype } from 'src/app/shared/models/meetingsubtype.model';
import { MeetingLocation } from 'src/app/shared/models/meetinglocation.model';
import { DialIn } from 'src/app/shared/models/dialin.model';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { MeetingInitiator } from 'src/app/shared/models/meetinginitiator.model';
import { FidelityInvitees } from 'src/app/shared/models/fidelityInvitees.model';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { ThirdPartyAttendee } from 'src/app/shared/models/thirdPartyAttendee.model';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap';
import { ViewChild } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { ConfigEmailComponent } from '../../shared/components/config-email/config-email.component';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { MeetingFormat } from 'src/app/shared/models/meetingFormat.model';
@Component({
  selector: 'mv2-conference-management',
  templateUrl: './conference-management.component.html',
  styleUrls: ['./conference-management.component.css']
})
export class ConferenceManagementComponent implements OnInit {

  conferenceDetail: any;
  conferencScheduleDtls: any;
  conferenceMeeting: FormGroup;
  emptyConferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
  conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
  // selectedConfMtgs = [];
  modalRef: BsModalRef;
  draftConfirmMessage = '';
  messageHeading = '';
  config = {
    ignoreBackdropClick: false
  };
  imageStatus = '';
  showNoButton = false;
  eventState = 'New';
  conferenceSaveCallType = 'post';
  confirmButton = 'OK';
  isModalShown = false;
  isUpdateModalShown = false;
  updatedReason = '';
  updateMethod = '';
  routeCase = 'draftmeeting';
  isOwnerEditable = false;
  ownerErrorResponse = false;
  pastMeeting = false;
  confirmButtonLabel = 'Confirm';
  isModifiedOnVisible = false;
  initialMeetingSchedules = [];
  conferenceEventId = '';
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private modalService: BsModalService,
    private cdr: ChangeDetectorRef,
    private titleCasePipe: TitleCasePipe) { }
  @ViewChild('saveDialogModal') saveDialogModal: ModalDirective;

  ngOnInit() {
    this.conferenceMeeting = this.fb.group({});
    // console.log('conferenceMeeting: ', this.conferenceMeeting);
    this.route.params.subscribe((params) => {
      if (params['action'] === 'update') {
        if (this.commonService.getConferenceSchedule().eventId && this.commonService.getConferenceMeetingDtls().eventId) {
          this.conferenceDetail = this.commonService.getConferenceMeetingDtls();
          this.eventState = this.conferenceDetail.eventState ? (this.conferenceDetail.eventState.toUpperCase() === 'NEW' ? 'Confirmed' : convertToTitleCase(this.conferenceDetail.eventState)) : 'Confirmed';
          this.conferencScheduleDtls = Object.assign({}, this.commonService.getConferenceSchedule());
          Object.values(this.conferencScheduleDtls.eventMeetings).forEach((meeting) => {
            meeting['fidelityInvitees'].forEach(element => {
              element.isCallIn = (typeof (element.isCallIn) === 'string') ? false : element.isCallIn;
              element.isInviteRequired = (typeof (element.isInviteRequired) === 'string') ? true : element.isInviteRequired;
              element.isInfoPackRequired = (typeof (element.isInfoPackRequired) === 'string') ? false : element.isInfoPackRequired;
              element.isInviteForInfoOnly = (typeof (element.isInviteForInfoOnly) === 'string') ? false : element.isInviteForInfoOnly;
            });
          });
        } else {
          this.commonService.getConferenceMeeting(params['eventId']).subscribe((response) => {
            // console.log('resoponse: ', response);
            if (response && response.length > 0) {
              // this.commonService.setMeetingType('Conference');
              if (response[0]['body'] && response[0]['statusCode'] === 200) {
                // console.log('response[0]: ', response[0]['body']);
                this.commonService.setConferenceMeetingDtls(response[0]['body']);
                this.conferenceDetail = this.commonService.getConferenceMeetingDtls();
                this.eventState = this.conferenceDetail.eventState ? (this.conferenceDetail.eventState.toUpperCase() === 'NEW' ? 'Confirmed' : convertToTitleCase(this.conferenceDetail.eventState)) : 'Confirmed';
              }
              if (response[1]['body'] && response[1]['statusCode'] === 200) {
                // console.log('response[1]: ', response[1]['body']);
                // if (this.commonService.getConferenceSchedule().eventId) {
                // this.conferencScheduleDtls = Object.assign({}, this.commonService.getConferenceSchedule());
                // Object.values(this.conferencScheduleDtls.eventMeetings).forEach((meeting) => {
                //   meeting['fidelityInvitees'].forEach(element => {
                //     element.isCallIn = (typeof (element.isCallIn) === 'string') ? false : element.isCallIn;
                //     element.isInviteRequired = (typeof (element.isInviteRequired) === 'string') ? true : element.isInviteRequired;
                //     element.isInfoPackRequired = (typeof (element.isInfoPackRequired) === 'string') ? false : element.isInfoPackRequired;
                //     element.isInviteForInfoOnly = (typeof (element.isInviteForInfoOnly) === 'string') ? false : element.isInviteForInfoOnly;
                //   });
                // });
                // console.log('this.conferencScheduleDtlsthis.conferencScheduleDtls: ', this.conferencScheduleDtls);
                // } else {
                this.conferencScheduleDtls = response[1]['body'];
                Object.values(this.conferencScheduleDtls.eventMeetings).forEach((meeting) => {
                  meeting['fidelityInvitees'].forEach(element => {
                    element.isCallIn = (element.isCallIn === 'Y');
                    element.isInviteRequired = (element.isInviteRequired === 'Y');
                    element.isInfoPackRequired = (element.isInfoPackRequired === 'Y');
                    element.isInviteForInfoOnly = (element.isInviteForInfoOnly === 'Y');
                  });
                });
                if (Object.values(this.conferencScheduleDtls.eventMeetings).length > 0) {
                  this.conferenceSaveCallType = 'put';
                } else {
                  this.conferenceSaveCallType = 'post';
                }
                this.commonService.setConferenceSchedule(Object.assign({}, this.conferencScheduleDtls));
                this.initializeSchedules(Object.assign({}, this.conferencScheduleDtls));
                // }
              } else if (!response[1]['body'] && response[1]['statusCode'] === 200) {
                this.commonService.setConferenceSchedule(this.emptyConferenceSchedule);
                this.conferencScheduleDtls = this.commonService.getConferenceSchedule();
              }
            }
          });
        }
      }
    });
    // this.commonService.selectedConfMtgs.subscribe((selectedMtgs) => {
    //   if (selectedMtgs) {
    //     this.selectedConfMtgs = selectedMtgs;
    //   }
    // });
    this.commonService.resetConferenceFormSubject.subscribe((element) => {
      if (element && this.commonService.getConferenceSchedule()) {
        this.commonService.resetConferenceSchedule(this.emptyConferenceSchedule);
      }
    });
    this.commonService.checkConferenceFormSubject.subscribe((element) => {
      if (element) {
        this.checkFormChanges(this.commonService.getTargetUrl());
      }
    });
  }

  checkFormChanges(uri) {
    const eventMeetings = this.conferenceMeeting.get('conferenceSchedule-details').get('conferenceDetailGrid').value;
    this.conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
    Object.values(eventMeetings).forEach((rowNode) => {
      const meetingObj = Object.assign({}, rowNode);
      this.setEventMeetingValues(meetingObj);
    });
    const newForm = JSON.stringify(this.conferenceSchedule.eventMeetings);
    const oldForm = JSON.stringify(this.initialMeetingSchedules);

    if (newForm === oldForm) {
      this.commonService.resetConferenceFormSubject.next(true);
      this.commonService.setTargetUrl(uri);
      this.router.navigate([uri, { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
    }
    else {
      this.messageHeading = 'Confirm Navigation';
      this.draftConfirmMessage = 'This page contains unsaved changes. Are you sure you want to exit ?';
      this.imageStatus = 'alert';
      this.isModalShown = true;
      this.showNoButton = true;
      this.confirmButton = 'YES';
      if (uri === '/events/meeting') {
        this.routeCase = 'meetingRouteToView'
      } else if (uri === '/contacts') {
        this.routeCase = 'meetingRouteToContacts'
      } else {
        this.routeCase = 'meetingRouteToCreate'
      }
      // this.cdr.detectChanges();
    }
  }


  draftForm() {
    let eventMeetings: any = this.conferenceMeeting.get('conferenceSchedule-details').get('conferenceDetailGrid').value;
    // console.log(this.conferenceMeeting.get('conferenceSchedule-details').get('conferenceDetailGrid').value);
    this.conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
    this.conferenceSchedule.eventId = this.conferenceDetail.eventId;
    this.conferenceSchedule.eventType = this.conferenceDetail.eventType;
    this.conferenceSchedule.eventLastUpdateDetails.corporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
    this.conferenceSchedule.eventLastUpdateDetails.name = this.commonService.getLoggedInUserInfo().getName();
    this.conferenceSchedule.eventLastUpdateDetails.updateReason = 'Meeting Creation';
    this.conferenceSchedule.eventLastUpdateDetails.updateTimestamp = new Date();
    Object.values(eventMeetings).forEach((rowNode) => {
      const meetingObj = Object.assign({}, rowNode);
      this.setEventMeetingValues(meetingObj);
    });
    // console.log(this.conferenceSchedule.eventMeetings);
    // if (action === 'Confirm') {
    if (this.conferenceSchedule.eventMeetings.length > 0) {
      // console.log('this.conferenceSchedule: ', this.conferenceSchedule);
      this.conferenceEventId = this.conferenceSchedule.eventId;
      this.commonService.insertConferenceSchedules(this.conferenceSchedule, this.conferenceSaveCallType).subscribe((response) => {
        // console.log('conferenceInsertResponse: ', response);
        this.draftConfirmMessage = 'Meeting schedules saved successfully.';
        this.messageHeading = 'Schedule confirmed';
        this.isModalShown = true;
        this.imageStatus = 'success';
        // this.commonService.setFormChangeValue(false);
        this.showNoButton = false;
        this.routeCase = 'draftmeeting';
        this.confirmButton = 'OK';
        // this.modalService.onHide.subscribe((reason) => {
        //   this.checkForBackDropClick(reason);
        // });
      }, (error) => {
        this.conferenceSchedule = this.emptyConferenceSchedule;
        this.conferenceEventId = '';
        // console.log('conferenceErrorResponse: ', error);
        this.draftConfirmMessage = 'The meeting could not be saved. Please try again.';
        this.messageHeading = 'Error';
        this.updatedReason = '';
        this.updateMethod = '';
        this.imageStatus = 'alert';
        this.isModalShown = true;
        this.isUpdateModalShown = false;
      });
    }
    // }
  }

  confirm(): void {
    if (this.routeCase === 'draftmeeting') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      // this.routeIfMeetingCreationSuccess();
      this.resInitializeTheGrid();
      // this.cdr.detectChanges();
    } else if (this.routeCase === 'meetingRouteToView') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      if (this.commonService.getConferenceSchedule()) {
        this.commonService.resetConferenceSchedule(this.emptyConferenceSchedule);
      }
      this.router.navigate(['/events/meeting'], { skipLocationChange: true })
      // this.cdr.detectChanges();
    } else if (this.routeCase === 'meetingRouteToContacts') {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      if (this.commonService.getConferenceSchedule()) {
        this.commonService.resetConferenceSchedule(this.emptyConferenceSchedule);
      }
      this.router.navigate(['/contacts'], { skipLocationChange: true })
      // this.cdr.detectChanges();
    } else {
      this.saveDialogModal.hide();
      this.isModalShown = false;
      if (this.commonService.getConferenceSchedule()) {
        this.commonService.resetConferenceSchedule(this.emptyConferenceSchedule);
      }
      this.router.navigate(['/meeting/create', { meetingType: this.commonService.getMeetingType() }], { skipLocationChange: true });
      // this.cdr.detectChanges();
      //    this.router.navigate(['/meeting/create'], {skipLocationChange: true})
    }
  }
  decline() {
    this.saveDialogModal.hide();
    this.isModalShown = false;
  }
  resInitializeTheGrid() {
    this.commonService.setConferenceSchedule(this.emptyConferenceSchedule);
    this.commonService.getConferenceMeeting(this.conferenceEventId).subscribe((response) => {
      if (response && response.length > 0) {
        if (response[0]['body'] && response[0]['statusCode'] === 200) {
          this.commonService.setConferenceMeetingDtls(response[0]['body']);
          this.conferenceDetail = this.commonService.getConferenceMeetingDtls();
          this.eventState = this.conferenceDetail.eventState ? this.conferenceDetail.eventState : 'New';
        }
        if (response[1]['body'] && response[1]['statusCode'] === 200) {
          this.conferencScheduleDtls = response[1]['body'];
          Object.values(this.conferencScheduleDtls.eventMeetings).forEach((meeting) => {
            meeting['fidelityInvitees'].forEach(element => {
              element.isCallIn = (element.isCallIn === 'Y');
              element.isInviteRequired = (element.isInviteRequired === 'Y');
              element.isInfoPackRequired = (element.isInfoPackRequired === 'Y');
              element.isInviteForInfoOnly = (element.isInviteForInfoOnly === 'Y');
            });
          });
          if (Object.values(this.conferencScheduleDtls.eventMeetings).length > 0) {
            this.conferenceSaveCallType = 'put';
          } else {
            this.conferenceSaveCallType = 'post';
          }
          this.commonService.setConferenceSchedule(this.conferencScheduleDtls);
          this.initializeSchedules(this.conferencScheduleDtls);
          this.commonService.redrawMasterGrid.next(true);
        } else if (!response[1]['body'] && response[1]['statusCode'] === 200) {
          this.commonService.setConferenceSchedule(this.emptyConferenceSchedule);
          this.conferencScheduleDtls = this.commonService.getConferenceSchedule();
          this.initializeSchedules(this.conferencScheduleDtls);
          this.commonService.redrawMasterGrid.next(true);
        }
      }
    });
  }
  routeIfMeetingCreationSuccess() {
    if (this.draftConfirmMessage === 'Meeting schedules saved successfully.' || this.draftConfirmMessage === 'Meeting saved as Draft successfully.' ||
      this.draftConfirmMessage === 'Meeting Updated successfully.' || this.draftConfirmMessage === 'Contact details could not be updated. Please try again.') {
      if (this.commonService.getConferenceSchedule()) {
        this.commonService.resetConferenceSchedule(this.emptyConferenceSchedule);
      }
      this.router.navigate(['/events/meeting'], { skipLocationChange: true });
    }
  }
  onHidden(operationType): void {
    if (operationType === 'update/cancel') {
      this.saveDialogModal.hide();
      this.isUpdateModalShown = false;
    } else if (operationType === 'create/draft/draftInvite') {
      if (this.routeCase === 'draftmeeting') {
        this.saveDialogModal.hide();
        this.isModalShown = false;
        this.routeIfMeetingCreationSuccess();
        // this.cdr.detectChanges();
      } else if (this.routeCase === 'meetingRouteToView') {
        this.saveDialogModal.hide();
        this.isModalShown = false;
        this.router.navigate(['/events/meeting'], { skipLocationChange: true })
        // this.cdr.detectChanges();
      }
    }
  }
  setEventMeetingValues(meetingObj: any) {
    // console.log('meetingObj: ', meetingObj);
    let newMeeting = new Meeting('', '', '', '', '', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('', ''),
      '', '', '', '', new Country('', ''), '', '', '', new DialIn('', ''), new MeetingLocation('', '', '', ''),
      new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
      new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('', '', '', '', '', '', '', ''),
      [], [], new MeetingCreator('', ''), '', '', '', '', '', '', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
      '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), '', '');


    newMeeting.meetingType = meetingObj.meetingType.includes('-') ? 'Company' : meetingObj.meetingType;
    newMeeting.businessEntity = meetingObj.meetingType.includes('-')
      ? meetingObj.meetingType.replace('Company - ', '') : '';
    if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'EQ') {
      newMeeting.securityDetail.securityName = meetingObj.companyName;
      newMeeting.securityDetail.securityTradableEntityId = meetingObj.companyId;
      newMeeting.securityDetail.ticker = meetingObj.ticker;
    } else if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'FI') {
      newMeeting.debtTickerDetail.debtTicker = meetingObj.companyName;
    } else if (newMeeting.meetingType === 'Broker') {
      newMeeting.brokerDetail.brokerFirmName = meetingObj.companyName;
      newMeeting.brokerDetail.brokerFirmId = meetingObj.companyId ? meetingObj.companyId : '';
      newMeeting['brokerFirmId'] = meetingObj.companyId ? meetingObj.companyId : '';
    }
    if (newMeeting.meetingType === 'Other') {
      newMeeting.meetingTopic = meetingObj.companyName;
    } else if (newMeeting.meetingType === 'Broker') {
      newMeeting.meetingTopic = '-';
    }
    newMeeting.meetingTimezone = this.conferenceDetail.eventTimezone;
    newMeeting.meetingDate = meetingObj.meetingDate ? (new Date(meetingObj.meetingDate).toISOString()).split('T')[0] : '';
    newMeeting['meetingDateInLocal'] = meetingObj.meetingDate ? (new Date(meetingObj.meetingDate).toISOString()).split('T')[0] : '';
    if (meetingObj.meetingTimeInGMT) {
      const meetingTime = meetingObj.meetingTimeInGMT.split(':');
      newMeeting.meetingTimeInGMT = meetingTime[0] + '' + meetingTime[1];
    } else {
      newMeeting.meetingTimeInGMT = '0000';
    }
    if (meetingObj.meetingTimeInLocalTimezone) {
      const meetingTimeInLocal = meetingObj.meetingTimeInLocalTimezone.split(':');
      newMeeting.meetingTimeInLocalTimezone = meetingTimeInLocal[0] + '' + meetingTimeInLocal[1];
    } else {
      meetingObj.meetingTimeInLocalTimezone = '0000';
    }
    // const momenttime = moment(meetingTime, "hmm").format("HH:mm");
    // let localTime: any;
    // if (newMeeting.meetingDate && newMeeting.meetingTimezone) {
    //   localTime = (momentTimezone.tz((newMeeting.meetingDate + ' ' + momenttime), newMeeting.meetingTimezone.split(' ')[0]));
    // } else {
    //   if (newMeeting.meetingTimezone) {
    //     const newDate = new Date().toISOString().split('T')[0];
    //     localTime = (momentTimezone.tz((newDate + ' ' + momenttime), newMeeting.meetingTimezone.split(' ')[0]));
    //   }
    // }
    // let userLocalTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    // let gmtTime = localTime.clone().tz("Europe/London").format();
    // newMeeting['meetingDateInLocal'] = meetingObj.meetingDate !== '' ? userLocalTime.substring(0, 10) : '';
    // newMeeting.meetingTimeInGMT = meetingObj.meetingTimeInGMT !== '0000' ? gmtTime.substring(11, 13) + gmtTime.substring(14, 16) : '0000';
    // newMeeting.meetingTimeInLocalTimezone = meetingObj.meetingTimeInGMT !== '0000' ? userLocalTime.substring(11, 13) + userLocalTime.substring(14, 16) : '0000';

    // meetingTimeInLocalTimezone
    newMeeting.scheduleId = meetingObj.scheduleId;
    newMeeting.meetingId = meetingObj.meetingId ? meetingObj.meetingId : '';
    newMeeting.eventScheduleStatus = meetingObj.eventScheduleStatus
    if (newMeeting.eventScheduleStatus.toUpperCase() === 'CONFIRMED') {
      newMeeting.meetingState = 'CONFIRMED';
    } else if (newMeeting.eventScheduleStatus.toUpperCase().includes('CANCELLED')) {
      newMeeting.meetingState = 'CANCELLED';
    } else {
      newMeeting.meetingState = 'DRAFT';
    }
    if (newMeeting.meetingType === 'Other') {
      newMeeting.meetingSubType.meetingSubTypeCode = 'OOTH';
      newMeeting.meetingSubType.meetingSubTypeDescription = 'Other';
    } else {
      newMeeting.meetingSubType.meetingSubTypeCode = 'GNRL';
      newMeeting.meetingSubType.meetingSubTypeDescription = 'General';
    }

    newMeeting.meetingSubType.meetingSubTypeOtherDescription = '';
    newMeeting.meetingSubType.meetingFormat.meetingFormatCode = '1';
    newMeeting.meetingSubType.meetingFormat.meetingFormatDescription = '1on1';
    if (newMeeting.eventScheduleStatus.toUpperCase().includes('CONFIRMED') ||
      newMeeting.eventScheduleStatus.toUpperCase().includes('CANCELLED')) {
      newMeeting.meetingStatus = meetingObj.meetingStatus ? meetingObj.meetingStatus : 'Confirmed';
    } else {
      newMeeting.meetingStatus = '';
    }
    if (meetingObj.meetingStatus) {
      newMeeting.emailSendingReason = 'UPDATED';
    } else {
      newMeeting.emailSendingReason = 'CREATED';
    }
    let hostCorporateId = '';
    let hostName = '';
    const inviteeArray = [];
    if (meetingObj.callRecordsFilAttendee.length > 0) {
      Object.values(meetingObj.callRecordsFilAttendee).forEach((rowNode, Index) => {
        const inviteeObj = Object.assign({}, rowNode);
        inviteeArray[Index] = inviteeObj;
        if (inviteeArray[Index]['host']
          || (meetingObj.hostCorporateId === inviteeArray[Index]['corporateId'])) {
          hostCorporateId = inviteeArray[Index]['corporateId'];
          hostName = inviteeArray[Index]['name'];
        }
        inviteeArray[Index]['isCallIn'] = inviteeArray[Index]['isCallIn'] === true ? 'Y' : 'N';
        inviteeArray[Index]['isInviteForInfoOnly'] = inviteeArray[Index]['isInviteForInfoOnly'] === true ? 'Y' : 'N';
        inviteeArray[Index]['inviteeResponse'] = inviteeArray[Index]['host']
          ? 'Accepted'
          : inviteeArray[Index]['inviteeResponse'] ? inviteeArray[Index]['inviteeResponse'] : '';
        inviteeArray[Index]['isInviteRequired'] = inviteeArray[Index]['isInviteRequired'] === true ? 'Y' : 'N';
        inviteeArray[Index]['isInfoPackRequired'] = inviteeArray[Index]['isInfoPackRequired'] === true ? 'Y' : 'N';
      });
      for (const item of inviteeArray) {
        if (item['name'].length !== 0) {
          let attendee: any;
          attendee = new FidelityInvitees(item['corporateId'].toUpperCase(),
            item['name'],
            item['isCallIn'],
            item['isInviteRequired'],
            item['isInfoPackRequired'],
            item['isInviteForInfoOnly'],
            item['inviteeResponse'] ? item['inviteeResponse'] : '');
          newMeeting.fidelityInvitees.push(attendee);
        }
      }
    }
    const externalContactsArray = Object.values(meetingObj.callRecordsThirdPartyAttendee);
    if (externalContactsArray.length > 0) {
      for (const thirdPartyItem of externalContactsArray) {
        if (thirdPartyItem['companyAttendee'].length !== 0) {
          const externalAttendee = new ThirdPartyAttendee(thirdPartyItem['companyAttendee'] ? convertToTitleCase(thirdPartyItem['companyAttendee']) : '', thirdPartyItem['companyAttendeeId'],
            thirdPartyItem['emailId'], thirdPartyItem['designation'], '');
          newMeeting.thirdPartyAttendee.push(externalAttendee);
        }
      }
    }
    newMeeting.hostCorporateId = meetingObj.hostCorporateId ? meetingObj.hostCorporateId : hostCorporateId;
    newMeeting.emailSubject = meetingObj.companyName + ' - ' + newMeeting.meetingSubType.meetingSubTypeDescription + ' - ' + convertToTitleCase(hostName);
    newMeeting.meetingCreator.corporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
    newMeeting.meetingCreator.creatorName = this.commonService.getLoggedInUserInfo().getName();
    newMeeting.meetingOwnerCorporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
    newMeeting.country.countryCode = this.conferenceDetail.countryCode;
    newMeeting.country.countryDescription = this.conferenceDetail.countryDescription;
    newMeeting.meetingCity = this.conferenceDetail.city;
    newMeeting.businessUnit = this.conferenceDetail.businessUnit;
    newMeeting.meetingDuration = 60;
    newMeeting.meetingLocation.locationType = 'External';
    newMeeting['insertedBy'] = this.commonService.getLoggedInUserInfo().getCorporateId();
    newMeeting.meetingLocation.externalLocationAddress = this.conferenceDetail.venue;
    newMeeting.meetingLocation['internalLocationRoomCode'] = '';
    // newMeeting.arrangementContact.brokerUsageInitiator = this.conferenceDetail.brokerUsageInitiator;
    newMeeting.meetingInitiator.meetingInitiatorCode = this.conferenceDetail.eventInitiatorCode;
    newMeeting.meetingInitiator.meetingInitiatorDescription = this.conferenceDetail.eventInitiatorDescription;
    newMeeting.meetingUpdateDetails.meetingLastUpdatedByCorporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
    newMeeting.meetingUpdateDetails.meetingLastUpdatedByName = convertToTitleCase(this.commonService.getLoggedInUserInfo().getName());
    newMeeting.arrangementContact.organizedThrough = this.conferenceDetail.arrangementContact.organizedThrough ?
      this.conferenceDetail.arrangementContact.organizedThrough : '';
    newMeeting.arrangementContact.organizerContactId = this.conferenceDetail.arrangementContact.organizerContactId ?
      this.conferenceDetail.arrangementContact.organizerContactId : '';
    newMeeting.arrangementContact.organizerName = this.conferenceDetail.arrangementContact.organizerName ?
      this.conferenceDetail.arrangementContact.organizerName : '';
    newMeeting.arrangementContact.organizerCompany = this.conferenceDetail.arrangementContact.organizerCompany ?
      this.conferenceDetail.arrangementContact.organizerCompany : '';
    newMeeting.arrangementContact.organizerPhone = this.conferenceDetail.arrangementContact.organizerPhone ?
      this.conferenceDetail.arrangementContact.organizerPhone : '';
    newMeeting.arrangementContact.organizerEmail = this.conferenceDetail.arrangementContact.organizerEmail;
    newMeeting.arrangementContact.organizerPosition = this.conferenceDetail.arrangementContact.organizerPosition ?
      this.conferenceDetail.arrangementContact.organizerPosition : '';
    newMeeting.arrangementContact.brokerUsageInitiator = this.conferenceDetail.arrangementContact.brokerUsage ? this.conferenceDetail.arrangementContact.brokerUsage : 'Company';
    newMeeting.brokerLocationIndicator = 'N';
    newMeeting.executiveInvited = 'N';
    newMeeting.meetingRegion = this.commonService.getLoggedInUserInfo().getRegionVal();
    this.conferenceSchedule.eventMeetings.push(newMeeting);
  }
  formInitialized(name, form) {
    this.conferenceMeeting.setControl(name, form);
  }
  initializeSchedules(initialResponse) {
    if (initialResponse['eventMeetings']) {
      initialResponse['eventMeetings'].forEach((meetingObj) => {
        let newMeeting = new Meeting('', '', '', '', '', '', '', new MeetingSubtype('', '', '', new MeetingFormat('', '')), new MeetingInitiator('', ''),
          '', '', '', '', new Country('', ''), '', '', '', new DialIn('', ''), new MeetingLocation('', '', '', ''),
          new SecurityDetails('', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
          new AssociatedEventDetail('', '', '', '', '', ''), new ArrangementContact('', '', '', '', '', '', '', ''),
          [], [], new MeetingCreator('', ''), '', '', '', '', '', '', '', '', 0, '', new MeetingUpdateDetails('', '', '', ''),
          '', new DebtTickerDetail('', '', ''), new BrokerDetail('', ''), '', '');
        newMeeting.meetingType = meetingObj.meetingType;
        newMeeting.businessEntity = meetingObj.businessEntity ? meetingObj.businessEntity : '';
        if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'EQ') {
          newMeeting.securityDetail.securityName = meetingObj.securityDetail.securityName;
          newMeeting.securityDetail.securityTradableEntityId = meetingObj.securityDetail.securityTradableEntityId;
          newMeeting.securityDetail.ticker = meetingObj.securityDetail.ticker;
        } else if (newMeeting.meetingType === 'Company' && newMeeting.businessEntity === 'FI') {
          newMeeting.debtTickerDetail.debtTicker = meetingObj.debtTickerDetail.debtTicker;
        } else if (newMeeting.meetingType === 'Broker') {
          newMeeting.brokerDetail.brokerFirmName = meetingObj.brokerDetail ? meetingObj.brokerDetail.brokerFirmName : '';
          newMeeting.brokerDetail.brokerFirmId = meetingObj.brokerDetail ? meetingObj.brokerDetail.brokerFirmId : '';
          newMeeting['brokerFirmId'] = meetingObj.brokerDetail ? meetingObj.brokerDetail.brokerFirmId : '';
        }
        newMeeting.meetingTopic = meetingObj.meetingTopic
          ? meetingObj.meetingTopic
          : (newMeeting.meetingType === 'Broker') ? '-' : '';
        newMeeting.meetingTimezone = this.conferenceDetail.eventTimezone;
        newMeeting.meetingDate = meetingObj.meetingDate ? meetingObj.meetingDate : ''
        newMeeting['meetingDateInLocal'] = meetingObj.meetingDate ? meetingObj.meetingDate : '';
        newMeeting.meetingTimeInGMT = meetingObj.meetingTimeInGMT ? meetingObj.meetingTimeInGMT : '';
        newMeeting.meetingTimeInLocalTimezone = meetingObj.meetingTimeInLocalTimezone ? meetingObj.meetingTimeInLocalTimezone : '';
        // const meetingTime = meetingObj.meetingTimeInGMT;
        // const momenttime = moment(meetingTime, "hmm").format("HH:mm");
        // let localTime = momentTimezone.tz((newMeeting.meetingDate + ' ' + momenttime), newMeeting.meetingTimezone.split(' ')[0]);
        // let userLocalTime = localTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
        // let gmtTime = localTime.clone().tz("Europe/London").format();
        // newMeeting['meetingDateInLocal'] = meetingObj.meetingDate !== '' ? userLocalTime.substring(0, 10) : '';
        // newMeeting.meetingTimeInGMT = meetingObj.meetingTimeInGMT !== '0000' ? gmtTime.substring(11, 13) + gmtTime.substring(14, 16) : '0000';
        // newMeeting.meetingTimeInLocalTimezone = meetingObj.meetingTimeInGMT !== '0000' ? userLocalTime.substring(11, 13) + userLocalTime.substring(14, 16) : '0000';
        newMeeting.scheduleId = meetingObj.scheduleId;
        newMeeting.meetingId = meetingObj.meetingId ? meetingObj.meetingId : '';
        newMeeting.eventScheduleStatus = meetingObj.eventScheduleStatus ? meetingObj.eventScheduleStatus : '';
        newMeeting.meetingState = meetingObj.meetingState;
        newMeeting.meetingSubType.meetingSubTypeCode = meetingObj.meetingSubType.meetingSubTypeCode;
        newMeeting.meetingSubType.meetingSubTypeDescription = meetingObj.meetingSubType.meetingSubTypeDescription;
        newMeeting.meetingSubType.meetingSubTypeOtherDescription = meetingObj.meetingSubType.meetingSubTypeOtherDescription
          ? meetingObj.meetingSubType.meetingSubTypeOtherDescription : '';
        newMeeting.meetingSubType.meetingFormat.meetingFormatCode = meetingObj.meetingSubType.meetingFormat
          ? meetingObj.meetingSubType.meetingFormat.meetingFormatCode : '';
        //  '1';
        newMeeting.meetingSubType.meetingFormat.meetingFormatDescription = meetingObj.meetingSubType.meetingFormat
          ? meetingObj.meetingSubType.meetingFormat.meetingFormatDescription : '';
        // '1on1';
        if (newMeeting.eventScheduleStatus.toUpperCase().includes('CONFIRMED') ||
          newMeeting.eventScheduleStatus.toUpperCase().includes('CANCELLED')) {
          newMeeting.meetingStatus = meetingObj.meetingStatus ? meetingObj.meetingStatus : 'Confirmed';
        } else {
          newMeeting.meetingStatus = '';
        }
        if (meetingObj.meetingStatus) {
          newMeeting.emailSendingReason = 'UPDATED';
        } else {
          newMeeting.emailSendingReason = 'CREATED';
        }
        if (meetingObj.fidelityInvitees.length > 0) {
          meetingObj.fidelityInvitees.forEach((item) => {
            let attendee: any;
            attendee = new FidelityInvitees(item['corporateId'].toUpperCase(),
              item['name'],
              item['isCallIn'] === true ? 'Y' : 'N',
              item['isInviteRequired'] === true ? 'Y' : 'N',
              item['isInfoPackRequired'] === true ? 'Y' : 'N',
              item['isInviteForInfoOnly'] === true ? 'Y' : 'N',
              item['inviteeResponse'] ? item['inviteeResponse'] : '');
            newMeeting.fidelityInvitees.push(attendee);
          });
        }
        if (meetingObj.thirdPartyAttendee.length > 0) {
          meetingObj.thirdPartyAttendee.forEach((item) => {
            const externalAttendee = new ThirdPartyAttendee(item['companyAttendee'] ? convertToTitleCase(item['companyAttendee']) : '', item['companyAttendeeId'],
              item['emailId'], item['designation'], '');
            newMeeting.thirdPartyAttendee.push(externalAttendee);
          });
        }
        newMeeting.hostCorporateId = meetingObj.hostCorporateId ? meetingObj.hostCorporateId : '';
        newMeeting.emailSubject = meetingObj.emailSubject;
        newMeeting.meetingCreator.corporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
        newMeeting.meetingCreator.creatorName = this.commonService.getLoggedInUserInfo().getName();
        newMeeting.meetingOwnerCorporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
        newMeeting.country.countryCode = this.conferenceDetail.countryCode;
        newMeeting.country.countryDescription = this.conferenceDetail.countryDescription;
        newMeeting.meetingCity = meetingObj.meetingCity;
        newMeeting.meetingTimezone = meetingObj.meetingTimezone;
        newMeeting.businessUnit = this.conferenceDetail.businessUnit;
        newMeeting.meetingDuration = meetingObj.meetingDuration;
        // newMeeting.meetingLocation.locationType = meetingObj.meetingLocation ? meetingObj.meetingLocation.locationType : '';
        newMeeting.meetingLocation.locationType = 'External';
        newMeeting['insertedBy'] = this.commonService.getLoggedInUserInfo().getCorporateId();
        // newMeeting.meetingLocation.externalLocationAddress = meetingObj.meetingLocation ? meetingObj.meetingLocation.externalLocationAddress : '';
        newMeeting.meetingLocation.externalLocationAddress = this.conferenceDetail.venue;
        newMeeting.meetingLocation['internalLocationRoomCode'] = '';
        // newMeeting.meetingInitiator.meetingInitiatorCode = meetingObj.meetingInitiator ? meetingObj.meetingInitiator.meetingInitiatorCode : '';
        // newMeeting.meetingInitiator.meetingInitiatorDescription = meetingObj.meetingInitiator ? meetingObj.meetingInitiator.meetingInitiatorDescription : '';
        newMeeting.meetingInitiator.meetingInitiatorCode = this.conferenceDetail.eventInitiatorCode;
        newMeeting.meetingInitiator.meetingInitiatorDescription = this.conferenceDetail.eventInitiatorDescription;
        newMeeting.meetingUpdateDetails.meetingLastUpdatedByCorporateId = this.commonService.getLoggedInUserInfo().getCorporateId();
        newMeeting.meetingUpdateDetails.meetingLastUpdatedByName = convertToTitleCase(this.commonService.getLoggedInUserInfo().getName());
        // newMeeting.meetingUpdateDetails.meetingLastUpdatedByCorporateId = meetingObj.meetingUpdateDetails ? meetingObj.meetingUpdateDetails.meetingLastUpdatedByCorporateId : '';
        // newMeeting.meetingUpdateDetails.meetingLastUpdatedByName = meetingObj.meetingUpdateDetails ? meetingObj.meetingUpdateDetails.meetingLastUpdatedByName : '';
        newMeeting.arrangementContact.organizedThrough = meetingObj.arrangementContact ? meetingObj.arrangementContact.organizedThrough : '';
        newMeeting.arrangementContact.organizerContactId = meetingObj.arrangementContact ? meetingObj.arrangementContact.organizerContactId : '';
        newMeeting.arrangementContact.organizerName = meetingObj.arrangementContact ? meetingObj.arrangementContact.organizerName : '';
        newMeeting.arrangementContact.organizerCompany = meetingObj.arrangementContact.organizerCompany ? meetingObj.arrangementContact.organizerCompany : '';
        newMeeting.arrangementContact.organizerPhone = meetingObj.arrangementContact.organizerPhone ? meetingObj.arrangementContact.organizerPhone : '';
        newMeeting.arrangementContact.organizerEmail = meetingObj.arrangementContact.organizerEmail ? meetingObj.arrangementContact.organizerEmail : '';
        newMeeting.arrangementContact.organizerPosition = meetingObj.arrangementContact.organizerPosition ? meetingObj.arrangementContact.organizerPosition : '';
        // newMeeting.arrangementContact.brokerUsageInitiator = meetingObj.arrangementContact ? meetingObj.arrangementContact.brokerUsageInitiator : '';
        newMeeting.arrangementContact.brokerUsageInitiator = this.conferenceDetail.arrangementContact.brokerUsage ? this.conferenceDetail.arrangementContact.brokerUsage : 'Company';
        newMeeting.executiveInvited = meetingObj.executiveInvited;
        newMeeting.meetingRegion = meetingObj.meetingRegion;
        newMeeting.brokerLocationIndicator = 'N';
        this.initialMeetingSchedules.push(newMeeting);
      });
    }
  }
  checkValidSelection() {
    let eventMeetings: any = this.conferenceMeeting.get('conferenceSchedule-details').get('conferenceDetailGrid').value;
    if (eventMeetings) {
      if (Object.values(eventMeetings).length === 0) {
        return true;
      } else {
        let meetingDateAndTimeMissing = false;
        let cancelledMeetingCount = 0;
        if (this.checkMeetingChanges()) {
          Object.values(eventMeetings).forEach((rowNode) => {
            const meeting = Object.assign({}, rowNode);
            if (meeting['meetingState'].toUpperCase() === 'CONFIRMED') {
              if (!(meeting['meetingDate'] && meeting['meetingTime'] && meeting['hostCorporateId'])) {
                meetingDateAndTimeMissing = true;
              } else {
                const splitValue = meeting['meetingTime'].split(':');
                if (splitValue[0] === '0' && splitValue[1] === '0') {
                  meetingDateAndTimeMissing = true;
                }
              }
            } else if (meeting['meetingState'].toUpperCase() === 'CANCELLED') {
              cancelledMeetingCount++;
              meetingDateAndTimeMissing = false;
            } else {
              meetingDateAndTimeMissing = false;
            }
          });
          if (Object.values(eventMeetings).length === cancelledMeetingCount) {
            return true;
          } else {
            return meetingDateAndTimeMissing;
          }
        } else {
          return true;
        }
      }
    } else {
      return true;
    }
  }
  checkMeetingChanges() {
    const eventMeetings = this.conferenceMeeting.get('conferenceSchedule-details').get('conferenceDetailGrid').value;
    this.conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
    Object.values(eventMeetings).forEach((rowNode) => {
      const meetingObj = Object.assign({}, rowNode);
      this.setEventMeetingValues(meetingObj);
    });
    const newForm = JSON.stringify(this.conferenceSchedule.eventMeetings);
    const oldForm = JSON.stringify(this.initialMeetingSchedules);
    if (newForm === oldForm) {
      return false;
    } else {
      return true;
    }
  }


  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }
}
