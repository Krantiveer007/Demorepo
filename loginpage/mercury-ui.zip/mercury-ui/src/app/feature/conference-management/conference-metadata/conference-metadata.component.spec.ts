import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConferenceMetadataComponent } from './conference-metadata.component';

describe('ConferenceMetadataComponent', () => {
  let component: ConferenceMetadataComponent;
  let fixture: ComponentFixture<ConferenceMetadataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConferenceMetadataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConferenceMetadataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
