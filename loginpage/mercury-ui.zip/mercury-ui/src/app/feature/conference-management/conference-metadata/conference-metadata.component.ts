import { Component, OnInit, Input } from '@angular/core';
import * as moment from 'moment';
import { SimpleChanges } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-conference-metadata',
  templateUrl: './conference-metadata.component.html',
  styleUrls: ['./conference-metadata.component.css']
})
export class ConferenceMetadataComponent implements OnInit {

  @Input() conferenceDetail: any;
  isConferenceDetailsVisible = true;
  constructor(private commonService: CommonService) { }

  ngOnInit() { }

  getFormattedDate(date) {
    if (date) {
      return moment(date).format('D MMM YYYY');
    }
  }

  getValidURL() {
    if (this.conferenceDetail && this.conferenceDetail.website) {
      if (this.conferenceDetail.website.indexOf("//") < 0) {
        return "//" + this.conferenceDetail.website;
      }
      return this.conferenceDetail.website;
    }
    return '';
  }
  ngOnChanges(changes: SimpleChanges) {
    this.conferenceDetail = changes.conferenceDetail.currentValue ? changes.conferenceDetail.currentValue : this.commonService.getConferenceMeetingDtls();
  }
}
