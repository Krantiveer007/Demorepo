import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule, APP_INITIALIZER, Injector } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './core/header/header.component';
import { Mv2SideNavComponent } from './core/sideNav/mv2-side-nav.component';
import { Mv2FooterComponent } from './core/mv2-footer/mv2-footer.component';
import { MeetingManagementModule } from './feature/meeting-management/meeting-management.module';
import { MeetingManagementComponent } from './feature/meeting-management/meeting-management.component';
import { TooltipModule, TypeaheadModule, ModalModule, BsDatepickerModule, TimepickerModule } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TitleCasePipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { loadUtilData, loadPersonData } from 'src/app/configs/feature.factory';
import { CommonService } from 'src/app/core/http/common.service';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { CanActivateAuthGuard } from 'src/app/shared/route-guards/auth-guard.service';
import { ErrorService } from 'src/app/core/error/error.service';
import { BsDropdownModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ContactManagementComponent } from './feature/contact-management/contact-management.component';
import { ContactCardDisplayComponent } from './feature/contact-management/contact-card-display/contact-card-display.component';
import { Mv2EventsSearchComponent } from 'src/app/feature/searchEvents/mv2-events-search.component';
import { ConferenceManagementComponent } from './feature/conference-management/conference-management.component';
import { ConferenceMetadataComponent } from './feature/conference-management/conference-metadata/conference-metadata.component';
import { ConferenceDetailComponent } from './feature/conference-management/conference-detail/conference-detail.component';
import { MeetingScheduleComponent } from './feature/conference-management/conference-detail/meeting-schedule/meeting-schedule.component';
import { CompanyRendererComponent } from './feature/conference-management/conference-detail/meeting-schedule/company-renderer/company-renderer.component';
import { AttendeeRendererComponent } from './feature/conference-management/conference-detail/meeting-schedule/attendee-renderer/attendee-renderer.component';
import 'ag-grid-enterprise';
import { DetailCellRendererComponent } from './shared/components/detail-cellrenderer/detail-cellrenderer.component';
import { ConfigRadioComponent } from './shared/components/config-radio/config-radio.component';
import { MasterGridComponent } from './feature/conference-management/conference-detail/master-grid/master-grid.component';
import { ConfigDropDownComponent } from './shared/components/config-drop-down/config-drop-down.component';
import { ConfigDaterendererComponent } from './shared/components/config-daterenderer/config-daterenderer.component';
import { ConfigTimerendererComponent } from './shared/components/config-timerenderer/config-timerenderer.component';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { ConfigDurationComponent } from './shared/components/config-duration/config-duration.component';
import { RowselectionheaderComponent } from './shared/components/rowselectionheader/rowselectionheader.component';
import { ConfigEditComponent } from './shared/components/config-edit/config-edit.component';
import { TaskNotesComponent } from './feature/conference-management/conference-detail/task-notes/task-notes.component';
import { ConfigEmailComponent } from './shared/components/config-email/config-email.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    Mv2SideNavComponent,
    Mv2FooterComponent,
    ContactManagementComponent,
    ContactCardDisplayComponent,
    Mv2EventsSearchComponent,
    ConferenceManagementComponent,
    ConferenceMetadataComponent,
    ConferenceDetailComponent,
    MeetingScheduleComponent,
    CompanyRendererComponent,
    AttendeeRendererComponent,
    DetailCellRendererComponent,
    ConfigRadioComponent,
    MasterGridComponent,
    ConfigDropDownComponent,
    ConfigDaterendererComponent,
    ConfigTimerendererComponent,
    ConfigDurationComponent,
    RowselectionheaderComponent,
    ContactCardDisplayComponent,
    ConfigEditComponent,
    TaskNotesComponent,
    ConfigEmailComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    MeetingManagementModule,
    TooltipModule.forRoot(),
    TypeaheadModule.forRoot(),
    AgGridModule.withComponents([]),
    NgSelectModule,
    BsDropdownModule.forRoot(),
    PopoverModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    TimePickerModule,
    CKEditorModule
  ],
  entryComponents: [CompanyRendererComponent,
    AttendeeRendererComponent,
    DetailCellRendererComponent,
    ConfigRadioComponent,
    ConfigDropDownComponent,
    ConfigDaterendererComponent,
    ConfigDurationComponent,
    RowselectionheaderComponent],
  providers: [BsModalService, TitleCasePipe, ErrorService, CanActivateAuthGuard,
    {
      provide: APP_INITIALIZER,
      useFactory: loadUtilData,
      deps: [CommonService, Injector],
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: loadPersonData,
      deps: [CommonService, Injector],
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
