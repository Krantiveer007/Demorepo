import { Subject } from 'rxjs/Subject';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { ErrorService } from 'src/app/core/error/error.service';
import { Injectable } from '@angular/core';
import { AppErrorConstants } from 'src/app/shared/app-constant/app-error.constants';
import { OnDestroy, OnInit } from '@angular/core';

@Injectable()
export class CanActivateAuthGuard implements CanActivate {
    message: string = '';
    public isDashboard: Subject<boolean> = new Subject<boolean>();

    constructor(private commonService: CommonService, private router: Router, private errorService: ErrorService) {
    }

    canActivate(route: ActivatedRouteSnapshot) {
        this.message = this.commonService.errorDetailsSubject.getValue();
        const userRoles = this.commonService.getLoggedInUserRoles();
        if (this.message) {
            this.errorService.processError(this.message);
            return false;
        }
        else if (userRoles.length === 0) {
            this.errorService.processError(AppErrorConstants.APP_UNAUTH);
            return false;
        }
        else {
            return true;
        }
    }
}
