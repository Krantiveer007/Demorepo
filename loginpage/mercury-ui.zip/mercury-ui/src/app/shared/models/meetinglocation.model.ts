export class MeetingLocation {
    locationType: string;
    internalLocationRoom: string;
    internalLocationRoomOther: string;
    externalLocationAddress: string;

    constructor(locationType, internalLocationRoom, internalLocationRoomOther, externalLocationAddress) {
        this.locationType = locationType;
        this.internalLocationRoom = internalLocationRoom;
        this.internalLocationRoomOther = internalLocationRoomOther;
        this.externalLocationAddress = externalLocationAddress;
    }
}
