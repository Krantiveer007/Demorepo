import { CompanyContact } from './companyContact.model'
import { BrokerContact } from './brokerContact.model'
import { OtherContact } from './otherContact.model'

export class ContactMapper {
    constructor(public contactType: string,
        public companyContact: CompanyContact,
        public brokerContact: BrokerContact,
        public otherContact: OtherContact) { }
}