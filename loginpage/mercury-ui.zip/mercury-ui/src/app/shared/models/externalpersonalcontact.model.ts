export class ExternalPersonalContact {
    contactType: string;
    externalPersonId: number;
    title: string;
    lastName: string;
    firstName: string;
    email: string;
    telephone: number;
    position: string;
    notes: string;

    constructor(contactType, externalPersonId, title, lastName, firstName, email, telephone, position, notes) {
        this.contactType = contactType;
        this.externalPersonId = externalPersonId;
        this.title = title;
        this.lastName = lastName;
        this.firstName = firstName;
        this.email = email;
        this.telephone = telephone;
        this.position = position;
        this.notes = notes;
    }
}
