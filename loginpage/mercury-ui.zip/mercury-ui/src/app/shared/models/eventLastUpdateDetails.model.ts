export class EventLastUpdateDetails {
        constructor (public corporateId: String, public name : String, public updateReason : String, public updateTimestamp) {}
    }