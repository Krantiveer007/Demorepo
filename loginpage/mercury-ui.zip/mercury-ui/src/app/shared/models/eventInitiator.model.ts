export class EventInitiator {
    constructor(public eventInitiatorCode, public eventInitiatorDescription) {
    }
}
