export class ThirdPartyAttendee {
    externalContactName: string;
    externalContactId: string;
    email: string;
    position: string;
    notes: string;

    constructor(externalContactName, externalContactId, email, position, notes) {
        this.externalContactName = externalContactName;
        this.externalContactId = externalContactId;
        this.email = email;
        this.position = position;
        this.notes = notes;
 }
}
