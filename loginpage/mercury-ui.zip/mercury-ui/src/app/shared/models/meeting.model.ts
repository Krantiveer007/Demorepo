import { MeetingSubtype } from './meetingsubtype.model';
import { MeetingInitiator } from './meetinginitiator.model';
import { Country } from './country.model';
import { DialIn } from './dialin.model';
import { MeetingLocation } from './meetinglocation.model';
import { SecurityDetails } from './securitydetails.model';
import { AssociatedEventDetail } from './associatedeventdetail.model';
import { ArrangementContact } from './arrangementcontact.model';
import { FidelityInvitees } from './fidelityInvitees.model';
import { ThirdPartyAttendee } from './thirdPartyAttendee.model';
import { MeetingCreator } from './meetingcreator.model';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { DebtTickerDetail } from './debtTickerDetail.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';

export class Meeting {
    meetingType: string;
    emailSendingReason: string;
    meetingState: string;
    businessUnit: string;
    executiveInvited: string;
    emailSubject: string;
    meetingTopic: string;
    meetingSubType: MeetingSubtype;
    meetingInitiator: MeetingInitiator;
    meetingDate: string;
    meetingDuration: number;
    meetingTimezone: string;
    additionalNotes: string;
    country: Country;
    meetingCity: string;
    meetingRegion: string;
    privateMeetingFlag: string;
    dialIn: DialIn;
    meetingLocation: MeetingLocation;
    securityDetail: SecurityDetails;
    associatedEventDetail: AssociatedEventDetail;
    arrangementContact: ArrangementContact;
    fidelityInvitees: FidelityInvitees[];
    thirdPartyAttendee: ThirdPartyAttendee[];
    meetingCreator: MeetingCreator;
    meetingCancellationReason: string;
    meetingOwnerCorporateId: string;
    meetingTimeInGMT: string;
    meetingTimeInLocalTimezone: string;
    hostCorporateId: string;
    meetingStatus: string;
    delayedByMins: string;
    meetingId: string;
    scheduleId: string;
    meetingUpdateDetails: MeetingUpdateDetails;
    businessEntity: string;
    debtTickerDetail: DebtTickerDetail;
    brokerDetail: BrokerDetail;
    brokerLocationIndicator: string;
    eventScheduleStatus: string
    
    constructor(meetingType, emailSendingReason, meetingState, businessUnit, executiveInvited, meetingTopic, emailSubject, meetingSubType
        , meetingInitiator, meetingDate, meetingDuration, meetingTimezone, additionalNotes, country, meetingCity, meetingRegion
        , privateMeetingFlag, dialIn, meetingLocation, securityDetail, associatedEventDetail, arrangementContact,
        fidelityInvitees, thirdPartyAttendee, meetingCreator, meetingCancellationReason, meetingOwnerCorporateId,
        meetingLastUpdatedBy, meetingLastUpdatedDateTime, meetingTimeInGMT, meetingTimeInLocalTimezone,
        hostCorporateId, meetingStatus, delayedByMins, meetingId, meetingUpdateDetails, businessEntity, debtTickerDetail, brokerDetail, brokerLocationIndicator,
        eventScheduleStatus) {
        this.meetingType = meetingType;
        this.emailSendingReason = emailSendingReason;
        this.businessUnit = businessUnit;
        this.executiveInvited = executiveInvited;
        this.meetingTopic = meetingTopic
        this.emailSubject = emailSubject;
        this.meetingSubType = meetingSubType;
        this.meetingInitiator = meetingInitiator;
        this.meetingDate = meetingDate;
        this.meetingDuration = meetingDuration;
        this.meetingTimezone = meetingTimezone;
        this.additionalNotes = additionalNotes;
        this.country = country;
        this.meetingCity = meetingCity;
        this.meetingRegion = meetingRegion;
        this.privateMeetingFlag = privateMeetingFlag;
        this.dialIn = dialIn;
        this.meetingLocation = meetingLocation;
        this.securityDetail = securityDetail;
        this.associatedEventDetail = associatedEventDetail;
        this.arrangementContact = arrangementContact;
        this.fidelityInvitees = fidelityInvitees;
        this.thirdPartyAttendee = thirdPartyAttendee;
        this.meetingCreator = meetingCreator;
        this.meetingCancellationReason = meetingCancellationReason;
        this.meetingOwnerCorporateId = meetingOwnerCorporateId;
        this.meetingUpdateDetails = meetingUpdateDetails;
        this.meetingTimeInGMT = meetingTimeInGMT;
        this.meetingTimeInLocalTimezone = meetingTimeInLocalTimezone;
        this.hostCorporateId = hostCorporateId;
        this.meetingState = meetingState;
        this.meetingStatus = meetingStatus;
        this.delayedByMins = delayedByMins;
        this.meetingId = meetingId;
        this.businessEntity = businessEntity;
        this.debtTickerDetail = debtTickerDetail;
        this.brokerDetail = brokerDetail;
        this.brokerLocationIndicator = brokerLocationIndicator;
        this.eventScheduleStatus = eventScheduleStatus;
    }
}
