export class Security {
  assetType: string;
  bbCode: string;
  busEntAltId: string;
  busEntLongDesc: string;
  cusipInt: string;
  factorableInd: string;
  fmrCusip: string;
  grdCountryCd: string;
  grdCountryDesc: string;
  instrCountryOverrideCd: string;
  instrCountryOverrideDesc: string;
  instrumentId: string;
  instrumentLongName: string;
  instrumentShortName: string;
  instrumentStructTypeCd: string;
  instrumentStructTypeDesc: string;
  instrumentTypeCd: string;
  instrumentTypeDesc: string;
  isinCode: string;
  issueCurrencyCd: string;
  liveCusip: string;
  locationCd: string;
  locationDesc: string;
  marketExchangeCd: string;
  marketExchangeDesc: string;
  productCategoryCd: string;
  relatedPortfolioId: string;
  ricCode: string;
  roundLotQty: string;
  sedolCode: string;
  status: string;
  ticker: string;
  tradableEntId: string;
  tradingCurrencyCd: string;
  tseCode: string;
  unitOfCalc: string;
  weight: string;
  searchedIn: string;
  primaryAnalystName: string;
  primaryAnalystCorpId: string;
  marketCapitalization: string;
  marketCapitalizationSize: string;

  constructor(assetType, bbCode, busEntAltId, busEntLongDesc, cusipInt, factorableInd, fmrCusip,
    grdCountryCd, grdCountryDesc, instrCountryOverrideCd, instrCountryOverrideDesc, instrumentId,
    instrumentLongName, instrumentShortName, instrumentStructTypeCd, instrumentStructTypeDesc,
    instrumentTypeCd, instrumentTypeDesc, isinCode, issueCurrencyCd, liveCusip, locationCd,
    locationDesc, marketExchangeCd, marketExchangeDesc, productCategoryCd, marketCapitalization,
    marketCapitalizationSize, relatedPortfolioId, ricCode, roundLotQty, sedolCode, status, ticker,
    tradableEntId, tradingCurrencyCd, tseCode, unitOfCalc, weight, searchedIn, primaryAnalystName, primaryAnalystCorpId) {
    this.assetType = assetType;
    this.bbCode = bbCode;
    this.busEntAltId = busEntAltId;
    this.busEntLongDesc = busEntLongDesc;
    this.cusipInt = cusipInt;
    this.factorableInd = factorableInd;
    this.fmrCusip = fmrCusip;
    this.grdCountryCd = grdCountryCd;
    this.grdCountryDesc = grdCountryDesc;
    this.instrCountryOverrideCd = instrCountryOverrideCd;
    this.instrCountryOverrideDesc = instrCountryOverrideDesc;
    this.instrumentId = instrumentId;
    this.instrumentLongName = instrumentLongName;
    this.instrumentShortName = instrumentShortName;
    this.instrumentStructTypeCd = instrumentStructTypeCd;
    this.instrumentStructTypeDesc = instrumentStructTypeDesc;
    this.instrumentTypeCd = instrumentTypeCd;
    this.instrumentTypeDesc = instrumentTypeDesc;
    this.isinCode = isinCode;
    this.issueCurrencyCd = issueCurrencyCd;
    this.liveCusip = liveCusip;
    this.locationCd = locationCd;
    this.locationDesc = locationDesc;
    this.marketExchangeCd = marketExchangeCd;
    this.marketExchangeDesc = marketExchangeDesc;
    this.productCategoryCd = productCategoryCd;
    this.relatedPortfolioId = relatedPortfolioId;
    this.ricCode = ricCode;
    this.roundLotQty = roundLotQty;
    this.sedolCode = sedolCode;
    this.status = status;
    this.ticker = ticker;
    this.tradableEntId = tradableEntId;
    this.tradingCurrencyCd = tradingCurrencyCd;
    this.primaryAnalystName = primaryAnalystName;
    this.primaryAnalystCorpId = primaryAnalystCorpId;
    this.tseCode = tseCode;
    this.unitOfCalc = unitOfCalc;
    this.weight = weight;
    this.searchedIn = searchedIn;
    this.marketCapitalization = marketCapitalization;
    this.marketCapitalizationSize = marketCapitalizationSize;
  }
  // setbbCode(bbCode: any) {
  //   this.bbCode = bbCode;
  // }
  // getbbCode() {
  //   return this.bbCode;
  // }

  // setfmrCusip(fmrCusip: any) {
  //   this.fmrCusip = fmrCusip;
  // }
  // getfmrCusip() {
  //   return this.fmrCusip;
  // }

  // setInstrumentLongName(instrumentLongName: any) {
  //   this.instrumentLongName = instrumentLongName;
  // }
  // getInstrumentLongName() {
  //   return this.instrumentLongName;
  // }

  // setisinCode(isinCode: any) {
  //   this.isinCode = isinCode;
  // }
  // getisinCode() {
  //   return this.isinCode;
  // }

  // setrelatedPortfolioId(relatedPortfolioId: any) {
  //   this.relatedPortfolioId = relatedPortfolioId;
  // }
  // getrelatedPortfolioId() {
  //   return this.relatedPortfolioId;
  // }

  // setticker(ticker: any) {
  //   this.ticker = ticker;
  // }
  // getticker() {
  //   return this.ticker;
  // }

  // settradableEntId(tradableEntId: any) {
  //   this.tradableEntId = tradableEntId;
  // }
  // gettradableEntId() {
  //   return this.tradableEntId;
  // }

  // setweight(weight: any) {
  //   this.weight = weight;
  // }
  // getweight() {
  //   return this.weight;
  // }

  // setsearchedIn(searchedIn: any) {
  //   this.searchedIn = searchedIn;
  // }
  // getsearchedIn() {
  //   return this.searchedIn;
  // }

  // setCountryDesc(grdCountryDesc: any) {
  //   this.grdCountryDesc = grdCountryDesc;
  // }
  // getCountryDesc() {
  //   return this.grdCountryDesc;
  // }
}
