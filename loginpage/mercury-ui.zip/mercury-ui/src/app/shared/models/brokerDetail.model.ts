export class BrokerDetail {
    constructor (public brokerFirmName: String, public brokerFirmId: String) {}
}