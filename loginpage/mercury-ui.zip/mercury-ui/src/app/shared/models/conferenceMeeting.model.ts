import { MeetingCreator } from "src/app/shared/models/meetingcreator.model";
import { MeetingUpdateDetails } from "src/app/shared/models/meetingUpdateDetails.model";
import { Country } from "src/app/shared/models/country.model";
import { EventInitiator } from "src/app/shared/models/eventInitiator.model";
import { BrokerDetail } from "src/app/shared/models/brokerDetail.model";
import { EventCreator } from "src/app/shared/models/eventCreator.model";
import { EventOwner } from "src/app/shared/models/eventOwner.model";
import { EventLastUpdateDetails } from "src/app/shared/models/eventLastUpdateDetails.model";
import { ArrangementContact } from '../../shared/models/arrangementcontact.model';

export class ConferenceMeeting {
    constructor(public eventId: string,
        public eventType: string,
        public eventName: string,
        public eventRegion: string,
        public eventTimezone: string,
        public eventOwner: EventOwner,
        public website: String,
        public eventLastUpdateDetails: EventLastUpdateDetails,
        public eventCreator: EventCreator,
        public city: string,
        public country: Country,
        public endDate: string,
        public brokerDetail: BrokerDetail,
        public eventInitiator: EventInitiator,
        public venue: string,
        public businessUnit: string,
        public meetingRequestDeadline: string,
        public startDate: string,
        public arrangementContact : ArrangementContact,
        public eventState: string,
        public meetingRegistrationDeadline : string
    ) { }
}