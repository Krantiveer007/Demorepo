export class MeetingCreator {
    corporateId: string;
    creatorName: string;

    constructor(corporateId, creatorName) {
        this.corporateId = corporateId;
        this.creatorName = creatorName;
    }
}
