// not to be used

export class Contacts {
    title: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    mobileNumber: string;
    email: string;
    mailingContact: string;
    notes: string;
    officeAddress: string;
    country: string;
    assistantFullName: string;
    assistantMobileNumber: string;
    assistantEmail: string;
    localTitle: string;
    localFirstName: string;
    localLastName: ['']
    internalPersonName: string;
    corporateId: string;
    dialIn: string;
    accessCode: string;
    companyName: string;
    oraganizationName: string;
    jobPosition: string;
    brokerFirmName: string;
    brokerFirmId: string;
    website: string;

    constructor(title, firstName, lastName, phoneNumber, mobileNumber, email, mailingContact, notes, officeAddress, country, assistantFullName,
        assistantMobileNumber, assistantEmail, localTitle, localFirstName, localLastName, internalPersonName, corporateId, dialIn, accessCode, companyName,
        oraganizationName, jobPosition, brokerFirmName, brokerFirmId, website) {
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.mobileNumber = mobileNumber;
        this.email = email;
        this.mailingContact = mailingContact;
        this.notes = notes;
        this.officeAddress = officeAddress;
        this.country = country;
        this.assistantFullName = assistantFullName;
        this.assistantMobileNumber = assistantMobileNumber;
        this.assistantEmail = assistantEmail;
        this.localTitle = localTitle;
        this.localFirstName = localFirstName;
        this.localLastName = localLastName;
        this.internalPersonName = internalPersonName;
        this.corporateId = corporateId;
        this.dialIn = dialIn;
        this.accessCode = accessCode;
        this.companyName = companyName;
        this.oraganizationName = oraganizationName;
        this.jobPosition = jobPosition;
        this.brokerFirmName = brokerFirmName;
        this.brokerFirmId = brokerFirmId;
        this.website = website;
    }
}
