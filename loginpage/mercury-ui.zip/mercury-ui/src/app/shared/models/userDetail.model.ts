import { timeInRange } from "@progress/kendo-angular-dateinputs/dist/es2015/util";

export class UserDetail {
    constructor(public corporateId: string, public name: string, public phoneNo: string, public userCountry: string,
        public userTimezone: string, public regionCode: string, public legalEntityCode: string, public regionVal: string, public timeZoneDesc,
        public defaultBU: string, public defaultCityCountry: string) { }

    setCorporatId(aid: string) {
        this.corporateId = aid;
    }
    getCorporateId() {
        return this.corporateId;
    }

    setName(name: string) {
        this.name = name;
    }
    getName() {
        return this.name;
    }

    setPhoneNo(phoneNo: string) {
        this.phoneNo = phoneNo;
    }
    getPhoneNo() {
        return this.phoneNo;
    }

    setUserCountry(userCountry: string) {
        this.userCountry = userCountry;
    }
    getUserCountry() {
        return this.userCountry;
    }

    setUserTimezone(userTimezone: string) {
        this.userTimezone = userTimezone;
    }
    getUserTimezone() {
        return this.userTimezone;
    }

    setRegionCode(regionCode: string) {
        this.regionCode = regionCode;
    }
    getRegionCode() {
        return this.regionCode;
    }

    setRegionVal(regionVal: string) {
        this.regionVal = regionVal;
    }
    getRegionVal() {
        return this.regionVal;
    }

    setLegalEntityCode(legalEntityCode: string) {
        this.legalEntityCode = legalEntityCode;
    }
    getLegalEntityCode() {
        return this.legalEntityCode;
    }

    setUserTimezoneDesc(timeZoneDesc: string) {
        this.timeZoneDesc = timeZoneDesc;
    }
    getUserTimezoneDesc() {
        return this.timeZoneDesc;
    }

    setDefaultBU(bu: string) {
        this.defaultBU = bu;
    }

    getDefaultBU() {
        return this.defaultBU;
    }

    setDefaultCityCountry(cityCountry: string) {
        this.defaultCityCountry = cityCountry;
    }

    getDefaultCityCountry() {
        return this.defaultCityCountry;
    }
}