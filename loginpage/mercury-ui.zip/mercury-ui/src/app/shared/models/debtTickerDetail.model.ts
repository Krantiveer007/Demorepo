export class DebtTickerDetail {
    constructor (public debtTicker: String, public analystCorporateId: String, public analystName: String) {}
}