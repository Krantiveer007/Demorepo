export class EventOwner {
    constructor(public corporateId, public name) {
    }
}
