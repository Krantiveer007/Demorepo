export class SecurityDetails {
    securityName: string;
    analyst: string;
    sector: string;
    marketCapitalization: number;
    country: string;
    analystTeam: string;
    analystCorporateId: string;
    marketCapitalizationSize: string;
    stockRegion: string;
    ticker: string;
    bloombergTicker: string;
    cusipIdentifier: string;
    tseIdentifier: string;
    sedolIdentifier: string;
    securityTradableEntityId: string;

    constructor(securityName, analyst, sector, marketCapitalization, country, analystTeam, analystCorporateId,
    marketCapitalizationSize, stockRegion, ticker, bloombergTicker, cusipIdentifier, tseIdentifier,
    sedolIdentifier, securityTradableEntityId) {
          this.securityName = securityName;
          this.analyst = analyst;
          this.sector = sector;
          this.marketCapitalization = marketCapitalization;
          this.country = country;
          this.analystTeam = analystTeam;
          this.analystCorporateId = analystCorporateId;
          this.marketCapitalizationSize = marketCapitalizationSize;
          this.stockRegion = stockRegion;
          this.ticker = ticker;
          this.bloombergTicker = bloombergTicker;
          this.cusipIdentifier = cusipIdentifier;
          this.tseIdentifier = tseIdentifier;
          this.sedolIdentifier = sedolIdentifier;
          this.securityTradableEntityId = securityTradableEntityId;
 }
}

