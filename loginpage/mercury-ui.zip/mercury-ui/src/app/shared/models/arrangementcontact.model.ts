export class ArrangementContact {
    organizedThrough: string;
    organizerContactId: number;
    organizerName: string;
    organizerCompany: string;
    organizerPhone: number;
    organizerEmail: string;
    organizerPosition: string;
    brokerUsageInitiator: string;

    constructor(organizedThrough, organizerContactId, organizerName, organizerCompany, organizerPhone, organizerEmail, organizerPosition, brokerUsageInitiator) {
        this.organizedThrough = organizedThrough;
        this.organizerContactId = organizerContactId;
        this.organizerName = organizerName;
        this.organizerCompany = organizerCompany;
        this.organizerPhone = organizerPhone;
        this.organizerEmail = organizerEmail;
        this.organizerPosition = organizerPosition;
        this.brokerUsageInitiator = brokerUsageInitiator;
    }

    getArrangementContactEmail() {
        return this.organizerEmail;
    }

    getArrangementContactPhone() {
        return this.organizerPhone;
    }
}
