export class InternalContact {

constructor(public corpId: String, public lastName: String, public firstName: String, public dialInNumber: String,
public dailInPin: String, public notes: String, public insertId: String, public updateId: String, public  oldVersionNumber: Number,
public deleteContactFlag: String, public extIntFlag: String) {}

}