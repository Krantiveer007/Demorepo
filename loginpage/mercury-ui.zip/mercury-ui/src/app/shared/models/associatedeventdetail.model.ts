export class AssociatedEventDetail {
    eventType: string;
    eventName: string;
    associatedEventId: number;
    eventStartDate: string;
    eventEndDate: string;
    eventPrincipalHost: string;

    constructor(eventType, eventName, associatedEventId, eventStartDate, eventEndDate, eventPrincipalHost) {
        this.eventType = eventType;
        this.eventName = eventName;
        this.associatedEventId = associatedEventId;
        this.eventStartDate = eventStartDate;
        this.eventEndDate = eventEndDate;
        this.eventPrincipalHost = eventPrincipalHost;
    }
}
