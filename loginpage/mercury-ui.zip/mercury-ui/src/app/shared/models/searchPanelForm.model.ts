export class SearchPanelForm {
    constructor(public meetingType: string, public meetingSubTypeCode: string[], public securityName: string, public securityTradableEntityId: string, public fromDate: number,
    public toDate: string, public insertedTimestamp: string, public hostname: string, public hostCorporateId: string, public attendee: string, public employeeId: string, 
    public businessUnit: string[], public businessEntity: string) {}
}