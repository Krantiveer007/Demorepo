export class MeetingFormat {
    constructor (public meetingFormatCode: string, public meetingFormatDescription: string) {}
}