import { SearchPanelForm } from './searchPanelForm.model';
import { SidePaneSearchPanelForm  } from './sidePaneSearchPanelForm.model';

export class SearchMeetingForm {
    constructor(public searchPanelForm: SearchPanelForm, public sidePaneSearchPanelForm : SidePaneSearchPanelForm ) {}
}