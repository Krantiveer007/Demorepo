class EmailMessage {
    to = [];
    cc = [];
    subject: string;
    htmlText: string;
    replyTo = []
    constructor(to = [], cc = [], subject: string = '', htmlText: string = '', replyTo = []) {
        this.to = to;
        this.cc = cc;
        this.subject = subject;
        this.htmlText = htmlText;
        this.replyTo = replyTo;
    }
}
export class EmailAdvartiseContact {
    message: EmailMessage;
    attachments= []

    constructor(message , attachments) {
        this.message = new EmailMessage();
        this.attachments = attachments;
    }
}
