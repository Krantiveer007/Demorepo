import { Meeting } from "src/app/shared/models/meeting.model";
import { EventLastUpdateDetails } from "src/app/shared/models/eventLastUpdateDetails.model";

export class ConferenceSchedule {
    constructor(
        public eventId: string,
        public eventType: string,
        public eventMeetings: Meeting[],
        public eventLastUpdateDetails: EventLastUpdateDetails,
    ) { }
}