export class MeetingInitiator {
    meetingInitiatorCode: string;
    meetingInitiatorDescription: string;

    constructor(meetingInitiatorCode, meetingInitiatorDescription) {
        this.meetingInitiatorCode = meetingInitiatorCode;
        this.meetingInitiatorDescription = meetingInitiatorDescription;
    }
}
