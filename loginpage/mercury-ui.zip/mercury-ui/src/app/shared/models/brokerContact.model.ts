import {Contact} from './contact.model'
import {BrokerFirm} from'./brokerFirm.model'
export class BrokerContact {
    constructor (public contact: Contact, public brokerFirm: BrokerFirm) {}
}