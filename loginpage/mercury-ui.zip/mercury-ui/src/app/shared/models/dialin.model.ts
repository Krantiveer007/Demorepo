export class DialIn {
    dialInNumber: string;
    dialInAccessCode: string;

    constructor(dialInNumber, dialInAccessCode) {
        this.dialInNumber = dialInNumber;
        this.dialInAccessCode = dialInAccessCode;
    }
}
