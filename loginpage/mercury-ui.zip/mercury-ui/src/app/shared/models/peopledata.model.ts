export class PeopleData {
    busUnitCd: string;
    businessTitle: string;
    cityDesc: string;
    corpId: string;
    costCenterCd: string;
    costCenterDesc: string;
    costCenterSiteCd: string;
    costCenterSiteDesc: string;
    directoryFullName: string;
    displayName: string;
    emailAddress: string;
    firstName: string;
    generalLedgerDesc: string;
    jobTitleName: string;
    lastName: string;
    middleName: string;
    organisationAffilCD: string;
    organisationAffilDesc: string;
    personId: number;
    phoneNo: string;
    prefFirstName: string;
    primarymailZoneCd: string;
    priorFullName: string;
    statusCd: string;

    constructor(busUnitCd, businessTitle, cityDesc, corpId, costCenterCd, costCenterDesc, costCenterSiteCd,
        costCenterSiteDesc, directoryFullName, displayName, emailAddress, firstName, generalLedgerDesc,
        jobTitleName, lastName, middleName, organisationAffilCD, organisationAffilDesc, personId, phoneNo,
        prefFirstName, primarymailZoneCd, priorFullName, statusCd) {
        this.busUnitCd = busUnitCd;
        this.businessTitle = businessTitle;
        this.cityDesc = cityDesc;
        this.corpId = corpId;
        this.costCenterCd = costCenterCd;
        this.costCenterDesc = costCenterDesc;
        this.costCenterSiteCd = costCenterSiteCd;
        this.costCenterSiteDesc = costCenterSiteDesc;
        this.directoryFullName = directoryFullName;
        this.displayName = displayName;
        this.emailAddress = emailAddress;
        this.firstName = firstName;
        this.generalLedgerDesc = generalLedgerDesc;
        this.jobTitleName = jobTitleName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.organisationAffilCD = organisationAffilCD;
        this.organisationAffilDesc = organisationAffilDesc;
        this.personId = personId;
        this.phoneNo = phoneNo;
        this.prefFirstName = prefFirstName;
        this.primarymailZoneCd = primarymailZoneCd;
        this.priorFullName = priorFullName;
        this.statusCd = statusCd;
    }
}
