export class MeetingUpdateDetails {
    
    meetingLastUpdatedByCorporateId: string;
    meetingLastUpdatedByName: string;
    meetingUpdatedReason: string;
    meetingUpdatedMethod: string;

    constructor(meetingLastUpdatedByCorporateId, meetingLastUpdatedByName, meetingUpdatedReason, meetingUpdatedMethod) {
        this.meetingLastUpdatedByCorporateId = meetingLastUpdatedByCorporateId;
        this.meetingLastUpdatedByName = meetingLastUpdatedByName;
        this.meetingUpdatedReason = meetingUpdatedReason;
        this.meetingUpdatedMethod = meetingUpdatedMethod;
    }
}
