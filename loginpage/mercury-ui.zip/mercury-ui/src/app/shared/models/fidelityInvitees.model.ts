export class FidelityInvitees {
    corporateId: string;
    name: string;
    isCallIn: string;
    isInviteRequired: string;
    isInfoPackRequired: string;
    isInviteForInfoOnly: string;
    inviteeResponse: string;
    host: boolean = false;

    constructor(corporateId, name, isCallIn, isInviteRequired, isInfoPackRequired, isInviteForInfoOnly, inviteeResponse) {
        this.corporateId = corporateId;
        this.name = name;
        this.isCallIn = isCallIn;
        this.isInviteRequired = isInviteRequired;
        this.isInfoPackRequired = isInfoPackRequired;
        this.isInviteForInfoOnly = isInviteForInfoOnly;
        this.inviteeResponse = inviteeResponse;
 }
}
