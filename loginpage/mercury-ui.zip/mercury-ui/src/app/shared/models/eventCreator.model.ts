export class EventCreator {
    constructor(public corporateId, public name, public insertedTimestamp) {
    }
}
