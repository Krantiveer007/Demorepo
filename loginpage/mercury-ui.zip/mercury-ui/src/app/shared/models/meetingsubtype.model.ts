import { MeetingFormat } from 'src/app/shared/models/meetingFormat.model';

export class MeetingSubtype {
    meetingSubTypeCode: string;
    meetingSubTypeDescription: string;
    meetingSubTypeOtherDescription: string;
    meetingFormat: MeetingFormat;

    constructor(meetingSubTypeCode, meetingSubTypeDescription, meetingSubTypeOtherDescription, meetingFormat) {
        this.meetingSubTypeCode = meetingSubTypeCode;
        this.meetingSubTypeDescription = meetingSubTypeDescription;
        this.meetingSubTypeOtherDescription = meetingSubTypeOtherDescription;
        this.meetingFormat = meetingFormat;
    }
}
