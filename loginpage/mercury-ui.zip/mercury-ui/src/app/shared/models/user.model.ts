import { UserDetail } from './userDetail.model';
export class User {
    // displayName: string;
    // aid: string;
    // roles: Array<Object>;

    constructor(public roles: Array<Object>, public userDetails: UserDetail) { }
    setRoles(userRoles: Array<Object>) {
        this.roles = userRoles;
    }

    getRoles() {
        return this.roles;
    }

    setUserDetails(userDetails: UserDetail) {
        this.userDetails = userDetails;
    }

    getUserDetails() {
        return this.userDetails;
    }

}