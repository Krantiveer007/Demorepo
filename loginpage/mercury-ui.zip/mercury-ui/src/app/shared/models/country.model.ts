export class Country {
    countryCode: string;
    countryDescription: string;

    constructor(countryCode, countryDescription) {
        this.countryCode = countryCode;
        this.countryDescription = countryDescription;
    }
}
