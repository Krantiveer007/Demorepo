import {Contact} from './contact.model'

export class OtherContact {
    constructor(public contact: Contact, public otherContactType, public companyName) {}
}