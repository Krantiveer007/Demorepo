import { Contact } from './contact.model'

export class CompanyContact {
    constructor(public contact: Contact,
        public sector: string,
        public companyName: string,
        public companyTicker: string,
        public ticker: string,
        public cusip: string) {
    }
}