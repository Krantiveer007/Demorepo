export class SidePaneSearchPanelForm {

    constructor ( public meetingRegion:string[], 
    public countryCode:string[], 
    public meetingCreatorName:string, 
    public meetingCreator:string, 
    public meetingOwner:string, 
    public meetingOwnerCorporateId: string, 
    public tseIdentifier: string, 
    public bloombergTicker: string, 
    public locationType: string, 
    public position: string, 
    public meetingState: string) {

    }
}