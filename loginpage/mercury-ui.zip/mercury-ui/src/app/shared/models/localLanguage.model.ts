export class LocalLanguage {

    constructor (public title: String, public firstName : String, public lastName : String) {}
}