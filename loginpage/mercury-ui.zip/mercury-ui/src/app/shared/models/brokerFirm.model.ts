export class BrokerFirm {
    constructor(public firmName : string,
        public telephone : string,
        public brokerFirmDescription : string,
        public brokerFirmWebsite : string,
        public brokerFirmAddress : string,
        public brokerFirmServiceProvided : string,
        public country : string,
        public region : string,
        public firmId: string,
        public insertID : string,
        public insertTimestamp : Date,
        public updateID : string,
        public updatedTimestamp : Date,
        public versionNumber  : string) { }
}