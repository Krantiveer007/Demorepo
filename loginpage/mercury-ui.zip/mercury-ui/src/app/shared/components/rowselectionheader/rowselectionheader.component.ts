import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-rowselectionheader',
  template: `
    <div class="selectAllRows" style="display: flex; margin-bottom: 10px;">
    <div class="InviteesCheckBox">
        <input type="checkbox" class="invitees-checkbox" [disabled]="isRowSelectDisabled" [checked]="isAllRowsSelected" (change)="selectAllRows($event)">
        <label></label>
    </div>
    </div>
  `,
  styleUrls: ['./rowselectionheader.component.css']
})
export class RowselectionheaderComponent {

  params: any;
  isRowSelectDisabled = false;
  value: any;
  isAllRowsSelected = false;
  constructor(private commonService: CommonService) { }

  agInit(params: any): void {
    this.params = params;
    this.isAllRowsSelected = this.params.context.componentParent.isAllRowsSelected;
    this.isRowSelectDisabled = this.params.context.componentParent.isRowSelectDisabled;
    this.commonService.selectAllRowHeaderCheckbox.subscribe((isAllRowsSelected)=>{
      this.isAllRowsSelected = isAllRowsSelected ? true : false;
    });
    if (params.value === null) {
      return undefined;
    } else {
      this.value = params.data;
    }
  }

  selectAllRows(event: any) {
    this.params.context.componentParent.selectAllRows(event);
  }
}
