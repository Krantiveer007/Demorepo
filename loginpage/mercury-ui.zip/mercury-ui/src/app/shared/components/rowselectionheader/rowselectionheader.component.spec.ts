import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RowselectionheaderComponent } from './rowselectionheader.component';

describe('RowselectionheaderComponent', () => {
  let component: RowselectionheaderComponent;
  let fixture: ComponentFixture<RowselectionheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RowselectionheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RowselectionheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
