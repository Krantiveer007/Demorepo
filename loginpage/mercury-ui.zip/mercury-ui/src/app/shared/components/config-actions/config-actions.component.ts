import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'mv2-config-actions',
  templateUrl: './config-actions.component.html',
  styleUrls: ['./config-actions.component.css']
})
export class ConfigActionsComponent implements ICellRendererAngularComp {

  params: any;
  showActions = false;
  actionGroupUrl = {
    default: '../assets/images/group.svg',
    onHover: '../assets/images/group-copy-5.svg'
  };
  actionGroupImage = this.actionGroupUrl.default;
  constructor() { }
  agInit(params): void {
    this.params = params;
  }
  isPopup() {
    return true;
  }
  onAction() {
    this.showActions = true;
    this.actionGroupImage = this.actionGroupUrl.onHover;
  }
  onImageHover(event) {
    this.actionGroupImage = this.actionGroupUrl.onHover;
  }
  mouseout(event) {
    this.actionGroupImage = this.actionGroupUrl.default;
  }
  refresh(): boolean {
    return false;
  }
}
