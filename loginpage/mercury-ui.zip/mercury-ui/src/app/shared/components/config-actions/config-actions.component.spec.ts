import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigActionsComponent } from './config-actions.component';

describe('ConfigActionsComponent', () => {
  let component: ConfigActionsComponent;
  let fixture: ComponentFixture<ConfigActionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigActionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
