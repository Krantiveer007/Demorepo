import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap';
import { TemplateRef } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { take } from 'rxjs/internal/operators/take';


@Component({
  selector: 'mv2-config-signup',
  template: `
  <button type='button' [disabled]='isSignUpEnabled' style='background: transparent; box-shadow: none!important;'
  class='btn tbl-btn' (click)=onSignUp(template)>
    <img src='{{signUpImage}}' style='height:20px!important;'>
  </button>
  <ng-template #template>
    <div class='modal-header'> 
      <div [ngClass]="{'headerStyleChange': isDLScreenVisible}">
        <h4 class='modal-title pull-left' *ngIf="!isDLScreenVisible">Sign Up</h4>
        <span style="display: flex; cursor: pointer;" (click)="goBackToSignUp('backClicked')">
          <div class="col-auto" style="padding: 20px 10px 0 20px;" *ngIf="isDLScreenVisible">
            <span class="backToSignUp"></span>
          </div>
          <h4 class='col-auto backLableTitle pull-left' *ngIf="isDLScreenVisible" style="padding-left: 0; border-right: 1px solid #dcdee1;">Back to Sign Up</h4>
        </span>
        <label *ngIf="isDLScreenVisible" class="modal-title">Distribution List</label>
      </div>
      <img src='./assets/images/grey-600-copy-3.svg' style='color: #313740;cursor:pointer;margin: 30px 20px;'
      class='pull-right' (click)='checkForNewAttendeeEntry(templateNested)'>
    </div>
    <div class='modal-body'>
      <mv2-mv2-mtg-sign-up (changeToDLScreenEvent)="changeScreen($event)" [distributionList]="distributionList" style='height:100%;' [ngClass]="{'hidden': isDLScreenVisible}"></mv2-mv2-mtg-sign-up>
      <mv2-distribution-list style='height:100%;' (emitEmployeeList)="getSelectedDlEmployeeList($event)" *ngIf="isDLScreenVisible"></mv2-distribution-list>
    </div>
    <div class='modal-footer'>
      <div class='signUpActions'>
        <button type='button' class='btn btn-primary' style="width: 95px;" (click)='saveMtgSignUp(signupResultTemplateNested)' *ngIf="!isDLScreenVisible">Sign Up</button>
        <button type='button' class='btn btn-secondary' (click)="goBackToSignUp('addToSignUp')" [disabled]="!isSubmitDLsEnabled" *ngIf="isDLScreenVisible">Add</button>
      </div>
    </div>
  </ng-template>

  <ng-template #templateNested>
  <div class='modal-header' style="height: 10%">
  <div class="row" style="width:100%; align-items: center;">
      <div class="col-10">
          <h4 class='modal-title pull-left' style="height: auto; padding: 20px">{{messageHeading}}</h4>
      </div>
     
  </div>
</div>
<div class='modal-body' style="height: 80%">
  <div class="row" style="margin: 15px !important; border: solid 1px #c7cbcf; align-items: center;">
      <div class="col-3" style="height: 90px;text-align: center;font-size: xx-large;padding-top: 18px; background-color: #edae00">
          <img src="./assets/images/message/alert.svg" style='width: 40px;height: 40px;'>

      </div>
      <div class="col-9">
          {{routeConfirmMessage}}
      </div>
  </div>
</div>
<div class='modal-footer' style="height: 10%; justify-content: center;">
<button type="button" class="btn btn-secondary" style="width: 80px; height: 32px; font-size:15px;" (click)="decline()">No</button>
  <button type="button" class="btn btn-primary" style="width: 80px; height: 32px; font-size:15px; margin-left: 20px;" (click)="confirm()">Yes</button>
  
</div>
</ng-template>

<ng-template #signupResultTemplateNested>
  <div class='modal-header'>
  <div class="row" style="width:100%; align-items: center;">
      <div class="col-10">
          <h4 class='modal-title pull-left headingHeight'>{{signupResultHeading}}</h4>
      </div>
     
  </div>
</div>
<div class='modal-body'>
  <div class="row" style="margin: 15px !important; border: solid 1px #c7cbcf; align-items: center;">
      <div class="col-3" [ngStyle]="{'background-color': imageStatus == 'alert'? '#edae00' : '#4AA00F'}" style="height: 90px;text-align: center;font-size: xx-large;padding-top: 18px;"
                        [ngClass]="{colorChange: imageStatus === 'alert'}">
          <img src="./assets/images/message/{{imageStatus}}.svg" style="width:40px;" [ngClass]="{alertSize: imageStatus==='alert'}">

      </div>
      <div class="col-9">
          {{signupResultMessage}}
      </div>
  </div>
</div>
<div class='modal-footer' style="justify-content: center;">
<button type="button" class="btn btn btn-secondary" style="width: 106px; height: 32px; font-size:15px;" (click)="confirmOK()">OK</button>
</div>
</ng-template>
`,
  styleUrls: ['./config-signup.component.css']
})
export class ConfigSignupComponent implements OnInit {
  public params: any;
  rowIndex: any;
  modalRef: BsModalRef | null;
  modalRef2: BsModalRef;
  modalRef3: BsModalRef;
  isSignUpEnabled = true;
  signUpAttendeeList: {};
  signupResultHeading = '';
  signupResultMessage = '';
  imageStatus = '';
  signUpUrl = {
    Enable: '../assets/images/group-355-copy.svg',
    Disable: '../assets/images/group-355-copy-3.svg'
  };
  signUpImage = this.signUpUrl.Disable;
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
  configSecond = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'second'
  };
  isDLScreenVisible = false;
  isSubmitDLsEnabled = false;
  distributionList = [];
  emittedDLFromDLGrid = [];
  messageHeading = 'Confirm Navigation';
  routeConfirmMessage = 'Selected fidelity participants will not be added to the meeting. Are you sure you want to exit ?';
  isModalShown = false;
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  constructor(private commonService: CommonService, private modalService: BsModalService, private fb: FormBuilder) { }

  agInit(params): void {
    this.params = params;
    const todaysDate = new Date;
    const meetingDate = new Date(this.params.data.meetingDate);
    const meetingState = this.params.data.meetingState;
    const oneDay = 1000 * 60 * 60 * 24;
    const differenceDays = Math.floor((meetingDate.getTime() - todaysDate.getTime()) / (oneDay));
    if (differenceDays >= -1 && meetingState.toUpperCase() !== 'CANCELLED') {
      this.isSignUpEnabled = false;
      this.signUpImage = this.signUpUrl.Enable;
    }
    // if (this.params.data.meetingType === 'Company - FI') {
    //   this.isSignUpEnabled = true;
    //   this.signUpImage = this.signUpUrl.Disable;
    // }
  }

  ngOnInit() {
    this.commonService.signUpAttendeeListObservable.subscribe((attendeeList) => {
      this.signUpAttendeeList = attendeeList;
    });
  }

  onSignUp(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
    this.commonService.setMeetingType(this.params.data['meetingType'] ? this.params.data['meetingType'] : '');
    this.commonService.signUpMeetingIdChange(this.params.data);
  }

  saveMtgSignUp(template: TemplateRef<any>) {
    if (this.signUpAttendeeList['fidelityInvitees'].length !== 0) {
      this.commonService.insertMtgSignUpAttendees(this.signUpAttendeeList).subscribe((response) => {
        // this.modalRef.hide();
        this.signupResultHeading = 'Signup Successful';
        this.signupResultMessage = 'Attendees have been signed up sucessfully';
        this.imageStatus = 'success';
        this.modalRef3 = this.modalService.show(template, this.configSecond);
        this.commonService.changeFilAttendeeList([]);
      }, (error) => {
        this.signupResultHeading = 'Signup Unsuccessful';
        this.signupResultMessage = 'Unable to signup Attendees. Please try again';
        this.imageStatus = 'alert';
        this.modalRef3 = this.modalService.show(template, this.configSecond);
        console.log(error);
      });
    } else {
      this.modalRef.hide();
      this.distributionList = [];
    }
  }

  confirmOK() {
    if (this.signupResultHeading === 'Signup Successful') {
      this.modalRef3.hide();
      this.modalRef.hide();
      this.distributionList = [];
    } else {
      this.modalRef3.hide();
    }
  }

  refresh(): boolean {
    return false;
  }

  checkForNewAttendeeEntry(templateNested: TemplateRef<any>) {
    if (this.signUpAttendeeList['fidelityInvitees'].length !== 0) {
      this.modalRef2 = this.modalService.show(templateNested, this.configSecond);
    }
    else {
      this.modalRef.hide();
      this.distributionList = [];
      this.isDLScreenVisible = false;
      this.commonService.changeFilAttendeeList([]);
    }
  }

  confirm() {
    this.modalRef2.hide();
    this.modalRef.hide();
    this.distributionList = [];
  }
  decline() {
    this.modalRef2.hide();
  }

  onHidden(): void {
    this.confirmModal.hide();
    this.isModalShown = false;
  }
  changeScreen(event) {
    if (event) {
      this.isDLScreenVisible = event;
    }
  }
  getSelectedDlEmployeeList(event) {
    this.emittedDLFromDLGrid = event;
    if (this.emittedDLFromDLGrid.length !== 0) {
      this.isSubmitDLsEnabled = true;
    } else {
      this.isSubmitDLsEnabled = false;
    }
  }

  goBackToSignUp(event) {
    if (event === 'addToSignUp') {
      if (this.emittedDLFromDLGrid) {
        this.distributionList = this.emittedDLFromDLGrid;
        // this.commonService.changeFilAttendeeList(this.distributionList);
      }
    }
    this.isDLScreenVisible = false;
  }
}
