import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigSignupComponent } from './config-signup.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { TypeaheadModule, BsModalService, TooltipModule } from 'ngx-bootstrap';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { Mv2MtgSignUpComponent } from 'src/app/feature/meeting-management/mv2-mtg-sign-up/mv2-mtg-sign-up.component';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';

describe('ConfigSignupComponent', () => {
  let component: ConfigSignupComponent;
  let fixture: ComponentFixture<ConfigSignupComponent>;
  const params = {
    data: {
      meetingDate: new Date
    }
  };
  const EnableImageUrl = '../assets/images/group-355-copy.svg';
  const DisableImageUrl = '../assets/images/group-355-copy-3.svg';
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        AgGridModule.withComponents([]),
        HttpClientModule,
        TooltipModule.forRoot()
      ],
      declarations: [ConfigSignupComponent, Mv2MtgSignUpComponent, CommonGridComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, BsModalService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigSignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should Verify that user should able to see the Sign Up button for the Todays meeting or Future dated meeting', () => {
    component.agInit(params);
    fixture.detectChanges();
    /*Should be Enable for Todays Meeting*/
    expect(component.signUpImage).toEqual(EnableImageUrl);
    expect(component.isSignUpEnabled).toEqual(false);
  });
  it('should Verify that Sign Up button for the Past dated meeting should be disabled', () => {
    params.data.meetingDate = new Date('05/05/2019');
    component.agInit(params);
    fixture.detectChanges();
    /*Should be Disable for Past Date Meeting*/
    expect(component.signUpImage).toEqual(DisableImageUrl);
    expect(component.isSignUpEnabled).toEqual(true);
  });
});
