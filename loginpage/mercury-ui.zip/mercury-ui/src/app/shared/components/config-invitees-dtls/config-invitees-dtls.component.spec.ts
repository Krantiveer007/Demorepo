import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigInviteesDtlsComponent } from './config-invitees-dtls.component';
import { FormsModule } from '@angular/forms';
import { TypeaheadModule, TypeaheadMatch } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
import { CommonService } from 'src/app/core/http/common.service';
import { of, throwError } from 'rxjs';
import { Observable } from 'rxjs/Observable';

describe('ConfigInviteesDtlsComponent', () => {
  let component: ConfigInviteesDtlsComponent;
  let fixture: ComponentFixture<ConfigInviteesDtlsComponent>;
  const peopleData =
    [{ 'corpId': 'A482682', 'displayName': 'SHEVADEKAR, SAPAN' },
    { 'corpId': 'A366680', 'displayName': 'MAINI, PANKAJ' },
    { 'corpId': 'A497865', 'displayName': 'GANDHI, PANKAJ' },
    { 'corpId': 'A501403', 'displayName': 'YADAV, PANKAJ' },
    { 'corpId': 'A498527', 'displayName': 'GUPTA, SAPAN' }
    ];
  const manipulatePeopleData = [
    'Shevadekar, Sapan' + ' &lt;' + 'A482682' + '&gt;',
    'Maini, Pankaj' + ' &lt;' + 'A366680' + '&gt;',
    'Gandhi, Pankaj' + ' &lt;' + 'A497865' + '&gt;',
    'Yadav, Pankaj' + ' &lt;' + 'A501403' + '&gt;',
    'Gupta, Sapan' + ' &lt;' + 'A498527' + '&gt;'
  ];
  const thirdPartyAttendee = {
    body: {
      Items: [{
        tradableEntityId: '12345',
        ContactStatus: 'Y',
        CreatedBy: 'a464909',
        CreatedDateTime: '22-JAN-09 11.12.45.000000000',
        Email: 'UNKWN530@unknown.uk',
        ExternalContactId: '2019-04-03T05:44:36.000Z#2780971a-0e57-4a5e-ba73-550a763fb957',
        ExternalContactType: 'CC',
        FirstName: 'Ian',
        LastName: 'Thornton',
        ExternalContactName: 'Thornton, Ian',
        LastUpdatedBy: 'a295812',
        LastUpdatedDateTime: '28-JUN-12 09.50.21.000000000',
        Notes: '',
        Position: 'Head of IR',
        Ticker: '*ARMHARM HOLDINGS PLC',
        Title: 'Mr.',
        Version: '3',
      },
      {
        CompanyName: 'ARM HOLDINGS PLC',
        ContactStatus: 'Y',
        CreatedBy: 'a464909',
        CreatedDateTime: '22-JAN-09 11.12.45.000000000',
        Email: 'UNKWN530@unknown.uk',
        ExternalContactId: '2019-04-03T05:44:36.000Z#2780971a-0e57-4a5e-ba73-550a763fb957',
        ExternalContactType: 'CC',
        FirstName: 'Ian',
        LastName: 'Hood',
        ExternalContactName: 'Hood, Ian',
        LastUpdatedBy: 'a295812',
        LastUpdatedDateTime: '28-JUN-12 09.50.21.000000000',
        Notes: '',
        Position: 'Head of IR',
        Ticker: '*ARMHARM HOLDINGS PLC',
        Title: 'Mr.',
        Version: '3',
      }]
    }
  };
  const manipulateExternalContacts = [
    'Thornton, Ian',
    'Hood, Ian'
  ];

  const params = {
    api: {
      sizeColumnsToFit: () => { },
      refreshCells: () => { }
    },
    gridColumnApi: {},
    value: 'Verma, Pankaj',
    column: {
      colDef: {
        headerName: 'FIL Invitees'
      }
    },
    context: {
      componentParent: {
        rowData: [{
          'Attendee': '',
          'AttendeeId': '',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        },
        {
          'Attendee': '',
          'AttendeeId': '',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        },
        {
          'Attendee': '',
          'AttendeeId': '',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        }],
        rowClicked: () => { }
      }
    }
  };
  const paramsFIlAteendeeFilled = {
    api: {
      sizeColumnsToFit: () => { },
      refreshCells: () => { }
    },
    gridColumnApi: {},
    value: '',
    column: {
      colDef: {
        headerName: 'FIL Invitees'
      }
    },
    context: {
      componentParent: {
        rowData: [{
          'Attendee': 'Man, Bat',
          'AttendeeId': 'a969969',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        },
        {
          'Attendee': 'Strange, Doctor',
          'AttendeeId': 'a969696',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        },
        {
          'Attendee': 'Yadav, Pankaj',
          'AttendeeId': 'a969696',
          'Call-In': false,
          'Infopacks': false,
          'Info Only': false,
          'Remove': ''
        }],
        rowClicked: () => { }
      }
    }
  };

  const paramsSignUpAttendee = {
    api: {
      sizeColumnsToFit: () => { },
      refreshCells: () => { }
    },
    gridColumnApi: {},
    value: '',
    column: {
      colDef: {
        headerName: 'FIL Invitees'
      }
    },
    context: {
      componentParent: {
        rowData: [{
          'signUpAttendeeName': 'Man, Spider',
          'corporateId': 'a565655',
          'isCallIn': false,
          'isInfoPackRequired': false,
          'isInviteForInfoOnly': false,
          'Remove': ''
        },
        {
          'signUpAttendeeName': 'Man, Bat',
          'corporateId': 'a666666',
          'isCallIn': false,
          'isInfoPackRequired': false,
          'isInviteForInfoOnly': false,
          'Remove': ''
        },
        {
          'signUpAttendeeName': 'Yadav, Pankaj',
          'corporateId': 'A501403',
          'isCallIn': false,
          'isInfoPackRequired': false,
          'isInviteForInfoOnly': false,
          'Remove': ''
        }],
        rowClicked: () => { }
      }
    }
  };
  const paramsThirdPartyAttendee = {
    api: {
      sizeColumnsToFit: () => { },
      refreshCells: () => { }
    },
    gridColumnApi: {},
    value: 'Verma, Pankaj',
    column: {
      colDef: {
        headerName: 'Attendee'
      }
    },
    context: {
      componentParent: {
        rowData: [{
          'ExternalContactName': 'Thornton, Ian',
          'ExternalContactId': '132456',
          'Email': 'ian.thornton@fil.com',
          'Position': 'CEO',
          'Notes': 'Test',
          'Remove': ''
        },
        {
          'ExternalContactName': 'Hood, Ian',
          'ExternalContactId': '123456',
          'Email': 'hood.Ian@fil.com',
          'Position': 'CFO',
          'Notes': 'Test',
          'Remove': ''
        },
        {
          'ExternalContactName': 'Thomas, Hood',
          'ExternalContactId': '132456',
          'Email': 'hood.thomas@fil.com',
          'Position': 'CTO',
          'Notes': 'Test',
          'Remove': ''
        }],
        rowClicked: () => { }
      }
    }
  };
  const peopleDataEvent: TypeaheadMatch = new TypeaheadMatch('Yadav, Pankaj &lt;A501403&gt;', 'Yadav, Pankaj &lt;A501403&gt;', false);
  const externalContactEvent: TypeaheadMatch = new TypeaheadMatch('Thornton, Ian', 'Thornton, Ian', false);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        TypeaheadModule.forRoot(),
        HttpClientModule,
        AgGridModule.withComponents([])
      ],
      declarations: [ConfigInviteesDtlsComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigInviteesDtlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have grid parameters', () => {
    component.agInit(params);
    expect(component.asyncSelected).toEqual('Verma, Pankaj');
  });
  it('should be able to get suggestion list of matching person when user types 3 characters', () => {
    component.asyncSelected = 'pan';
    component.inviteeType = 'FIL Invitees';
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(peopleDataService, 'getPeopleData').and.returnValue(of(peopleData));
    fixture.detectChanges();
    component.getPeopleData();
    fixture.detectChanges();

    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulatePeopleData);
    });
  });
  it('should be able to get thirdPartyAttendee of selected security when user types 3 characters', () => {
    component.asyncSelected = 'Ian';
    component.tradableEntityId = '12345';
    component.inviteeType = 'Attendee';
    const dataService = fixture.debugElement.injector.get(CommonService);
    const spy = spyOn(dataService, 'getExternalContacts').and.returnValue(of(thirdPartyAttendee));
    fixture.detectChanges();
    component.getPeopleData();
    fixture.detectChanges();
    component.peopleDataSource.subscribe(response => {
      expect(response).toEqual(manipulateExternalContacts);
    });
  });
  it('should throw error while fetching data from service', () => {
    component.asyncSelected = 'Pan';
    component.tradableEntityId = '12345';
    component.inviteeType = 'Attendee';
    const peopleDataService = fixture.debugElement.injector.get(CommonService);
    spyOn(peopleDataService, 'getExternalContacts').and.returnValue(throwError('Error Thrown'));
    fixture.detectChanges();
    component.getPeopleData();
    fixture.detectChanges();
    component.peopleDataSource.subscribe((response) => {
      expect(response).toEqual([]);
    },
      (error) => {
      });
  });
  it('should return only name on typeheadselect for Meeting Host', () => {
    fixture.detectChanges();
    component.agInit(params);
    fixture.detectChanges();
    component.typeaheadOnSelect(peopleDataEvent);
    expect(component.asyncSelected).toEqual('Yadav, Pankaj');
  });
  it('should return ContactName on typeheadselect for ThirdPartyAttendee', () => {
    params.column.colDef.headerName = 'Attendee';
    fixture.detectChanges();
    component.agInit(params);
    fixture.detectChanges();
    component.typeaheadOnSelect(externalContactEvent);
    expect(component.asyncSelected).toEqual('Thornton, Ian');
  });
  it('should Verify that user should NOT able to add duplicate entries for the Third Party Attendees', () => {
    fixture.detectChanges();
    component.agInit(paramsThirdPartyAttendee);
    fixture.detectChanges();
    /*Thornton, Ian already added in Params and is passed as a new Attendee in typeaheadOnSelect*/
    component.typeaheadOnSelect(externalContactEvent);
    // Expected to return true: means attendee already exists
    expect(component.alreadyExistsError).toEqual(true);
  });
  it('should Verify that user should NOT able to add duplicate entries for the SignUp Attendees', () => {
    fixture.detectChanges();
    component.agInit(paramsSignUpAttendee);
    fixture.detectChanges();
    /*Thornton, Ian already added in Params and is passed as a new Attendee in typeaheadOnSelect*/
    component.typeaheadOnSelect(peopleDataEvent);
    // Expected to return true: means attendee already exists
    expect(component.alreadyExistsError).toEqual(true);
  });
  it('should Verify that user should NOT able to add duplicate entries for the Fidelity Attendees', () => {
    fixture.detectChanges();
    component.agInit(paramsFIlAteendeeFilled);
    fixture.detectChanges();
    /*Thornton, Ian already added in Params and is passed as a new Attendee in typeaheadOnSelect*/
    component.typeaheadOnSelect(peopleDataEvent);
    // Expected to return true: means attendee already exists
    expect(component.alreadyExistsError).toEqual(true);
  });
  it('should Verify that user should be add a attendee and remove it and then add it again without getting an duplicate error', () => {
    fixture.detectChanges();
    paramsFIlAteendeeFilled.value = 'Yadav, Pankaj';
    component.agInit(paramsFIlAteendeeFilled);
    fixture.detectChanges();
    /*Thornton, Ian already added in Params and is passed as a new Attendee in typeaheadOnSelect*/
    component.typeaheadOnSelect(peopleDataEvent);
    // Expected to return true: means attendee already exists
    expect(component.alreadyExistsError).toEqual(false);
  });
  it('should show loading when a letter is typed', () => {
    component.changeTypeaheadLoading(true);
    fixture.detectChanges();
    expect(component.typeaheadLoading).toEqual(true);
  });
  it('should error message when type searched value is not found', () => {
    component.typeaheadNoResults(true);
    fixture.detectChanges();
    expect(component.errorResponse).toEqual(true);
  });
});
