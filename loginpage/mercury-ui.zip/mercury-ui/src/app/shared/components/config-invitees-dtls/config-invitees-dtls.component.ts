import { Component, OnInit, AfterViewInit, NgZone, ViewContainerRef, ViewChild } from '@angular/core';
import { AgEditorComponent } from 'ag-grid-angular/main';
import { Observable, Subscription, EMPTY } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Params } from '@angular/router';
import * as moment from 'moment';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { filterExternalContactResponse, filterPeopleResponse } from 'src/app/shared/utils/filter-response.utility';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { TypeaheadData, TypeaheadDataSource } from 'src/app/shared/utils/typeahead.utility';
@Component({
  selector: 'mv2-config-invitees-dtls',
  styleUrls: ['./config-invitees-dtls.component.css'],
  template: `
  <div [ngClass]="{'failedSearch':errorResponse}">
  <input [(ngModel)]='asyncSelected' class='form-control meetingAttendee' [ngClass]="{'loader': typeaheadLoading}" [typeaheadScrollable]='true'
      [typeaheadOptionsInScrollableView]='7' typeaheadOptionsLimit='9999' typeaheadMinLength=3 typeaheadOptionField="selectedVal"
      (input)='getMtgParticipants()' [typeaheadAsync]='true' (typeaheadNoResults)='typeaheadNoResults($event)' (typeaheadOnSelect)='typeaheadOnSelect($event)'
      (typeaheadLoading)='changeTypeaheadLoading($event)' (keydown.Tab)="tabKeyPressed($event)" #container [disabled]="enableCheckBox"
      [typeahead]='peopleDataSource' (blur)="onBlur()" [typeaheadWaitMs]="1000" placeholder={{searchPlaceholder}}>
  <div class='alert alert-danger searchErrorResponse' *ngIf='errorResponse'>No matching results found, please try again.</div>
  <div class='alert alert-danger alreadyExistsError' *ngIf='alreadyExistsError'>Attendee already exists in the meeting</div>
  <div class='alert alert-danger securityNameRequired' *ngIf='(securityRequired || brokerFirmRequired)'>{{paramIsRequiredMessage}}</div>
  </div>`
})
export class ConfigInviteesDtlsComponent implements OnInit, AgEditorComponent, AfterViewInit {
  @ViewChild('container', { read: ViewContainerRef }) public container;
  peopleDataSource: Observable<any>;
  params: any;
  asyncSelected: any;
  peopleDataSubscription: Subscription;
  data: any;
  typeaheadLoading = false;
  errorResponse = false;
  alreadyExistsError = false;
  visited = false;
  inviteeId: string;
  inviteeType: string;
  tradableEntityId = '';
  externalContacts: any = [];
  securityRequired = false;
  brokerFirmRequired = false;
  paramIsRequiredMessage = 'Security Name Required';
  enableCheckBox = false;
  searchPlaceholder = '';
  currentAction = '';
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);

  constructor(private commonService: CommonService, private ngZone: NgZone, private route: ActivatedRoute) {
    this.commonService.tradableEntityIdObservable.subscribe(message => this.tradableEntityId = message);
  }

  ngOnInit() {
    this.peopleDataSource = EMPTY;
  }
  agInit(params) {
    this.data = params;
    this.inviteeType = params.column.colDef.headerName;
    if (this.data.value) {
      this.asyncSelected = this.data.value;
    }
    this.route.params.subscribe((params: Params) => {
      this.currentAction = params['action'];
    });
    if (this.inviteeType === 'Attendee' || this.inviteeType === 'Company Attendee') {
      this.searchPlaceholder = 'Search by last name...';
    } else if (this.inviteeType === 'FIL Invitees') {
      this.searchPlaceholder = 'Search by last name/AID...'
    }
  }

  isPopup() {
    return true;
  }

  getMtgParticipants(): void {
    const selectedSecurityType = this.data.context.componentParent.selectedSecurity ? this.data.context.componentParent.selectedSecurity : '';
    if (this.inviteeType === 'Attendee'
      && this.tradableEntityId.length === 0
      && this.commonService.getMeetingType().includes('Company')
      && selectedSecurityType === 'Equity') {
      this.securityRequired = true;
      this.paramIsRequiredMessage = 'Security Name Required';
      this.typeaheadLoading = false;
    } else if (this.commonService.getMeetingType() === 'Other'
      || this.commonService.getMeetingType() === 'Broker'
      || selectedSecurityType === 'Fixed Income') {
      this.securityRequired = false;
    } else if (this.inviteeType === 'Attendee'
      && this.commonService.getMeetingType() === 'Broker'
      && this.commonService.getBrokerFirmDetails().brokerFirmName.length === 0) {
      this.securityRequired = false;
      this.brokerFirmRequired = true;
      this.paramIsRequiredMessage = 'Broker Firm Required';
      this.typeaheadLoading = false;
    } else if (this.commonService.getMeetingType() === 'Conference') {
      this.securityRequired = false;
    }
    if (((this.commonService.getMeetingType().includes('Company') && !this.securityRequired && selectedSecurityType === 'Equity')
      || this.commonService.getMeetingType() === 'Other'
      || (this.commonService.getMeetingType() === 'Broker' && !this.brokerFirmRequired)
      || (this.commonService.getMeetingType().includes('Company') && selectedSecurityType === 'Fixed Income')
      || this.commonService.getMeetingType() === 'Conference')) {
      if (this.inviteeType === 'FIL Invitees') {
        this.getPeopleData();
      } else if (this.inviteeType === 'Attendee' || this.inviteeType === 'Company Attendee') {
        this.getExternalContactData(selectedSecurityType);
      }
    }
    if (this.asyncSelected.length < 3) {
      this.alreadyExistsError = false;
    }
  }

  getExternalContactData(selectedSecurityType: string): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.asyncSelected.toUpperCase();
    if (this.commonService.getMeetingType().includes('Company') && selectedSecurityType === 'Equity') {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue,
        this.commonService.securities.ticker,
        'Company', selectedSecurityType);
    } else if ((this.commonService.getMeetingType() === 'Other')
      || (this.commonService.getMeetingType() === 'Conference')
      || (this.commonService.getMeetingType().includes('Company') && selectedSecurityType === 'Fixed Income')) {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue,
        '',
        'All', selectedSecurityType);
    } else if (this.commonService.getMeetingType() === 'Broker') {
      typeaheadData = this.typeaheadDataSource.getExternalContactsData(searchedValue,
        this.commonService.getBrokerFirmDetails().brokerFirmId,
        'Broker', '');
    }
    this.peopleDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
  }

  getPeopleData(): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.asyncSelected;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
    this.errorResponse = typeaheadData.isResponseError;
  }

  onBlur() {
    this.asyncSelected = '';
    // this.alreadyExistsError = false;
    this.getMtgParticipants();
  }

  changeTypeaheadLoading(e: boolean): void {
    this.typeaheadLoading = e;
  }
  typeaheadOnSelect(event) {
    let selectedEventInstance = event;
    const selectedName = (this.inviteeType !== 'Attendee' && this.inviteeType !== 'Company Attendee') ? convertToTitleCase(selectedEventInstance.item.name) : selectedEventInstance.item.fullname
    if (this.data.value === selectedName) {
      this.alreadyExistsError = false;
    } else {
      let rowDataValue = [];
      if (this.commonService.getMeetingType() === 'Conference' && this.data.colDef.field === 'name') {
        rowDataValue = this.data.context.componentParent.rowDataFilAttendee;
      } else if (this.commonService.getMeetingType() === 'Conference' && this.data.colDef.field === 'companyAttendee') {
        rowDataValue = this.data.context.componentParent.rowDataThirdPartyAttendee;
      } else {
        rowDataValue = this.data.context.componentParent.rowData;
      }
      rowDataValue.every((node) => {
        if (this.inviteeType === 'FIL Invitees') {
          if ('Attendee' in node) {
            this.alreadyExistsError = (node.Attendee.replace(' (Host)', '') === selectedName) ? true : false;
          } else if ('name' in node) {
            this.alreadyExistsError = (node.name === selectedName) ? true : false;
          }
          else {
            this.alreadyExistsError = (node.signUpAttendeeName === selectedName) ? true : false;
          }
        } else {
          if (this.inviteeType === 'Company Attendee') {
            this.alreadyExistsError = (node.companyAttendee === selectedName && node.company.toUpperCase() === selectedEventInstance.item.company.toUpperCase()) ? true : false;
          } else if (this.commonService.getMeetingType() !== 'Broker') {
            this.alreadyExistsError = (node.ExternalContactName.toUpperCase() === selectedName.toUpperCase() && node.Company.toUpperCase() === selectedEventInstance.item.company.toUpperCase()) ? true : false;
          } else {
            this.alreadyExistsError = (node.ExternalContactName.toUpperCase() === selectedName.toUpperCase() && node.Company.toUpperCase() === selectedEventInstance.item.firmName.toUpperCase()) ? true : false;
          }
        }
        if (this.alreadyExistsError) {
          return false;
        } else {
          return true;
        }
      });
    }
    if (!this.alreadyExistsError) {
      let selectedExternalContacts: any;
      if (this.inviteeType === 'FIL Invitees') {
        this.asyncSelected = convertToTitleCase(selectedEventInstance.item.name);
        this.inviteeId = selectedEventInstance.item.corporateId;
      } else {
        this.asyncSelected = selectedEventInstance.item.fullname;
        selectedExternalContacts = selectedEventInstance.item;
        if (this.commonService.getMeetingType() === 'Broker') {
          selectedExternalContacts.company = selectedExternalContacts['firmName'];
        }
      }
      this.visited = true;
      if (this.data) {
        this.data.context.componentParent.rowClicked(this.data, this.asyncSelected, this.inviteeId, selectedExternalContacts);
        this.data.api.refreshCells({
          rowNodes: [this.data.node],
          force: true
        });
      }
    } else {
      this.asyncSelected = selectedName;
    }
  }

  getValue(): any {
    if (this.visited) {
      return this.asyncSelected;
    } else {
      return this.data.value;
    }
  }

  typeaheadNoResults(event: boolean): void {
    this.errorResponse = event;
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.container.element.nativeElement.focus();
    });
  }

  tabKeyPressed(event) {
    event.preventDefault();
    this.data.context.componentParent.typeaheadTabKeyPress(this.data);
  }

}
