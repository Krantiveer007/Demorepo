import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';


declare var jquery: any;
declare var $: any;
//     <div class="alert alert-danger searchErrorResponse" *ngIf="checkInvalidDuration">Please enter valid meeting duration</div>
@Component({
  selector: 'mv2-config-duration',
  template: `
    <div class="duration durationPicker" style="height: 28px!important" id="duration">
    </div>`,
  styleUrls: ['./config-duration.component.css']
})
export class ConfigDurationComponent implements OnInit {
  params: any;
  value: any;
  checkInvalidDuration = false;
  options = {
    hour: {
      value: 0,
      min: 0,
      max: 24,
      step: 1,
      symbol: 'h'
    },
    minute: {
      value: 0,
      min: 0,
      max: 60,
      step: 5,
      symbol: 'mins'
    },
    direction: 'increment', // increment or decrement
    inputHourTextbox: null, // hour textbox
    inputMinuteTextbox: null, // minutes textbox
    postfixText: '', // text to display after the input fields',
    numberPaddingChar: '0' // number left padding character ex: 00052
  };

  constructor(private fb: FormBuilder) { }

  agInit(params: any): void {
    this.params = params;
    const convertDurationInHours = Math.floor((this.params.value) / 60);
    const convertDurationInMinutes = (this.params.value) % 60;
    $('.duration').timesetter(this.options).setHour(convertDurationInHours);
    $('.duration').timesetter(this.options).setMinute(convertDurationInMinutes);
    if (params.value === null) {
      return undefined;
    } else {
      this.value = params.value;
    }
  }

  ngOnInit() {
    $('.duration').timesetter(this.options);
    $('.duration').timesetter(this.options).setHour(1);
    $('.duration').change(() => {
      const hours = $('.duration').timesetter().getHoursValue();
      const minutes = $('.duration').timesetter().getMinutesValue();
      const durationValue = (hours * 60) + minutes;
      this.params.data['duration'] = durationValue;
      if (durationValue === 0) {
        this.checkInvalidDuration = true;
      } else {
        this.checkInvalidDuration = false;
      }
    });
  }

  isPopup() {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  refresh(): boolean {
    return false;
  }
}
