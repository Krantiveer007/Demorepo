import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigDurationComponent } from './config-duration.component';

describe('ConfigDurationComponent', () => {
  let component: ConfigDurationComponent;
  let fixture: ComponentFixture<ConfigDurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigDurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigDurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
