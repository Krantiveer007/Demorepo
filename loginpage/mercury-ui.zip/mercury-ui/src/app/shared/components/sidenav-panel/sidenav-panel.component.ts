import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';
import { RouterModule, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'mv2-sidenav-panel',
  templateUrl: './sidenav-panel.component.html',
  styleUrls: ['./sidenav-panel.component.css']
})
export class SidenavPanelComponent implements OnInit, OnDestroy {
  taskLabel = '';
  constructor(private commonService: CommonService, private route: ActivatedRoute) { }

  ngOnInit() {
    if (this.route['_routerState'].snapshot.url === '/sideDrawer/filter') {
      this.taskLabel = 'More Filters';
    }
  }

  ngOnDestroy() {
    this.commonService.sidePanelMessageSource.next(false);
  }

  hidePanel() {
    this.commonService.sidePanelMessageSource.next(false);
  }
}
