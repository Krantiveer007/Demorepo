import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigResposneComponent } from './config-resposne.component';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';

describe('ConfigResposneComponent', () => {
  let component: ConfigResposneComponent;
  let fixture: ComponentFixture<ConfigResposneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({imports: [
      FormsModule,
      NgSelectModule,
    ],
      declarations: [ ConfigResposneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigResposneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
