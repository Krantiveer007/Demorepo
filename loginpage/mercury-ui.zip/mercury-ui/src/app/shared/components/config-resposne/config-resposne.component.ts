import { Component, OnInit } from '@angular/core';
import { INVITEERESPONSE } from 'src/app/shared/app-constant/meeting.constants';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Params } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'mv2-config-resposne',
  template: `
  <div>
    <ng-select [(ngModel)] = "value" class="ngWidth" [items]="inviteeResposnes" [clearable]="false"  [searchable]="false"
      (change)="onChange($event)" [disabled] = "disableSelect">
    </ng-select>
  </div>
  `,
  styleUrls: ['./config-resposne.component.css']
})
export class ConfigResposneComponent implements ICellRendererAngularComp {
 
  inviteeResposnes = INVITEERESPONSE;
  params: any;
  value: any;
  isVisible = false;
  disableSelect = true;
  count = 0;
  constructor(private route: ActivatedRoute, private commonService: CommonService) {
    this.params = '';
  }
  isPopup() {
    return true;
  }
  agInit(params): void {
    this.count++;
    this.params = params;
    if (this.params.value) {
      this.params.data[this.params.colDef.field] = this.params.value;
      this.value = this.params.value;
    }
    if (this.params.node.data.Attendee) {
      if (this.params.rowIndex === 0) {
        this.disableSelect = true;
        //  this.params.context.componentParent.addResponse(this.params, 'Accepted');
        this.value = 'Accepted';
      } else if (this.params.node.data.ResponseCheck) {
        this.disableSelect = false;
      } else {
        this.disableSelect = true;
      }
    }
    // if (this.params.node.data.Attendee
    //   || this.params.node.data.ExternalContactName
    //   || ((this.params.node.data.signUpAttendeeName) && ('Remove' in this.params.node.data))) {
    //   this.enableCheckBox = false;
    // }
    // (this.params.node.data.Attendee && (this.enableCheckBox = false));
    if (('Attendee' in this.params.data) && (this.params.rowIndex > 0)) {
      this.isVisible = true;
    }

    //  this.route.params.subscribe((params: Params) => {
    //     if (params['action'] === 'update') {
    //       this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
    //      //  this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'));
    //      });
    //     }});
  }
  getValue(): any {
    return this.value;
  }
  onChange(event) {
    this.params.data[this.params.colDef.field] = event;
    this.params.context.componentParent.addResponse(this.params, event);
    // this.value = event;
  }
  refresh(): boolean {
    return false;
  }

  //   checkIfMeetingDateISMoreThan365Days(date: string) {
  //   const format = 'DD/MM/YYYY';
  //  const val = moment(date, format, true);
  //  const ONE_DAY = 1000 * 60 * 60 * 24;
  //  const meetingDate = val.toDate();
  //  const todayDate: Date = new Date();
  //  const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
  //  if (differenceDays > 365) {
  //           this.disableSelect = true;
  // }

  // }
}
