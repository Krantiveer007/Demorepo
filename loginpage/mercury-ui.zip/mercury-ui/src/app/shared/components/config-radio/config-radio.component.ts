import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Params } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'mv2-config-radio',
  template: `
  <label [ngClass]="{'externalContact': externalContact}" class="container">
    <input type="radio" name="{{parentCompanyName}}" [value]="selectedHost" [checked]="selectedHost" style="display:none;"
     (change)="selectHost($event)" [disabled]="isDisabled">
    <span class="checkmark"></span>
  </label>
  `,
  styleUrls: ['./config-radio.component.css']
})
export class ConfigRadioComponent implements ICellRendererAngularComp {
  public params: any;
  isDisabled = false;
  selectedHost = false;
  externalContact = false
  parentCompanyName = '';
  value: any;

  agInit(params: any): void {
    this.params = params;
    this.selectedHost = this.params.value ? this.params.value : false;
    if (this.params.context.componentParent.gridType === "externalContactSearchGrid") {
      this.externalContact = true;
      this.parentCompanyName = "externalContact"
    } else {
      this.parentCompanyName = this.params.context.componentParent.params.data.companyName.replace(/[^a-zA-Z0-9]/g, '_')
        + this.params.context.componentParent.params.data.scheduleId;
      if ((this.params.node.data.name) && ('host' in this.params.node.data)) {
        this.isDisabled = false;
      } else {
        this.isDisabled = true;
      }
      if (this.params.context.componentParent.params.data.meetingState.toUpperCase() === 'CANCELLED') {
        this.isDisabled = true;
      }
    }

  }

  selectHost(event) {
    this.params.data["host"] = event.currentTarget.checked;
    this.value = event.currentTarget.checked;
    this.params.api.forEachNode((node, index) => {
      if (node.data.corporateId !== this.params.data.corporateId) {
        node.data.host = false;
      }
    });
    if (this.params.context.componentParent.gridType === "externalContactSearchGrid") {
      this.params.api.deselectAll();
      this.params.node.setSelected(event.currentTarget.checked);
      this.params.data[this.params.colDef.field] = event.currentTarget.checked;
    } else {
      this.params.context.componentParent.setMasterGridData('gridOptionsFilAttendee', 'radioButton');
      // this.params.api.refreshCells({
      //   rowNodes: [this.params.node],
      //   force: true
      // });
      // this.params.context.componentParent.rowDataFilAttendee.forEach(element => {
      //   if (element.name) {
      //     this.params.api.refreshCells({
      //       rowNodes: [this.params.node],
      //       force: true
      //     });
      //   }
      // });
    }
  }

  isPopup() {
    return true;
  }

  refresh(): boolean {
    return false;
  }
}