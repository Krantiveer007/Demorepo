import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigRadioComponent } from './config-radio.component';

describe('ConfigRadioComponent', () => {
  let component: ConfigRadioComponent;
  let fixture: ComponentFixture<ConfigRadioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigRadioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigRadioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
