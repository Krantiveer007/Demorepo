import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigDaterendererComponent } from './config-daterenderer.component';

describe('ConfigDaterendererComponent', () => {
  let component: ConfigDaterendererComponent;
  let fixture: ComponentFixture<ConfigDaterendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigDaterendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigDaterendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
