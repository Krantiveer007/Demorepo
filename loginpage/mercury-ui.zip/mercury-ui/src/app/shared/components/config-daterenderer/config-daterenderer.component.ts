import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { BsDatepickerDirective } from 'ngx-bootstrap';
import { BsDatepickerConfig, BsDaterangepickerDirective } from 'ngx-bootstrap/datepicker';

import { MeetingFieldValidations } from 'src/app/shared/validators/meeting-field-validation';
import { DatePipe } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-config-daterenderer',
  template: `
  <form [formGroup]="meetingDateForm"
  [ngClass]="{'placeholderColor': !meetingDateForm.controls.selectedDate.value}">
    <input type="text" class="form-control inputBox" [minDate]="minDate" [maxDate]="maxDate" placeholder="Select Date..." bsDatepicker
    #dp="bsDatepicker" formControlName="selectedDate" (keydown)="onKeyDown($event, 'deadLine')"
    [bsConfig]="{ dateInputFormat: 'DD MMM YYYY', containerClass: 'theme-dark-blue', showWeekNumbers:false }"
    [ngClass]="{'failedSearch': (checkInvalidDate() || checkMoreThanOneYearDate()), 'mandatorymarking': !meetingDateForm.controls.selectedDate.value}" 
    (bsValueChange)="onValueChange($event)"/>
    <div class="alert alert-danger searchErrorResponse" *ngIf="checkInvalidDate() || checkMoreThanOneYearDate()">
      {{checkInvalidDate() ? 'Please enter valid date' : dateErrorReason }}
    </div>
  </form>`,
  styleUrls: ['./config-daterenderer.component.css'],
})
export class ConfigDaterendererComponent implements OnInit {

  minDate: Date;
  maxDate: Date;
  dateErrorReason = '';
  params: any;
  value: any;
  meetingDateForm = this.fb.group({
    selectedDate: ['', MeetingFieldValidations.Date]
  });
  // isDateDisabled = false;
  isMtgDateEmpty = false;

  @ViewChild('dp') datePicker: BsDatepickerDirective;
  constructor(private fb: FormBuilder, private commonService: CommonService) { }

  agInit(params: any): void {
    this.params = params;
    // console.log('agInit: ', this.params);
    if (this.params.data.meetingDate) {
      this.meetingDateForm.patchValue({
        'selectedDate': new Date(this.params.data.meetingDate)
      });
    } else {
      this.params.data.meetingDate = this.meetingDateForm.get('selectedDate').value;
      this.isMtgDateEmpty = true;
    }
    if('eventScheduleStatus' in this.params.node.data) {
      if(this.params.context.componentParent.isEditableFieldsEnabled) {
        this.meetingDateForm.get('selectedDate').enable();
      } else {
        this.meetingDateForm.get('selectedDate').disable();
      }
    }
    // if(this.params.data.selection && this.isMtgDateEmpty) {
    //   this.meetingDateForm.get('selectedDate').setErrors({ 'dateRequired': true });
    // }
    if (params.value === null) {
      return undefined;
    } else {
      this.value = params.value;
    }
  }

  ngOnInit() {
    const conferenceDetails = this.commonService.getConferenceMeetingDtls();
    this.minDate = new Date(conferenceDetails.startDate);
    this.maxDate = new Date(conferenceDetails.endDate);
  }

  onKeyDown(event, type) {
    if (event.keyCode === 9) {
      this.datePicker.hide();
    } else {
      this.datePicker.show();
    }
  }

  onValueChange(event) {
    this.params.data["meetingDate"] = event;
    this.value = event;
    if (event && this.isMtgDateEmpty) {
      this.isMtgDateEmpty = false;
      this.params.api.refreshCells({
        rowNodes: [this.params.node],
        force: true
      });
      // this.meetingDateForm.get('selectedDate').setErrors(null);
      console.log(this.params.context);
      // this.params.context.componentParent.resetRowSelections();
    }
  }
  checkInvalidDate(): boolean {
    if (this.meetingDateForm.get('selectedDate').errors !== null && this.meetingDateForm.get('selectedDate').errors.invalidDate) {
      return true;
    }
    return false;
  }
  checkMoreThanOneYearDate(): boolean {
    if (this.meetingDateForm.get('selectedDate').errors !== null && this.meetingDateForm.get('selectedDate').errors.moreThanOneYearDate) {
      this.dateErrorReason = 'Start Date must be within past 365 days';
      return true;
    }
    return false;
  }

  isPopup() {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  refresh(): boolean {
    return false;
  }
}
