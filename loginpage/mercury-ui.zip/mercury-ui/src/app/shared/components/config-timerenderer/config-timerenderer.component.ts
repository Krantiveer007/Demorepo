import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import { CommonService } from 'src/app/core/http/common.service';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'mv2-config-timerenderer',
  template: `
  <form [formGroup]="meetingTimeForm" style="display:flex;">
  <kendo-timepicker [format]="'HH:mm'" formControlName="meetingTime" (valueChange)="timeChange($event)"
    [ngClass]="{'failedSearch':checkInvalidTime(), 'mandatoryMarking': mandatoryFieldCheck()}"
  id="{{parentCompanyName}}" (blur)="onBlur()" style="height: 28px!important"></kendo-timepicker>
  <div class="alert alert-danger searchErrorResponse responseWidthTime" *ngIf="checkInvalidTime()">Please enter valid meeting time</div>
  <div  style="padding-left: 10px; height: 28px!important">
    <p style="margin:0;"><span style="font-weight: bold;">Local Time : </span>{{userDisplayTime}}</p></div>
  </form>`,
  styleUrls: ['./config-timerenderer.component.css']
})

export class ConfigTimerendererComponent {

  params: any;
  value: any;
  meetingTimeForm = this.fb.group({
    meetingTime: [new Date(0, 0, 0, 0, 0)],
  });
  parentCompanyName = '';
  userDisplayTime = '';
  enableRowSelectionObj = {
    time: false,
    date: false
  };

  constructor(private fb: FormBuilder, private commonService: CommonService) { }

  agInit(params: any): void {
    this.params = params;
    this.parentCompanyName = this.params.data.companyName.replace(/[^a-zA-Z0-9]/g, '_')
      + this.params.data.companyName.scheduleId;
    if (this.params.data.meetingTime) {
      if (!this.params.data.meetingTime.includes(':')) {
        const splitTime = this.params.data.meetingTime.match(/.{1,2}/g);
        this.params.data.meetingTime = splitTime[0] + ':' + splitTime[1];
        this.params.data.meetingTimeInGMT = splitTime[0] + ':' + splitTime[1];
      }
      this.meetingTimeForm.patchValue({
        'meetingTime': this.params.data.meetingTime
      });
    } else {
      const newdate: Date = new Date(this.meetingTimeForm.get('meetingTime').value);
      const hours = newdate.getHours() < 10 ? 0 + '' + newdate.getHours() : newdate.getHours();
      const minutes = newdate.getMinutes() < 10 ? 0 + '' + newdate.getMinutes() : newdate.getMinutes();
      this.userDisplayTime = hours + ':' + minutes;
      this.params.data.meetingTimeInLocalTimezone = this.userDisplayTime;
    }
    if (this.params.data.meetingTimeInGMT) {
      if (this.params.data.meetingTimeInGMT.includes('00:00')) {
        this.meetingTimeForm.patchValue({
          'meetingTime': new Date(0, 0, 0, 0, 0)
        });
        this.userDisplayTime = '00:00'
      } else {
        const newdate = this.params.data.meetingTimeInGMT;
        // const timeVal = (newdate.includes('T')) ? newdate.split('T')[1] : newdate;
        const splitMeetingTimeInGMT = newdate ? newdate.split(':') : '';
        let meetingTimezone = this.params.data.eventTimezone;
        let splitMeetingTimezone = meetingTimezone ? meetingTimezone.split(' ') : '';
        let dateArrray = moment(this.params.data.meetingDate).format('YYYY-MM-DD');
        let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
        let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
        let meetingTimeInMeetingTimezone = '';
        if (splitMeetingTimezone.length === 2) {
          meetingTimeInMeetingTimezone = gmtTime.clone().tz(splitMeetingTimezone[0]).format();
        }
        this.setTimeInUserTimezone("Europe/London", this.commonService.getLoggedInUserInfo().getUserTimezone(), splitMeetingTimeInGMT[0], splitMeetingTimeInGMT[1], 'localTime');
        if (meetingTimezone) {
          this.setTimeInUserTimezone("Europe/London", meetingTimezone.split(' ')[0], splitMeetingTimeInGMT[0], splitMeetingTimeInGMT[1], 'meetingTime');
        }
      }
    }
    if ('eventScheduleStatus' in this.params.node.data) {
      if (this.params.context.componentParent.isEditableFieldsEnabled) {
        this.meetingTimeForm.get('meetingTime').enable();
      } else {
        this.meetingTimeForm.get('meetingTime').disable();
      }
    }
    // else {
    //   this.meetingTimeForm.get('meetingTime').setErrors({ 'timeRequired': true })
    // }

    if (params.value === null) {
      return undefined;
    } else {
      this.value = this.meetingTimeForm.get('meetingTime').value;
    }
  }

  checkInvalidTime(): boolean {
    if (this.meetingTimeForm.get('meetingTime').errors !== null &&
      (this.meetingTimeForm.get('meetingTime').errors.invalidTime || this.meetingTimeForm.get('meetingTime').errors.timeRequired)) {
      return true;
    }
    return false;
  }
  mandatoryFieldCheck() {
    if (this.meetingTimeForm.get('meetingTime').value) {
      const newdate: Date = new Date(this.meetingTimeForm.get('meetingTime').value);
      const hours = newdate.getHours();
      const minutes = newdate.getMinutes();
      if (hours === 0 && minutes === 0) {
        $(this.parentCompanyName).addClass("mandatoryMarking");
        return true;
      } else {
        $(this.parentCompanyName).removeClass("mandatoryMarking");
        return false;
      }
    } else {
      $(this.parentCompanyName).addClass("mandatoryMarking");
      return true;
    }
  }
  timeChange(event: string) {
    if (event) {
      const newdate: Date = new Date(this.meetingTimeForm.get('meetingTime').value);
      const hours = newdate.getHours();
      const minutes = newdate.getMinutes();
      if (hours === 0 && minutes === 0) {
        this.meetingTimeForm.get('meetingTime').setErrors({ 'timeRequired': true });
      } else {
        this.enableRowSelectionObj.time = true;
        // this.params.api.refreshCells({
        //   rowNodes: [this.params.node],
        //   force: true
        // });
        this.meetingTimeForm.get('meetingTime').setErrors(null);
        if (this.params.data.eventTimezone) {
          let hrs = newdate.getHours() < 10 ? 0 + '' + newdate.getHours() : newdate.getHours();
          let mins = newdate.getMinutes() < 10 ? 0 + '' + newdate.getMinutes() : newdate.getMinutes();
          // this.setTimeInUserTimezone(this.params.data.eventTimezone.split(' ')[0],
          //   this.commonService.getLoggedInUserInfo().getUserTimezone(),
          //   this.meetingTimeForm.get('meetingTime').value.toLocaleString().split(':')[0].slice(-2), this.meetingTimeForm.get('meetingTime').value.toLocaleString().split(':')[1], "localTime");

          this.setTimeInUserTimezone(this.params.data.eventTimezone.split(' ')[0],
            this.commonService.getLoggedInUserInfo().getUserTimezone(),
            hrs, mins, "localTime");
          this.setTimeInUserTimezone(this.params.data.eventTimezone.split(' ')[0],
            "Europe/London",
            hrs, mins, "timeInGmt");
        }
      }
      this.params.data["meetingTime"] = hours + ':' + minutes;
    } else {
      this.meetingTimeForm.get('meetingTime').setErrors({ 'timeRequired': true });
      // console.log('asdsadsadsa', this.meetingTimeForm.get('meetingTime').value);
      // this.params.context.componentParent.unSelectRowNode(this.params.node.rowIndex, 'timeRenderer');
    }
  }


  private setTimeInUserTimezone(currentTimezone, toTimezone, currentTimeHrs, currentTimeMins, formFieldToBeUpdated) {
    const currentDate = moment(new Date()).format('YYYY-MM-DD');
    const currentMomentTime = currentDate + ' ' + currentTimeHrs + ':' + currentTimeMins;
    const meetingTimeZone = momentTimezone.tz(currentMomentTime, currentTimezone);
    // console.log('toTimezone: ', toTimezone);
    const userTime = meetingTimeZone.clone().tz(toTimezone).format();
    const newDate = new Date(0, 0, 0, + userTime.substring(11, 13), + userTime.substring(14, 16));
    const hours = newDate.getHours() < 10 ? 0 + '' + newDate.getHours() : newDate.getHours();
    const minutes = newDate.getMinutes() < 10 ? 0 + '' + newDate.getMinutes() : newDate.getMinutes();
    if (formFieldToBeUpdated === 'localTime') {
      this.userDisplayTime = hours + ':' + minutes;
      this.params.data.meetingTimeInLocalTimezone = this.userDisplayTime;
    } else if (formFieldToBeUpdated === 'timeInGmt') {
      this.params.data["meetingTimeInGMT"] = hours + ':' + minutes;
    } else {
      this.meetingTimeForm.patchValue({
        'meetingTime': new Date(0, 0, 0, + userTime.substring(11, 13), + userTime.substring(14, 16)),
      });
      this.params.data.meetingTime = hours + ':' + minutes;
    }
  }

  onBlur() {
    const newdate: Date = new Date(this.meetingTimeForm.get('meetingTime').value);
    const hours = newdate.getHours();
    const minutes = newdate.getMinutes();
    if (!(hours === 0 && minutes === 0)) {
      this.params.api.refreshCells({
        rowNodes: [this.params.node],
        force: true
      });
    }
  }
  isPopup() {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  refresh(): boolean {
    return false;
  }
}
