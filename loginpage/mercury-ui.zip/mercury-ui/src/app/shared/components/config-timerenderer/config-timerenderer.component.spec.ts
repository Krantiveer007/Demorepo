import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigTimerendererComponent } from './config-timerenderer.component';

describe('ConfigTimerendererComponent', () => {
  let component: ConfigTimerendererComponent;
  let fixture: ComponentFixture<ConfigTimerendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigTimerendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigTimerendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
