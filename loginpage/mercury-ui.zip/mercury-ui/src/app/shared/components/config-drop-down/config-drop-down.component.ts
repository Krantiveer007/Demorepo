import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mv2-config-drop-down',
  template: `
  <div class="row align-items-center" style="height: 28px; font-size:15px;">
    <ng-select class="company-renderer" bindLabel="status" [disabled]="isEventStatusDisabled" [clearable]="false" style="padding:0; width:100%;height: 28px;min-height: 28px !important;" [(ngModel)]="selectedStatus" [items]="scheduleStatus"
    [searchable]="false" (change)="selectScheduleStatus($event)"></ng-select>
  </div>`,
  styleUrls: ['./config-drop-down.component.css']
})
export class ConfigDropDownComponent implements OnInit {

  selectedStatus;
  params: any;
  scheduleStatus = [
    { status: 'New' },
    { status: 'Requested' },
    { status: 'Waitlisted' },
    { status: 'Confirmed' },
    { status: 'Cancelled by FIL' },
    { status: 'Cancelled by Broker' },
    { status: 'Cancelled by Company' }
  ];
  // scheduleStatus = ["New", "Requested", "Waitlisted", "Confirmed", "Cancelled by FIL", "Cancelled by Broker", "Cancelled by Company"];
  value: any;
  isEventStatusDisabled = false;
  constructor() { }

  agInit(params: any): void {
    this.params = params;
    // console.log('this.params: ', params);
    // if()
    if (this.params.data["eventScheduleStatus"]) {
      this.selectedStatus = this.params.data["eventScheduleStatus"];
    } else {
      this.selectedStatus = this.scheduleStatus[0].status;
      this.params.data["eventScheduleStatus"] = this.selectedStatus;
    }
    if (!(this.params.data.meetingTime
      && this.params.data.meetingDate
      && this.params.data.hostCorporateId)) {
      this.scheduleStatus.forEach((rowNode) => {
        if (rowNode.status === 'Confirmed' || rowNode.status.includes('Cancelled')) {
          rowNode['disabled'] = true;
        }
      });
    }
    if (this.params.data.meetingState.toUpperCase() === 'DRAFT' || this.params.data.meetingState.toUpperCase() === 'NEW') {
      this.scheduleStatus.forEach((rowNode) => {
        if (rowNode.status.includes('Cancelled')) {
          rowNode['disabled'] = true;
        }
      });
    }
    if (this.params.data.meetingState.toUpperCase() === 'CONFIRMED') {
      this.scheduleStatus.forEach((rowNode) => {
        if (!(rowNode.status === 'Confirmed' || rowNode.status.includes('Cancelled'))) {
          rowNode['disabled'] = true;
        }
      });
    }
    // else if (this.params.data.meetingState.toUpperCase() === 'DRAFT'
    //   && this.selectedStatus.toUpperCase() === 'REQUESTED') {
    //   this.scheduleStatus.forEach((rowNode) => {
    //     if (rowNode.status === 'New') {
    //       rowNode['disabled'] = true;
    //     }
    //   });
    // } else if (this.params.data.meetingState.toUpperCase() === 'DRAFT'
    //   && this.selectedStatus.toUpperCase() === 'WAITLISTED') {
    //   this.scheduleStatus.forEach((rowNode) => {
    //     if (rowNode.status === 'New' || rowNode.status === 'Requested') {
    //       rowNode['disabled'] = true;
    //     }
    //   });
    // }
    if ('eventScheduleStatus' in this.params.node.data) {
      this.isEventStatusDisabled = !this.params.context.componentParent.isEditableFieldsEnabled;
    } else {
      this.isEventStatusDisabled = false;
    }
    if (params.value === null) {
      return undefined;
    } else {
      this.value = params.value;
    }
  }

  ngOnInit() {
  }
  selectScheduleStatus(event) {
    this.params.data["eventScheduleStatus"] = event.status;
  }

  isPopup() {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  refresh(params): boolean {
    console.log('params:::::', params);
    // (params.data.meetingTime || 
    // // || params.data.hostCorporateId)
    // if (!params.data.meetingDate ) {
    //   this.scheduleStatus.forEach((rowNode) => {
    //     if (rowNode.status === 'New') {
    //       rowNode['disabled'] = true;
    //     }
    //   });
    // }
    return false;
  }

}
