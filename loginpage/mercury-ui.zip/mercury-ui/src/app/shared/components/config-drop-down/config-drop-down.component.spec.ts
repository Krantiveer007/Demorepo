import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigDropDownComponent } from './config-drop-down.component';

describe('ConfigDropDownComponent', () => {
  let component: ConfigDropDownComponent;
  let fixture: ComponentFixture<ConfigDropDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigDropDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
