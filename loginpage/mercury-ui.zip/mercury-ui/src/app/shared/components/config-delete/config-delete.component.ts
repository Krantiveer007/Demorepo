import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Params } from '@angular/router';
import * as moment from 'moment';

import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';

@Component({
  selector: 'mv2-config-delete',
  template: `
  <div  [ngClass]="{'editButtonDisplayFlex': isEditVisible}">
    <button type="button" name="{{parentCompanyName}}" style="background: transparent; box-shadow: none!important;"
    class="btn tbl-btn" *ngIf="isEditVisible">
      <img src= "./assets/images/Edit.svg" style="height:19px;color: solid 1px #000000;width:18px;"
        *ngIf="isFieldsEditable" (click)="onEdit('edit')">
      <img src= "./assets/images/save.svg" style= "height:16px;color: solid 1px #000000;width:18px;"
      *ngIf="!isFieldsEditable" (click)="onEdit('cross')">
    </button>
    <div style="width: 30px"></div>
    <button type="button" [disabled] = "isSelected" style="background: transparent; box-shadow: none!important;"
    class="btn tbl-btn" (click)= onRemove() *ngIf="isVisible">
      <img src= "./assets/images/group-14-copy.svg" style= "height:19px;color: solid 1px #000000;width:18px;">
    </button>
  </div>
    
  `,
  styleUrls: ['./config-delete.component.css']
})
export class ConfigDeleteComponent implements ICellRendererAngularComp {
  isVisible = false;
  public params: any;
  rowIndex: any;
  isSelected = true;
  isEditVisible = false;
  isFieldsEditable = true;
  parentCompanyName = '';

  constructor(private commonService: CommonService, private route: ActivatedRoute) { }
  agInit(params): void {
    this.params = params;
    // console.log('host: ', this.params);
    if (('Attendee' in this.params.data) && (this.params.rowIndex > 0)) {
      this.isVisible = true;
    } else if (('signUpAttendeeName' in this.params.data)
      || ('ExternalContactName' in this.params.data)
      || ('name' in this.params.data)
      || ('companyAttendee' in this.params.data)
      || ('eventScheduleStatus' in this.params.data)) {
      this.isVisible = true;
    }
    if (this.params.node.data.Attendee
      || this.params.node.data.ExternalContactName
      || ((this.params.node.data.signUpAttendeeName) && ('Remove' in this.params.node.data))
      || (this.params.node.data.name)
      || ((this.params.node.data.companyAttendee) && ('companyAttendee' in this.params.node.data))
      || ((this.params.node.data.eventScheduleStatus) && ('eventScheduleStatus' in this.params.node.data))) {
      this.isSelected = false;
    }
    if (this.params.node.data.name && this.params.node.data.host) {
      this.isVisible = false;
    }
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
          }
        });
      }
    });
    if ('eventScheduleStatus' in this.params.node.data) {
      this.isEditVisible = (this.params.data.meetingState === 'CANCELLED') ? false : true;
      this.parentCompanyName = this.params.data.companyName.replace(/[^a-zA-Z0-9]/g, '_')
        + this.params.data.scheduleId;
      this.isFieldsEditable = !this.params.context.componentParent.isEditableFieldsEnabled;
    } else {
      this.isEditVisible = false;
    }
    if ('eventScheduleStatus' in this.params.node.data
      && (this.params.data.meetingState.toUpperCase() === 'CANCELLED'
        || this.params.data.meetingState.toUpperCase() === 'CONFIRMED')) {
      this.isVisible = false;
    }
    if ('name' in this.params.node.data && this.params.context && this.params.context.componentParent
      && this.params.context.componentParent.params
      && this.params.context.componentParent.params.data.meetingState.toUpperCase() === 'CANCELLED') {
      this.isSelected = true;
    }
  }
  onRemove() {
    if ((this.params.node.data.name) || ('eventScheduleStatus' in this.params.node.data)
      || ((this.params.node.data.companyAttendee) && ('companyAttendee' in this.params.node.data))) {
      this.params.context.componentParent.onRemoveClicked(this.params);
    } else {
      this.params.context.componentParent.onRemoveClicked(this.params.node.rowIndex);
    }
  }
  refresh(): boolean {
    return false;
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.isSelected = true;
    }
  }

  onEdit(imgClicked: string) {
    if (imgClicked === 'edit') {
      this.params.context.componentParent.enableEditableFields(true, this.params.node.rowIndex);
    } else {
      this.params.context.componentParent.enableEditableFields(false, this.params.node.rowIndex);
    }
  }
}
