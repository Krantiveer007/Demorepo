import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigDeleteComponent } from './config-delete.component';
import { HttpClientModule } from '@angular/common/http';

describe('ConfigDeleteComponent', () => {
  let component: ConfigDeleteComponent;
  let fixture: ComponentFixture<ConfigDeleteComponent>;
  const params = {
    api: { sizeColumnsToFit: () => { } },
    gridColumnApi: {},
    value: 'Verma, Pankaj',
    rowIndex : 3,
    node : {
      data : {
        'Attendee': 'Sehrawat, Krantiveer',
        'AttendeeId': 'A595905',
        'Call-In': false,
        'Info Only': false,
        'Infopacks': false,
        'Remove': ''
      }
    },
    data: {
      'Attendee': 'Sehrawat, Krantiveer',
      'AttendeeId': 'A595905',
      'Call-In': false,
      'Info Only': false,
      'Infopacks': false,
      'Remove': ''
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule
      ],
      declarations: [ ConfigDeleteComponent ],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should not able to delete the Host row i.e., Trash Icon not available for host Row', () => {
    // For Host : RowIndex = 0
    params.rowIndex = 0;
    component.agInit(params);
    expect(component.isVisible).toEqual(false);
  });
  it('should be able to delete all rows other than the Host row', () => {
    // For Host : RowIndex = 0
    params.rowIndex = 1;
    fixture.detectChanges();
    component.agInit(params);
    expect(component.isVisible).toEqual(true);
    expect(component.isSelected).toEqual(false);
  });
  it('should be able to use Trash Icon only if an Attendee is selected', () => {
    fixture.detectChanges();
    component.agInit(params);
    expect(component.isSelected).toEqual(false);
  });
  it('should Verify that existing FIL invitees for the meeting should get listed under Signed Up invitees grid and'
  + 'trash button for them should be disabled', () => {
    const paramsFilAttendee = {
      node : {
        data : {
          'employeeDisplayName': 'Thornton, Ian',
          'employeeId': 'a596595',
          'callInFlag': false,
          'infoPackRequiredFlag': true,
          'inviteForInfoOnly': true
        }
      },
      data : {
        'employeeDisplayName': 'Thornton, Ian',
        'employeeId': 'a596595',
        'callInFlag': false,
        'infoPackRequiredFlag': true,
        'inviteForInfoOnly': true
      }
    };
    fixture.detectChanges();
    component.agInit(paramsFilAttendee);
    /*Should return True for is attendee is already present i.e., don't have 'remove' as property*/
    expect(component.isSelected).toEqual(true);
  });
});

// agInit(params: ICellRendererParams): void {
//   this.params = params;
//   if(this.params.rowIndex > 0){
//     this.isVisible = true;
//   }
