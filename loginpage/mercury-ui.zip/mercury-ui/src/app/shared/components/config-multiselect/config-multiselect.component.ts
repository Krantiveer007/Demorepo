import { Component, OnInit, Input, forwardRef, OnChanges, SimpleChanges } from '@angular/core';
import {
  MultiSelectComponent,
  FilteringEventArgs,
  CheckBoxSelectionService,
  SelectEventArgs
} from '@syncfusion/ej2-angular-dropdowns';
import { EmitType } from '@syncfusion/ej2-base';
import { DataManager, Query } from '@syncfusion/ej2-data';
import {
  FormsModule,
  ControlValueAccessor,
  NG_VALUE_ACCESSOR
} from '@angular/forms';

@Component({
  selector: 'mv2-config-multiselect',
  templateUrl: './config-multiselect.component.html',
  styleUrls: ['./config-multiselect.component.css'],
  providers: [
    CheckBoxSelectionService,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ConfigMultiselectComponent),
      multi: true
    }
  ]
})
export class ConfigMultiselectComponent
  implements OnInit, ControlValueAccessor {
  @Input('meetingSubtypeDescription') meetingSubtypeDescription: any;
  @Input('businessUnitSource') businessUnitSource: any;
  @Input('countries') countries: any;
  @Input('regions') regions: any;
  @Input('meetingLocations') meetingLocations: any;
  @Input('isMtgSubTypeDisabled') isMtgSubTypeDisabled: any;

  public mode: string;
  public selectAllText: string;
  value: any[] = [];
  touched = false;
  public selectedValues = [];
  public formSelectedValue = [];
  dataSource: any;

  public fields: Object;
  public placeholder: string;
  public popWidth: string = '200px';

  onModelChange: Function = (value: any[]) => { };

  onModelTouched: Function = (): boolean => {
    return this.touched;
  };
  ngOnChanges(change: SimpleChanges) {
    if (this.meetingSubtypeDescription) {
      this.dataSource = this.meetingSubtypeDescription;
      this.fields = { text: 'KeyDesc', value: 'KeyCode' };
      this.placeholder = 'Select Meeting Subtypes';
    }
  }
  ngOnInit(): void {
    this.mode = 'CheckBox';
    this.selectAllText = 'Select All';
    if (this.meetingSubtypeDescription) {
      this.dataSource = this.meetingSubtypeDescription;
      this.fields = { text: 'KeyDesc', value: 'KeyCode' };
      this.placeholder = 'Select Meeting Subtypes';
    } else if (this.businessUnitSource) {
      this.dataSource = this.businessUnitSource;
      this.fields = { text: 'KeyCode', value: 'KeyCode' };
      this.placeholder = 'Select Business Units';
    } else if (this.countries) {
      this.dataSource = this.countries;
      this.fields = { text: 'KeyDesc', value: 'KeyCode' };
      this.placeholder = 'Select Countries';
    } else if (this.regions) {
      this.dataSource = this.regions;
      this.fields = { text: 'KeyDesc', value: 'KeyDesc' };
      this.placeholder = 'Select Regions';
    } else if (this.meetingLocations) {
      this.dataSource = this.meetingLocations;
      this.placeholder = 'Select Meeting Locations';
    }
  }

  writeValue(value: any): void {
    if (value) {
      this.value = value;
      this.formSelectedValue = this.value;
      if (value.length === 0) {
        this.selectedValues = [];
        this.onModelChange(this.selectedValues);
        this.onModelTouched();
      } else {
        this.value.forEach(rowNode => {
          this.selectedValues.push(rowNode);
        });
      }
    } else {
      if (this.meetingLocations) {
        this.formSelectedValue = [];
        this.selectedValues = [];
        this.onModelChange(this.selectedValues);
        this.onModelTouched();
      }
    }
  }
  registerOnChange(fn: Function): void {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onModelTouched = fn;
  }

  public onSelect(event): void {
    if (this.meetingLocations) {
      this.selectedValues.push(event.itemData);
    } else if (this.regions) {
      this.selectedValues.push(event.itemData.KeyDesc);
    } else {
      this.selectedValues.push(event.itemData.KeyCode);
    }
    this.onModelChange(this.selectedValues);
    this.onModelTouched();
  }

  public onRemove(event): void {
    let removeIndex: any;
    this.selectedValues.forEach((rowNode, Index) => {
      if (this.meetingLocations) {
        if (rowNode === event.itemData) {
          removeIndex = Index;
        }
      } else {
        if (rowNode === event.itemData.KeyCode) {
          removeIndex = Index;
        }
      }
    });
    this.selectedValues.splice(removeIndex, 1);
    this.onModelChange(this.selectedValues);
    this.onModelTouched();
  }
}
