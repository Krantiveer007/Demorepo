import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigMultiselectComponent } from './config-multiselect.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { MultiSelectModule } from '@syncfusion/ej2-angular-dropdowns';

describe('ConfigMultiselectComponent', () => {
  let component: ConfigMultiselectComponent;
  let fixture: ComponentFixture<ConfigMultiselectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
      FormsModule,
      ReactiveFormsModule,
      CommonModule,
      BrowserModule,
      MultiSelectModule
    ],
      declarations: [ ConfigMultiselectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigMultiselectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
