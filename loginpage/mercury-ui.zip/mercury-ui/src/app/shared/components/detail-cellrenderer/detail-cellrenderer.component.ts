import { Component, OnInit } from '@angular/core';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ConfigRadioComponent } from 'src/app/shared/components/config-radio/config-radio.component';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { CommonService } from 'src/app/core/http/common.service';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'mv2-detail-cellrenderer',
  templateUrl: './detail-cellrenderer.component.html',
  styleUrls: ['./detail-cellrenderer.component.css'],
})
export class DetailCellRendererComponent implements OnInit {

  gridOptionsFilAttendee: GridOptions;
  gridOptionsThirdPartyAttendee: GridOptions;
  params: any;
  masterGridApi: any;
  masterRowIndex: any;
  colDefsFilAttendee: any;
  colDefsThirdPartyAttendee: any;
  rowDataFilAttendee = [];
  rowDataThirdPartyAttendee = [];
  overlayNoRowsTemplate = '';

  constructor(private commonService: CommonService) { }

  agInit(params: any): void {
    this.params = params;
    this.masterGridApi = params.api;
    // console.log('params: ', params);
    this.masterRowIndex = params.rowIndex;
  }

  ngOnInit() {
    this.gridOptionsFilAttendee = <GridOptions>{
      headerHeight: 32,
      rowHeight: 32,
      rowBuffer: 200,
      suppressNoRowsOverlay: false,
      // suppressCellSelection: true,
      resizable: true,
      suppressMovableColumns: true,
      suppressCellSelection: true,
      suppressKeyboardEvent: this.suppressEnterAndSpace,
      context: {
        componentParent: this
      },
      suppressRefresh: true
    };
    this.gridOptionsThirdPartyAttendee = <GridOptions>{
      headerHeight: 30,
      rowHeight: 32,
      rowBuffer: 200,
      suppressNoRowsOverlay: false,
      suppressCellSelection: true,
      suppressKeyboardEvent: this.suppressEnterAndSpace,
      resizable: true,
      suppressMovableColumns: true,
      context: {
        componentParent: this
      },
      suppressRefresh: true
    };
    this.colDefsFilAttendee = [
      {
        headerName: 'FIL Invitees',
        field: "name",
        editable: true,
        cellEditorFramework: ConfigInviteesDtlsComponent,
        resizable: true,
        sortable: true,
        width: 280,
        singleClickEdit: true,
        headerClass: 'attendeeHeader',
        cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff', 'padding-left': '33px' }
      },
      {
        headerName: 'Host',
        field: 'host',
        resizable: true,
        sortable: true,
        cellRendererFramework: ConfigRadioComponent,
        headerClass: 'mv2-headerCenterAlign',
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'AID',
        field: 'corporateId',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Info Pack',
        field: 'isInfoPackRequired',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Call In',
        field: 'isCallIn',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Invite',
        field: 'isInviteRequired',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Info Only',
        field: 'isInviteForInfoOnly',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
      // {
      //   headerName: 'Attendee Notes',
      //   field: 'attendeeNotes',
      //   resizable: true,
      //   sortable: true,
      //   headerClass: 'mv2-headerCenterAlign',
      //   cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      // },
      {
        headerName: 'Action',
        field: 'action',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigDeleteComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
    ];
    this.colDefsThirdPartyAttendee = [
      {
        headerName: 'Company Attendee',
        field: "companyAttendee",
        editable: true,
        singleClickEdit: true,
        cellEditorFramework: ConfigInviteesDtlsComponent,
        resizable: true,
        sortable: true,
        width: 280,
        headerClass: 'attendeeHeader',
        cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff', 'padding-left': '33px' }
      },
      {
        headerName: 'Company',
        field: 'company',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerLeftAlign',
        cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Email ID',
        field: 'emailId',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerLeftAlign',
        cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      },
      {
        headerName: 'Designation',
        field: 'designation',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerLeftAlign',
        cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      },
      // {
      //   headerName: 'Prefered Language',
      //   field: 'preferedLanguage',
      //   resizable: true,
      //   sortable: true,
      //   headerClass: 'mv2-headerLeftAlign',
      //   cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      // },
      // {
      //   headerName: 'Attendee Notes',
      //   field: 'attendeeNotes',
      //   resizable: true,
      //   sortable: true,
      //   headerClass: 'mv2-headerLeftAlign',
      //   cellStyle: { 'text-align': 'left!important', 'background-color': '#ffffff' }
      // },
      {
        headerName: 'Action',
        field: 'action',
        resizable: true,
        sortable: true,
        headerClass: 'mv2-headerCenterAlign',
        cellRendererFramework: ConfigDeleteComponent,
        cellStyle: { 'text-align': 'center!important', 'background-color': '#ffffff' }
      },
    ];
    if (this.params.data.callRecordsFilAttendee.length) {
      this.params.data.callRecordsFilAttendee.forEach((rowNode) => {
        const filAttendeeValue = {
          name: convertToTitleCase(rowNode.name),
          corporateId: rowNode.corporateId,
          host: (rowNode.hasOwnProperty('host'))
            ? rowNode.host
            : (rowNode.corporateId === this.params.data.hostCorporateId),
          isInfoPackRequired: rowNode.isInfoPackRequired,
          isCallIn: rowNode.isCallIn,
          isInviteForInfoOnly: rowNode.isInviteForInfoOnly,
          inviteeResponse: rowNode.inviteeResponse ? rowNode.inviteeResponse : '',
          isInviteRequired: rowNode.name
            ? rowNode.isInviteRequired
            : false,
          action: ''
        }
        this.rowDataFilAttendee.push(filAttendeeValue);
      });
    }
    if (this.rowDataFilAttendee.length > 0
      && this.rowDataFilAttendee[this.rowDataFilAttendee.length - 1]['name'] !== '') {
      do {
        this.rowDataFilAttendee.push(
          {
            'name': '',
            'host': false,
            'corporateId': '',
            'isInfoPackRequired': false,
            'isCallIn': false,
            'isInviteForInfoOnly': false,
            'inviteeResponse': '',
            'isInviteRequired': false,
            'action': ''
          });
      } while (this.rowDataFilAttendee.length < 1);
    } else if (this.rowDataFilAttendee.length === 0) {
      this.rowDataFilAttendee.push(
        {
          'name': '',
          'host': false,
          'corporateId': '',
          'isInfoPackRequired': false,
          'isCallIn': false,
          'isInviteForInfoOnly': false,
          'inviteeResponse': '',
          'isInviteRequired': false,
          'action': ''
        });
    }
    if (this.params.data.callRecordsThirdPartyAttendee.length) {
      this.params.data.callRecordsThirdPartyAttendee.forEach((rowNode) => {
        let thirdPartyAttendee = {};
        if (rowNode.hasOwnProperty('companyAttendee')) {
          thirdPartyAttendee = {
            companyAttendee: convertToTitleCase(rowNode.companyAttendee),
            companyAttendeeId: rowNode.companyAttendeeId,
            company: rowNode.company,
            emailId: rowNode.emailId,
            designation: rowNode.designation,
            action: '',
          }
        } else if (rowNode.hasOwnProperty('externalContactName')) {
          thirdPartyAttendee = {
            companyAttendee: convertToTitleCase(rowNode.externalContactName),
            companyAttendeeId: rowNode.externalContactId,
            company: this.params.data.companyName,
            emailId: rowNode.email,
            designation: rowNode.position,
            action: '',
          }
        }
        this.rowDataThirdPartyAttendee.push(thirdPartyAttendee);
      });
    }
    if (this.rowDataThirdPartyAttendee.length > 0
      && this.rowDataThirdPartyAttendee[this.rowDataThirdPartyAttendee.length - 1]['companyAttendee'] !== '') {
      do {
        this.rowDataThirdPartyAttendee.push(
          {
            'companyAttendee': '',
            'companyAttendeeId': '',
            'company': '',
            'emailId': '',
            'designation': '',
            'action': ''
          });
      } while (this.rowDataThirdPartyAttendee.length < 1);
    } else if (this.rowDataThirdPartyAttendee.length === 0) {
      this.rowDataThirdPartyAttendee.push(
        {
          'companyAttendee': '',
          'companyAttendeeId': '',
          'company': '',
          'emailId': '',
          'designation': '',
          'action': ''
        });
    }
    this.params.data.callRecordsFilAttendee = this.rowDataFilAttendee;
    this.params.data.callRecordsThirdPartyAttendee = this.rowDataThirdPartyAttendee;
    this.gridOptionsFilAttendee.rowSelection = 'single';
    this.gridOptionsThirdPartyAttendee.rowSelection = 'single';
    this.overlayNoRowsTemplate =
      '<div style=\"font-size: 18px;color: #747c89;\">No rows to display.</div>';
    if (this.params.data.meetingState.toUpperCase() === 'CANCELLED') {
      this.gridOptionsFilAttendee.suppressCellSelection = true;
      this.colDefsFilAttendee.forEach((rowNode, Index) => {
        rowNode.editable = false;
        rowNode.cellStyle = { 'border-right': 'solid 1px #dadada!important', 'background': '#eeeff0 !important' };
      });
      this.gridOptionsThirdPartyAttendee.suppressCellSelection = true;
      this.colDefsThirdPartyAttendee.forEach((rowNode, Index) => {
        rowNode.editable = false;
        rowNode.cellStyle = { 'border-right': 'solid 1px #dadada!important', 'background': '#eeeff0 !important' };
      });
    }

  }

  onGridReady(params) {
    let detailGridId = "detail_" + this.masterRowIndex;
    let gridInfo = {
      id: detailGridId,
      api: params.api,
      columnApi: params.columnApi
    };
    this.masterGridApi.addDetailGridInfo(detailGridId, gridInfo);
  }

  ngOnDestroy(): void {
    let detailGridId = "detail_" + this.masterRowIndex;
    // ag-Grid is automatically destroyed
    this.masterGridApi.removeDetailGridInfo(detailGridId);
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  rowClicked(params, addedAttendee: string, attendeeId: string, selectedExternalContact: any) {
    let gridOptionsType = '';
    let displayName: string;
    if ('host' in params.data) {
      displayName = 'name';
      this.gridOptionsFilAttendee.rowData[params.node.rowIndex]['corporateId'] = attendeeId;
      gridOptionsType = 'gridOptionsFilAttendee';
    } else {
      displayName = 'companyAttendee';
      gridOptionsType = 'gridOptionsThirdPartyAttendee';
      (selectedExternalContact.externalId === null || selectedExternalContact.externalId === undefined)
        ? selectedExternalContact.externalId = ''
        : this.gridOptionsThirdPartyAttendee.rowData[params.node.rowIndex].companyAttendeeId = selectedExternalContact.externalId;

      (selectedExternalContact.emailId === null || selectedExternalContact.emailId === undefined)
        ? selectedExternalContact.emailId = ''
        : this.gridOptionsThirdPartyAttendee.rowData[params.node.rowIndex].emailId = selectedExternalContact.emailId;

      (selectedExternalContact.position === null || selectedExternalContact.position === undefined)
        ? selectedExternalContact.position = ''
        : this.gridOptionsThirdPartyAttendee.rowData[params.node.rowIndex].designation = selectedExternalContact.position;

      (selectedExternalContact.company === null || selectedExternalContact.company === undefined)
        ? selectedExternalContact.company = ''
        : this.gridOptionsThirdPartyAttendee.rowData[params.node.rowIndex].company = convertToTitleCase(selectedExternalContact.company);
    }
    this[gridOptionsType].rowData[params.node.rowIndex][displayName] = convertToTitleCase(addedAttendee);
    if ('host' in params.data && 'isInviteRequired' in params.data) {
      this[gridOptionsType].rowData[params.node.rowIndex]['isInviteRequired'] = true;
    }
    let mtgAttendeeAdded = true;
    this[gridOptionsType].rowData.forEach(rowNode => {
      if (rowNode[displayName] && rowNode[displayName].length === 0) {
        mtgAttendeeAdded = false;
      }
    });
    params.node.setSelected(true);
    if (mtgAttendeeAdded === true && this[gridOptionsType].rowData[this[gridOptionsType].rowData.length - 1][displayName].length !== 0) {
      this.addRow(gridOptionsType);
    }
    // console.log('this.conferenceInRenderer: ', this.params);
    this.typeaheadTabKeyPress(params);
    this.setMasterGridData(gridOptionsType, 'rowClicked');
  }

  private addRow(gridOptionsType: string) {
    const newItem = this.createNewRowData(gridOptionsType);
    this[gridOptionsType].api.updateRowData({ add: [newItem] });
    this[gridOptionsType].api.ensureIndexVisible(this[gridOptionsType].rowData.length, 'bottom');
    this[gridOptionsType].rowData.push(newItem);
  }

  private createNewRowData(gridOptionsType: string) {
    let newData = {};
    if (gridOptionsType === 'gridOptionsFilAttendee') {
      newData = {
        'name': '',
        'host': false,
        'corporateId': '',
        'isInfoPackRequired': false,
        'isCallIn': false,
        'isInviteForInfoOnly': false,
        'inviteeResponse': false,
        'isInviteRequired': false,
        'action': ''
      };
    } else {
      newData = {
        'companyAttendee': '',
        'companyAttendeeId': '',
        'company': '',
        'emailId': '',
        'designation': '',
        // 'preferedLanguage': '',
        'action': ''
      };
    }
    return newData;
  }

  setMasterGridData(gridOptionsType: string, callLocation: string) {
    if (gridOptionsType === 'gridOptionsFilAttendee') {
      this.params.data.callRecordsFilAttendee = this[gridOptionsType].rowData;
      this[gridOptionsType].api.setRowData(this[gridOptionsType].rowData);
      this[gridOptionsType].rowData.forEach((rowNode) => {
        if (rowNode.host) {
          this.params.data.hostCorporateId = rowNode.corporateId;
        }
      });
      // if (callLocation === 'radioButton') {
      // }
    } else {
      this.params.data.callRecordsThirdPartyAttendee = this[gridOptionsType].rowData;
      this[gridOptionsType].api.setRowData(this[gridOptionsType].rowData);
    }
    this.params.data.attendeeCount = this.getAttendeeCount(this.params);
    this.params.context.componentParent.refreshCellsForSelectedHost(this.masterRowIndex - 1, callLocation);
  }
  typeaheadTabKeyPress(params) {
    params.api.setFocusedCell(params.rowIndex, 'host', null);
  }

  onRemoveClicked(params: any) {
    let gridRowDataType = '';
    let gridOptionsType = '';
    let meetingInvitee = '';
    if ('host' in params.data) {
      gridRowDataType = 'rowDataFilAttendee';
      gridOptionsType = 'gridOptionsFilAttendee';
    } else {
      gridRowDataType = 'rowDataThirdPartyAttendee';
      gridOptionsType = 'gridOptionsThirdPartyAttendee';
    }
    this[gridRowDataType] = this[gridOptionsType].rowData;
    if (params.node.rowIndex !== -1) {
      this[gridRowDataType].splice(params.node.rowIndex, 1);
    }
    if (this[gridRowDataType].length < 1) {
      const newItem = this.createNewRowData(gridRowDataType);
      this[gridRowDataType].push(newItem);
    }
    this.refreshGrid(gridRowDataType, gridOptionsType);
    let removedCompanyRowIndexInSchedule: any;
    let conferenceSchedule = JSON.parse(JSON.stringify(this.commonService.getConferenceSchedule()));
    conferenceSchedule.eventMeetings.forEach((meeting) => {
      if (meeting.scheduleId === this.params.data.scheduleId) {
        if (gridOptionsType === 'gridOptionsFilAttendee' && meeting.fidelityInvitees.length) {
          meeting.fidelityInvitees.forEach((rowNode, Index) => {
            if (rowNode.corporateId === params.data.corporateId) {
              removedCompanyRowIndexInSchedule = Index;
            }
          });
          meeting.fidelityInvitees.splice(removedCompanyRowIndexInSchedule, 1);
        } else {
          if (meeting.thirdPartyAttendee.length) {
            meeting.thirdPartyAttendee.forEach((rowNode, Index) => {
              if (rowNode['companyAttendeeId'] === params.data.companyAttendeeId) {
                removedCompanyRowIndexInSchedule = Index;
              }
            });
            meeting.thirdPartyAttendee.splice(removedCompanyRowIndexInSchedule, 1);
          }
        }
      }
    });
    this.commonService.setConferenceSchedule(conferenceSchedule);
    this.setMasterGridData(gridOptionsType, 'rowRemoved');
  }

  private refreshGrid(rowData: string, gridOptions) {
    this[rowData].forEach((rowNode, index) => {
      rowNode.index = index + 1;
    });
    this[gridOptions].api.setRowData(this[rowData]);
  }
  private suppressEnterAndSpace(params) {
    const KEY_ENTER = 13;
    const KEY_SPACE = 32;
    const event = params.event;
    const key = event.which;
    const suppress = (key === KEY_ENTER || key === KEY_SPACE);
    return suppress;
  }
  private getAttendeeCount(params: any) {
    let attendeeTotalCount = '';
    let filAttendeeCount = 0;
    let thirdPartyAttendeeCount = 0;
    if (params.data.callRecordsFilAttendee && params.data.callRecordsFilAttendee.length > 0) {
      params.data.callRecordsFilAttendee.forEach((invitee) => {
        if (invitee.name) {
          filAttendeeCount++;
        }
      })
    }
    if (params.data.callRecordsThirdPartyAttendee && params.data.callRecordsThirdPartyAttendee.length > 0) {
      params.data.callRecordsThirdPartyAttendee.forEach((invitee) => {
        if (invitee.companyAttendee) {
          thirdPartyAttendeeCount++;
        }
      })
    }
    attendeeTotalCount = 'FIL : ' + filAttendeeCount + ', ' + 'Company : ' + thirdPartyAttendeeCount;
    return attendeeTotalCount;
  }
  getValue(): any {
    return this.gridOptionsFilAttendee.rowData;
  }
  // called when the cell is refreshed
  // refresh(params: any): boolean {
  //   console.log('paramsparamsparamsparams: ', params);
  //   return true;
  // }
}
