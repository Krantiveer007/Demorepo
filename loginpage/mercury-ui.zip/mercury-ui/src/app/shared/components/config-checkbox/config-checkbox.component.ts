import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/core/http/common.service';
import { Params } from '@angular/router';
import * as moment from 'moment';
@Component({
  selector: 'mv2-config-checkbox',
  template: `
  <div class="InviteesCheckBox">
    <input type="checkbox" class="invitees-checkbox" [ngClass]="{'changeCursorPointer': enableCheckBox}" [disabled]= "enableCheckBox"
    [checked]= "params.value" (change)="onChange($event)">
  </div>
  `,
  styleUrls: ['./config-checkbox.component.css']
})
export class ConfigCheckboxComponent implements ICellRendererAngularComp {

  params: any;
  enableCheckBox = true;
  count = 0;
  constructor(private route: ActivatedRoute, private commonService: CommonService) {
    this.params = '';
  }
  agInit(params): void {
    this.count++;
    this.params = params;
    if (this.params.node.data.Attendee
      || this.params.node.data.ExternalContactName
      || ((this.params.node.data.signUpAttendeeName) && ('Remove' in this.params.node.data))
      || (this.params.node.data.name)) {
      this.enableCheckBox = false;
    }
    if (('Attendee' in this.params.node.data) && !this.params.context) {
      this.enableCheckBox = true;
    }
    if (('Attendee' in this.params.node.data) && !('Response' in this.params.node.data) && (this.params.node.selectable === false)) {
      this.enableCheckBox = true;
    }
    if (this.params.node.data.Attendee
      && this.params.colDef.headerName === 'Invite'
      && ('Remove' in this.params.node.data)
      && this.params.node.rowIndex === 0) {
      this.enableCheckBox = true;
    }
    if ('name' in this.params.node.data
      && this.params.context && this.params.context.componentParent && this.params.context.componentParent.params &&
      this.params.context.componentParent.params.data.meetingState.toUpperCase() === 'CANCELLED') {
      this.enableCheckBox = true;
    }
    this.route.params.subscribe((params: Params) => {
      if (params['action'] === 'update') {
        this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
          }
        });
      }
    });
  }
  onChange(event) {
    this.params.data[this.params.colDef.field] = event.currentTarget.checked;
    if (this.params.data.name) {
      this.params.context.componentParent.setMasterGridData('gridOptionsFilAttendee', 'checkBox');
    }
  }
  refresh(): boolean {
    return false;
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.enableCheckBox = true;
    }

  }
}
