import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigCheckboxComponent } from './config-checkbox.component';
import { FormsModule } from '@angular/forms';

describe('ConfigCheckboxComponent', () => {
  let component: ConfigCheckboxComponent;
  let fixture: ComponentFixture<ConfigCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({imports: [
      FormsModule
    ],
      declarations: [ ConfigCheckboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('is Not able to select Call-in, Info-pack or Info Only checkbox when a new row with no attendee', () => {
    const params = {
      node : {
        data : {
          'Attendee': '',
          'AttendeeId': '',
          'Call-In': false,
          'Info Only': false,
          'Infopacks': false,
          'Remove': ''
        }
      }
    };
    fixture.detectChanges();
    component.agInit(params);
    expect(component.enableCheckBox).toEqual(true);
  });
  it('Verify that Call-In, Info packs, Info Only checkbox should be disabled for the existing FIL attendees', () => {
    const params = {
      node : {
        data : {
          'employeeDisplayName': 'Thornton, Ian',
          'employeeId': 'a596595',
          'callInFlag': false,
          'infoPackRequiredFlag': true,
          'inviteForInfoOnly': true
        }
      }
    };
    fixture.detectChanges();
    component.agInit(params);
    expect(component.enableCheckBox).toEqual(true);
  });
  it('should be able to select single or multiple Call-in/Info-pack/Info Only checkboxes' +
      'when a attendee is present for the corresponding row', () => {
    const params = {
      node : {
        data : {
          'Attendee': 'Sehrawat, Krantiveer',
          'AttendeeId': 'A595905',
          'Call-In': false,
          'Info Only': false,
          'Infopacks': false,
          'Remove': ''
        }
      }
    };
    fixture.detectChanges();
    component.agInit(params);
    expect(component.enableCheckBox).toEqual(false);
  });
});
