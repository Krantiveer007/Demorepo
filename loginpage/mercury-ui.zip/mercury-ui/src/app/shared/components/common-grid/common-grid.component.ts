import { Component, OnInit, Input, forwardRef, AfterViewInit } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigCheckboxComponent } from 'src/app/shared/components/config-checkbox/config-checkbox.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonService, SignUpRequired } from 'src/app/core/http/common.service';
import { Observable } from 'rxjs';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import * as moment from 'moment';
import { Params } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { OnDestroy, SimpleChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationEnd } from '@angular/router';
import { RoutesRecognized } from '@angular/router';
import * as momentTimezone from 'moment-timezone';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/pairwise';
import { ConfigRowSelectionComponent } from 'src/app/shared/components/config-row-selection/config-row-selection.component';
import Utils from '../../../shared/utils/common.utility';
// declare var $: any;
@Component({
  selector: 'mv2-common-grid',
  templateUrl: './common-grid.component.html',
  styleUrls: ['./common-grid.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CommonGridComponent),
      multi: true
    }
  ]
})
export class CommonGridComponent implements ControlValueAccessor, OnInit, AfterViewInit, OnDestroy, OnChanges {

  pastMeeting = false;

  value: any[] = [];
  touched = false;
  gridOptions: GridOptions;
  newCount = 1;
  gridApi: any;
  meetingType = '';
  rowData = [];
  currentUrl = '';
  previousUrl = '';
  columnDefs: any[];
  attainedMaxHeight = false;
  FILAttendeeGridMaxHeight = false;
  FILAttendeeAutoHeight = false;
  holdersMaxHeight = false;
  dLEmployeeMaxHeight = false;
  externalContactMaxHeight = false;
  meetingDataResponse: Observable<any>;
  meetingObj: any;
  tradableEntityId = '';
  subjectLine = '';
  mtgDateTime: any;
  currentAction = '';
  hostObs: Subscription;
  analystObs: Subscription;
  holdersSubscription: Subscription;
  holdersFilAttendeeSyncSubs: Subscription;
  removeHolderFilAttendeeSyncSubs: Subscription;
  tradableEntitySubscription: Subscription;
  securityAnalystSubscription: Subscription;
  addHolderAttendeeSubscription: Subscription;
  addDLAttendeeSubscription: Subscription;
  updateMtgDtlsSourceSubsciprtion: Subscription;
  currentMessageSubscription: Subscription;
  signUpMeetingIdObservableSubs: Subscription;
  defaultCompanyAttendeesObservableSubs: Subscription;
  filAttendeeListSourceObservableSUbs: Subscription;
  mtgHost = '';
  gridType = '';
  unsetDisplay = false;
  overlayNoRowsTemplate;
  mtgDetailsSubscription: Subscription;
  signUpForMeSubscription: Subscription;
  mtgLocation = '';
  mtgSubType = '';
  isRowSelectable;
  businessEntity = '';
  filAttendeeListForHoldersOrDLs = [];
  mtgSecurityName: '';
  isAllRowsSelected = false;
  isRowSelectDisabled = true;
  action = '';
  // hostCorpId = '';
  mtgDtlsObj = {
    'subjectLine': '',
    'mtgDateTime': '',
    'mtgHost': '',
    'mtgLocation': '',
    'mtgSubType': '',
    'businessEntity': '',
    'meetingType': ''
  };
  signUpInfo = {
    'meetingId': [],
    'fidelityInvitees': []
  };
  resetMeetingDetails: Subscription;
  meetingState = '';

  @Input() gridInfoObj: any;
  @Input() signUpDLAddedAttendees: any;
  @Input() disableCreateNewContactBtn: any;
  @Output() emitMeetingDetails = new EventEmitter<any>();
  @Output() emitSelectedHolders = new EventEmitter<any>();
  @Output() emitSelectedDLEmployees = new EventEmitter<any>();
  @Output() emitSelectedExternalContact = new EventEmitter<any>();
  @Output() createContactEmit = new EventEmitter<boolean>();
  @Output() editContactEmit = new EventEmitter<any>();
  @Input('selectedSecurity') selectedSecurity: string;
  @Input('contactData') contactData: any;
  @Input('disableSelectAll') disableSelectAll: boolean;
  onModelChange: Function = (value: any[]) => {
  }

  onModelTouched: Function = (): boolean => {
    return this.touched;
  }

  signUpRequired: SignUpRequired;
  constructor(private commonService: CommonService, private route: ActivatedRoute, private router: Router) {
    this.gridInfoObj = {
      'rowData': [],
      'columnDefs': [],
      'gridType': '' 
    };
  }
  

  ngOnInit() {
    this.gridOptions = {
      rowBuffer: 200,
      headerHeight: 40,
      rowHeight: 32,
      // suppressNoRowsOverlay: true,
      suppressMovableColumns: true,
      suppressScrollOnNewData: true,
      context: {
        componentParent: this
      },
      rowSelection: 'single'
    };
    this.disableSelectAll = Utils.isVoid(this.disableSelectAll) ? false : this.disableSelectAll;
    // $("#div1").addClass("disabledbutton");
    this.gridType = this.gridInfoObj.gridType;
    this.columnDefs = this.gridInfoObj.columnDefs;
    this.columnDefs.forEach((rowNode, Index) => {
      if (Index === 0) {
        rowNode.editable = this.isGridEditable;
        if (rowNode.field === 'Attendee' && this.gridType === 'filAttendeeGrid') {
          rowNode.cellStyle = { 'border-right': '1px solid #dadada' };
        }
      }
      rowNode.suppressKeyboardEvent = this.suppressEnterAndSpace;
    });
    if (this.gridInfoObj.gridType === 'filAttendeeGrid') {
      this.rowData = this.gridInfoObj.rowData;
      this.router.events.filter(e => e instanceof RoutesRecognized || e instanceof NavigationEnd).pairwise().subscribe((event) => {
        this.resetColumnDefDependingUponMeetingType(event);
      });
      this.hostObs = this.commonService.hostDataObservable.subscribe((response) => {
        if (response && response['hostCorpId'].length > 0) {
          if (response['primaryAnalystId'] && response['primaryAnalystId'].length > 0 && this.meetingType === 'Company') {
            if (response['primaryAnalystId'] === response['hostCorpId']) {
              if (this.isHostAlreadyPresentAsAttendeeValidation(response['hostCorpId'])) {
                this.commonService.hostAddedAsAttendeeSubject.next(true);
              } else {
                this.setHostInFilAttendeeGrid(response['hostName'], response['hostCorpId']);
              }
            } else {
              const currentHost = Object.assign({}, this.rowData[0]);
              if (this.isHostAlreadyPresentAsAttendeeValidation(response['hostCorpId'])) {
                this.commonService.hostAddedAsAttendeeSubject.next(true);
              } else {
                const currentHostAsAttendee = {
                  'Attendee': currentHost['Attendee'].replace(' (Host)', ''),
                  'AttendeeId': currentHost['AttendeeId'],
                  'Response': '',
                  'Call-In': currentHost['Call-In'],
                  'Invite': currentHost['Invite'],
                  'Infopacks': currentHost['Infopacks'],
                  'Info Only': currentHost['Info Only'],
                };
                // this.rowData.forEach((rowNode, Index) => {
                //   if (rowNode.Attendee.length === 0) {
                //     this.rowData.pop();
                //   }
                // });
                for (let i = (this.rowData.length - 1); i > 0; i--) {
                  if (this.rowData[i].Attendee.length === 0) {
                    this.rowData.pop();
                  }
                }
                if (this.rowData[this.rowData.length - 1].Attendee.length === 0 && this.rowData.length > 1) {
                  this.rowData.pop();
                }
                this.rowData.push(currentHostAsAttendee);
                if (this.rowData[this.rowData.length - 1]['Attendee'] !== '') {
                  do {
                    this.rowData.push(
                      {
                        'Attendee': '',
                        'AttendeeId': '',
                        'Response': '',
                        'Call-In': false,
                        'Invite': false,
                        'Infopacks': false,
                        'Info Only': false,
                      });
                  } while (this.rowData.length < 4)
                }
                this.setHostInFilAttendeeGrid(response['hostName'], response['hostCorpId']);
                const hostDetail = {
                  'hostName': response['hostName'],
                  'hostCorpId': response['hostCorpId'],
                  'hostPhoneNumber': response['hostPhoneNumber'],
                  'primaryAnalystId': '',
                  'primaryAnalystName': ''
                };
                this.commonService.changeHostDetails(hostDetail);
              }
            }
          } else {
            if (this.isHostAlreadyPresentAsAttendeeValidation(response['hostCorpId'])) {
              this.commonService.hostAddedAsAttendeeSubject.next(true);
            } else {
              this.setHostInFilAttendeeGrid(response['hostName'], response['hostCorpId']);
            }
          }
        }
      });

      this.route.params.subscribe((params: Params) => {
        this.action = params['action'];
        if (params['action'] === 'create') {
          this.meetingType = params['meetingType'];          
          if (this.meetingType === 'Company') {
            this.analystObs = this.commonService.tradableEntityIdObservable.subscribe((trdEntId) => {
              if (trdEntId) {
                this.resetFidelityAttendeesGrid();
                let analystData = [];
                if (this.selectedSecurity === 'Equity') {
                this.securityAnalystSubscription = this.commonService.getSecurityAnalysts(trdEntId).subscribe((response) => {
                  if (response['status'] === 200 && response['data'].length > 0) {
                    response['data'].forEach((rowNode, Index) => {
                      if (rowNode.analystRoleTypeDesc === 'Primary' && rowNode.teamDept === 'FUND') {
                        if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'EUR'
                          && rowNode.teamLocation !== 'LDN'
                          && rowNode.bussinessUnitCd !== 'FIL-LDN') {
                          const analystDetails = {
                            'name': convertToTitleCase(rowNode.name),
                            'corporateId': rowNode.corporateId
                          }
                          analystData.push(analystDetails);
                        } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'JP') {
                          if (rowNode.teamLocation !== 'TOK'
                            && rowNode.bussinessUnitCd !== 'FIL-TOK') {
                            const analystDetails = {
                              'name': convertToTitleCase(rowNode.name),
                              'corporateId': rowNode.corporateId
                            }
                            analystData.push(analystDetails);
                          }
                        } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'APxJ') {
                          if (rowNode.teamLocation !== 'HKG'
                            && rowNode.bussinessUnitCd !== 'FIL-HKG') {
                            const analystDetails = {
                              'name': convertToTitleCase(rowNode.name),
                              'corporateId': rowNode.corporateId
                            }
                            analystData.push(analystDetails);
                          }
                        } else if (this.commonService.getLoggedInUserInfo().getRegionCode() === 'CAN') {
                          if (rowNode.teamLocation !== 'PYR'
                            && rowNode.bussinessUnitCd !== 'FIL-CAN') {
                            const analystDetails = {
                              'name': convertToTitleCase(rowNode.name),
                              'corporateId': rowNode.corporateId
                            }
                            analystData.push(analystDetails);
                          }
                        }
                      }
                    });
                    for (let i = 0; i < analystData.length; i++) {
                      this.rowData[i + 1]['Attendee'] = analystData[i].name;
                      this.rowData[i + 1]['AttendeeId'] = analystData[i].corporateId;
                      this.rowData[i + 1]['Call-In'] = false;
                      this.rowData[i + 1]['Invite'] = false;
                      this.rowData[i + 1]['Infopacks'] = false;
                      this.rowData[i + 1]['Info Only'] = false;
                      this.rowData[i + 1]['Response'] = '';
                    }
                    this.gridApi.setRowData(this.rowData);
                    this.gridApi.forEachNode((node) => {
                      if (node.rowIndex === 0) {
                        node.setSelected(true);
                      }
                    });
                    this.commonService.changeFilAttendeeList(this.rowData);
                  }
                });
                }
              }
            });
          }
        } else if (params['action'] === 'update') {
          this.updateMtgDtlsSourceSubsciprtion = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
            if (response) {
              this.meetingState = response.meetingState;
              this.meetingType = response.meetingType;
              this.businessEntity = response.businessEntity;
              // this.hostCorpId = response['hostCorpId'];
              if (this.meetingType !== 'Company' || (this.meetingType === 'Company' && this.businessEntity === 'FI')) {
                if (response.meetingState === 'CONFIRMED' || response.meetingState === 'DRAFTINVITE') {
                  this.columnDefs.splice(4, 1);
                } else if (response.meetingState === 'DRAFT') {
                  this.columnDefs.splice(3, 1);
                }
              }
              const filAttendee = (response.fidelityInvitees) ? response.fidelityInvitees : [];
              filAttendee.forEach((item, index) => {
                if (item['corporateId'] === response['hostCorporateId']) {
                  if (filAttendee[0]['corporateId'] !== item['corporateId']) {
                    filAttendee.splice(0, 0, item);
                    filAttendee.splice(index + 1, 1);
                  }
                }
              });
              if (filAttendee.length >= 4) {
                this.rowData = (response.fidelityInvitees) ? Object.assign([], response.fidelityInvitees) : [];
              }
              filAttendee.forEach((rowNode, Index) => {
                this.rowData[Index]['Attendee'] = convertToTitleCase((response.fidelityInvitees[Index].name)
                  ? response.fidelityInvitees[Index].name
                  : '');
                this.rowData[Index]['AttendeeId'] = response.fidelityInvitees[Index].corporateId
                  ? response.fidelityInvitees[Index].corporateId
                  : '';
                this.rowData[Index]['Call-In'] = (response.fidelityInvitees[Index].isCallIn === 'Y') ? true : false;
                if (this.meetingType === 'Company') {
                  this.rowData[Index]['Infopacks'] = (response.fidelityInvitees[Index].isInfoPackRequired === 'Y') ? true : false;
                }
                this.rowData[Index]['Invite'] = (response.fidelityInvitees[Index].isInviteRequired === 'Y') ? true : false;
                this.rowData[Index]['Info Only'] = (response.fidelityInvitees[Index].isInviteForInfoOnly === 'Y') ? true : false;
                this.rowData[Index]['Response'] = response.fidelityInvitees[Index].inviteeResponse
                  ? response.fidelityInvitees[Index].inviteeResponse
                  : '';
              });
              if (filAttendee.length >= 4) {
                if (this.rowData[this.rowData.length - 1]['Attendee'] !== '') {
                  let rowDataElement = {};
                  if (this.meetingType === 'Company') {
                    rowDataElement = {
                      'Attendee': '',
                      'AttendeeId': '',
                      'Response': '',
                      'Call-In': false,
                      'Invite': false,
                      'Infopacks': false,
                      'Info Only': false,
                    }
                  } else {
                    rowDataElement = {
                      'Attendee': '',
                      'AttendeeId': '',
                      'Response': '',
                      'Call-In': false,
                      'Invite': false,
                      'Info Only': false,
                    }
                  }
                  this.rowData.push(rowDataElement);
                }
              }
              // if (this.gridApi && this.rowData.length > 4) {
              //   this.unsetDisplay = false;
              //   if (this.rowData.length >= 20) {
              //     this.FILAttendeeGridMaxHeight = true;
              //     this.FILAttendeeAutoHeight = false;
              //     this.gridApi.setDomLayout('normal');
              //   } else {
              //     this.FILAttendeeGridMaxHeight = false;
              //     this.FILAttendeeAutoHeight = true;
              //     this.gridApi.setDomLayout('autoHeight')
              //   }
              // }
            }
          });

          this.rowData.forEach((item) => {
            if (item['AttendeeId'] !== '') {
              item['ResponseCheck'] = true;
            }
          });
          this.commonService.changeFilAttendeeList(this.rowData);
          this.rowData[0]['Attendee'] = this.rowData[0]['Attendee'] + ' (Host)';
        }
      });
      if (this.meetingType === 'Company') {
        this.addAttendeesToFidelityAttendeeGrid('holdersDtlsSourceObservable');
      }
      this.addAttendeesToFidelityAttendeeGrid('dLEmployeeSourceObservable');
    } else if (this.gridInfoObj.gridType === 'thirdPartyAttendeeGrid') {
      this.rowData = this.gridInfoObj.rowData;
      this.route.params.subscribe((params: Params) => {
        if (params['action'] === 'update') {
          this.updateMtgDtlsSourceSubsciprtion = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
            if (response) {
              //   this.meetingState = response.meetingState;
              this.meetingType = response.meetingType;
              const thirdPartyAttendee = (response.thirdPartyAttendee) ? response.thirdPartyAttendee : [];
              if (thirdPartyAttendee.length >= 3) {
                this.rowData = (response.thirdPartyAttendee) ? response.thirdPartyAttendee : [];
              }
              if (thirdPartyAttendee.length > 0) {
                thirdPartyAttendee.forEach((rowNode, Index) => {
                  this.rowData[Index]['ExternalContactName'] = thirdPartyAttendee[Index].externalContactName ? thirdPartyAttendee[Index].externalContactName : '';
                  this.rowData[Index]['ExternalContactId'] = thirdPartyAttendee[Index].externalContactId ? thirdPartyAttendee[Index].externalContactId : '';
                  this.rowData[Index]['Email'] = thirdPartyAttendee[Index].email ? thirdPartyAttendee[Index].email : '';
                  this.rowData[Index]['Position'] = thirdPartyAttendee[Index].position ? thirdPartyAttendee[Index].position : ''
                  this.rowData[Index]['Notes'] = thirdPartyAttendee[Index].notes ? thirdPartyAttendee[Index].notes : '';
                  this.rowData[Index]['Company'] = thirdPartyAttendee[Index].company ? convertToTitleCase(thirdPartyAttendee[Index].company) : '';
                });

                if (thirdPartyAttendee.length >= 3) {
                  if (this.rowData[this.rowData.length - 1]['ExternalContactId'] !== '') {
                    this.rowData.push(
                      {
                        'ExternalContactName': '',
                        'ExternalContactId': '',
                        'Company': '',
                        'Email': '',
                        'Position': '',
                        'Notes': '',
                        'Remove': ''
                      });
                  }
                }
              }
            }
          });
          if(this.gridApi) {
    this.gridApi.ensureIndexVisible(this.rowData.length - 1 , 'bottom');
    }

        } else {
          //     this.tradableEntitySubscription = this.commonService.tradableEntityIdObservable.subscribe((message) => {
          //       this.tradableEntityId = message;
          //       const resetRowData = [
          //         {
          //           'ExternalContactName': '',
          //           'ExternalContactId': '',
          //           'Company': '',
          //           'Email': '',
          //           'Position': '',
          //           'Notes': '',
          //           'Remove': ''
          //         },
          //         {
          //           'ExternalContactName': '',
          //           'ExternalContactId': '',
          //           'Company': '',
          //           'Email': '',
          //           'Position': '',
          //           'Notes': '',
          //           'Remove': ''
          //         },
          //         {
          //           'ExternalContactName': '',
          //           'ExternalContactId': '',
          //           'Company': '',
          //           'Email': '',
          //           'Position': '',
          //           'Notes': '',
          //           'Remove': ''
          //         },
          //         {
          //           'ExternalContactName': '',
          //           'ExternalContactId': '',
          //           'Company': '',
          //           'Email': '',
          //           'Position': '',
          //           'Notes': '',
          //           'Remove': ''
          //         }
          //       ];
          //       this.rowData = resetRowData;
          //     });
        }
      });
      this.currentMessageSubscription = this.commonService.currentMessage.subscribe((securityName) => {
        this.mtgSecurityName = securityName;
      });
    this.addThirdPartyAttendeeToGrid('externalContactSourceeObservable');
    
    } else if (this.gridInfoObj.gridType === 'signUpAttendeeGrid') {
      this.unsetDisplay = true;
      this.signUpMeetingIdObservableSubs = this.commonService.signUpMeetingIdObservable.subscribe((meetingData) => {
        this.meetingObj = meetingData;
      });
      this.mtgDetailsSubscription = this.commonService.getMtgDetailsForMtgId(this.meetingObj.meetingId, this.meetingObj.meetingType).subscribe((response) => {
        const convertedDate = moment(response.body.meetingDate).format('DD/MM/YYYY');
        const businessEntity = response.body.businessEntity ? response.body.businessEntity : '';
        if (response.statusCode === 200) {
          let getHostNameFromFILAttendees = '';
          response.body.fidelityInvitees.forEach(invitee => {
            if (invitee.corporateId === response.body.hostCorporateId) {
              getHostNameFromFILAttendees = invitee.name;
            }
          });
          this.mtgDtlsObj.subjectLine = (response.body.emailSubject) ? response.body.emailSubject : '';
          this.mtgDtlsObj.mtgDateTime = ((response.body.meetingDate) ? convertedDate : '')
            + ' ' + ((response.body.meetingTimeInGMT) ? (this.getMeetngDateInLocalTime(response.body))['time'] : '');
          this.mtgDtlsObj.mtgHost = convertToTitleCase(getHostNameFromFILAttendees);
          this.mtgDtlsObj.mtgLocation = (response.body.locationType) ? response.body.locationType : '';
          this.mtgDtlsObj.mtgSubType = (response.body.meetingSubTypeDescription) ? response.body.meetingSubTypeDescription : '';
          this.mtgDtlsObj.businessEntity = response.body.businessEntity ? response.body.businessEntity : '';
          this.mtgDtlsObj.meetingType = response.body.meetingType ? response.body.meetingType : '';
          this.rowData = (response.body.fidelityInvitees) ? response.body.fidelityInvitees : [];
          if (this.commonService.getMeetingType().includes('Company') && businessEntity === 'FI') {
            this.rowData.forEach((element) => {
              delete element.isInfoPackRequired;
            });
          }
          let meetingCreatorId = response.body.meetingCreator ? response.body.meetingCreator.corporateId : '';
          if (meetingCreatorId && meetingCreatorId === this.commonService.getLoggedInUserInfo().getCorporateId()) {
            this.signUpRequired = {
              isRequired: true,
              requiredReason: 'userIsOnlyMtgCreator'
            }
            this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
          }
          response.body.fidelityInvitees.forEach((rowNode, Index) => {
            this.rowData[Index]['signUpAttendeeName'] = convertToTitleCase(rowNode.name ? rowNode.name : '');
            this.rowData[Index]['corporateId'] = rowNode.corporateId ? rowNode.corporateId : '';
            this.rowData[Index]['isCallIn'] = (rowNode.isCallIn === 'Y') ? true : false;
            this.rowData[Index]['isInviteRequired'] = (rowNode.isInviteRequired === 'Y') ? true : false;
            if (this.commonService.getMeetingType().includes('Company') && businessEntity === 'EQ') {
              this.rowData[Index]['isInfoPackRequired'] = (rowNode.isInfoPackRequired === 'Y') ? true : false;
            }
            this.rowData[Index]['isInviteForInfoOnly'] = (rowNode.isInviteForInfoOnly === 'Y') ? true : false;
            if (this.rowData[Index]['corporateId'] === this.commonService.getLoggedInUserInfo().getCorporateId()) {
              this.signUpRequired = {
                isRequired: true,
                requiredReason: 'userIsMtgCreatorAndAttendee'
              }
              this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
            }
          });
          if (this.commonService.getMeetingType().includes('Company') && businessEntity === 'EQ') {
            this.rowData.push({
              'signUpAttendeeName': '',
              'corporateId': '',
              'isCallIn': false,
              'isInviteRequired': false,
              'isInfoPackRequired': false,
              'isInviteForInfoOnly': false,
              'Remove': ''
            });
          } else if (this.commonService.getMeetingType() === 'Other'
            || (this.commonService.getMeetingType().includes('Company') && businessEntity === 'FI')
            || this.commonService.getMeetingType() === 'Broker') {
            this.rowData.push({
              'signUpAttendeeName': '',
              'corporateId': '',
              'isCallIn': false,
              'isInviteRequired': false,
              'isInviteForInfoOnly': false,
              'Remove': ''
            });
          }
          if (this.rowData.length >= 14) {
            this.unsetDisplay = false;
            this.attainedMaxHeight = true;
            this.gridApi.setDomLayout('normal');
          }
          this.emitMeetingDetails.emit(this.mtgDtlsObj);
          if (this.gridApi) {
            this.gridApi.setRowData(this.rowData);
            this.commonService.changeFilAttendeeList(this.rowData);
            this.gridApi.setFocusedCell(this.rowData.length - 1, 'signUpAttendeeName', null);
            this.gridApi.ensureIndexVisible(this.rowData.length - 1 , 'bottom');
            this.gridApi.forEachNode((node) => {
              if (node.rowIndex === (this.rowData.length - 1)) {
                node.setSelected(true);
              }
            });
          }
        } else {
          console.log('No Response', response.errorMessage);
        }
      });
      this.gridOptions.getRowStyle = function (params) {
        if (!('Remove' in params.data)) {
          return {
            background: '#eeeff0!important'
          };
        }
      };
    } else if (this.gridInfoObj.gridType === 'holdersGrid') {
      this.tradableEntitySubscription = this.commonService.tradableEntityIdObservable.subscribe((trdEntId) => {
        if (trdEntId) {
          if (this.gridApi) {
            this.gridOptions.localeText = {
              noRowsToShow: `<span style="vertical-align: middle;">
              <img style="width:25px;height:25px;" src="/assets/images/spinner.gif">
              <span style="color: #747c89; font-size: 15px;">&nbsp Security Holders are being fetched...</span>
              </span>` };
            this.gridApi.setRowData([]);
          }
          this.holdersSubscription = this.commonService.getHoldersData(trdEntId, this.selectedSecurity).subscribe((response) => {
            if (response['data'] && response['status'] === 200) {
              if (response['data'].length > 0) {
                this.rowData = response['data'];
                // this.isRowSelectDisabled = true;
                response['data'].forEach((rowNode, Index) => {
                  let isRowSelectable = false;
                  let isCallin = false;
                  let isInvite = true;
                  let isInfoPack = false;
                  let isInfoOnly = false;
                  if (this.filAttendeeListForHoldersOrDLs.length > 0) {
                    this.filAttendeeListForHoldersOrDLs.forEach((filAttendeeList) => {
                      if (rowNode.corporateId.toUpperCase() === filAttendeeList.AttendeeId.toUpperCase()) {
                        isRowSelectable = true;
                        isCallin = filAttendeeList['Call-In'];
                        isInvite = filAttendeeList['Invite'];
                        isInfoPack = filAttendeeList['Infopacks'];
                        isInfoOnly = filAttendeeList['Info Only'];
                      }
                    })
                  }
                  this.rowData[Index]['selection'] = isRowSelectable;
                  this.rowData[Index]['holderRank'] = rowNode.holderRank ? rowNode.holderRank : '';
                  this.rowData[Index]['Attendee'] = rowNode.name ? convertToTitleCase(rowNode.name) : '';
                  this.rowData[Index]['AttendeeId'] = rowNode.corporateId ? rowNode.corporateId : '';
                  this.rowData[Index]['Call-In'] = isCallin;
                  this.rowData[Index]['Invite'] = isInvite;
                  this.rowData[Index]['Infopacks'] = isInfoPack;
                  this.rowData[Index]['Info Only'] = isInfoOnly;

                  delete this.rowData[Index].corporateId;
                  delete this.rowData[Index].name;
                });
                if (this.gridApi) {
                  if (this.rowData.length === 1) {
                    this.gridOptions.rowHeight = 50;
                  } else {
                    this.gridOptions.rowHeight = 32;
                  }
                  this.gridApi.setRowData(this.rowData);
                }
                if (this.rowData.length >= 10) {
                  this.unsetDisplay = false;
                  this.holdersMaxHeight = true;
                  this.gridApi.setDomLayout('normal');
                }
                if (this.rowData.length > 0) {
                  let count = 0;
                  this.isRowSelectDisabled = false;
                  this.rowData.forEach((rowNode) => {
                    if (rowNode.selection === true) {
                      count++;
                    }
                  })
                  if (this.rowData.length === count) {
                    this.isRowSelectDisabled = true;
                    this.isAllRowsSelected = true;
                    this.emitSelectedHolders.emit([]);
                  }
                }
              } else if (response['data'].length === 0) {
                this.isRowSelectDisabled = true;
                if (this.gridApi) {
                  this.rowData = response['data'];
                  this.gridOptions.localeText = { noRowsToShow: this.noRowShowStyling() };
                  this.gridApi.setRowData(this.rowData);
                  this.unsetDisplay = false;
                  this.holdersMaxHeight = false;
                  this.gridApi.setDomLayout('autoHeight');
                }
              }
            } else {
              this.isRowSelectDisabled = true;
              if (this.gridApi) {
                this.rowData = response['data'];
                this.gridOptions.localeText = { noRowsToShow: this.noRowShowStyling() };
                this.gridApi.setRowData(this.rowData);
                this.unsetDisplay = false;
                this.holdersMaxHeight = false;
                this.gridApi.setDomLayout('autoHeight');
              }
            }
          },
            (error) => {
              this.isRowSelectDisabled = true;
              this.isAllRowsSelected = false;
              this.rowData = [];
              this.gridOptions.localeText = { noRowsToShow: this.noRowShowStyling() };
              this.gridApi.setRowData(this.rowData);
              this.unsetDisplay = false;
              this.holdersMaxHeight = false;
              this.gridApi.setDomLayout('autoHeight');
            });
        }
      });
      this.gridOptions.rowSelection = 'multiple';
      this.gridOptions.localeText = { noRowsToShow: this.noRowShowStyling() };
      this.gridOptions.suppressRowClickSelection = true;
      // this.validateAlreadyPresentAttendee();
      this.holdersFilAttendeeSyncSubs = this.commonService.filAttendeeListSourceObservable.subscribe((filAttendeeResponse) => {
        if (filAttendeeResponse && this.gridApi && this.rowData.length > 0) {
          // let filAttendeeListWithOnlyHolders = [];
          let filAttendeeList = [];
          filAttendeeResponse.forEach((node, Index) => {
            if (node.AttendeeId) {
              let newNode = Object.assign({}, node);
              filAttendeeList.push(newNode);
              // if (node.hasOwnProperty('holderRank')) { }
            }
          });
          if (filAttendeeList.length > 0) {
            this.gridOptions.isRowSelectable = function (node) {
              let isSelected = true;
              filAttendeeList.forEach((filAttendeeNode) => {
                if (node.data.AttendeeId === filAttendeeNode.AttendeeId) {
                  isSelected = false;
                }
              });
              return isSelected;
            };
            this.rowData.forEach((personRowNode) => {
              filAttendeeList.forEach((filAttendeeNode) => {
                if (personRowNode.AttendeeId === filAttendeeNode.AttendeeId) {
                  personRowNode.selection = true;
                }
              });
            });
            this.gridOptions.getRowStyle = function (params) {
              let isSelected = true;
              filAttendeeList.forEach((filAttendeeNode) => {
                if (params.data.AttendeeId === filAttendeeNode.AttendeeId) {
                  isSelected = false;
                }
              });
              if (!isSelected) {
                return {
                  background: '#eeeff0!important'
                };
              }
            };
            this.gridApi.setRowData(this.rowData);
            this.gridApi.forEachNode((node) => {
              filAttendeeList.forEach((filAttendeeNode) => {
                if (node.data.AttendeeId === filAttendeeNode.AttendeeId) {
                  node.setSelected(false);
                }
              });
            });
            let attendeeAndHoldersListCount = 0;
            this.rowData.forEach((rowNode) => {
              filAttendeeList.forEach((attendeeList) => {
                if (rowNode.AttendeeId === attendeeList.AttendeeId) {
                  attendeeAndHoldersListCount++;
                }
              });
            });
            if (attendeeAndHoldersListCount === this.rowData.length) {
              this.isAllRowsSelected = true;
              this.isRowSelectDisabled = true;
            } else if (attendeeAndHoldersListCount === 0) {
              this.isAllRowsSelected = false;
              this.isRowSelectDisabled = false;
            } else {
              this.isAllRowsSelected = false;
              this.isRowSelectDisabled = false;
            }
            const selectedRows = this.gridApi.getSelectedRows();
            this.emitSelectedHolders.emit(selectedRows);
          }
        }
      });
      this.removeHolderFilAttendeeSyncSubs = this.commonService.removedAttendeeSubject.subscribe((removedAttendee: any) => {
        if (removedAttendee && this.gridApi && this.rowData.length > 0) {
          this.gridOptions.isRowSelectable = function (node) {
            let isSelected = true;
            if (node.data.AttendeeId === removedAttendee.AttendeeId) {
              isSelected = true;
            }
            return isSelected;
          };
          this.rowData.forEach((personRowNode) => {
            if (personRowNode.AttendeeId === removedAttendee.AttendeeId) {
              personRowNode.selection = false;
            }
          });
          this.gridOptions.getRowStyle = function (params) {
            let isSelected = false;
            if (params.data.AttendeeId === removedAttendee.AttendeeId) {
              isSelected = true;
            }
            if (isSelected) {
              return {
                background: '#fff'
              };
            }
          };
          this.gridApi.setRowData(this.rowData);
          this.gridApi.forEachNode((node) => {
            if (node.data.AttendeeId === removedAttendee.AttendeeId) {
              node.setSelected(false);
            }
          });
          const selectedRows = this.gridApi.getSelectedRows();
          this.emitSelectedHolders.emit(selectedRows);
        }
      });
    } else if (this.gridInfoObj.gridType === 'distributionListGrid') {
      this.gridOptions.rowSelection = 'multiple';
      this.gridOptions.localeText = { noRowsToShow: this.noRowShowStylingForDL() };
      this.gridOptions.suppressRowClickSelection = true;
      this.validateAlreadyPresentAttendee();
    } else if (this.gridInfoObj.gridType === 'externalContactSearchGrid') {
      this.gridOptions.rowSelection = 'multiple';
      this.gridOptions.suppressRowClickSelection = true;
      this.rowData = this.gridInfoObj.rowData;
      if (this.contactData && this.contactData.length > 0) {
        this.isRowSelectDisabled = false;
        this.rowData = JSON.parse(JSON.stringify(this.contactData));
        this.contactData.forEach((item, index) => {
          this.rowData[index]['Name'] = item['contactTypeObj']['contact']['fullName'] ? item['contactTypeObj']['contact']['fullName'] : '';
          this.rowData[index]['ExternalContactId'] = item['contactTypeObj']['contact']['externalId'] ? item['contactTypeObj']['contact']['externalId'] : '';
          this.rowData[index]['Email'] = item['contactTypeObj']['contact']['email'] ? item['contactTypeObj']['contact']['email'] : '';
          this.rowData[index]['Position'] = item['contactTypeObj']['contact']['position'] ? item['contactTypeObj']['contact']['position']  : ''
          this.rowData[index]['Notes'] = item['contactTypeObj']['contact']['notes'] ? item['contactTypeObj']['contact']['notes'] : '';
          if(item['contactType'] === 'BC') {            
            this.rowData[index]['Company'] = item['contactTypeObj']['brokerFirm'] && item['contactTypeObj']['brokerFirm']['firmName'] ? item['contactTypeObj']['brokerFirm']['firmName'] : '';
          } else {
            this.rowData[index]['Company'] = item['contactTypeObj']['companyName'] ? item['contactTypeObj']['companyName'] : '';
          }
        //  delete this.rowData[index]['contactType'];
        //  delete this.rowData[index]['contactTypeObj'];
        });
        console.log("rowdata pushed", this.rowData)
        this.gridOptions.rowData = this.rowData;
        if (this.rowData.length >= 14) {
          this.unsetDisplay = false;
          this.externalContactMaxHeight = true;
          this.gridApi.setDomLayout('normal');
        } else {
        if(this.gridApi) {
        this.gridApi.setDomLayout('autoHeight');
        }
      } 
      } else {
        this.emitSelectedExternalContact.emit([]);
      }
    }
    this.gridOptions.onSelectionChanged = this.onSelectionChanged;
    this.gridOptions.rowData = this.rowData;

    this.resetMeetingDetails = this.commonService.resetMeetingDetailsSubject.subscribe(res => {
      if (res) {
        this.resetMeetingDetailValues();
      }
    });
    if (this.gridType === 'holdersGrid' || this.gridType === 'signUpAttendeeGrid' || this.gridType === 'filAttendeeGrid' || this.gridType === 'distributionListGrid') {
      this.columnDefs.forEach((rowNode, Index) => {
        if (rowNode.field !== 'Attendee' && rowNode.field !== 'signUpAttendeeName') {
          rowNode.headerClass = 'mv2-headerCenterAlign';
        } else if (rowNode.field === 'signUpAttendeeName') {
          rowNode.headerClass = 'mv2-headerLeftAlign';
        }
      });
    }

    this.signUpForMeSubscription = this.commonService.signUpForMeSubject.subscribe(res => {
      if (res) {
        if (this.gridInfoObj.gridType === 'signUpAttendeeGrid') {
          this.rowData[this.rowData.length - 1] = {
            'signUpAttendeeName': convertToTitleCase(this.commonService.getLoggedInUserInfo().getName()),
            'corporateId': this.commonService.getLoggedInUserInfo().getCorporateId(),
            'isCallIn': false,
            'isInviteRequired': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false,
            'Remove': ''
          };
          this.signUpInfo.meetingId = this.meetingObj.meetingId;
          this.signUpInfo.fidelityInvitees[this.signUpInfo.fidelityInvitees.length] = this.rowData[this.rowData.length - 1];
          this.commonService.signUpAttendeeListChange(this.signUpInfo);
          this.rowData.push({
            'signUpAttendeeName': '',
            'corporateId': '',
            'isCallIn': false,
            'isInviteRequired': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false,
            'Remove': ''
          });
          this.gridApi.setRowData(this.rowData);
          this.signUpRequired = {
            isRequired: true,
            requiredReason: 'newUserSelectedSignUpForMe'
          }
          this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
        }
      }
    });
    this.route.params.subscribe((params: Params) => {
      this.currentAction = params['action'];
      if (params['action'] === 'update') {
        this.updateMtgDtlsSourceSubsciprtion = this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
          if (response) {
            this.meetingType = response.meetingType;
            this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
          }
        });
      }
    });

    if (this.gridInfoObj.gridType === 'thirdPartyAttendeeGrid' && this.currentAction !== 'update') {
      this.defaultCompanyAttendeesObservableSubs = this.commonService.defaultCompanyAttendeesObservable.subscribe((response) => {
        if (response && response.length !== 0) {
          this.rowData = response;
          response.forEach((item, index) => {
            this.rowData[index]['ExternalContactName'] = response[index].externalContactName ? response[index].externalContactName : '';
            this.rowData[index]['ExternalContactId'] = response[index].externalId ? response[index].externalId : '';
            this.rowData[index]['Email'] = response[index].email ? response[index].email : '';
            this.rowData[index]['Position'] = response[index].position ? response[index].position : ''
            this.rowData[index]['Notes'] = response[index].notes ? response[index].notes : '';
            this.rowData[index]['Company'] = convertToTitleCase(this.mtgSecurityName);
          });
          if (this.rowData[this.rowData.length-1]['ExternalContactId'] !== '' || this.rowData.length < 3) {
            this.rowData.push(
              {
                'ExternalContactName': '',
                'ExternalContactId': '',
                'Company': '',
                'Email': '',
                'Position': '',
                'Notes': '',
                'Remove': ''
              });
          }
          this.gridApi.setRowData(this.rowData);
        }
        else {
          if (this.gridApi) {
            this.rowData.forEach((item, index) => {
              this.rowData[index]['ExternalContactName'] = '';
              this.rowData[index]['ExternalContactId'] = '';
              this.rowData[index]['Email'] = '';
              this.rowData[index]['Position'] = ''
              this.rowData[index]['Notes'] = '';
              this.rowData[index]['Company'] = '';
            });
            this.gridApi.setRowData(this.rowData);
          }
        }
      }, (error) => {
        console.log(error)
      });

    }

    // if (this.gridInfoObj.gridType !== 'distributionListGrid' && this.gridInfoObj.gridType !== 'holdersGrid' && this.gridInfoObj.gridType !== 'signUpAttendeeGrid' && this.gridInfoObj.gridType !== 'thirdPartyAttendeeGrid') {
    //   if (this.selectedSecurity === 'Equity') {
    //     this.resetColumnDefs('Company');
    //   } else {
    //     this.resetColumnDefs('Other');
    //   }
    // } else {
    //   if (this.selectedSecurity === 'Fixed Income') {
    //     this.columnDefs.splice(5, 1);
    //   }
    // }
  }
  ModelTouched: Function = (): boolean => {
    return this.touched;

  }
  ngAfterViewInit() {
    this.onModelChange(this.rowData);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.gridInfoObj.gridType === 'distributionListGrid') {
      let change = changes['gridInfoObj'];
      let currentVal = change.currentValue ? change.currentValue : '';
      this.rowData = currentVal.rowData;
      this.isRowSelectDisabled = false;
      if (this.rowData.length === 0) {
        this.isRowSelectDisabled = true;
        this.unsetDisplay = false;
        this.dLEmployeeMaxHeight = false;
        if (this.gridApi) {
          this.gridApi.setDomLayout('autoHeight');
        }
      } else {
        currentVal.rowData.forEach((rowNode, Index) => {
          let isRowSelectable = false;
          let isCallin = false;
          let isInvite = true;
          let isInfoPack = false;
          let isInfoOnly = false;
          if (this.filAttendeeListForHoldersOrDLs.length > 0) {
            this.filAttendeeListForHoldersOrDLs.forEach((filAttendeeList) => {
              if (filAttendeeList.AttendeeId) {
                if (rowNode.userId.toUpperCase() === filAttendeeList.AttendeeId.toUpperCase()) {
                  isRowSelectable = true;
                  isCallin = filAttendeeList['Call-In'];
                  isInvite = filAttendeeList['Invite'];
                  isInfoPack = filAttendeeList['Infopacks'];
                  isInfoOnly = filAttendeeList['Info Only'];
                }
              } else if (filAttendeeList.corporateId) {
                if (rowNode.userId.toUpperCase() === filAttendeeList.corporateId.toUpperCase()) {
                  isRowSelectable = true;
                  isCallin = filAttendeeList['isCallIn'];
                  isInvite = filAttendeeList['isInviteRequired'];
                  isInfoPack = filAttendeeList['isInfoPackRequired'];
                  isInfoOnly = filAttendeeList['isInviteForInfoOnly'];
                }
              }
            })
          }
          this.rowData[Index]['selection'] = isRowSelectable;
          this.rowData[Index]['Attendee'] = rowNode.displayName ? convertToTitleCase(rowNode.displayName) : '';
          this.rowData[Index]['AttendeeId'] = rowNode.userId ? rowNode.userId : '';
          this.rowData[Index]['Call-In'] = isCallin;
          this.rowData[Index]['Invite'] = isInvite;
          if (this.commonService.getMeetingType().includes('Company')) {
            this.rowData[Index]['Infopacks'] = isInfoPack;
          }
          this.rowData[Index]['Info Only'] = isInfoOnly;
          delete this.rowData[Index].userId;
          delete this.rowData[Index].displayName;
          delete this.rowData[Index].name;
          delete this.rowData[Index].emailId;
          // delete this.rowData[Index].phoneNo;
        });
        if (this.gridApi) {
          this.gridApi.setRowData(this.rowData);
        }
        if (this.rowData.length >= 14) {
          this.unsetDisplay = false;
          this.dLEmployeeMaxHeight = true;
          this.gridApi.setDomLayout('normal');
        }
        if (this.rowData.length > 0) {
          let count = 0;
          this.rowData.forEach((rowNode) => {
            if (rowNode.selection === true) {
              count++;
            }
          })
          if (this.rowData.length === count) {
            this.isRowSelectDisabled = true;
            this.isAllRowsSelected = true;
            this.emitSelectedDLEmployees.emit([]);
          }
        }
      }
    } else if (this.gridInfoObj.gridType === 'signUpAttendeeGrid') {
      if (this.signUpDLAddedAttendees) {
        this.signUpDLAddedAttendees.forEach((rowNode, Index) => {
          let dlAttendeeInstance = Object.assign({}, rowNode);
          dlAttendeeInstance['signUpAttendeeName'] = dlAttendeeInstance['Attendee'];
          dlAttendeeInstance['corporateId'] = dlAttendeeInstance['AttendeeId'];
          dlAttendeeInstance['isCallIn'] = dlAttendeeInstance['Call-In'];
          dlAttendeeInstance['isInviteRequired'] = dlAttendeeInstance['Invite'];
          if (this.commonService.getMeetingType().includes('Company')) {
            dlAttendeeInstance['isInfoPackRequired'] = dlAttendeeInstance['Infopacks'];
          }
          dlAttendeeInstance['isInviteForInfoOnly'] = dlAttendeeInstance['Info Only'];
          dlAttendeeInstance['Remove'] = '';
          delete dlAttendeeInstance['Attendee'];
          delete dlAttendeeInstance['AttendeeId'];
          delete dlAttendeeInstance['Call-In'];
          delete dlAttendeeInstance['Invite'];
          delete dlAttendeeInstance['Infopacks'];
          delete dlAttendeeInstance['Info Only'];
          delete dlAttendeeInstance['selection'];
          this.rowData.push(dlAttendeeInstance);
        });
        this.rowData.forEach((rowNode, Index) => {
          if (rowNode.signUpAttendeeName.length === 0) {
            this.rowData.splice(Index, 1);
          }
        });
        if (this.rowData.filter((row) => row.corporateId === '').length === 0) {
          this.rowData.push({
            'signUpAttendeeName': '',
            'corporateId': '',
            'isCallIn': false,
            'isInviteRequired': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false,
            'Remove': ''
          });
        }
      }
      if (this.gridApi) {
        this.gridApi.setRowData(this.rowData);
        let j = 0;
        this.signUpInfo.meetingId = this.meetingObj.meetingId;
        for (let i = 0; i < this.gridOptions.rowData.length; i++) {
          if ((this.gridOptions.rowData[i].signUpAttendeeName.length !== 0) && ('Remove' in this.gridOptions.rowData[i])) {
            this.signUpInfo.fidelityInvitees[j] = this.gridOptions.rowData[i];
            if (this.signUpInfo.fidelityInvitees[j]['corporateId'] === this.commonService.getLoggedInUserInfo().getCorporateId()) {
              this.signUpRequired = {
                isRequired: true,
                requiredReason: 'userIsMtgCreatorAndAttendee'
              }
              this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
            }
            j++;
          }
        }
        this.commonService.signUpAttendeeListChange(this.signUpInfo);
        this.gridApi.setFocusedCell(this.rowData.length - 1, 'signUpAttendeeName', null);
        this.gridApi.ensureIndexVisible(this.rowData.length - 1 , 'bottom');
        this.gridApi.forEachNode((node) => {
          if (node.rowIndex === (this.rowData.length - 1)) {
            node.setSelected(true);
          }
        });
        if (this.rowData.length >= 14) {
          this.unsetDisplay = false;
          this.attainedMaxHeight = true;
          this.gridApi.setDomLayout('normal');
        }
      }
    } else if (this.gridInfoObj.gridType === 'filAttendeeGrid') {
      if (this.rowData.length > 4) {
        this.unsetDisplay = false;
        if (this.rowData.length >= 20) {
          this.FILAttendeeGridMaxHeight = true;
          this.FILAttendeeAutoHeight = false;
          this.gridApi.setDomLayout('normal');
        } else {
          this.FILAttendeeGridMaxHeight = false;
          this.FILAttendeeAutoHeight = true;
          this.gridApi.setDomLayout('autoHeight')
        }
      }
    } else if (this.gridInfoObj.gridType === 'externalContactSearchGrid') {
      if(this.gridOptions) {
      this.gridOptions.rowSelection = 'multiple';
      this.gridOptions.suppressRowClickSelection = true;
      }
      this.rowData = this.gridInfoObj.rowData;
      this.isAllRowsSelected = false;
      if( this.contactData && this.contactData.length > 0) {
        this.isRowSelectDisabled = false;
        this.rowData = JSON.parse(JSON.stringify(this.contactData));
        this.contactData.forEach((item, index) => {
          this.rowData[index]['Name'] = item['contactTypeObj']['contact']['fullName'] ? item['contactTypeObj']['contact']['fullName'] : '';
          this.rowData[index]['ExternalContactId'] = item['contactTypeObj']['contact']['externalId'] ? item['contactTypeObj']['contact']['externalId'] : '';
          this.rowData[index]['Email'] = item['contactTypeObj']['contact']['email'] ? item['contactTypeObj']['contact']['email'] : '';
          this.rowData[index]['Position'] = item['contactTypeObj']['contact']['position'] ? item['contactTypeObj']['contact']['position']  : ''
          this.rowData[index]['Notes'] = item['contactTypeObj']['contact']['notes'] ? item['contactTypeObj']['contact']['notes'] : '';
          if(item['contactType'] === 'BC') {            
            this.rowData[index]['Company'] = item['contactTypeObj']['brokerFirm'] && item['contactTypeObj']['brokerFirm']['firmName'] ? item['contactTypeObj']['brokerFirm']['firmName'] : '';
          } else {
            this.rowData[index]['Company'] = item['contactTypeObj']['companyName'] ? item['contactTypeObj']['companyName'] : '';
          }
        //  delete this.rowData[index]['contactType'];
        //  delete this.rowData[index]['contactTypeObj'];
        });
        console.log("rowdata pushed", this.rowData)
        this.gridOptions.rowData = this.rowData;
        if (this.rowData.length >= 14) {
          this.unsetDisplay = false;
          this.externalContactMaxHeight = true;
          this.gridApi.setDomLayout('normal');
        } else {
          this.gridApi.setDomLayout('autoHeight');
        }
      } else {        
        this.emitSelectedExternalContact.emit([]);     
        if(this.gridApi) {
        this.gridApi.setDomLayout('autoHeight');
        }
      }  
      
    }
  
    // if (this.currentAction === 'create'
    //   && this.gridInfoObj.gridType === 'holdersGrid'
    //   && (this.selectedSecurity === 'Equity' || this.selectedSecurity === 'Fixed Income')) {
    //   this.resetHoldersGrid();
    // }
    if (this.action === 'create' && this.gridInfoObj.gridType === 'filAttendeeGrid') {
      if (this.selectedSecurity === 'Equity') {
        this.resetColumnDefs('Company');
      } else {
        this.resetColumnDefs('Other');
      }
    }
  }
  ngOnDestroy() {
    this.emitSelectedExternalContact.emit([]);
    if (this.gridType !== 'distributionListGrid') {
      this.businessEntity = '';
      this.commonService.changeHostDetails(null);
      if (this.hostObs) {
        this.hostObs.unsubscribe();
      }
      if (this.analystObs) {
        this.analystObs.unsubscribe();
      }
      if (this.holdersSubscription) {
        this.holdersSubscription.unsubscribe();
      }
      if (this.holdersFilAttendeeSyncSubs) {
        this.holdersFilAttendeeSyncSubs.unsubscribe();
      }
      if (this.removeHolderFilAttendeeSyncSubs) {
        this.removeHolderFilAttendeeSyncSubs.unsubscribe();
      }
      if (this.tradableEntitySubscription) {
        this.tradableEntitySubscription.unsubscribe();
      }
      if (this.addHolderAttendeeSubscription) {
        this.addHolderAttendeeSubscription.unsubscribe();
      }


      if (this.securityAnalystSubscription) {
        this.securityAnalystSubscription.unsubscribe();
      }
      if (this.mtgDetailsSubscription) {
        this.mtgDetailsSubscription.unsubscribe();
      }
      if (this.holdersSubscription) {
        this.holdersSubscription.unsubscribe();
      }
      if (this.signUpForMeSubscription) {
        this.signUpForMeSubscription.unsubscribe();
      }

      if (this.updateMtgDtlsSourceSubsciprtion) {
        this.updateMtgDtlsSourceSubsciprtion.unsubscribe();
      }
      if (this.currentMessageSubscription) {
        this.currentMessageSubscription.unsubscribe();
      }
      if (this.signUpMeetingIdObservableSubs) {
        this.signUpMeetingIdObservableSubs.unsubscribe();
      }
      if (this.defaultCompanyAttendeesObservableSubs) {
        this.defaultCompanyAttendeesObservableSubs.unsubscribe();
      }
      if (this.filAttendeeListSourceObservableSUbs) {
        this.filAttendeeListSourceObservableSUbs.unsubscribe();
      }

      if (this.addDLAttendeeSubscription) {
        this.addDLAttendeeSubscription.unsubscribe();
      }
      this.resetMeetingDetails.unsubscribe();
      this.signUpRequired = {
        isRequired: false,
        requiredReason: 'resetSignUpForMe'
      }
      this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
      if (this.gridInfoObj.gridType !== 'holdersGrid' && this.gridInfoObj.gridType !== 'externalContactSearchGrid' ) {
        this.commonService.searchedSecurityChange('');
      }
      this.commonService.changeHostDetails(null);
    }
  }

  writeValue(value: any): void {
    if (value) {
      this.value = value;
    }
  }
  registerOnChange(fn: Function): void {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onModelTouched = fn;
  }


  onSelectionChanged = (): void => {
    const selectedRows: any[] = this.gridApi.getSelectedRows();
  
    if (this.gridType === 'holdersGrid' || this.gridType === 'distributionListGrid' || this.gridType === 'externalContactSearchGrid') {
      if (selectedRows.length === this.gridApi.getDisplayedRowCount()) {
        selectedRows.forEach((rowNode) => {
          rowNode.selection = true;
        });
        this.rowData.forEach((rowNode) => {
          rowNode.selection = true;
        });
        this.isAllRowsSelected = true;
      } else if (selectedRows.length === 0) {
        this.isAllRowsSelected = false;
        this.rowData.forEach((rowNode) => {
          rowNode.selection = false;
        });
        this.gridOptions.api.setRowData(this.rowData);
        this.gridApi.forEachNode((node) => {
          node.setSelected(false);
        });
      } else {
        if (this.gridType === 'holdersGrid' || this.gridType === 'distributionListGrid' || this.gridType === 'externalContactSearchGrid') {
          this.isAllRowsSelected = false;
          let selectedRowCount = this.selectHoldersPresentInAttendeeList();
          if ((selectedRowCount + this.gridApi.getSelectedRows().length) === this.rowData.length) {
            this.isAllRowsSelected = true;
          }
        }
      }
      if (this.gridType === 'holdersGrid') {
        this.emitSelectedHolders.emit(selectedRows);
      } else if (this.gridType === 'distributionListGrid') {
        
        this.emitSelectedDLEmployees.emit(selectedRows);
      } else if (this.gridType === 'externalContactSearchGrid') {
       
        this.emitSelectedExternalContact.emit(selectedRows);
      }
    }
    if (selectedRows.length === 0) {
      this.value = [];
    } else {
      this.value = Object.assign({}, this.gridOptions.rowData);
    }
    this.touched = true;
    this.onModelChange(this.value);
    this.onModelTouched();
  }

  isHostAlreadyPresentAsAttendeeValidation(hostCorpId) {
    let isHostAddedAsAttendee = false;
    this.rowData.forEach((rowNode, Index) => {
      if (Index > 0) {
        if (rowNode.AttendeeId === hostCorpId) {
          isHostAddedAsAttendee = true;
        }
      }
    });
    return isHostAddedAsAttendee;
  }
  setHostInFilAttendeeGrid(hostName, hostCorpId) {
    this.rowData[0]['Attendee'] = hostName + ' (Host)';
    this.rowData[0]['AttendeeId'] = hostCorpId;
    this.rowData[0]['Call-In'] = false;
    this.rowData[0]['Invite'] = true;
    if (this.meetingType === 'Company') {
      this.rowData[0]['Infopacks'] = false;
    }
    this.rowData[0]['Info Only'] = false;
    this.rowData[0]['Response'] = 'Accepted';
    if(this.gridApi) {
    this.gridApi.setRowData(this.rowData);
    
    this.gridApi.forEachNode((node) => {
      if (node.rowIndex === 0) {
        node.setSelected(true);
      }
    });
    }
    this.commonService.changeFilAttendeeList(this.rowData);
  }
  selectAllRows(event) {
    let selectedRows: any[];
    this.isAllRowsSelected = event.currentTarget.checked;
    if (this.isAllRowsSelected) {
      this.rowData.forEach((rowNode) => {
        rowNode.selection = true;
      });
      if (this.gridType === 'holdersGrid') {
        this.gridOptions.getRowStyle = function (params) {
          return { background: '#eeeff0' };
        };
      }
      console.log("rowdata", this.rowData)
      this.gridOptions.api.setRowData( this.rowData);
      this.gridApi.forEachNode((node) => {
        node.setSelected(true);
      });
      selectedRows = this.gridApi.getSelectedRows();
      console.log("grip adpi sleected rows", selectedRows)
      selectedRows.forEach((rowNode) => {
        rowNode.selection = true;
      });
    } else {
      this.rowData.forEach((rowNode) => {
        rowNode.selection = false;
      });
      if (this.gridType === 'holdersGrid') {
        let selectedNodes = this.gridApi.getSelectedNodes();
        this.gridOptions.getRowStyle = function (params) {
          let isSelected = false;
          selectedNodes.every((node) => {
            if (params.data.AttendeeId === node.data.AttendeeId) {
              isSelected = true;
            }
            if (isSelected) {
              return false;
            } else {
              return true;
            }
          });
          if (isSelected) {
            return { background: '#fff' };
          } else {
            return { background: '#eeeff0' }
          }
        };
      }
      this.gridOptions.api.setRowData(this.rowData);

      this.gridApi.forEachNode((node) => {
        node.setSelected(false);
      });
      selectedRows = this.gridApi.getSelectedRows();

      selectedRows.forEach((rowNode) => {
        rowNode.selection = false;
      });
    }
    if (this.gridType === 'holdersGrid') {
      this.emitSelectedHolders.emit(selectedRows);
    } else if (this.gridType === 'distributionListGrid') {
      console.log('all rows', selectedRows)
      this.emitSelectedDLEmployees.emit(selectedRows);
    } else if (this.gridType === 'externalContactSearchGrid') {
      console.log('all rows', selectedRows)
      this.emitSelectedExternalContact.emit(selectedRows);
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    if (this.gridType === 'signUpAttendeeGrid') {
      const localData = [];
      this.gridApi.setDomLayout('autoHeight');
      params.api.hideOverlay();
      this.commonService.signUpAttendeeListChange(this.signUpInfo);
    }
    else if (this.gridType === 'holdersGrid' || this.gridType === 'distributionListGrid' || this.gridType === 'externalContactSearchGrid') {
      this.gridApi.setDomLayout('autoHeight');
      
    } else if (this.gridType === 'filAttendeeGrid') {
      if (this.gridApi.getDisplayedRowCount() > 4) {
        this.unsetDisplay = false;
        if (this.gridApi.getDisplayedRowCount() >= 20) {
          this.FILAttendeeGridMaxHeight = true;
          this.FILAttendeeAutoHeight = false;
          this.gridApi.setDomLayout('normal');
        } else {
          this.FILAttendeeGridMaxHeight = false;
          this.FILAttendeeAutoHeight = true;
          this.gridApi.setDomLayout('autoHeight')
        }
      }
    }
  }

  validateAlreadyPresentAttendee() {
    this.filAttendeeListSourceObservableSUbs = this.commonService.filAttendeeListSourceObservable.subscribe((filAttendeesList: any) => {
      if (filAttendeesList.length !== 0) {
        this.isRowSelectable = function (node) {
          let isSelected = true;
          filAttendeesList.forEach((filAttendeesList) => {
            if (filAttendeesList.AttendeeId) {
              if (node.data.AttendeeId === filAttendeesList.AttendeeId) {
                isSelected = false;
              }
            } else if (filAttendeesList.corporateId) {
              if (node.data.AttendeeId === filAttendeesList.corporateId) {
                isSelected = false;
              }
            }

          });
          return isSelected;
        };
        this.rowData.forEach((personRowNode) => {
          filAttendeesList.forEach((filAttendeesList) => {
            if (filAttendeesList.AttendeeId) {
              if (personRowNode.AttendeeId === filAttendeesList.AttendeeId) {
                personRowNode.selection = true;
              }
            } else if (filAttendeesList.corporateId) {
              if (personRowNode.AttendeeId === filAttendeesList.corporateId) {
                personRowNode.selection = true;
              }
            }

          });
        });
        this.gridOptions.getRowStyle = function (params) {
          let isSelected = true;
          filAttendeesList.forEach((personRowNode) => {
            if (personRowNode.AttendeeId) {
              if (params.data.AttendeeId === personRowNode.AttendeeId) {
                isSelected = false;
              }
            } else if (personRowNode.corporateId) {
              if (params.data.AttendeeId === personRowNode.corporateId) {
                isSelected = false;
              }
            }

          });
          if (!isSelected) {
            return {
              background: '#eeeff0'
            };
          }
        };
        this.filAttendeeListForHoldersOrDLs = filAttendeesList;
      }
    });
  }
  selectHoldersPresentInAttendeeList() {
    let selectedRowCount = 0;
    this.filAttendeeListSourceObservableSUbs = this.commonService.filAttendeeListSourceObservable.subscribe((filAttendeesList) => {
      if (filAttendeesList.length !== 0) {
        this.rowData.forEach((holdersRowNode) => {
          filAttendeesList.forEach((filAttendeesList) => {
            if (holdersRowNode.AttendeeId === filAttendeesList.AttendeeId) {
              holdersRowNode.selection = true;
              selectedRowCount++;
            }
          });
        });
      }
    });
    return selectedRowCount;
  }

  resetFidelityAttendeesGrid() {
    this.rowData = [{
      'Attendee': '',
      'AttendeeId': '',
      'Response': '',
      'Call-In': false,
      'Invite': false,
      'Infopacks': false,
      'Info Only': false,
      'Remove': ''
    }];
    for (let i = 0; i < 3; i++) {
      this.rowData.push({
        'Attendee': '',
        'AttendeeId': '',
        'Response': '',
        'Call-In': false,
        'Invite': false,
        'Infopacks': false,
        'Info Only': false,
        'Remove': ''
      });
    }
    this.FILAttendeeGridMaxHeight = false;
    this.FILAttendeeAutoHeight = false;
    // this.rowData = [{
    //   'Attendee': '',
    //   'AttendeeId': '',
    //   'Response': '',
    //   'Call-In': false,
    //   'Invite': false,
    //   'Infopacks': false,
    //   'Info Only': false,
    //   'Remove': ''
    // },
    // {
    //   'Attendee': '',
    //   'AttendeeId': '',
    //   'Response': '',
    //   'Call-In': false,
    //   'Invite': false,
    //   'Infopacks': false,
    //   'Info Only': false,
    //   'Remove': ''
    // },
    // {
    //   'Attendee': '',
    //   'AttendeeId': '',
    //   'Response': '',
    //   'Call-In': false,
    //   'Invite': false,
    //   'Infopacks': false,
    //   'Info Only': false,
    //   'Remove': ''
    // },
    // {
    //   'Attendee': '',
    //   'AttendeeId': '',
    //   'Response': '',
    //   'Call-In': false,
    //   'Invite': false,
    //   'Infopacks': false,
    //   'Info Only': false,
    //   'Remove': ''
    // }];
    if (this.gridApi) {
      if (this.meetingType === 'Other' || this.meetingType === 'Broker') {
        this.rowData.splice(5, 1);
      }
      this.gridApi.setRowData(this.rowData);
    }
  }

  resetColumnDefs(meetingType) {
    // this.columnDefs = [];
    this.columnDefs = [{
      headerName: 'FIL Invitees',
      field: 'Attendee',
      width: 338,
      cellEditorFramework: ConfigInviteesDtlsComponent,
      editable: true,
      suppressSizeToFit: true,
      singleClickEdit: true,
      cellStyle: { 'border-right': '1px solid #dadada' }
    },
    {
      headerName: 'Call-In',
      field: 'Call-In',
      // width: 269,
      headerClass: 'mv2-headerCenterAlign',
      cellRendererFramework: ConfigCheckboxComponent,
      cellStyle: { 'border-right': '1px solid #dadada' }
    },
    {
      headerName: 'Invite',
      field: 'Invite',
      // width: 269,
      headerClass: 'mv2-headerCenterAlign',
      cellRendererFramework: ConfigCheckboxComponent,
      cellStyle: { 'border-right': '1px solid #dadada' }
    },
    {
      headerName: 'Infopacks',
      field: 'Infopacks',
      // width: 269,
      headerClass: 'mv2-headerCenterAlign',
      cellRendererFramework: ConfigCheckboxComponent,
      cellStyle: { 'border-right': '1px solid #dadada' }
    },
    {
      headerName: 'Info Only',
      field: 'Info Only',
      // width: 269,
      headerClass: 'mv2-headerCenterAlign',
      cellRendererFramework: ConfigCheckboxComponent,
      cellStyle: { 'border-right': '1px solid #dadada' }
    },
    {
      headerName: 'Action',
      field: 'Remove',
      // width: 269,
      headerClass: 'mv2-headerCenterAlign',
      // pinned: 'right',
      cellRendererFramework: ConfigDeleteComponent,
      cellStyle: { 'text-align': 'center' }
    }];

    this.columnDefs.forEach((rowNode, Index) => {
      if (Index === 0) {
        rowNode.editable = this.isGridEditable;
        rowNode.cellStyle = { 'border-right': '1px solid #dadada' };
      }
      rowNode['suppressKeyboardEvent'] = this.suppressEnterAndSpace;
    });

    if (meetingType === 'Company' && this.gridOptions && this.gridOptions.api) {
      this.gridOptions.api.setColumnDefs(this.columnDefs);
      this.gridApi.sizeColumnsToFit();
    } else if ((meetingType === 'Other' || meetingType === 'Broker') && this.gridOptions && this.gridOptions.api) {
      this.columnDefs.splice(3, 1);
      this.gridOptions.api.setColumnDefs(this.columnDefs);
      this.gridOptions.api.sizeColumnsToFit();
    }
    this.commonService.hostAddedAsAttendeeSubject.next(false);
  }

  addAttendeesToFidelityAttendeeGrid(observableName) {
    return this.commonService[observableName].subscribe((personList) => {
      if (personList.length !== 0) {
        let isAlreadyExists = false;
        // this.rowData.forEach((rowNode, Index) => {
        //   if (rowNode.Attendee.length === 0) {
        //     this.rowData.pop();
        //   }
        // });
        for (let i = (this.rowData.length - 1); i > 0; i--) {
          if (this.rowData[i].Attendee.length === 0) {
            this.rowData.pop();
          }
        }
        if (this.rowData[this.rowData.length - 1].Attendee.length === 0 && this.rowData.length > 1) {
          this.rowData.pop();
        }
        personList.forEach((personRowNode, Index) => {
          isAlreadyExists = false;
          this.rowData.forEach((rowDataRowNode, Index) => {
            if (personRowNode.AttendeeId.toUpperCase() === rowDataRowNode.AttendeeId.toUpperCase()) {
              isAlreadyExists = true;
            }
          });
          if (!isAlreadyExists) {
            this.rowData.push(personRowNode);
          }
        });
        if (this.rowData[this.rowData.length - 1]['Attendee'] !== '') {
          do {
            let rowDataElement = {};
            if (this.meetingType === 'Company') {
              rowDataElement = {
                'Attendee': '',
                'AttendeeId': '',
                'Response': '',
                'Call-In': false,
                'Invite': false,
                'Infopacks': false,
                'Info Only': false,
              }
            } else {
              rowDataElement = {
                'Attendee': '',
                'AttendeeId': '',
                'Response': '',
                'Call-In': false,
                'Invite': false,
                'Info Only': false,
              }
            }
            this.rowData.push(rowDataElement);
          } while (this.rowData.length < 4)
        }
        if (this.gridApi) {
          this.gridApi.setRowData(this.rowData);
          this.gridApi.forEachNode((node) => {
            if (node.rowIndex === 0) {
              node.setSelected(true);
            }
          });
          if (this.gridApi.getDisplayedRowCount() > 4) {
            this.unsetDisplay = false;
            if (this.gridApi.getDisplayedRowCount() >= 20) {
              this.FILAttendeeGridMaxHeight = true;
              this.FILAttendeeAutoHeight = false;
              this.gridApi.setDomLayout('normal');
            } else {
              this.FILAttendeeGridMaxHeight = false;
              this.FILAttendeeAutoHeight = true;
              this.gridApi.setDomLayout('autoHeight')
            }
          }
          this.commonService.changeFilAttendeeList(this.rowData);
        }
      }
    });
  }

  rowClicked(params, addedAttendee: string, attendeeId: string, selectedExternalContact: any) {
    let displayName: string;
    let mtgAttendeeAdded = true;
    if (this.gridType === 'filAttendeeGrid') {
      displayName = 'Attendee';
      this.gridOptions.rowData[params.node.rowIndex]['AttendeeId'] = attendeeId;
    } else if (this.gridType === 'signUpAttendeeGrid') {
      displayName = 'signUpAttendeeName';
      this.gridOptions.rowData[params.node.rowIndex]['corporateId'] = attendeeId;
    } else if (this.gridType === 'thirdPartyAttendeeGrid') {
      displayName = 'ExternalContactName';
      (selectedExternalContact.externalId === null || selectedExternalContact.externalId === undefined)
        ? selectedExternalContact.externalId = ''
        : this.gridOptions.rowData[params.node.rowIndex].ExternalContactId = selectedExternalContact.externalId;

      (selectedExternalContact.emailId === null || selectedExternalContact.emailId === undefined)
        ? selectedExternalContact.emailId = ''
        : this.gridOptions.rowData[params.node.rowIndex].Email = selectedExternalContact.emailId;

      (selectedExternalContact.position === null || selectedExternalContact.position === undefined)
        ? selectedExternalContact.position = ''
        : this.gridOptions.rowData[params.node.rowIndex].Position = selectedExternalContact.position;

      (selectedExternalContact.notes === null || selectedExternalContact.notes === undefined)
        ? selectedExternalContact.notes = ''
        : this.gridOptions.rowData[params.node.rowIndex].Notes = selectedExternalContact.notes;

      (selectedExternalContact.company === null || selectedExternalContact.company === undefined)
        ? selectedExternalContact.company = ''
        : this.gridOptions.rowData[params.node.rowIndex].Company = convertToTitleCase(selectedExternalContact.company);
      // this.gridOptions.rowData[params.node.rowIndex].Company = this.mtgSecurityName;
    }
    this.gridOptions.rowData[params.node.rowIndex][displayName] = addedAttendee;
    if ((this.gridType === 'filAttendeeGrid' || this.gridType === 'signUpAttendeeGrid')) {
      if ('Invite' in params.data) {
        this.gridOptions.rowData[params.node.rowIndex]['Invite'] = true;
      } else if ('isInviteRequired' in params.data) {
        this.gridOptions.rowData[params.node.rowIndex]['isInviteRequired'] = true;
      }
    }
    // if(this.gridType === 'filAttendeeGrid'){
    //   console.log('params.node.data: ', params.node.data);
    //   let removedAttendee = Object.assign([],  this.gridOptions.rowData);
    //   removedAttendee.forEach((removeAttend)=>{
    //     if(removeAttend.hasOwnProperty('holderRank')
    //     && removeAttend.hasOwnProperty('selection')) {
    //       delete removeAttend.holderRank;
    //       delete removeAttend.selection;
    //     }
    //   });
    //   this.gridOptions.rowData = removedAttendee;
    //   this.rowData = removedAttendee;
    // }
    this.gridOptions.rowData.forEach(rowNode => {
      if (rowNode[displayName].length === 0) {
        mtgAttendeeAdded = false;
      }
    });
    params.node.setSelected(true);
    if (mtgAttendeeAdded === true) {
      this.addRow();
    }
    this.rowData = this.gridOptions.rowData;
    if (this.gridType === 'filAttendeeGrid') {
      this.commonService.changeFilAttendeeList(this.rowData);
    }
    if (this.gridType === 'signUpAttendeeGrid') {
      let j = 0;
      this.signUpInfo.meetingId = this.meetingObj.meetingId;
      for (let i = 0; i < this.gridOptions.rowData.length; i++) {
        if ((this.gridOptions.rowData[i].signUpAttendeeName.length !== 0) && ('Remove' in this.gridOptions.rowData[i])) {
          this.signUpInfo.fidelityInvitees[j] = this.gridOptions.rowData[i];
          if (this.signUpInfo.fidelityInvitees[j]['corporateId'] === this.commonService.getLoggedInUserInfo().getCorporateId()) {
            this.signUpRequired = {
              isRequired: true,
              requiredReason: 'userIsMtgCreatorAndAttendee'
            }
            this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
          }
          j++;
        }
      }
      this.commonService.signUpAttendeeListChange(this.signUpInfo);
    }
    if (this.gridType === 'filAttendeeGrid' && this.meetingState === 'CONFIRMED' && params.node.rowIndex === 0) {
      this.addResponse(params, 'Accepted');
    }
    this.typeaheadTabKeyPress(params);
  }

  addResponse(params, responseData) {
    this.gridOptions.rowData[params.node.rowIndex].Response = responseData;
    this.rowData[params.node.rowIndex].Response = responseData;
    this.typeaheadTabKeyPress(params);
  }

  private addRow() {
    const newItem = this.createNewRowData();
    this.gridApi.updateRowData({ add: [newItem] });
    this.gridApi.ensureIndexVisible(this.gridOptions.rowData.length, 'bottom');
    this.gridOptions.rowData.push(newItem);
    if (this.gridType === 'signUpAttendeeGrid') {
      if (this.gridApi.getDisplayedRowCount() >= 14) {
        this.unsetDisplay = false;
        this.attainedMaxHeight = true;
        this.gridApi.setDomLayout('normal');
      }
    } else if (this.gridType === 'filAttendeeGrid') {
      if (this.gridApi.getDisplayedRowCount() > 4) {
        this.unsetDisplay = false;
        if (this.gridApi.getDisplayedRowCount() >= 20) {
          this.FILAttendeeGridMaxHeight = true;
          this.FILAttendeeAutoHeight = false;
          this.gridApi.setDomLayout('normal');
        } else {
          this.FILAttendeeGridMaxHeight = false;
          this.FILAttendeeAutoHeight = true;
          this.gridApi.setDomLayout('autoHeight')
        }
      }
    }
  }

  private createNewRowData() {
    let newData = {};
    if (this.gridType === 'filAttendeeGrid') {
      if (this.meetingType === 'Company') {
        newData = {
          'Attendee': '',
          'AttendeeId': '',
          'Response': '',
          'Call-In': false,
          'Invite': false,
          'Infopacks': false,
          'Info Only': false,
        };
      } else {
        newData = {
          'Attendee': '',
          'AttendeeId': '',
          'Response': '',
          'Call-In': false,
          'Invite': false,
          'Info Only': false,
        };
      }
    } else if (this.gridType === 'signUpAttendeeGrid') {
      if (this.meetingType === 'Company') {
        newData = {
          'signUpAttendeeName': '',
          'corporateId': '',
          'isCallIn': false,
          'isInviteRequired': false,
          'isInfoPackRequired': false,
          'isInviteForInfoOnly': false,
          'Remove': ''
        };
      } else {
        newData = {
          'signUpAttendeeName': '',
          'corporateId': '',
          'isCallIn': false,
          'isInviteRequired': false,
          'isInviteForInfoOnly': false,
          'Remove': ''
        };
      }
    } else if (this.gridType === 'thirdPartyAttendeeGrid') {
      newData = {
        'ExternalContactName': '',
        'ExternalContactId': '',
        'Company': '',
        'Email': '',
        'Position': '',
        'Notes': '',
        'Remove': ''
      };
    }
    this.newCount++;
    return newData;
  }

  onRemoveClicked(rowIndex) {
    this.rowData = this.gridOptions.rowData;
    const removedAttendeeInstance = this.rowData[rowIndex];
    this.commonService.removedAttendeeSubject.next(removedAttendeeInstance);
    // if (removedAttendeeInstance.hasOwnProperty('holderRank')) {}
    if (rowIndex !== -1) {
      if (this.gridType === 'signUpAttendeeGrid') {
        this.signUpInfo.fidelityInvitees.forEach((element, index) => {
          if (element['corporateId'] === this.rowData[rowIndex]['corporateId']) {
            if (element['corporateId'] === this.commonService.getLoggedInUserInfo().getCorporateId()) {
              this.signUpRequired = {
                isRequired: false,
                requiredReason: 'userWasMtgCreatorAndAttendee'
              }
              this.commonService.disableSignupForMeSubject.next(this.signUpRequired);
            }
            this.signUpInfo.fidelityInvitees.splice(index, 1);
          }
        });
      }
      this.rowData.splice(rowIndex, 1);
    }
    this.commonService.signUpAttendeeListChange(this.signUpInfo);
    if (this.gridType === 'signUpAttendeeGrid') {
      if (this.gridApi.getDisplayedRowCount() < 14) {
        this.unsetDisplay = true;
        this.attainedMaxHeight = false;
        this.gridApi.setDomLayout('autoHeight');
      }
    } else if (this.gridType === 'thirdPartyAttendeeGrid') {

      if (this.rowData.length < 3) {
        let newData = {
          'ExternalContactName': '',
          'ExternalContactId': '',
          'Company': '',
          'Email': '',
          'Position': '',
          'Notes': '',
          'Remove': ''
        };
        this.rowData.push(newData);
      }
    } else if (this.gridType === 'filAttendeeGrid') {
      if (this.rowData.length < 4) {
        let rowDataElement = {};
        if (this.meetingType === 'Company') {
          rowDataElement = {
            'Attendee': '',
            'AttendeeId': '',
            'Response': '',
            'Call-In': false,
            'Invite': false,
            'Infopacks': false,
            'Info Only': false,
          }
        } else {
          rowDataElement = {
            'Attendee': '',
            'AttendeeId': '',
            'Response': '',
            'Call-In': false,
            'Invite': false,
            'Info Only': false,
          }
        }
        this.rowData.push(rowDataElement);
      }
      if (this.gridApi.getDisplayedRowCount() > 4) {
        this.unsetDisplay = false;
        if (this.gridApi.getDisplayedRowCount() >= 20) {
          this.FILAttendeeGridMaxHeight = true;
          this.FILAttendeeAutoHeight = false;
          this.gridApi.setDomLayout('normal');
        } else {
          this.FILAttendeeGridMaxHeight = false;
          this.FILAttendeeAutoHeight = true;
          this.gridApi.setDomLayout('autoHeight')
        }
      }
      this.emitSelectedHolders.emit(this.rowData);
      this.emitSelectedDLEmployees.emit(this.rowData);
    }
    this.value = Object.assign({}, this.gridOptions.rowData);
    this.onModelChange(this.value);
    this.onModelTouched();
    if (this.gridType !== 'thirdPartyAttendeeGrid') {
      this.commonService.changeFilAttendeeList(this.rowData);
    }
    // this.gridApi.setRowData(this.rowData);
    this.refreshGrid();
  }

  bodyScroll(event) {
    this.gridOptions.api.stopEditing(true);
  }

  typeaheadTabKeyPress(params) {
    if (this.gridType === 'filAttendeeGrid') {
      if (this.meetingState === 'CONFIRMED') {

        params.api.setFocusedCell(params.rowIndex, 'Response', null);
      } else {
        params.api.setFocusedCell(params.rowIndex, 'Call-In', null);
      }
    } else if (this.gridType === 'signUpAttendeeGrid') {
      params.api.setFocusedCell(params.rowIndex, 'isCallIn', null);
    } else if (this.gridType === 'thirdPartyAttendeeGrid') {
      params.api.setFocusedCell(params.rowIndex, 'Email', null);
    }
  }
  private isGridEditable(params) {
    if ('Remove' in params.data || 'Attendee' in params.data || 'ExternalContactName' in params.data) {
      if (params.node.rowIndex === 0 && 'Attendee' in params.data) {
        return false;
      } else if ('Attendee' in params.data && params.colDef.headerName === '') {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  keyDown(params) {
    let displayName: string;
    const selectedRows = this.gridApi.getFocusedCell();
    const currentColumnId = selectedRows.column.getColId();
    const currentRowIndex = selectedRows.rowIndex;
    if (this.gridType === 'filAttendeeGrid') {
      displayName = 'Attendee';
    } else if (this.gridType === 'signUpAttendeeGrid') {
      displayName = 'signUpAttendeeName';
    } else if (this.gridType === 'thirdPartyAttendeeGrid') {
      displayName = 'ExternalContactName';
    }
    if ((this.gridOptions.rowData[currentRowIndex][displayName] !== '')
      && ((displayName === 'Attendee')
        || (displayName === 'ExternalContactName')
        || ((displayName === 'signUpAttendeeName') && ('Remove' in this.gridOptions.rowData[currentRowIndex])))) {
      if ((currentColumnId !== displayName) && (params.key === 'Enter' || params.key === 'F2')) {
        if (currentColumnId === 'Remove') {
          if (currentRowIndex !== 0 && (displayName === 'Attendee' || displayName === 'signUpAttendeeName')) {
            this.onRemoveClicked(currentRowIndex);
          } else if (displayName === 'ExternalContactName') {
            this.onRemoveClicked(currentRowIndex);
          }
        } else {
          const rowNode = this.gridApi.getDisplayedRowAtIndex(currentRowIndex);
          const data = { columns: [currentColumnId], rowNodes: [rowNode] };
          const instances = this.gridApi.getCellRendererInstances(data);
          instances.forEach((instance) => {
            if (instance._agAwareComponent.params.value) {
              instance._agAwareComponent.params.value = false;
              this.gridOptions.rowData[currentRowIndex][currentColumnId] = false;
            } else {
              instance._agAwareComponent.params.value = true;
              this.gridOptions.rowData[currentRowIndex][currentColumnId] = true;
            }
          });
        }
      }
    }
  }

  private suppressEnterAndSpace(params) {
    const KEY_ENTER = 13;
    const KEY_SPACE = 32;
    const event = params.event;
    const key = event.which;
    const suppress = (key === KEY_ENTER || key === KEY_SPACE)
    return suppress;
  }
  private refreshGrid() {
    this.rowData.forEach((rowNode, index) => {
      rowNode.index = index + 1;
    });
    this.gridOptions.api.setRowData(this.rowData);
  }

  resetMeetingDetailValues() {
    if (this.gridType === 'holdersGrid' && this.gridApi) {
      this.resetHoldersGrid();
    } else {
      if (this.gridInfoObj.gridType === 'thirdPartyAttendeeGrid') {
        const resetRowData = [
          {
            'ExternalContactName': '',
            'ExternalContactId': '',
            'Company': '',
            'Email': '',
            'Position': '',
            'Notes': '',
            'Remove': ''
          },
          {
            'ExternalContactName': '',
            'ExternalContactId': '',
            'Company': '',
            'Email': '',
            'Position': '',
            'Notes': '',
            'Remove': ''
          },
          {
            'ExternalContactName': '',
            'ExternalContactId': '',
            'Company': '',
            'Email': '',
            'Position': '',
            'Notes': '',
            'Remove': ''
          }
        ];
        this.rowData = resetRowData;
      } else if (this.gridInfoObj.gridType === 'filAttendeeGrid') {
        let resetRowData = [{
          'Attendee': '',
          'AttendeeId': '',
          'Response': '',
          'Call-In': false,
          'Invite': false,
          'Infopacks': false,
          'Info Only': false
        }];
        for (let i = 0; i < 3; i++) {
          resetRowData.push({
            'Attendee': '',
            'AttendeeId': '',
            'Response': '',
            'Call-In': false,
            'Invite': false,
            'Infopacks': false,
            'Info Only': false,
          });
        }
        this.FILAttendeeGridMaxHeight = false;
        this.FILAttendeeAutoHeight = false;
        if (this.meetingType !== 'Company') {
          resetRowData.forEach((rowNode) => {
            delete rowNode.Infopacks;
          });
        }
        this.rowData = resetRowData;
        if (this.gridInfoObj.columnDefs[1]['headerName'] === 'Response') {
          this.gridInfoObj.columnDefs.splice(1, 1);
          this.gridOptions.api.setColumnDefs(this.gridInfoObj.columnDefs)
          this.gridApi.sizeColumnsToFit();
        }
        if (this.gridApi) {
          this.gridApi.setRowData(this.rowData);
        }
        this.commonService.searchedSecurityChange('');
      }
      if (this.pastMeeting) {
        this.columnDefs.forEach((rowNode, Index) => {
          rowNode.editable = true;
          rowNode.cellStyle = { 'border-right': 'solid 1px #dadada!important', 'background': 'none !important' };
          if (Index === 0) {
            if (rowNode.field === 'Attendee' && this.gridType === 'filAttendeeGrid') {
              // rowNode.editable = false;
              // rowNode.cellStyle = { 'border-right': '1px solid #dadada', 'background': '#dcdee1!important', 'color': '#016fad!important' };;
              rowNode.cellStyle = { 'border-right': '1px solid #dadada' };
            }
          }
        });
        this.pastMeeting = false;
        this.gridOptions.api.setColumnDefs(this.columnDefs)
      }

    }
  }

  checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
    const format = 'DD/MM/YYYY';
    const val = moment(date, format, true);
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const meetingDate = val.toDate();
    const todayDate: Date = new Date();
    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
    if (differenceDays > 365 || meetingState === 'CANCELLED') {
      this.gridOptions.suppressCellSelection = true,
        this.columnDefs.forEach((rowNode, Index) => {
          rowNode.editable = false;
          rowNode.cellStyle = { 'border-right': 'solid 1px #dadada!important', 'background': '#eeeff0 !important' };
        });
      this.pastMeeting = true;
    }
  }

  resetHoldersGrid() {
    const resetColumnDefs = [
      {
        headerName: '',
        field: 'selection',
        cellRendererFramework: ConfigRowSelectionComponent,
        width: 50,
        sortable: true,
        cellStyle: { 'border-right': '1px solid #dadada' }
      },
      {
        headerName: 'Rank',
        field: 'holderRank',
        width: 80,
        sort: 'asc',
        sortingOrder: ['desc', 'asc'],
        sortable: true,
        cellStyle: { 'border-right': '1px solid #dadada', 'text-align': 'center' }
      },
      {
        headerName: 'Name',
        field: 'Attendee',
        width: 190,
        sortable: true,
        sortingOrder: ['desc', 'asc'],
        cellStyle: { 'border-right': '1px solid #dadada' }
      },
      {
        headerName: 'Call-In',
        field: 'Call-In',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'border-right': '1px solid #dadada' }
      },
      {
        headerName: 'Invite',
        field: 'Invite',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'border-right': '1px solid #dadada' }
      },
      {
        headerName: 'Infopacks',
        field: 'Infopacks',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'border-right': '1px solid #dadada' }
      },
      {
        headerName: 'Info Only',
        field: 'Info Only',
        cellRendererFramework: ConfigCheckboxComponent,
        cellStyle: { 'border-right': '1px solid #dadada' }
      }];
    const resetRowData = [];
    if (this.selectedSecurity === 'Fixed Income') {
      resetColumnDefs.splice(1, 1);
      resetColumnDefs.splice(4, 1);
    }
    this.columnDefs = resetColumnDefs;
    this.gridOptions.api.setColumnDefs(this.columnDefs);
    this.gridApi.setRowData([]);
    this.gridApi.sizeColumnsToFit();
    this.isRowSelectDisabled = true;
    this.unsetDisplay = false;
    this.holdersMaxHeight = false;
    this.gridApi.setDomLayout('autoHeight');
    this.gridOptions.localeText = { noRowsToShow: this.noRowShowStyling() };
  }
  resetColumnDefDependingUponMeetingType(event) {
    if (event[0] instanceof NavigationEnd) {
      this.previousUrl = event[0]['urlAfterRedirects'];
      console.log('this.previousUrl: ', this.previousUrl);
    }
    if (event[1] instanceof NavigationEnd) {
      this.currentUrl = event[1]['urlAfterRedirects'];
      console.log('this.currentUrl: ', this.currentUrl);
    }
    if (this.previousUrl.includes('meetingType=Company') && this.currentUrl.includes('meetingType=Other')) {
      this.resetColumnDefs('Other');
    } else if (this.previousUrl.includes('meetingType=Other') && this.currentUrl.includes('meetingType=Company')) {
      this.resetColumnDefs('Company');
    } else if (this.previousUrl.includes('meetingType=Company') && this.currentUrl.includes('meetingType=Broker')) {
      this.resetColumnDefs('Broker');
    } else if (this.previousUrl.includes('meetingType=Broker') && this.currentUrl.includes('meetingType=Company')) {
      this.resetColumnDefs('Company');
    } else if (this.previousUrl.includes('meetingType=Other') && this.currentUrl.includes('meetingType=Broker')) {
      this.resetColumnDefs('Broker');
    } else if (this.previousUrl.includes('meetingType=Broker') && this.currentUrl.includes('meetingType=Other')) {
      this.resetColumnDefs('Other');
    } else if (this.previousUrl === '' && this.currentUrl.includes('meetingType=Broker')) {
      this.resetColumnDefs('Broker');
    } else if (this.previousUrl === '' && this.currentUrl.includes('meetingType=Other')) {
      this.resetColumnDefs('Other');
    } else if (this.previousUrl === '' && this.currentUrl.includes('meetingType=Company')) {
      this.resetColumnDefs('Company');
    }
  }

  getMeetngDateInLocalTime(meetingData): Object {
    const splitMeetingTimeInGMT = (meetingData.meetingTimeInGMT) ? meetingData.meetingTimeInGMT.match(/.{1,2}/g) : '';
    // time conversion into user's Region
    let dateArrray = moment(meetingData.meetingDate).format('YYYY-MM-DD');
    let gmtTime = momentTimezone.tz((dateArrray + ' ' + splitMeetingTimeInGMT[0] + ':' + splitMeetingTimeInGMT[1]), "Europe/London");
    let localTime = gmtTime.clone().tz(this.commonService.getLoggedInUserInfo().getUserTimezone()).format();
    return {
      'date': moment(localTime.substring(0, 10)).format('DD MMM YYYY'),
      'time': localTime.substring(11, 13) + ':' + localTime.substring(14, 16)
    }
  }

  noRowShowStyling() {
    return `<span style="color: #747c89;font-size: 15px;">No holders to show</span>`;
  }

  noRowShowStylingForDL() {
    return `<span style="color: #747c89;font-size: 15px;">No Distribution List members to show</span>`;
  }


addThirdPartyAttendeeToGrid(observableName) {
    return this.commonService[observableName].subscribe((personList) => {
      if (personList.length !== 0) {
        console.log("personlist", personList)
        let isAlreadyExists = false;
        // this.rowData.forEach((rowNode, Index) => {
        //   if (rowNode.Attendee.length === 0) {
        //     this.rowData.pop();
        //   }
        // });
        for (let i = (this.rowData.length - 1); i >= 0; i--) {
          if (this.rowData[i].ExternalContactId.length === 0) {
            this.rowData.pop();
          }
        }
        if (this.rowData[this.rowData.length - 1] && this.rowData[this.rowData.length - 1].ExternalContactId.length === 0 && this.rowData.length > 1) {
          this.rowData.pop();
        }
        console.log("existing contacts", this.rowData)
        personList.forEach((personRowNode, Index) => {
          isAlreadyExists = false;
          this.rowData.forEach((rowDataRowNode, Index) => {
            if (personRowNode.ExternalContactId === rowDataRowNode.ExternalContactId) {
              isAlreadyExists = true;
            }
          });
          if (!isAlreadyExists) {
            let contact = {};
            contact['ExternalContactName'] = personRowNode['Name'];
            contact['ExternalContactId'] = personRowNode['ExternalContactId'];
            contact['Company'] = convertToTitleCase(personRowNode['Company']);
            contact['Email'] = personRowNode['Email'];
            contact['Position'] = personRowNode['Position'];
            contact['Notes'] = personRowNode['Notes'];
            contact['Remove'] = "";
            this.rowData.push(contact);
          }
        });
        if (this.rowData[this.rowData.length - 1]['ExternalContactId'] !== '') {
          do {
            let rowDataElement =  {
            'ExternalContactName': '',
            'ExternalContactId': '',
            'Company': '',
            'Email': '',
            'Position': '',
            'Notes': '',
            'Remove': ''
          };          
            this.rowData.push(rowDataElement);
          } while (this.rowData.length < 3)
        }
        if (this.gridApi) {
          this.gridApi.setRowData(this.rowData);
          this.gridApi.forEachNode((node) => {
            if (node.rowIndex === 0) {
              node.setSelected(true);
            }
          });
          if (this.rowData.length > 3) {
          this.gridApi.ensureIndexVisible(this.rowData.length - 1 , 'bottom');
          }
          // if (this.gridApi.getDisplayedRowCount() > 4) {
          //     this.unsetDisplay = false;            
          //     this.FILAttendeeGridMaxHeight = true;
          //     this.FILAttendeeAutoHeight = false;
          //     this.gridApi.setDomLayout('normal');
            
          // }
          }
      }
    });
  }
  
    createNewContact() {
      this.createContactEmit.emit(true);
    }

    onEditClicked(rowIndex) {
      let selectedRow = this.rowData[rowIndex];
      console.log(this.contactData)
      let selectedContact = this.contactData.filter((item) => {return item['contactTypeObj']['contact']['externalId'] === selectedRow['ExternalContactId']});
      this.editContactEmit.emit(selectedContact);
    }



}
