import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonGridComponent } from './common-grid.component';
import { ConfigInviteesDtlsComponent } from 'src/app/shared/components/config-invitees-dtls/config-invitees-dtls.component';
import { ConfigDeleteComponent } from 'src/app/shared/components/config-delete/config-delete.component';
import { HttpClientModule } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonService } from 'src/app/core/http/common.service';
import { of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { UserDetail } from 'src/app/shared/models/userDetail.model';

@NgModule({
  entryComponents: [
    ConfigDeleteComponent,
  ] 
})
class TestModule { }

describe('CommonGridComponent', () => {
  let component: CommonGridComponent;
  let fixture: ComponentFixture<CommonGridComponent>;
  const columnDefs = [
    {
      headerName: 'Attendee',
      field: 'Attendee',
    },
    {
      headerName: 'Email',
      field: 'Email',
    },
    {
      headerName: 'Position',
      field: 'Position',
    },
    {
      headerName: 'Notes',
      field: 'Notes',
    },
    {
      headerName: '',
      field: 'Remove',
    }
  ];
  let mockRowDataTPA = [];
  const blankMockRowDataTPA = [
    {
      'ExternalContactName': '',
      'ExternalContactId': '',
      'Email': '',
      'Position': '',
      'Notes': '',
      'Remove': ''
    },
    {
      'ExternalContactName': '',
      'ExternalContactId': '',
      'Email': '',
      'Position': '',
      'Notes': '',
      'Remove': ''
    },
    {
      'ExternalContactName': '',
      'ExternalContactId': '',
      'Email': '',
      'Position': '',
      'Notes': '',
      'Remove': ''
    }];
  const mockRowDataFIL = [
    {
      'Attendee': 'Thornton, Ian',
      'AttendeeId': '123',
      'Call-In': true,
      'Infopacks': false,
      'Info Only': false,
      'Remove': ''
    },
    {
      'Attendee': 'Verma, Pankaj',
      'AttendeeId': '1234',
      'Call-In': false,
      'Infopacks': false,
      'Info Only': true,
      'Remove': ''
    },
    {
      'Attendee': 'Patrick, Tim',
      'AttendeeId': '12345',
      'Call-In': false,
      'Infopacks': true,
      'Info Only': false,
      'Remove': ''
    }
  ];
  const mtgDtlsResponse = {
    statusCode: 200,
    body: {
      emailSubject: 'Test',
      meetingDate: '05/05/2019',
      meetingTimeInGMT: '1257',
      hostCorporateId: 'a565656',
      locationType: 'Internal',
      meetingSubTypeDescription: 'Conference-Call',
      fidelityInvitees: []
    }
  };
  const rowClickedParams = {
    api: { sizeColumnsToit: () => { }, setFocusedCell: () => { } },
    gridColumnApi: {},
    node: {
      rowIndex: 2,
      setSelected: () => { }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TypeaheadModule.forRoot(),
        AgGridModule.withComponents([]),
        HttpClientModule,
        TestModule
      ],
      declarations: [CommonGridComponent,
        ConfigInviteesDtlsComponent,
        ConfigDeleteComponent],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, { provide: ActivatedRoute, useValue: { params: of() } }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonGridComponent);
    component = fixture.componentInstance;
    mockRowDataTPA = [
      {
        'ExternalContactName': 'Thornton, Ian',
        'ExternalContactId': '123',
        'Email': 'unknown1@uk.com',
        'Position': 'CEO',
        'Notes': 'Test Notes',
        'Remove': ''
      },
      {
        'ExternalContactName': 'Verma, Pankaj',
        'ExternalContactId': '1234',
        'Email': 'unknown12@uk.com',
        'Position': 'CTO',
        'Notes': 'Test Notes',
        'Remove': ''
      },
      {
        'ExternalContactName': 'Patrick, Tim',
        'ExternalContactId': '12345',
        'Email': 'unknown123@uk.com',
        'Position': 'CFO',
        'Notes': 'Test Notes',
        'Remove': ''
      }
    ];
    mtgDtlsResponse.body.fidelityInvitees = [
      {
        'name': 'Thornton, Ian',
        'corporateId': 'a565656',
        'isCallIn': false,
        'isInfoPackRequired': true,
        'isInviteForInfoOnly': true,
        'Remove': ''
      },
      {
        'name': 'Man, Spider',
        'corporateId': 'a592235',
        'isCallIn': false,
        'isInfoPackRequired': false,
        'isInviteForInfoOnly': true,
        'Remove': ''
      },
      {
        'name': 'Man, Iron',
        'corporateId': 'a592295',
        'isCallIn': false,
        'isInfoPackRequired': true,
        'isInviteForInfoOnly': false,
        'Remove': ''
      }
    ];
    rowClickedParams.node.rowIndex = 2;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should verify that grid API is available after `detectChanges`', () => {
    fixture.detectChanges();
    expect(component.gridOptions.api).toBeTruthy();
  });


  it('should test onGridReady', async(() => {
    component.gridType = 'signUpAttendeeGrid';
    component.gridOptions.onGridReady = function (params) {
      fixture.detectChanges();
      expect(component.gridApi).toEqual(params.api);
    };
  }));

  it('should verify that user should able to see Fidelity Attendee grid on the create meeting page with 3 rows', () => {
    const mockGridInfoObj: any = {
      'rowData': mockRowDataFIL,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'filAttendeeGrid'
    };
    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.ngOnInit();
    expect(component.gridOptions.rowData.length).toEqual(3);
  });
  it('should verify that user should able to see Third Party Attendee grid on the create meeting page with 3 rows', () => {
    const mockGridInfoObj: any = {
      'rowData': mockRowDataTPA,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'thirdPartyAttendeeGrid'
    };
    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.ngOnInit();
    expect(component.gridOptions.rowData.length).toEqual(3);
  });
  it('should not add a new row when previous rows are not filled in third Party Attendees and the last row is filled ', async(() => {
    const mockGridInfoObj: any = {
      'rowData': blankMockRowDataTPA,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'thirdPartyAttendeeGrid'
    };
    component.gridInfoObj = mockGridInfoObj;
    // rowClickedParams.node.rowIndex = 2;
    fixture.detectChanges();
    // New attendee selected at the last Row
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      // Default Expected Grid Size is 3
      expect(component.gridOptions.rowData.length).toEqual(3);
      // Expected that All previous Grid Rows are blank
      expect(component.gridOptions.rowData[0].ExternalContactName.length).toEqual(0);
      expect(component.gridOptions.rowData[1].ExternalContactName.length).toEqual(0);
      expect(component.gridOptions.rowData[2].ExternalContactName.length).toEqual(0);
      component.rowClicked(rowClickedParams
        , 'Verma, Rahul'
        , '123465'
        , [{
          'ExternalContactName': 'Verma, Rahul',
          'ExternalContactId': '123456',
          'Email': 'unknown123@uk.com',
          'Position': 'CFO',
          'Notes': 'Test Notes',
          'Remove': ''
        }]);

      // No New Row Added, Expected Grid Size remains same
      expect(component.gridOptions.rowData.length).toEqual(3);
    };
  }));
  it('should add a new row when user enters third Party Attendee in the last row with all previous row filled ', async(() => {
    const mockGridInfoObj = {
      'rowData': mockRowDataTPA,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'thirdPartyAttendeeGrid'
    };
    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      // component.gridOptions.rowData = rowData;
      component.rowClicked(rowClickedParams
        , 'Verma, Rahul'
        , '123465'
        , [{
          'ExternalContactName': 'Verma, Rahul',
          'ExternalContactId': '123456',
          'Email': 'unknown123@uk.com',
          'Position': 'CFO',
          'Notes': 'Test Notes',
          'Remove': ''
        }]);
      expect(component.gridOptions.rowData.length).toEqual(4);

      rowClickedParams.node.rowIndex = 3;
      fixture.detectChanges();
      component.rowClicked(rowClickedParams
        , 'Gandhi, Pankaj'
        , '123465'
        , [{
          'ExternalContactName': 'Gandhi, Pankaj',
          'ExternalContactId': '1234567',
          'Email': 'unknown13@uk.com',
          'Position': 'CFO',
          'Notes': 'Test Notes',
          'Remove': ''
        }]);
      expect(component.gridOptions.rowData.length).toEqual(5);
    };
  }));
  it('should add a new row when user enters Fidelity Attendee in the last row with all previous row filled ', async(() => {
    const mockGridInfoObj = {
      'rowData': mockRowDataFIL,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'filAttendeeGrid'
    };
    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      // component.gridOptions.rowData = rowData;
      component.rowClicked(rowClickedParams
        , 'Verma, Rahul'
        , 'a999999'
        , []);
      expect(component.gridOptions.rowData.length).toEqual(4);

      rowClickedParams.node.rowIndex = 3;
      fixture.detectChanges();
      component.rowClicked(rowClickedParams
        , 'Gandhi, Pankaj'
        , 'a789789'
        , []);
      expect(component.gridOptions.rowData.length).toEqual(5);
    };

  }));
  it('should add a new row when user enters SignUp Attendee in the last row with all previous row filled ', async(() => {
    const mockGridInfoObj = {
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'signUpAttendeeGrid'
    };
    const mockMeetingID = '2019-05-02T09:53:15.000Z-b4e92221-7476-46cb-9149-acb26e888260';
    const commonService = fixture.debugElement.injector.get(CommonService);
    commonService.signUpMeetingIdObservable = of(mockMeetingID);
    spyOn(commonService, 'getMtgDetailsForMtgId').and.returnValue(of(mtgDtlsResponse));

    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      // component.gridOptions.rowData = rowData;
      component.rowClicked(rowClickedParams
        , 'Verma, Rahul'
        , 'a969695'
        , []);
      expect(component.gridOptions.rowData.length).toEqual(4);

      rowClickedParams.node.rowIndex = 3;
      fixture.detectChanges();
      component.rowClicked(rowClickedParams
        , 'Gandhi, Pankaj'
        , 'a778788'
        , []);
      expect(component.gridOptions.rowData.length).toEqual(5);
    };
  }));
  it('should be able to delete the added row when click on Trash button', () => {
    component.gridOptions.rowData = mockRowDataTPA;
    fixture.detectChanges();
    // we remove row where Attendee: 'Verma, Pankaj'
    component.onRemoveClicked(1);
    fixture.detectChanges();
    // On removing row where Attendee: 'Verma, Pankaj' Grid Rows reduces to 2
    expect(component.gridOptions.rowData.length).toEqual(2);
    // On removing row where Attendee: 'Verma, Pankaj'
    // 3rd row where Attendee: 'Patrick, Tim' replaces 2nd row whereAttendee: 'Verma, Pankaj'
    expect(component.gridOptions.rowData[1].ExternalContactName).toEqual('Patrick, Tim');
  });
  it('should verify that user should able to see SignUp Attendee grid on the with already present FIL attendees on signup page', async(() => {
    const mockGridInfoObj: any = {
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'signUpAttendeeGrid'
    };
    const mockMtgDtlsObj = {
      subjectLine: mtgDtlsResponse.body.emailSubject,
      mtgDateTime: mtgDtlsResponse.body.meetingDate + ' ' + mtgDtlsResponse.body.meetingTimeInGMT.replace(/(..)/g, '$1:').slice(0, -1),
      mtgHost: mtgDtlsResponse.body.fidelityInvitees[0].name,
      mtgLocation: mtgDtlsResponse.body.locationType,
      mtgSubType: mtgDtlsResponse.body.meetingSubTypeDescription
    };
    const mockMeetingID = '2019-05-02T09:53:15.000Z-b4e92221-7476-46cb-9149-acb26e888260';
    const commonService = fixture.debugElement.injector.get(CommonService);
    commonService.signUpMeetingIdObservable = of(mockMeetingID);
    spyOn(commonService, 'getMtgDetailsForMtgId').and.returnValue(of(mtgDtlsResponse));

    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {

      component.ngOnInit();

      fixture.detectChanges();
      // this.gridOptions.api = params.api;
      expect(component.meetingId).toEqual(mockMeetingID);
      expect(component.mtgDtlsObj).toEqual(mockMtgDtlsObj);
      expect(component.gridOptions.rowData.length).toEqual(4);
    };
  }));
  it('should be able to move the cell selection to next cell on tab key press', async(() => {
    component.gridOptions.onGridReady = function (params) {
      // set rowIndex in params where you want to focus on Grid
      params['rowIndex'] = 1;
      component.gridType = 'filAttendeeGrid';

      fixture.detectChanges();
      component.typeaheadTabKeyPress(params);
      let getFocusedCellObj = component.gridApi.getFocusedCell();
      expect(getFocusedCellObj.rowIndex).toEqual(1);

      params['rowIndex'] = 2;
      component.gridType = 'signUpAttendeeGrid';
      fixture.detectChanges();
      component.typeaheadTabKeyPress(params);
      getFocusedCellObj = component.gridApi.getFocusedCell();
      expect(getFocusedCellObj.rowIndex).toEqual(2);

      params['rowIndex'] = 1;
      component.gridType = 'thirdPartyAttendeeGrid';
      fixture.detectChanges();
      component.typeaheadTabKeyPress(params);
      getFocusedCellObj = component.gridApi.getFocusedCell();
      expect(getFocusedCellObj.rowIndex).toEqual(1);
    };
  }));
  it('should be able to select/Deselect a checkBox or trash icon on keyboard actions', () => {
    // component.keyDown();
    const mockGridInfoObj = {
      'rowData': mockRowDataFIL,
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'filAttendeeGrid'
    };
    const keyboardParams = {
      rowIndex: 1,
      column: {
        colId: 'Remove'
      },
      key: 'Enter'
    };
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      component.gridApi.setFocusedCell(2, 'Attendee', null);
      component.gridApi.column = {
        colId: 'Attendee'
      };
      fixture.detectChanges();
      const getFocusedCellObj = component.gridApi.getFocusedCell();
      expect(getFocusedCellObj.rowIndex).toEqual(2);
      component.keyDown(keyboardParams);
      expect(component.gridOptions.rowData.length).toEqual(120);
      expect(component.onRemoveClicked(params['rowIndex'])).toHaveBeenCalled();
    };
  });

  it('should be signup logged in user to the meeting automatically when clicked on sign up for me', () => {
    // component.keyDown();
    const rowData = [{
            'signUpAttendeeName': 'Gulati, Deepali',
            'corporateId': 'A123456',
            'isCallIn': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false,
            'Remove': ''
          },
          {
            'signUpAttendeeName': '',
            'corporateId': '',
            'isCallIn': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false,
            'Remove': ''
          }];
    const userDetail = new UserDetail('A608245', 'SHARMA, KANIKA', '12345', 'India', 'GMT+5:30', 'IN', 'abc', '', '');
    component.rowData = rowData;
    component.gridInfoObj.gridType = 'signUpAttendeeGrid';
    let commonService = fixture.debugElement.injector.get(CommonService);
    commonService.setLoggedInUserInfo(userDetail);
    component.meetingId = '123456789';
    spyOn(commonService, 'signUpForMeSubject').and.returnValue(of(true));
    
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
    fixture.detectChanges();
    expect(component.signUpInfo).toEqual({meetingId: ['123456789'], fidelityInvitees: [{
      'signUpAttendeeName': 'Sharma, Kanika',
            'corporateId': 'A608245',
            'isCallIn': false,
            'isInfoPackRequired': false,
            'isInviteForInfoOnly': false, 
            'Remove': ''
    }]});
    }    
  });

  it('should disable signup for me if logged in user is already a part of meeting invitees ', async(() => {
    const mockGridInfoObj = {
      'columnDefs': [{}, {}, {}, {}, {}],
      'gridType': 'signUpAttendeeGrid'
    };
    const userDetail = new UserDetail('A608245', 'SHARMA, KANIKA', '12345', 'India', 'GMT+5:30', 'IN', 'abc', '', '')
    const mockMtgDtlsObj = {
      subjectLine: mtgDtlsResponse.body.emailSubject,
      mtgDateTime: mtgDtlsResponse.body.meetingDate + ' ' + mtgDtlsResponse.body.meetingTimeInGMT,
      mtgHost: mtgDtlsResponse.body.hostCorporateId,
      mtgLocation: mtgDtlsResponse.body.locationType,
      mtgSubType: mtgDtlsResponse.body.meetingSubTypeDescription
    };
    const mockMeetingID = '2019-05-02T09:53:15.000Z-b4e92221-7476-46cb-9149-acb26e888260';
    const commonService = fixture.debugElement.injector.get(CommonService);
    
    commonService.setLoggedInUserInfo(userDetail);
    commonService.signUpMeetingIdObservable = of(mockMeetingID);
    spyOn(commonService, 'getMtgDetailsForMtgId').and.returnValue(of(mtgDtlsResponse));
    component.gridInfoObj = mockGridInfoObj;
    fixture.detectChanges();
    component.gridOptions.onGridReady = function (params) {
      component.ngOnInit();
      // component.gridOptions.rowData = rowData;
      component.rowClicked(rowClickedParams
        , 'Sharma, Kanika'
        , 'A608245'
        , []);
      fixture.detectChanges();
    };
  }));
  
});
