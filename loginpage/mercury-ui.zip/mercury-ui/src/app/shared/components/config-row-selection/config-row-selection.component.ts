import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { CommonService } from 'src/app/core/http/common.service';

@Component({
  selector: 'mv2-config-row-selection',
  template: `
  <div class="InviteesCheckBox">
    <input type="checkbox" class="invitees-checkbox" [disabled]="enableCheckBox" [checked]= "isChecked" (change)="onChange($event)">
  </div>
  `,
  styleUrls: ['./config-row-selection.component.css']
})
export class ConfigRowSelectionComponent implements ICellRendererAngularComp {

  params: any;
  enableCheckBox = false;
  isChecked = false;
  constructor(private commonService: CommonService) {
    this.params = '';
  }
  agInit(params): void {
    this.params = params;
    this.isChecked = params.node.selected;
    if (this.params.node.selectable === false) {
      this.enableCheckBox = true;
      this.isChecked = true;
    } else if (this.params.node.data.selection === true) {
      this.isChecked = true;
    }
    this.checkMandatoryFields(this.params);
  }
  onChange(event) {
    this.params.node.setSelected(event.currentTarget.checked);
    this.params.data[this.params.colDef.field] = event.currentTarget.checked;
  }

  refresh(params): boolean {
    this.checkMandatoryFields(params);
    return true;
  }
  checkMandatoryFields(params: any) {
    if ((params.data).hasOwnProperty('meetingDate') && (params.data).hasOwnProperty('meetingTime')) {
      if (!(params.data.meetingDate && params.data.meetingTime)) {
        this.enableCheckBox = true;
        this.isChecked = false;
      } else {
        this.enableCheckBox = false;
      }
    }
  }
}
