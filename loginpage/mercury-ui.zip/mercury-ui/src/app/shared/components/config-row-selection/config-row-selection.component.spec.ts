import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigRowSelectionComponent } from './config-row-selection.component';

describe('ConfigRowSelectionComponent', () => {
  let component: ConfigRowSelectionComponent;
  let fixture: ComponentFixture<ConfigRowSelectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigRowSelectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigRowSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
