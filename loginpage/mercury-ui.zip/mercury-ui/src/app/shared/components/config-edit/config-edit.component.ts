import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';

import { CommonService } from 'src/app/core/http/common.service';



@Component({
  selector: 'mv2-config-edit',
 template: `
    <button type="button" style="background: transparent; box-shadow: none!important;"
      class="btn tbl-btn" (click)= onEdit()>
     <span class = "editIcon"> </span>
    </button>
  `,
  styleUrls: ['./config-edit.component.css']
})
  //  <img src= "./assets/images/group-2.svg" style= "height:19px;color: solid 1px #000000;width:18px;">
export class ConfigEditComponent implements ICellRendererAngularComp {
 // isVisible = false;
  public params: any;
  rowIndex: any;
  // isSelected = true;

  constructor(private commonService: CommonService) { }
  agInit(params): void {
    this.params = params;
    // if (('Attendee' in this.params.data) && (this.params.rowIndex > 0)) {
    //   this.isVisible = true;
    // } else if (('signUpAttendeeName' in this.params.data) || ('ExternalContactName' in this.params.data)) {
    //   this.isVisible = true;
    // }
    // if (this.params.node.data.Attendee
    //   || this.params.node.data.ExternalContactName
    //   || ((this.params.node.data.signUpAttendeeName) && ('Remove' in this.params.node.data))) {
    //   this.isSelected = false;
    // }

    //  this.route.params.subscribe((params: Params) => {
    //     if (params['action'] === 'update') {
    //       this.commonService.updateMtgDtlsSourceObservable.subscribe((response) => {
    //         if (response) {
    //           this.checkIfMeetingDateISMoreThan365Days(moment(response.meetingDate).format('DD/MM/YYYY'), response.meetingState);
    //         }
    //      });
    //     }});
  }
  onEdit() {
    this.params.context.componentParent.onEditClicked(this.params.node.rowIndex);
  }
  refresh(): boolean {
    return false;
  }

  //   checkIfMeetingDateISMoreThan365Days(date: string, meetingState: string) {
  //   const format = 'DD/MM/YYYY';
  //  const val = moment(date, format, true);
  //  const ONE_DAY = 1000 * 60 * 60 * 24;
  //  const meetingDate = val.toDate();
  //  const todayDate: Date = new Date();
  //  const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
  //  if (differenceDays > 365 || meetingState === 'CANCELLED') {
  //           this.isSelected = true;
  // }

  // }
}

