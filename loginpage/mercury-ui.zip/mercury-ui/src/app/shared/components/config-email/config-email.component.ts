import { Component, OnInit, Input, ViewChild, ElementRef, COMPILER_OPTIONS, NgZone } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap';
import { EmailAdvartiseContact } from 'src/app/shared/models/emailAdvertiseContact.modal';
import { find, get, pull } from 'lodash';
import Utils from '../../../shared/utils/common.utility';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { ChangeEvent } from '@ckeditor/ckeditor5-angular/ckeditor.component';
import { CommonService } from 'src/app/core/http/common.service';
import { Observable, Observer, EMPTY, BehaviorSubject } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { TypeaheadDataSource, TypeaheadData } from 'src/app/shared/utils/typeahead.utility';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import * as moment from 'moment';
const toBase64 = file => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = () => resolve(reader.result);
  reader.onerror = error => reject(error);

});

const getAid = data => {
  let aids = [];
  if (!Utils.isVoid(data))
    aids = data.map(a => a.corporateId);
  return aids;
}
const toErrorMsg = 'No matching results found, please try again.';
const createHtmlContent = cfData => {

  let html = `<table border="0" cellpadding="0" cellspacing="0" style="border: 0px;"><tbody><tr><td>Conference</td><td><strong>${cfData.eventName}</strong></td></tr><tr><td>Dates</td><td>${moment(cfData.startDate).format('DD/MM/YYYY')} - ${moment(cfData.endDate).format('DD/MM/YYYY')}</td></tr><tr><td>Venue</td><td>${cfData.venue}</td></tr>
  <tr><td>Website</td><td><a href="${cfData.website}">${cfData.website ? cfData.website : ''}</a></td></tr><tr><td>Contact</td><td>${cfData.arrangementContact ? cfData.arrangementContact.organizerName : ''}<a href="mailto:${cfData.arrangementContact ? cfData.arrangementContact.organizerEmail : ''}"><br>${cfData.arrangementContact ? cfData.arrangementContact.organizerEmail : ''}</a>
  </td></tr><tr><td> Registration Deadline&nbsp;&nbsp; </td><td>${moment(cfData.meetingRegistrationDeadline).format('DD/MM/YYYY')}</td></tr><tr><td> Meeting Request Deadline&nbsp;&nbsp; </td><td>${moment(cfData.meetingRequestDeadline).format('DD/MM/YYYY')}</td></tr>
  </tbody></table>&nbsp<br>`;
  return html;
}
@Component({
  selector: 'mv2-config-email',
  templateUrl: './config-email.component.html',
  styleUrls: ['./config-email.component.css']
})
export class ConfigEmailComponent implements OnInit {
  public Editor = ClassicEditor;
  totalFileSize = [];
  peopleDataSource: Observable<any>;
  distrubationList = [];
  minDate: Date;
  maxDate: Date;
  utilDataObservable: Observable<any>;
  @Input() conferenceDetail: any;
  @ViewChild('attachementFile') InputFrameVariable: ElementRef;
  @ViewChild('toEmailTagInput') toEmailInputRef: ElementRef;
  @ViewChild('ccEmailTagInput') ccEmailInputRef: ElementRef;
  emailData = new EmailAdvartiseContact({}, []);
  tabValue: string = "advertise";
  typeaheadLoadingTo: boolean;
  typeaheadLoadingCc: boolean;
  typeaheadLoadingReplyTo: boolean;
  isModalShown: boolean = false;
  imageStatus: string = "";
  emailForm = this.fb.group({});
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
  };
  resultNotFound: any = { 'cc': false, 'to': false, 'replyTo': false, toErrorMsg: toErrorMsg, htmlTextErrorMsg: '', reminderDate: false };
  draftConfirmMessage: string = "";
  messageHeading: string = "";
  public editorConfig = {
    //placeholder: 'Type the content here!',
    height: 300,
    resize_dir: 'both',
    resize_minWidth: 200,
    resize_minHeight: 300,
    resize_maxWidth: 500
  }
  emailModelRef: BsModalRef | null;
  @ViewChild('saveDialogModal') saveDialogModal: ModalDirective;
  typeaheadDataSource: TypeaheadDataSource = new TypeaheadDataSource(this.commonService, this.ngZone);
  constructor(private fb: FormBuilder, private modalService: BsModalService, private ngZone: NgZone,
    private commonService: CommonService) {
  }
  resetEmailData() {
    this.emailData = new EmailAdvartiseContact({}, []);
    this.totalFileSize = [];
    this.minDate = new Date();
    this.maxDate = new Date(this.conferenceDetail.startDate);
    this.minDate.setDate(this.minDate.getDate());
    this.maxDate.setDate(this.maxDate.getDate()-1);
  }
  ngOnInit() {
    this.fetchUtilData();
    this.emailForm = this.fb.group({
      to: [undefined],
      cc: [undefined],
      replyTo: [undefined],
      subject: [Validators.required],
      htmlText: [Validators.required],
      reminderDate: [Validators.required]
    });
  }
  showConfirmMsg(isModalShown = true, imageStatus = "success", draftConfirmMessage, messageHeading) {
    this.isModalShown = true;
    this.imageStatus = imageStatus;
    this.draftConfirmMessage = draftConfirmMessage;
    this.messageHeading = messageHeading;
  }
  isRequestFail(res) {
    if (res.statusCode !== 200 || res.body === 'FAILURE') {
      return true;
    } else {
      return false;
    }
  }
  retSetErrorMsg() {
    this.resultNotFound = { 'cc': false, 'to': false, 'replyTo': false, 'htmlText': false, 'toErrorMsg': toErrorMsg, htmlTextErrorMsg: '', reminderDate: false };
  }
  closeEmailModel() {
    this.retSetErrorMsg();
    this.emailModelRef.hide();
  }
  openEmailBox(template, tabValue) {
    this.tabValue = tabValue;
    this.emailModelRef = this.modalService.show(template, this.config);
    this.resetEmailData();
    console.log('Conference detail : ',this.conferenceDetail);
    if (!Utils.isVoid(this.conferenceDetail)) {
      this.emailData.message.subject = `${this.conferenceDetail.eventName} ${this.conferenceDetail.city}, ${this.conferenceDetail.countryDescription}  ${moment(this.conferenceDetail.startDate).format('DD/MM/YYYY')} - ${moment(this.conferenceDetail.endDate).format('DD/MM/YYYY')}`;
      this.emailForm.patchValue({
        'subject': this.emailData.message.subject,
        'htmlText': this.tabValue ==='advertise' ?createHtmlContent(this.conferenceDetail) : '',
        'to': '',
        'cc': '',
        'replyTo': '',
        'reminderDate': ''
      });
      this.emailData.message.replyTo = [this.conferenceDetail.eventOwner];
      const userRegion = this.commonService.getLoggedInUserInfo();
      let dl;
      this.distrubationList.forEach((v) => {
        if (v.KeyCode === userRegion.regionCode) {
          dl = v;
        }
      })
      dl = Utils.isVoid(dl) ? this.distrubationList[0] : dl;
      this.emailData.message.to = [dl.KeyDesc[0]];
      //this.emailData.message.to = this.tabValue === "advertise" ? [dl.KeyDesc] : [];
    }
  }

  refreshHideModal(event) {
    if (event) {
      this.emailModelRef.hide();
    }
  }
  focusToEmailInput(): void {
    if (!Utils.isVoid(this.toEmailInputRef))
      this.toEmailInputRef.nativeElement.focus();
  }
  focusCcEmailInput(): void {
    if (!Utils.isVoid(this.ccEmailInputRef))
      this.ccEmailInputRef.nativeElement.focus();
  }
  addEmail(event, value, emailType) {
    if (event.code === 'Backspace' && !value) {
      emailType === 'to' ? this.removeToEmail() : this.removeCcEmail();
      return;
    } else {
      if (event.code === 'Comma' || event.code === 'Space' || event.code === 'Enter') {
        this.addTag(value, emailType);
        this.emailForm.controls[emailType].setValue('');
      }
    }
  }
  ccEmailKeyup(event: KeyboardEvent): void {
    const inputValue: string = this.emailForm.controls.cc.value;
    this.addEmail(event, inputValue, 'cc');
  }
  emailKeyup(event: KeyboardEvent, emailType): void {
    const inputValue: string = this.emailForm.controls[emailType].value;
    if (event.code === 'Backspace' && !inputValue) {
      this.emailData.message[emailType].splice(-1);
    }
  }
  toEmailKeyup(event: KeyboardEvent): void {
    const inputValue: string = this.emailForm.controls.to.value;
    this.addEmail(event, inputValue, 'to');
  }

  addTag(tag: string, emailType: string): void {
    if (tag[tag.length - 1] === ',' || tag[tag.length - 1] === ' ') {
      tag = tag.slice(0, -1);
    }
    if (tag.length > 0 && !find(this.emailData.message[emailType], tag)) {
      this.emailData.message[emailType].push(tag);
    }
  }

  removeToEmail(tag?: string): void {
    if (!!tag) {
      pull(this.emailData.message.to, tag);
    } else {
      this.emailData.message.to.splice(-1);
    }
  }
  removeCcEmail(tag?: string): void {
    if (!!tag) {
      pull(this.emailData.message.cc, tag);
    } else {
      this.emailData.message.cc.splice(-1);
    }
  }
  removeReplyToEmail(tag?: string): void {
    if (!!tag) {
      pull(this.emailData.message.replyTo, tag);
    } else {
      this.emailData.message.replyTo.splice(-1);
    }
  }
  onEmailTextChange({ editor }: ChangeEvent) {
    if (!Utils.isVoid(editor)) {
      this.emailData.message.htmlText = editor.getData();
      this.resultNotFound.htmlText = false;
    }
  }

  onReminderTextChange() {
    this.resultNotFound.htmlText = false;
  }

  async handleFileInput(event) {
    let files = event.target.files;
    const fileInfo = files.item(0);
    if (files && files.length === 0) {
      return;
    }
    const base64Data = JSON.stringify(await toBase64(fileInfo));
    this.totalFileSize.push(fileInfo.size);
    const fileObj = {
      "filename": fileInfo.name,
      "content": base64Data.split("base64,")[1],//window.btoa(base64Data),
      "encoding": "base64"
    }
    if (this.totalFileSize.reduce((a, b) => a + b) > 5000000) {
      this.resultNotFound.htmlText = true;
      this.totalFileSize.pop();
      this.resultNotFound.htmlTextErrorMsg = 'Maximum 5 MB of attachments allow.';
      event.target.value = '';
      // this.InputFrameVariable.nativeElement.value = '';
      return;
    } else {
      this.resultNotFound.htmlText = false;
    }
    this.emailData.attachments.push(fileObj);
  }
  removeAttachement(index) {
    this.emailData.attachments.splice(index, 1);
    this.totalFileSize.splice(index, 1);
    this.resultNotFound.htmlText = false;
  }
  sendAdvertise() {
    let emailBody = { attachments: [], message: { to: [], cc: [], replyTo: [], distributionList: [], subject: '', htmlText: '' } };
    if (Utils.isVoid(this.emailData.message.to)) {
      this.resultNotFound.to = true;
      this.resultNotFound.toErrorMsg = 'Please enter at least one email Id';
      return;
    }
    let toEmail = Object.assign(this.emailData.message.to);
    if (!Utils.isVoid(this.emailData.message.to[0].email)) {
      let dl = this.emailData.message.to[0];
      emailBody.message['distributionList'] = [dl.email];
      toEmail = [...this.emailData.message.to];
      toEmail.shift();
    }
    this.emailData.message.htmlText = this.emailForm.controls.htmlText.value;
    if (Utils.isVoid(this.emailData.message.htmlText)) {
      this.resultNotFound.htmlText = true;
      this.resultNotFound.htmlTextErrorMsg = 'Please Enter Email Body.'
      return;
    }
    emailBody.message.htmlText = this.emailData.message.htmlText;
    emailBody.message.subject = this.emailData.message.subject;
    emailBody.message.to = getAid(toEmail);
    emailBody.message.cc = getAid(this.emailData.message.cc);
    emailBody.message.replyTo = getAid(this.emailData.message.replyTo);
    emailBody.attachments = this.emailData.attachments;
    this.commonService.sendEmailWithAttachement(emailBody).subscribe((response) => {
      if (this.isRequestFail(response)) {
        this.showConfirmMsg(true, 'alert', 'Unable to Advertise Conference, Please try again.', 'Error');
      } else {
        this.showConfirmMsg(true, 'success', 'Advertise Conference Successfully.', 'Success !');
      }
    },
      (error) => {
        this.showConfirmMsg(true, 'alert', 'Unable to Advertise Conference, Please try again ', 'Error');
      });
  }
  onDateChange() {
    this.resultNotFound.reminderDate = false;
  }
  sendReminder() {
    let reminderDate = this.emailForm.get('reminderDate').value;
    if(!reminderDate){
      this.resultNotFound.reminderDate = true;
      return;
    }
    this.resultNotFound.reminderDate = false;
    let toEmail = Object.assign(this.emailData.message.to);
    let distributionList = [];
    if (!Utils.isVoid(this.emailData.message.to[0].email)) {
      let dl = this.emailData.message.to[0];
      distributionList = [dl.email];
      toEmail = [...this.emailData.message.to];
      toEmail.shift();
    }
    if (Utils.isVoid(this.emailData.message.to)) {
      this.resultNotFound.to = true;
      this.resultNotFound.toErrorMsg = 'Please enter at least one email Id';
      return;
    }
    this.emailData.message.htmlText = this.emailForm.controls.htmlText.value;
    if (Utils.isVoid(this.emailData.message.htmlText)) {
      this.resultNotFound.htmlText = true;
      this.resultNotFound.htmlTextErrorMsg = 'Please Enter Email Body.'
      return;
    }
    let reminderEmailBody = {
      "appointment": {
        "subject": this.emailData.message.subject,
        "body": this.emailData.message.htmlText,
        "startDayTime": reminderDate,
        "meetingLocation": this.conferenceDetail.venue,
        "distributionList" : distributionList,
        'requiredAttendees' : getAid(toEmail)
      }
    }
    this.commonService.sendReminder(reminderEmailBody).subscribe((response) => {
      if (this.isRequestFail(response)) {
        this.showConfirmMsg(true, 'alert', 'Unable to send reminder, Please try again.', 'Error');
      } else {
        this.showConfirmMsg(true, 'success', 'reminder sent Successfully.', 'Success !');
      }
    },
      (error) => {
        this.showConfirmMsg(true, 'alert', 'Unable to send reminder, Please try again.', 'Error');
      });
  }

  sendEmail() {
    if (this.tabValue === 'reminder') {
      this.sendReminder();
    } else {
      this.sendAdvertise();
    }

  }
  cancelEmail() {
    this.emailModelRef.hide();
  }

  getPeopleData(type): void {
    let typeaheadData: TypeaheadData;
    const searchedValue = this.emailForm.get(type).value;
    typeaheadData = this.typeaheadDataSource.getPeopleData(searchedValue);
    this.peopleDataSource = typeaheadData.dataSource;
  }

  typeaheadNoResults(event: boolean, dropDownType: string): void {
    this.resultNotFound[dropDownType] = event;
  }

  typeaheadOnSelect(event: TypeaheadMatch, dropDownType: string): void {
    const data = { 'corporateId': event.item.corporateId, 'name': event.item.name }
    let duplicateNotFound = true;
    this.emailData.message[dropDownType].forEach(v => {
      if (v.corporateId === data.corporateId) {
        duplicateNotFound = false;
      }
    });
    if (duplicateNotFound) {
      this.emailData.message[dropDownType].push(data);
    }
    this.emailForm.controls[dropDownType].setValue('');
  }
  changeTypeaheadLoading(e: boolean, dropDownType: string): void {
    if (dropDownType === 'cc') {
      this.typeaheadLoadingCc = e;
    } else if (dropDownType === 'to') {
      this.typeaheadLoadingTo = e;
    } else if (dropDownType === 'replyTo') {
      this.typeaheadLoadingReplyTo = e;
    }
  }

  onBlurMethod(dropDownType) {
    if (dropDownType === 'cc') {
      this.typeaheadLoadingCc = false;
    } else if (dropDownType === 'to') {
      this.typeaheadLoadingTo = false;
    } else if (dropDownType === 'replyTo') {
      this.typeaheadLoadingReplyTo = false;
    }
    this.getPeopleData(dropDownType);
  }

  fetchUtilData() {
    this.utilDataObservable = this.commonService.utilMessageObservable;
    this.utilDataObservable.subscribe((message) => {
      if (message !== '') {
        this.distrubationList = message.filter(element => element.UtilKeyName === 'conferenceAdvertiseTo');
      }
    },
      (error) => {
        console.log(error);
      });
  }
  onHidden(operationType): void {
    this.saveDialogModal.hide();
  }
  confirm(): void {
    this.emailModelRef.hide();
    this.isModalShown = false;
  }
}