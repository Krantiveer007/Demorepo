export const LOCATIONS = [
  'Conference Call',
  'In-house',
  'External',
  'Video Call'

];
export const MEETINGTYPE = [
  'All Meetings',
  'Broker',
  'Company',
  'Other',
  'Conference'
];

export const EVENTTYPE = [
  'All Events',
  'Conference',
  'Trip',
  'FIL Event'
];

export const EVENTSTATE = [
  'All States',
  'Confirmed',
  'Cancelled',
  'Completed'
];

export const SEARCHTYPE = [
  'All Contacts',
  'Broker Contact',
  'Company Contact',
  'Internal Contact',
  'Other Contact',
  'Broker Firm'
];

export const MEETINGSTATUS = [
  { status: 'Confirmed' },
  { status: 'On Time' },
  { status: 'Delayed' },
  { status: 'Arrived' }
];

export const MEETINGSTATE = [
  'Cancelled',
  'Confirmed',
  'Draft'
  //  'Draft and Invite',
];

export const INVITEERESPONSE = [
  'Accepted',
  'Tentative',
  'Declined'
];

export const USER_ROLES = {
  VIEW_MEETING: 'mercury-create-company-meeting',
  VIEW_CONTACT: 'mercury-create-external-contact'
};

export const firmCountryList = [
  {
    'mer_country_cd': 'MULT',
    'mer_country_desc': 'MULTI-NATIONAL',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'UAE',
    'mer_country_desc': 'UNITED ARAB EMIRATES',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NV',
    'mer_country_desc': 'NETHERLANDS ANTILLES',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ARG',
    'mer_country_desc': 'ARGENTINA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'AUST',
    'mer_country_desc': 'AUSTRIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'ASTL',
    'mer_country_desc': 'AUSTRALIA',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'BBDS',
    'mer_country_desc': 'BARBADOS',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BANG',
    'mer_country_desc': 'BANGLADESH',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BELG',
    'mer_country_desc': 'BELGIUM',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'BULG',
    'mer_country_desc': 'BULGARIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'BAHR',
    'mer_country_desc': 'BAHRAIN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BMDA',
    'mer_country_desc': 'BERMUDA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'BRUN',
    'mer_country_desc': 'BRUNEI',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BOLV',
    'mer_country_desc': 'BOLIVIA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'BRAZ',
    'mer_country_desc': 'BRAZIL',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'BAHM',
    'mer_country_desc': 'BAHAMAS (NASSAU)',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BOTS',
    'mer_country_desc': 'BOTSWANA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'BELR',
    'mer_country_desc': 'BELARUS',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'BLZ',
    'mer_country_desc': 'BELIZE',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'CANA',
    'mer_country_desc': 'CANADA',
    'mer_region_cd': 'CAN'
  },
  {
    'mer_country_cd': 'CONG',
    'mer_country_desc': 'CONGO DEMOCRATIC REPUBLIC OF',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'SWIT',
    'mer_country_desc': 'SWITZERLAND',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'COTE',
    'mer_country_desc': 'COTE DIVOIRE',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'CHIL',
    'mer_country_desc': 'CHILE',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'CAMR',
    'mer_country_desc': 'CAMEROON',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'CHNR',
    'mer_country_desc': 'CHINA',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'COL',
    'mer_country_desc': 'COLOMBIA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'COST',
    'mer_country_desc': 'COSTA RICA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'CYPR',
    'mer_country_desc': 'CYPRUS',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'CZEC',
    'mer_country_desc': 'CZECH REPUBLIC',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GERW',
    'mer_country_desc': 'GERMANY',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'DENM',
    'mer_country_desc': 'DENMARK',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'DOMR',
    'mer_country_desc': 'DOMINICAN REPUBLIC',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ALGR',
    'mer_country_desc': 'ALGERIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ECUA',
    'mer_country_desc': 'ECUADOR',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'ESTN',
    'mer_country_desc': 'ESTONIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'EGPT',
    'mer_country_desc': 'EGYPT',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'SPAI',
    'mer_country_desc': 'SPAIN',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'FINL',
    'mer_country_desc': 'FINLAND',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'FRAN',
    'mer_country_desc': 'FRANCE',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GABO',
    'mer_country_desc': 'GABON',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'UK',
    'mer_country_desc': 'UNITED KINGDOM',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GHAN',
    'mer_country_desc': 'GHANA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'GIBR',
    'mer_country_desc': 'GIBRALTAR',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GRNL',
    'mer_country_desc': 'GREENLAND',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'GREE',
    'mer_country_desc': 'GREECE',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GUAT',
    'mer_country_desc': 'GUATEMALA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'HOKO',
    'mer_country_desc': 'HONG KONG',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'HOND',
    'mer_country_desc': 'HONDURAS',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'CROT',
    'mer_country_desc': 'CROATIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'HUNG',
    'mer_country_desc': 'HUNGARY',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'INDO',
    'mer_country_desc': 'INDONESIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'IREL',
    'mer_country_desc': 'IRELAND',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'ISRA',
    'mer_country_desc': 'ISRAEL',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'IND',
    'mer_country_desc': 'INDIA',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'IRAQ',
    'mer_country_desc': 'IRAQ',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'IRAN',
    'mer_country_desc': 'IRAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ICEL',
    'mer_country_desc': 'ICELAND',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'ITAL',
    'mer_country_desc': 'ITALY',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'JAM',
    'mer_country_desc': 'JAMAICA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'JORD',
    'mer_country_desc': 'JORDAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'JAPA',
    'mer_country_desc': 'JAPAN',
    'mer_region_cd': 'JP'
  },
  {
    'mer_country_cd': 'KENY',
    'mer_country_desc': 'KENYA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'KOR',
    'mer_country_desc': 'KOREA (SOUTH)',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'KUWT',
    'mer_country_desc': 'KUWAIT',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'GCAY',
    'mer_country_desc': 'GRAND CAYMAN (UK OVERSEAS TER)',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'KAZA',
    'mer_country_desc': 'KAZAKHSTAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'LEB',
    'mer_country_desc': 'LEBANON',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'LIEC',
    'mer_country_desc': 'LIECHTENSTEIN',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SRIL',
    'mer_country_desc': 'SRI LANKA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'LIBR',
    'mer_country_desc': 'LIBERIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'LUX',
    'mer_country_desc': 'LUXEMBOURG',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'LATV',
    'mer_country_desc': 'LATVIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'LIBY',
    'mer_country_desc': 'LIBYA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MORO',
    'mer_country_desc': 'MOROCCO',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MOLD',
    'mer_country_desc': 'MOLDOVA REPUBLIC OF',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'MSHL',
    'mer_country_desc': 'MARSHALL ISLANDS REPUBLIC OF',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MACE',
    'mer_country_desc': 'MACEDONIA, FORMER YUGO REP OF',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'MALT',
    'mer_country_desc': 'MALTA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'MAUR',
    'mer_country_desc': 'MAURITIUS',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MEXI',
    'mer_country_desc': 'MEXICO',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'MLAY',
    'mer_country_desc': 'MALAYSIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NIGR',
    'mer_country_desc': 'NIGERIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NIC',
    'mer_country_desc': 'NICARAGUA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NETH',
    'mer_country_desc': 'NETHERLANDS',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'NORW',
    'mer_country_desc': 'NORWAY',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'NEWZ',
    'mer_country_desc': 'NEW ZEALAND',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'OMAN',
    'mer_country_desc': 'OMAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'PANA',
    'mer_country_desc': 'PANAMA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'PERU',
    'mer_country_desc': 'PERU',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'PAPU',
    'mer_country_desc': 'PAPUA NEW GUINEA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'PHIL',
    'mer_country_desc': 'PHILIPPINES',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'PAK',
    'mer_country_desc': 'PAKISTAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'POL',
    'mer_country_desc': 'POLAND',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'PTGL',
    'mer_country_desc': 'PORTUGAL',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'QATR',
    'mer_country_desc': 'QATAR',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ROMN',
    'mer_country_desc': 'ROMANIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'RUS',
    'mer_country_desc': 'RUSSIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SAUD',
    'mer_country_desc': 'SAUDI ARABIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'SWED',
    'mer_country_desc': 'SWEDEN',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SING',
    'mer_country_desc': 'SINGAPORE',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'SLVN',
    'mer_country_desc': 'SLOVENIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SLOV',
    'mer_country_desc': 'SLOVAKIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'ELSV',
    'mer_country_desc': 'EL SALVADOR',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'SWAZ',
    'mer_country_desc': 'SWAZILAND',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'TKCC',
    'mer_country_desc': 'TURKS & CAICOS ISLANDS',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'THAI',
    'mer_country_desc': 'THAILAND',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'TUNI',
    'mer_country_desc': 'TUNISIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'TURK',
    'mer_country_desc': 'TURKEY',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'TRIN',
    'mer_country_desc': 'TRINIDAD & TOBAGO',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'CHNA',
    'mer_country_desc': 'TAIWAN',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'TANZ',
    'mer_country_desc': 'TANZANIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'UKRA',
    'mer_country_desc': 'UKRAINE',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'UGAN',
    'mer_country_desc': 'UGANDA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'USA',
    'mer_country_desc': 'USA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'URUG',
    'mer_country_desc': 'URUGUAY',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'UZBE',
    'mer_country_desc': 'UZBEKISTAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'VENZ',
    'mer_country_desc': 'VENEZUELA',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'BRVI',
    'mer_country_desc': 'BRITISH VIRGIN ISLANDS',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'VIET',
    'mer_country_desc': 'VIETNAM',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'YUGO',
    'mer_country_desc': 'YUGOSLAVIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SOAF',
    'mer_country_desc': 'SOUTH AFRICA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ZAMB',
    'mer_country_desc': 'ZAMBIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ZAIR',
    'mer_country_desc': 'ZAIRE (OLD - DO NOT USE)',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ZIMB',
    'mer_country_desc': 'ZIMBABWE',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ANGL',
    'mer_country_desc': 'ANGOLA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'LITH',
    'mer_country_desc': 'LITHUANIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'MNCO',
    'mer_country_desc': 'MONACO',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SERB',
    'mer_country_desc': 'SERBIA & MONTENEGRO (OLD)',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'ANTG',
    'mer_country_desc': 'ANTIGUA & BARBUDA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'GYNA',
    'mer_country_desc': 'GUYANA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'FIJI',
    'mer_country_desc': 'FIJI',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NMBA',
    'mer_country_desc': 'NAMIBIA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'ARBA',
    'mer_country_desc': 'ARUBA',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MACA',
    'mer_country_desc': 'MACAU',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'MNRO',
    'mer_country_desc': 'MONTENEGRO',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'GRGA',
    'mer_country_desc': 'GEORGIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SRBA',
    'mer_country_desc': 'SERBIA',
    'mer_region_cd': 'EUR'
  },
  {
    'mer_country_cd': 'SUDA',
    'mer_country_desc': 'SUDAN',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'NA',
    'mer_country_desc': 'NA',
    'mer_region_cd': 'NA'
  },
  {
    'mer_country_cd': 'TAI',
    'mer_country_desc': 'TAIWAN',
    'mer_region_cd': 'APxJ'
  },
  {
    'mer_country_cd': 'OT',
    'mer_country_desc': 'OTHER',
    'mer_region_cd': 'OT'
  },
  {
    'mer_country_cd': 'PY',
    'mer_country_desc': 'PARAGUAY',
    'mer_region_cd': 'AME'
  },
  {
    'mer_country_cd': 'BJSY',
    'mer_country_desc': 'BALWICK OF JERSEY',
    'mer_region_cd': 'EUR'
  }
]
