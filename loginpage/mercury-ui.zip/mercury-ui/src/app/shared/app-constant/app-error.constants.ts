export class AppErrorConstants {
    public static readonly SEARCH_PAGE_ERROR = 'An error occurred. Please contact Application Support Group.';
   // public static readonly TOO_MANY_RESULTS_ERROR = 'Search returned too many results; please refine and try again';
  //  public static readonly MP_CREATE_PAGE_ERROR = 'An error occurred. Please contact Application Support Group.';
    public static readonly APP_UNAUTH = 'You are not authorized to access the application.';
    public static readonly USER_NOT_IN_OVERRIDE_TABLE = 'You dont have permissions to access the application. Please contact Application Support Group.';
  //  public static readonly PAGE_UNAUTH = 'You are not authorized to access this page.';
  //  public static readonly SECURITY_SEARCH_ERROR = 'An error occurred in the search; please try again';
 //   public static readonly NO_SECURITY_FOUND_ERROR = 'Search did not return any results; please try another';
//    public static readonly NO_CLASSIFIED_SECURITY_FOUND_ERROR = 'A security result has been found but cannot be displayed as it is not classified under this component';
  //  public static readonly UNABLE_TO_FETCH_ASSET_MAPS = 'Unable to fetch asset Maps.';

}
