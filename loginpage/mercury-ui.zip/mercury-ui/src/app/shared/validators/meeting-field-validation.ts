import { MeetingValidators } from 'src/app/shared/validators/meeting-validators';

export class MeetingFieldValidations {
    public static readonly Date = [MeetingValidators.DateValidator];
    public static readonly FromToDate = [MeetingValidators.FromToDateValidator];
    public static readonly InvalidDateValidator = [MeetingValidators.InvalidDateValidator];
    public static readonly CheckInvalidValues = [MeetingValidators.CheckInvalidValues];
    public static readonly CheckForPastDate = [MeetingValidators.CheckForPastDate];
    public static readonly CheckMtgRequestDeadline = [MeetingValidators.CheckMtgRegDeadline, MeetingValidators.CheckMtgRequestDeadline];
    public static readonly CheckEmptyEmailAndPhone = [MeetingValidators.CheckEmptyEmailAndPhone];
    public static readonly DateRangeValidator = [MeetingValidators.DateRangeValidator];
}

