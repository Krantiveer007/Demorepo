import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
export class MeetingValidators {

    public static DateValidator(control: FormControl): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        const val = moment(control.value, format, true);
        if (!val.isValid() && control.value !== '' && control.value !== null) {
            return { invalidDate: true };
        } else {
            if (control.value !== '') {
                const ONE_DAY = 1000 * 60 * 60 * 24;
                const meetingDate = val.toDate();
                const todayDate: Date = new Date();
                const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
                if (differenceDays > 365) {
                    return { moreThanOneYearDate: true };
                } else {
                    return null;
                }
            }
        }
    }

    public static DateRangeValidator(control: FormControl): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        let startDateVal: any;
        let endDateVal: any;
        if (control.value) {
            startDateVal = moment(control.value[0], format, true);
            endDateVal = moment(control.value[1], format, true);
            if (!startDateVal.isValid() && !endDateVal.isValid()
                && control.value !== '' && control.value !== null && control.value.length !== 2) {
                return { invalidDate: true };
            } else {
                if (control.value !== '') {
                    const ONE_DAY = 1000 * 60 * 60 * 24;
                    const meetingDate = startDateVal.toDate();
                    const todayDate: Date = new Date();
                    const differenceDays = Math.floor((todayDate.getTime() - meetingDate.getTime()) / (ONE_DAY));
                    if (differenceDays > 365) {
                        return { moreThanOneYearDate: true };
                    } else {
                        return null;
                    }
                }
            }
        }
    }

    public static InvalidDateValidator(control: FormControl): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        const val = moment(control.value, format, true);
        if (!val.isValid() && control.value !== '') {
            return { invalidDate: true };
        }
    }

    public static CheckForPastDate(control: FormControl): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        const val = moment(control.value, format, true);
        if (!val.isValid() && control.value !== '') {
            return { invalidDate: true };
        } else {
            if (control.value !== '') {
                const ONE_DAY = 1000 * 60 * 60 * 24;
                const meetingDate = val.toDate();
                const todayDate: Date = new Date();
                const differenceDays = Math.floor((meetingDate.getTime() - todayDate.getTime()) / (ONE_DAY));
                if (differenceDays > 0) {
                    return { futureDate: true };
                } else {
                    return null;
                }
            }
        }
    }

    public static FromToDateValidator(group: FormGroup): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        const fromVal = moment(group.controls['fromDate'].value, format, true);
        const toVal = moment(group.controls['toDate'].value, format, true);
        // if (!val.isValid() && control.value !== '') {
        //     return { invalidDate: true };
        // } else {
        if (group.controls['fromDate'].value !== '' && group.controls['toDate'].value !== '') {
            const ONE_DAY = 1000 * 60 * 60 * 24;
            const fromMeetingDate = fromVal.toDate();
            const toMeetingDate = toVal.toDate();
            //   const todayDate: Date = new Date();
            const differenceDays = Math.floor((toMeetingDate.getTime() - fromMeetingDate.getTime()) / (ONE_DAY));
            if (differenceDays < 0) {
                return { fromDateExceedToDateError: true };
            } else {
                return null;
            }
        }
    }


    public static CheckInvalidValues(group: FormGroup): { [s: string]: boolean } {
        if (group.get('dailin').value) {
            if (group.get('dailpicker').value === '') {
                return { dialpickerRequired: true };
            }
            if (group.get('accesscode').value === '') {
                return { accessCodeRequired: true };
            }
        }
        if (group.get('meetingStatus').value.status === 'Delayed') {
            if ((group.get('delayedByMins').value * 1) === 0 || group.get('delayedByMins').value === '0' || group.get('delayedByMins').value === '') {
                return { deleayedMinsRequired: true };
            }
        }
        return null;
    }

    public static CheckMtgRequestDeadline(group: FormGroup): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        let startDate : any; 
        if (group.controls['dateRange'].value) {
            startDate = moment(group.controls['dateRange'].value[0], format, true);
        }
        const mtgDeadline = moment(group.controls['meetingRequestDeadline'].value, format, true);
        if (group.controls['dateRange'].value !== '' && group.controls['meetingRequestDeadline'].value !== '') {
            const ONE_DAY = 1000 * 60 * 60 * 24;
            const mtgStartDate = startDate.toDate();
            const mtgDeadlineDate = mtgDeadline.toDate();
            //   const todayDate: Date = new Date();
            console.log('mtgDeadlineDate.getTime(): ', mtgDeadlineDate.getTime());
            console.log('mtgEndDate.getTime(): ', mtgStartDate.getTime());
            const differenceDays = Math.floor((mtgDeadlineDate.getTime() - mtgStartDate.getTime()) / (ONE_DAY));
            if (differenceDays >= 0) {
                return { mtgDeadlineExceedEndDateError: true };
            } else {
                return null;
            }
        }
    }
    public static CheckMtgRegDeadline(group: FormGroup): { [s: string]: boolean } {
        const format = 'DD/MM/YYYY';
        let startDate : any; 
        if (group.controls['dateRange'].value) {
            startDate = moment(group.controls['dateRange'].value[0], format, true);
        }
        const mtgDeadline = moment(group.controls['meetingRegistrationDeadline'].value, format, true);
        if (group.controls['dateRange'].value !== '' && group.controls['meetingRegistrationDeadline'].value !== '') {
            const ONE_DAY = 1000 * 60 * 60 * 24;
            const mtgStartDate = startDate.toDate();
            const mtgDeadlineDate = mtgDeadline.toDate();
            //   const todayDate: Date = new Date();
            console.log('mtgDeadlineDate.getTime(): ', mtgDeadlineDate.getTime());
            console.log('mtgEndDate.getTime(): ', mtgStartDate.getTime());
            const differenceDays = Math.floor((mtgDeadlineDate.getTime() - mtgStartDate.getTime()) / (ONE_DAY));
            if (differenceDays >= 0) {
                return { mtgRegDeadlineExceedEndDateError: true };
            } else {
                return null;
            }
        }
    }

    public static CheckEmptyEmailAndPhone(formGroup: FormGroup): {[s: string]: boolean } {
        if (formGroup.get('organizerEmail').value === '' && formGroup.get('organizerPhone').value === '' && formGroup.get('organizerContactId').value !== '') {
            return { eitherEmailOrPhoneReqd: true };
        } else {
            return null;
        }
    }
}

