export default class  Utils {
    static isVoid(val :any) {
        if(val === undefined || val === null || val ===''){
            return true;
        }
        if (Array.isArray(val) || typeof val === 'string') {
            return val.length === 0;
        }
        if(typeof val === 'object' && Object.keys(val).length === 0){
            return true;
        }
        if(! isNaN(val)){
            return false;
        }
        return !val || Object.keys(val).length === 0;
    }
}