import { convertToTitleCase } from './convert-title-case.utility';

export function filterPeopleResponse(peopleResponse: any[]) {
    let peopleDataArray = [];
    for (let i = 0, j = 0; i < peopleResponse.length; i++) {
        if ('name' in peopleResponse[i]) {
            peopleDataArray[j] = peopleResponse[i];
            j++;
        }
    }
    for (const item of peopleDataArray) {
        item['selectedVal'] = convertToTitleCase(item.name) + ' &lt;' + item.corporateId + '&gt;';
    }
    return peopleDataArray;
}

export function filterExternalContactResponse(contactResponse: any, contactType: string) {
    if (contactType === 'Broker') {
        for (const item of contactResponse) {
            item['selectedVal'] = convertToTitleCase(item.fullname) + ' &lt;' + convertToTitleCase(item.firmName) + '&gt;'
                + ' (' + item.emailId + ' )';
            //  item['selectedVal'] = convertToTitleCase(item.fullname);
        }
    } else {
        for (const item of contactResponse) {
            item['selectedVal'] = convertToTitleCase(item.fullname) + ' &lt;' + convertToTitleCase(item.company) + '&gt;'
                + ' (' + item.emailId + ' )';
        }
    }
    return contactResponse;
}

export function filterSecuritydata(securityResponse: any[]) {
    for (const item of securityResponse) {
        item['itemValue'] = item.instrumentLongName
            + ((item.ticker) ? ('&lt;' + item.ticker + '&gt;') : '')
            + ((item.securityType === 'FI') ? ('(' + 'FI' + ')') : ((item.securityType === 'EQ') ? ('(' + 'EQ' + ')') : ''))
            + (((item.analystRoleTypeDesc === 'Primary') && item.name) ? ('(' + item.name + ')') : '');
    }
    return securityResponse;
}
export function filterBrokerFirm(brokerFirmResponse: any[]) {
    for (const item of brokerFirmResponse) {
        item['itemValue'] = item.firmName;
    }
    return brokerFirmResponse;
}

export function filterDebtTickerData(debtTickerResponse: any[]) {
    for (const item of debtTickerResponse) {
        item['debtTickerVal'] = item.debtTicker
            + ((item.analystName) ? ('&lt;' + item.analystName + '&gt;') : '');
    }
    return debtTickerResponse;
}

export function filterBrokerGroups(brokerGroupFirmResponse: any[], searchedValue: string) {
    let serachedValResponse = [];
    for (const item of brokerGroupFirmResponse) {
        if (item['firmName'].toLowerCase().includes(searchedValue.toLowerCase())) {
            item['itemValue'] = item.firmName + ' ' + ('&lt;' + item.firmId + '&gt;');
            serachedValResponse.push(item);
        }
    }
    return serachedValResponse;
}

