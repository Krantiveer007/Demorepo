import * as moment from 'moment';

export function dateComparator(date1, date2) {
    const isAfter = moment(date1).isAfter(date2);
    if (isAfter) {
        return 1;
    } else {
        return -1;
    }
}
