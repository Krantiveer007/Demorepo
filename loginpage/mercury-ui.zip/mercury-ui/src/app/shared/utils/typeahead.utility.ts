import { OnInit, NgZone } from "@angular/core";
import { filterPeopleResponse, filterSecuritydata, filterBrokerFirm, filterDebtTickerData, filterExternalContactResponse, filterBrokerGroups } from "src/app/shared/utils/filter-response.utility";
import { Observable, EMPTY, Subscription } from "rxjs";
import { CommonService } from "src/app/core/http/common.service";

export interface TypeaheadData {
    dataSource: Observable<any>;
    isResponseError: boolean;
}

export class TypeaheadDataSource implements OnInit {

    peopleDataSubscription: Subscription;
    securityDataSubscription: Subscription;
    debtTickerSubscription: Subscription;
    constructor(private commonService: CommonService, private ngZone: NgZone) { }

    ngOnInit() { }

    getPeopleData(searchedValue: string): TypeaheadData {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        }
        if (searchedValue && searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer: any) => {
                this.peopleDataSubscription = this.commonService.getPeopleData(searchedValue).subscribe((response) => {
                    typeaheadData.isResponseError = false;
                    if (response['status'] === 200) {
                        if (response['data'].length > 0) {
                            this.ngZone.run(() => {
                                observer.next(filterPeopleResponse(response['data']));
                            });
                        } else {
                            observer.next([]);
                            typeaheadData.isResponseError = true;
                        }
                    } else {
                        observer.next([]);
                        typeaheadData.isResponseError = true;
                    }
                },
                    (error) => {
                        observer.next([]);
                        typeaheadData.isResponseError = true;
                    });
            });
        } else {
            if (typeaheadData.dataSource === EMPTY && this.peopleDataSubscription) {
                this.peopleDataSubscription.unsubscribe();
            }
        }
        return typeaheadData;
    }

    getSecurities(searchedValue): TypeaheadData {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        };
        if (searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer) => {
                this.securityDataSubscription = this.commonService.getSecurities(searchedValue).subscribe((response) => {
                    if (response['status'] === 200 && response['data']['status'] !== 404) {
                        typeaheadData.isResponseError = false;
                        this.ngZone.run(() => observer.next(filterSecuritydata(response['data'])));
                    } else {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    }
                },
                    (error) => {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    });
            });
        } else {
            if (typeaheadData.dataSource === EMPTY && this.securityDataSubscription) {
                this.securityDataSubscription.unsubscribe();
            }
        }
        return typeaheadData;
    }

    getExternalContactsData(searchedValue: string, securityOrFirmIdentifier: string, contactType: string, selectedSecurityType: string) {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        };
        if (searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer: any) => {
                this.peopleDataSubscription = this.commonService.getExternalContacts(searchedValue,
                    securityOrFirmIdentifier,
                    contactType).subscribe((response) => {
                        let contactResponse: any[];
                        if ((this.commonService.getMeetingType() === 'Company' && selectedSecurityType === 'Equity')
                            || (contactType !== 'All' && securityOrFirmIdentifier === '')) {
                            contactResponse = response['body'];
                        } else if (contactType === 'Broker' && securityOrFirmIdentifier) {
                            if(response['body']) {
                                contactResponse = [];
                            response['body'].forEach(element => {
                                let contact = {};
                                contact['emailId'] = element['contactTypeObj']['contact']['email']
                                contact['externalId'] = element['contactTypeObj']['contact']['externalId']
                                contact['firmId'] = element['contactTypeObj']['brokerFirm']['firmId']
                                contact['firmName'] = element['contactTypeObj']['brokerFirm']['firmName']
                                contact['fullname'] = element['contactTypeObj']['contact']['fullName']
                                contact['telephoneNo'] = element['contactTypeObj']['contact']['telephone']
                                contact['version'] = element['contactTypeObj']['contact']['versionNo']
                                contactResponse.push(contact)
                            });
                            } else {
                                contactResponse = [];
                            }
                        } else {
                            contactResponse = response;
                        }
                        if (contactResponse.length > 0) {
                            typeaheadData.isResponseError = false;
                            this.ngZone.run(() => {
                                observer.next(filterExternalContactResponse(contactResponse, contactType));
                            });
                        } else {
                            observer.next([]);
                            typeaheadData.isResponseError = true;
                        }
                    },
                    (error) => {
                        observer.next([]);
                        typeaheadData.isResponseError = true;
                    });
            });
        } else {
            if (typeaheadData.dataSource === EMPTY && this.peopleDataSubscription) {
                this.peopleDataSubscription.unsubscribe();
            }
        }
        return typeaheadData;
    }

    getDebtTicker(searchedValue) {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        };
        if (searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer) => {
                let fixedIncomeDebtTickers = [];
                fixedIncomeDebtTickers = this.commonService.getDebtTicker(searchedValue);
                
                if (fixedIncomeDebtTickers.length > 0) {
                    typeaheadData.isResponseError = false;
                    this.ngZone.run(() => observer.next(filterDebtTickerData(fixedIncomeDebtTickers)));
                } else {
                    typeaheadData.isResponseError = true;
                    observer.next([]);
                }
            });
        }
        return typeaheadData;
    }
    getBrokerFirms(searchedValue): TypeaheadData {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        };
        if (searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer) => {
                const queryString = 'brokerFirmName=' + searchedValue;
                this.securityDataSubscription = this.commonService.getBrokerFirm(queryString).subscribe((response) => {
                    if (response.length > 0) {
                        typeaheadData.isResponseError = false;
                        this.ngZone.run(() => observer.next(filterBrokerFirm(response)));
                    } else {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    }
                },
                    (error) => {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    });
            });
        } else {
            if (typeaheadData.dataSource === EMPTY && this.securityDataSubscription) {
                this.securityDataSubscription.unsubscribe();
            }
        }
        return typeaheadData;
    }

    gerBrokerGroups(searchedValue): TypeaheadData {
        let typeaheadData: TypeaheadData = {
            dataSource: EMPTY,
            isResponseError: false
        };
        if (searchedValue.length >= 3) {
            typeaheadData.dataSource = new Observable((observer) => {
                
                this.securityDataSubscription = this.commonService.getBrokerGroups().subscribe((response) => {
                    if (response.length > 0) {
                        typeaheadData.isResponseError = false;
                        this.ngZone.run(() => observer.next(filterBrokerGroups(response, searchedValue)));
                    } else {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    }
                },
                    (error) => {
                        typeaheadData.isResponseError = true;
                        observer.next([]);
                    });
            });
        } else {
            if (typeaheadData.dataSource === EMPTY && this.securityDataSubscription) {
                this.securityDataSubscription.unsubscribe();
            }
        }
        return typeaheadData;
    }
}
