import * as cityTimezones from 'city-timezones';

export interface populateTimeZoneEvent {
    Cities: string;
    Country: string;
    GRD_COUNTRY_CD: string;
    ISO_COUNTRY_CD: string;
    KeyCode: string;
    UtilKeyName: string;
    cityCountryVal: string;
    timezoneVal: string;
}
export function populateTimeZone(event: populateTimeZoneEvent) {
    if (event) {
        const cityDescription = cityTimezones.lookupViaCity(event['Cities']);
        let timeZoneDesc = null;
        if (cityDescription.length !== 0) {
            if (cityDescription.length > 1) {
                const filteredCity = cityDescription.filter(element => element.iso2 === event['ISO_COUNTRY_CD']);
                if (filteredCity.length !== 0) {
                    timeZoneDesc = filteredCity[0].timezone;
                } else {
                    timeZoneDesc = null;
                    //  this.nocitycountrymap.push(event)
                }
            } else {
                timeZoneDesc = cityDescription[0]['timezone'];
            }

            if (timeZoneDesc !== null) {
                const date = new Date().toLocaleString('en-US', { timeZone: timeZoneDesc, timeZoneName: 'short' });
                const indexOfOpenBracket = date.indexOf('GMT');
                if (indexOfOpenBracket !== -1) {
                    return timeZoneDesc + ' ' + date.substring(indexOfOpenBracket, date.length);
                } else {
                    return timeZoneDesc + ' ' + date.substring(date.length - 3, date.length);
                }
            }
        } else {
            return event['timezoneVal']? event['timezoneVal']: '';
        }
    }
}