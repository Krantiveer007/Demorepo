import { Inject, Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class UrlHandlerService {

    private domainName = 'bip.uk.fid-intl.com';
    private domainLowerEnv = 'fidelity.co.uk:15012';

    // AWS Url for fetching Mercury Utility Details
    utilService =
        this.generateUrl`${this.getAWSUtilServiceUrl(this.envName)}/util-service?ActiveInd=Y&AttributesToGet=`
        + `UtilKeyName,KeyCode,KeyDesc,Region,Country,ISO_COUNTRY_CD,GRD_COUNTRY_CD,Cities`;


    // AWS Url for fetching DL List NAmes for autosuggestion
    dlListFetchUrl =
        this.generateUrl`${this.getAWSUtilServiceUrl(this.envName)}/distributionListNames?dlSearchVal=`

    // AWS Url for adding new DL Names in Dynamo
    dlListAddUrl =
        this.generateUrl`${this.getAWSUtilServiceUrl(this.envName)}/addDistributionListName`


    // AWS Url for fetching company meeting details
    compMtgDtlsForMtgIdAWSUrl = this.generateUrl`${this.getAWSMeetingServiceUrl(this.envName)}/meetings/company-meeting`;
    // AWS Url for fetching other meeting details
    othMtgDtlsForMtgIdAWSUrl = this.generateUrl`${this.getAWSOtherMeetingServiceUrl(this.envName)}/meetings/other-meeting`;
    // AWS Url for fetching security details.
    securityServiceAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/searchsecurity?identifierValue=`;
    // AWS Url for fetching market data details for tradable entity Id.
    marketCapServiceAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/marketcapitalisation?tradableEntityId=`;
    // AWS Url for fetching holders details for tradable entity Id.
    // holdersServiceAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/holders?tradableEntityId=`;


    // AWS Url for fetching Logged In User Details
    // getLoggedInUserDetails = this.generateUrl`${this.getAWSUserDataServiceUrl(this.envName)}/user-detail?corporateId=`;

    // AWS Url for fetching holders details for debt ticker.
    holdersServiceAWSUrlForDebtTicker = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/holders/fi-instruments-data?debtTicker=`;



    // AWS Url for fetching People data Details
    personDataServiceAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/persons/searchbyname?name=`;
    // AWS Url for fetching People data Details for Corporate Ids.
    personDataServiceForCorpIdAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/persons/searchbycorpid?corpIds=`;
    // AWS Url for fetching security details for Tradable entity Id.
    securityServiceForTrdEntIdAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/searchbytradabaleentityid?tradableEntityId=`;
    // AWS Url for fetching analyst details for Tradable entity Id.
    analystServiceForTrdEntIdAWSUrl = this.generateUrl`${this.getAWSFodeServiceUrl(this.envName)}/fods/security/analyst?tradableEntityId=`;
    // AWS Url for fetching contact details for contact name
    contactServiceForAWSUrl = this.generateUrl`${this.getAWSContactServiceUrl(this.envName)}/contacts/external/`;

    contactSearchServiceLayer7Url = this.generateUrl`${this.getAWSContactServiceUrl(this.envName)}/contacts/external/all`;

    // Layer 7 Url for fetching fixed income debt tickers
    fixedIncomeDebtTicker = this.generateUrl`${this.getAWSUtilServiceUrl(this.envName)}/fi-analyst`;

    // Layer 7 Url for getting broker firm details
    paasContacts = this.generateUrl`https://api${this.getLayer7Env(this.envName)}/api/mercury/v1/paas`;


    // Layer 7 Url for fetching all people data user details
    personData = this.generateUrl`https://api${this.getLayer7Env(this.envName)}/api/mercury/v1/web/getPersonData`;
    // Layer 7 Url for expand and fetching employee details for Distribution List
    employeeServiceForDLs = this.generateUrl`https://api${this.getLayer7Env(this.envName)}/api/mercury/v1/paas/addDistributionList?dlName=`;

    hostDialInDetails = this.generateUrl`https://api${this.getLayer7Env(this.envName)}/api/mercury/v1/paas/getHostContact?hostCorpId=`;

    //conference AWS url for fetching conference events and meeting schedule details.
    conferenceAWSUrl = this.generateUrl`https://${this.getAWSConferenceServiceUrl(this.envName)}/event/conference`;

    // Layer 7 for fetching all type of contacts for searched value
    //  paasAllContactTypeServiceUrl = this.generateUrl`https://contactmanagement${this.envName}.npapps.paas.bip.uk.fid-intl.com/api/getOtherAttendeeByName`;





    // AWS Url for fetching data from AWS
    getDataAWSFromAWS = this.generateUrl`https://api${this.getLayer7Env(this.envName)}/api/mercury/v1/aws/${this.awsEnvName}`;
    //getDataAWSFromAWS1 = this.generateUrl`https://62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev`;

    constructor( @Inject('EnvName') private envName: string, @Inject('AWSEnvName') private awsEnvName: string) { }

    private generateUrl(strings, ...values) {
        let str = '';
        strings.forEach((string, i) => {
            str += string + (values[i] || '');
        });
        return str;
    }

    private getLayer7Env(envName) {
        switch (envName) {
            case 'dev':
                return 'gateway-dev.uk.fid-intl.com:17012';
            case 'int':
                return 'gateway-dev.uk.fid-intl.com:17012';
            case 'qa':
                return 'gateway-qa.uk.fid-intl.com:17012';
            case 'uat':
                return 'gateway-uat.uk.fid-intl.com:17012';
            case 'sit':
                return 'gateway-sit.uk.fid-intl.com:17012';
            case '':
                return '.bip.uk.fid-intl.com';
        }
    }

    getAWSMeetingServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'isnugl6101.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return '2n447jug0m.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return 'glscrqg3l6.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 'j2h3tyejwd.execute-api.eu-west-1.amazonaws.com';
        }
    }

    getAWSOtherMeetingServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'luspunjz82.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return 'd3owiaewc0.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return '0jexc5lut8.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 's74u43pmx6.execute-api.eu-west-1.amazonaws.com';
        }
    }
    getAWSBrokerMeetingServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'vpbddkw0le.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return 'vpbddkw0le.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return '5l3jo7dfaa.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 'i1rf1edptd.execute-api.eu-west-1.amazonaws.com';
        }
    }
    // private getAWSUserDataServiceUrl(envName) {
    //     switch (envName) {
    //         case 'dev':
    //             return 'bzvngdg3a9.execute-api.eu-west-1.amazonaws.com';
    //         case 'qa':
    //             return 'bzvngdg3a9.execute-api.eu-west-1.amazonaws.com';
    //         case 'uat':
    //             return 'mlb3ymi9x9.execute-api.eu-west-1.amazonaws.com';
    //         case '':
    //             return '';
    //     }
    // }
    getAWSUtilServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'ormnka9hui.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return 'heepu9a69a.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return 'wueazsoa05.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 'zo9rd6r114.execute-api.eu-west-1.amazonaws.com';
        }
    }
    getAWSFodeServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'igrt9gd7d7.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return '8lew3u6gsd.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return 'a89dy5yv91.execute-api.eu-west-1.amazonaws.com';
            case '':
                return '8mrxwb0056.execute-api.eu-west-1.amazonaws.com';
        }
    }

    getAWSContactServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return '4m9pe7u6i8.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return 'cxzdtanvp4.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return 'fmoaoczrw0.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 'qqsyrp3poa.execute-api.eu-west-1.amazonaws.com';
        }
    }


    getAWSUserDetailServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return 'bzvngdg3a9.execute-api.eu-west-1.amazonaws.com';
            case 'qa':
                return 'kg6295fltl.execute-api.eu-west-1.amazonaws.com';
            case 'uat':
                return 'mlb3ymi9x9.execute-api.eu-west-1.amazonaws.com';
            case '':
                return 'y2mbkng3dk.execute-api.eu-west-1.amazonaws.com';
        }
    }

    getAWSConferenceServiceUrl(envName) {
        switch (envName) {
            case 'dev':
                return '62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev';
            case 'qa':
                return '62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev';
            case 'uat':
                return '62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev';
            case '':
                return '';
        }
    }
}
