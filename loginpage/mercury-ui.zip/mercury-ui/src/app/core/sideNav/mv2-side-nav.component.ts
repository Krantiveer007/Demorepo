import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonService } from 'src/app/core/http/common.service';
import { ErrorService } from 'src/app/core/error/error.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Input } from '@angular/core';
import { OnChanges } from '@angular/core';

@Component({
  selector: 'mv2-side-nav',
  templateUrl: './mv2-side-nav.component.html',
  styleUrls: ['./mv2-side-nav.component.css']
})
export class Mv2SideNavComponent implements OnInit, OnChanges {
  menuList: string[];
  filLogoUrl = 'assets/images/Fidelity_DesktopLogo.svg';
  objectKeys = Object.keys;
  formParam = '';
  menuListObj = {
    // 'Dashboard': {
    //   'src': 'assets/images/sidebar/dashboard.svg',
    //   'selected': false
    // },
    'Events': {
      'src': 'assets/images/sidebar/meetings.svg',
      'selected': true
    },
    'Contacts': {
      'src': 'assets/images/sidebar/contacts.svg',
      'selected': false
    },
    // 'Reports': {
    //   'src': 'assets/images/sidebar/reports.svg',
    //   'selected': false
    // },
    // 'Events1': {
    //   'src': 'assets/images/sidebar/wishlist.svg',
    //   'selected': false
    // },
    // 'Watchlist': {
    //   'src': 'assets/images/sidebar/watchlist.svg',
    //   'selected': false
    // }
  };
  @Input() selectedNavImage: string;
  constructor(private commonService: CommonService, private router: Router, private errorService: ErrorService, private route: ActivatedRoute) {
    this.menuList = [
      'Dashboard', 'Meeting', 'Contacts'
    ];
  }

  ngOnInit() {
    //   const observable = this.commonService.getUtilData();
    //   observable.subscribe((response) => {
    //     this.commonService.utilMessageSource.next(response['Items']);
    //   },
    //   (error) => {
    //     throw new Error('Bad response status');
    //   }
    //   );

    // this.route.params.subscribe((params) => {
    //   this.formParam = params['action']});
    this.router.events.subscribe((event) => {
      if (event['url']) {
        this.formParam = event['url'];
        if (this.formParam.includes('/meeting') || this.formParam === '/') {
          this.menuListObj['Events'].selected = true;
          this.menuListObj['Contacts'].selected = false;
        } else if (this.formParam.includes('/contacts')) {
          this.menuListObj['Events'].selected = false;
          this.menuListObj['Contacts'].selected = true;
        }
      }
    });
  }
  ngOnChanges(changes: any) {
    this.menuListObj['Events'].selected = true;
    this.menuListObj['Contacts'].selected = false;
  }

  navigateToModule(imageClicked: any) {
    if (imageClicked === this.menuListObj['Events'].src) {
      this.menuListObj['Events'].selected = true;
      this.menuListObj['Contacts'].selected = false;
      this.commonService.setTargetUrl('/events/meeting');
      // this.router.navigate(['/meetings'], { skipLocationChange: true });
      if (this.errorService.isError
        || ((this.formParam === '/meeting/create' && !this.commonService.getLoggedInUserRoles().includes('mercury-create-company-meeting'))
          || (this.formParam === '/meeting/update' && !this.commonService.getLoggedInUserRoles().includes('mercury-update-company-meeting')))) {
        this.router.navigate(['/events/meeting'], { skipLocationChange: true });
      } else {
        if (this.formParam.includes('/contacts/add') || this.formParam.includes('/contacts/update')) {
          this.commonService.checkContactFormChanges.next(true);
        } else if (this.formParam.includes('/contacts')) {
          this.router.navigate(['/events/meeting'], { skipLocationChange: true });
        } else if (this.formParam.includes("/conference/update;eventId")) {
          this.commonService.checkConferenceFormSubject.next(true);
        } else if (this.formParam.includes('/editConference')) {
          this.router.navigate(['/events/meeting'], { skipLocationChange: true });
        }
        else {
          this.commonService.checkFormUpdateSubject.next(true);
        }
      }
    } else if (imageClicked === this.menuListObj['Contacts'].src) {
      this.commonService.setTargetUrl('/contacts');
      if (this.formParam.includes('/contacts/add') || this.formParam.includes('/contacts/update')) {
        this.menuListObj['Contacts'].selected = true;
        this.menuListObj['Events'].selected = false;
        this.commonService.checkContactFormChanges.next(true);
      } else if (this.formParam.includes('/meeting/create') || this.formParam.includes('/meeting/update')) {
        this.commonService.checkFormUpdateSubject.next(true);
      } else if (this.formParam.includes("/conference/update;eventId")) {
        this.commonService.checkConferenceFormSubject.next(true);
      } else if (this.formParam.includes('/editConference')) {
        this.router.navigate(['/contacts'], { skipLocationChange: true });
      } else {
        this.menuListObj['Contacts'].selected = true;
        this.menuListObj['Events'].selected = false;
        this.router.navigate(['/contacts'], { skipLocationChange: true });
      }
    }
  }
}

