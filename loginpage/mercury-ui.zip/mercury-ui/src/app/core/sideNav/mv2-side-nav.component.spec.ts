import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { Mv2SideNavComponent } from './mv2-side-nav.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { Observable, of } from 'rxjs';
import { MeetingManagementComponent } from '../../feature/meeting-management/meeting-management.component';
import { Mv2DynamicContentComponent } from '../../feature/meeting-management/mv2-dynamic-content/mv2-dynamic-content.component';
import { Mv2StaticContentComponent } from '../../feature/meeting-management/mv2-static-content/mv2-static-content.component';
import { TypeaheadModule, BsDropdownModule } from 'ngx-bootstrap';

import {
  ThirdPartyAttendeeComponent
} from '../../feature/meeting-management/mv2-dynamic-content/third-party-attendee/third-party-attendee.component';
import { AgGridModule } from 'ag-grid-angular';
import { TooltipModule } from 'ngx-bootstrap';
import { TimepickerModule, BsModalService, ModalModule } from 'ngx-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { Location } from '@angular/common';
import { IntlModule } from '@progress/kendo-angular-intl';
import { TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { IntlService } from '@progress/kendo-angular-intl';
import { CommonGridComponent } from 'src/app/shared/components/common-grid/common-grid.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ErrorService } from 'src/app/core/error';
import { EventDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/event-details/event-details.component';
import { MeetingDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/meeting-details/meeting-details.component';
import { InviteesDetailsComponent } from 'src/app/feature/meeting-management/mv2-dynamic-content/meetings/invitees-details/invitees-details.component';

const appRoutes: Routes = [
  { path: 'meeting/:action', component: MeetingManagementComponent }
];


describe('Mv2SideNavComponent', () => {
  let component: Mv2SideNavComponent;
  let fixture: ComponentFixture<Mv2SideNavComponent>;
  let location: Location;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        FormsModule,
        TooltipModule,
        TypeaheadModule,
        RouterModule.forRoot(appRoutes),
        AgGridModule.withComponents([]),
        NgSelectModule,
        TimepickerModule,
        ModalModule,
        ReactiveFormsModule,
        IntlModule,
        TimePickerModule,
        BrowserModule,
        BrowserAnimationsModule,
        BsDropdownModule.forRoot()
      ],
      providers: [{ provide: 'EnvName', useValue: 'DEV' }, { provide: APP_BASE_HREF, useValue: '/' },
        BsModalService, { provide: ActivatedRoute, useValue: { params: of() } }, ErrorService],
      declarations: [Mv2SideNavComponent, MeetingManagementComponent, Mv2DynamicContentComponent,
        EventDetailsComponent, Mv2StaticContentComponent, CommonGridComponent,
        InviteesDetailsComponent, MeetingDetailsComponent, ThirdPartyAttendeeComponent],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2SideNavComponent);
    component = fixture.componentInstance;
    location = TestBed.get(Location);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change Fidelity Logo Icon on click on Side navigation bar', () => {
    const toogleSideNav = true;

    component.toggleSideBar();
    expect(component.toggleSideNav).toEqual(toogleSideNav);

    component.toggleSideBar();
    expect(component.toggleSideNav).not.toEqual(toogleSideNav);
  });


  // fit('should route to Create Meetings Page when clicked on meetings icon', () => {
  //   const activatedRoute = fixture.debugElement.injector.get(ActivatedRoute);
  //   component.navigateToModule('mv2-Person-img');
  //   fixture.detectChanges();
  //   expect(location.path()).toEqual('/meeting/create');
  // });
});
