import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, ActivatedRoute, Params } from '@angular/router';


@Component({
  selector: 'mv2-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  userName = 'Krantiveer Sehrawat';
  constructor() { }

  ngOnInit() {
  }
}
