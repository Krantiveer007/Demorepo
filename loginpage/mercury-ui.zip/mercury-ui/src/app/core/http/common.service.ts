import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { RequestOptions, Headers } from '@angular/http';
import { User } from 'src/app/shared/models/user.model';
import { map, share } from 'rxjs/operators';
import { UserDetail } from 'src/app/shared/models/userDetail.model';
import { FormGroup } from '@angular/forms';
import { Security } from 'src/app/shared/models/security.model';
import { UrlHandlerService } from 'src/app/shared/services/url-handler.service';
import { PeopleData } from 'src/app/shared/models/peopledata.model';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { BehaviorSubject, ReplaySubject, Subject, of, EMPTY } from 'rxjs';
import { retryWhen } from 'rxjs/internal/operators/retryWhen';
import { Meeting } from '../../shared/models/meeting.model';
import { ArrangementContact } from '../../shared/models/arrangementcontact.model';
import { convertToTitleCase } from 'src/app/shared/utils/convert-title-case.utility';
import { forkJoin } from 'rxjs/internal/observable/forkJoin';
import { catchError } from 'rxjs/internal/operators/catchError';
import { ContactMapper } from 'src/app/shared/models/contactMapper.model';
import { ConferenceMeeting } from 'src/app/shared/models/conferenceMeeting.model';
import { EventOwner } from 'src/app/shared/models/eventOwner.model';
import { EventCreator } from 'src/app/shared/models/eventCreator.model';
import { Country } from 'src/app/shared/models/country.model';
import { BrokerDetail } from 'src/app/shared/models/brokerDetail.model';
import { EventLastUpdateDetails } from 'src/app/shared/models/eventLastUpdateDetails.model';
import { EventInitiator } from 'src/app/shared/models/eventInitiator.model';
import { ConferenceSchedule } from 'src/app/shared/models/conferenceSchedule.model';
import { SecurityDetails } from 'src/app/shared/models/securitydetails.model';
import { AssociatedEventDetail } from 'src/app/shared/models/associatedeventdetail.model';
import { MeetingCreator } from 'src/app/shared/models/meetingcreator.model';
import { DebtTickerDetail } from 'src/app/shared/models/debtTickerDetail.model';
import { DialIn } from 'src/app/shared/models/dialin.model';
import { MeetingLocation } from 'src/app/shared/models/meetinglocation.model';
import { MeetingSubtype } from 'src/app/shared/models/meetingsubtype.model';
import { MeetingInitiator } from 'src/app/shared/models/meetinginitiator.model';
import { MeetingUpdateDetails } from 'src/app/shared/models/meetingUpdateDetails.model';
import { SearchMeetingForm } from 'src/app/shared/models/searchMeetingForm.model';
import { SearchPanelForm } from 'src/app/shared/models/searchPanelForm.model';
import { SidePaneSearchPanelForm } from 'src/app/shared/models/sidePaneSearchPanelForm.model';
import { DatePipe } from '@angular/common';
import { populateTimeZone, populateTimeZoneEvent } from 'src/app/shared/utils/fetchTimezoneFromUtil.utility';
import { LocalLanguage } from 'src/app/shared/models/localLanguage.model';
// import { Contacts } from '../../shared/models/contacts.model';
// import { ActivatedRoute } from '@angular/router';
// import { Params } from '@angular/router';


export interface SignUpRequired {
    isRequired: boolean;
    requiredReason: string;
}

@Injectable({
    providedIn: 'root'
})

export class CommonService {

    resetFormSubject: Subject<boolean> = new Subject<boolean>();
    checkFormUpdateSubject: Subject<boolean> = new Subject<boolean>();
    resetConferenceFormSubject: Subject<boolean> = new Subject<boolean>();
    checkConferenceFormSubject: Subject<boolean> = new Subject<boolean>();
    redrawMasterGrid: Subject<boolean> = new Subject<boolean>();
    checkContactFormChanges: Subject<boolean> = new Subject<boolean>();
    resetMeetingDetailsSubject: Subject<boolean> = new Subject<boolean>();
    errorDetails: string = '';
    signUpForMeSubject: Subject<boolean> = new Subject<boolean>();
    disableSignupForMeSubject: Subject<SignUpRequired> = new Subject<SignUpRequired>();
    hostAddedAsAttendeeSubject: Subject<boolean> = new Subject<boolean>();
    removedAttendeeSubject: Subject<string> = new Subject<string>();
    defaultUserBUSubj: Subject<string> = new Subject<string>();
    errorDetailsSubject: BehaviorSubject<string> = new BehaviorSubject<string>('');
    onBrokerFirmChange: Subject<any> = new Subject<any>();
    viewConferenceDtlsSource: Subject<any> = new Subject<any>();
    // selectedConfMtgs: Subject<any[]> = new Subject<any[]>();
    // rowSelectHeaderDisable: Subject<boolean> = new Subject<boolean>();
    selectAllRowHeaderCheckbox: Subject<boolean> = new Subject<boolean>();
    isConferenceVisible = true;
    enableRowSelection: BehaviorSubject<Object> = new BehaviorSubject<Object>({
        'time': false,
        'date': false
    });

    sectorOfSecurity: Subject<string> = new Subject<string>();
    datePipe: DatePipe;
    dataSource = [];
    // loggedInUserName = '';
    searchedValue: string;
    formChange = false;
    targetUrl = '';
    meetingsForConflict = [];
    loggedInUser = new User([], new UserDetail('', '', '', '', '', '', '', '', '', '', ''));
    arrangementContactDetails = new ArrangementContact('', '', '', '', '', '', '', '');
    selectedDebtTickervalue = '';
    // sectorOfSecurity = '';

    conferenceMeeting = new ConferenceMeeting('', '', '', '', '', new EventOwner('', ''), '', new EventLastUpdateDetails('', '', '', ''),
        new EventCreator('', '', ''), '', new Country('', ''), '', new BrokerDetail('', ''), new EventInitiator('', ''), '', '', '', '', new ArrangementContact('', '', '', '', '', '', '', ''), '', '');

    // meetingState = new BehaviorSubject<string>('New');
    // meetingStateObservable = this.meetingState.asObservable();
    // headers = new HttpHeaders({ 'user': 'a608245', 'application': 'mercury', apikey: '0a76883a-cdfa-4a73-8194-bc0629065ddb'});
    headers = new HttpHeaders({ 'user': this.getLoggedInUserInfo().getCorporateId(), 'application': 'mercury', 'content-type': 'application/json' });

    securities: Security = new Security('-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-',
        '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
    // searchPanelForm = new SearchPanelForm('All Meetings', [], '', '', this.getMeetingFromDate(), '', '', '', '', '', '', this.getDefaultBUForSearch(), 'Equity');
    // sideSearchPanelForm = new SidePaneSearchPanelForm([], [], '', '', '', '', '', '', '', '', '');
    // serachMeetingForm = new SearchMeetingForm(this.searchPanelForm, this.sideSearchPanelForm);
    searchMeetingForm: FormGroup;
    searchContactForm: FormGroup;
    securityDetails = [];
    meetingType = '';
    // utility;ServiceData: any;
    // utilityServiceDataObservable: any;
    fixedIncomeDebtTicker = [];
    brokerFirmDetail = {
        brokerFirmName: '',
        brokerFirmId: ''
    };
    brokerFirmAllDetail = {
        brokerFirmName: '',
        brokerFirmId: '',
        telephone: ''
    }
    countries = [];
    private messageSource = new BehaviorSubject<any>('');
    currentMessage = this.messageSource.asObservable();

    private hideStaticViewSource = new BehaviorSubject<any>('');
    hideStaticView$ = this.hideStaticViewSource.asObservable();

    hostDataSource = new BehaviorSubject<Object>(null);
    hostDataObservable = this.hostDataSource.asObservable();

    utilMessageSource = new BehaviorSubject<any>('');
    utilMessageObservable = this.utilMessageSource.asObservable();

    signUpMeetingIdSource = new BehaviorSubject<any>('');
    signUpMeetingIdObservable = this.signUpMeetingIdSource.asObservable();
    sidePanelMessageSource = new BehaviorSubject<boolean>(false);
    sidePanelObservable = this.sidePanelMessageSource.asObservable();

    tradableEntityIdSource = new BehaviorSubject<any>('');
    tradableEntityIdObservable = this.tradableEntityIdSource.asObservable();

    searchMeetings = new BehaviorSubject<boolean>(false);
    // searchMeetings = new ReplaySubject<boolean>(1);
    searchMeetingsObservable = this.searchMeetings.asObservable();

    searchMeetingsData = new BehaviorSubject<any>(null);
    searchMeetingsDataObservable = this.searchMeetingsData.asObservable();

    searchEventsData = new BehaviorSubject<any>(null);
    searchEventsDataObservable = this.searchEventsData.asObservable();

    resetSearchFilters = new BehaviorSubject<boolean>(true);
    resetSearchFiltersObservable = this.resetSearchFilters.asObservable();


    signUpAttendeeListSource = new BehaviorSubject<any>('');
    signUpAttendeeListObservable = this.signUpAttendeeListSource.asObservable();

    updateMtgDtlsSource = new BehaviorSubject<any>('');
    updateMtgDtlsSourceObservable = this.updateMtgDtlsSource.asObservable();

    holdersDtlsSource = new BehaviorSubject<any>([]);
    holdersDtlsSourceObservable = this.holdersDtlsSource.asObservable();

    dLEmployeeSource = new BehaviorSubject<any>([]);
    dLEmployeeSourceObservable = this.dLEmployeeSource.asObservable();

    externalContactSource = new BehaviorSubject<any>([]);
    externalContactSourceeObservable = this.externalContactSource.asObservable();

    filAttendeeListSource = new BehaviorSubject<any>([]);
    filAttendeeListSourceObservable = this.filAttendeeListSource.asObservable();

    defaultCompanyAttendees = new BehaviorSubject<any>([]);

    defaultCompanyAttendeesObservable = this.defaultCompanyAttendees.asObservable();

    selectedDebtTicker = new BehaviorSubject<any>([]);
    selectedDebtTickerObservable = this.selectedDebtTicker.asObservable();

    conferenceSchedule = new ConferenceSchedule('', '', [], new EventLastUpdateDetails('', '', '', ''));
    conferenceSubMtgs = [];
    cityCountry: any;
    // _url = "app/configs/utility.json";

    meetingLocationChangeSubj: Subject<string> = new Subject<string>();

    constructor( @Inject('EnvName') private envName: string, private httpClient: HttpClient, private urlHandlerService: UrlHandlerService) {
    }

    setConferenceSchedule(conferenceSchedule: ConferenceSchedule) {
        // console.log('conferenceSchedule: ', conferenceSchedule);
        if (conferenceSchedule.eventId) {
            this.conferenceSchedule = conferenceSchedule;
        } else {
            this.conferenceSchedule.eventId = this.conferenceMeeting.eventId;
            this.conferenceSchedule.eventType = this.conferenceMeeting.eventType;
            this.conferenceSchedule.eventLastUpdateDetails = this.conferenceMeeting.eventLastUpdateDetails;
        }
    }

    getConferenceSchedule() {
        return this.conferenceSchedule;
    }

    resetConferenceSchedule(conferenceSchedule) {
        this.conferenceSchedule = conferenceSchedule;
    }
    getUtilData() {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSUtilServiceUrl(this.envName) });
        return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/util-service?ActiveInd=Y&AttributesToGet='
            + 'UtilKeyName,KeyCode,KeyDesc,Region,Country,ISO_COUNTRY_CD,GRD_COUNTRY_CD,Cities, SubtypeEntity, timezoneVal', { headers: httpHeaders, withCredentials: true });
    }

    getSecurities(searchedValue: string) {
        if (searchedValue.length > 0) {
            // console.log('searchedValue: ', searchedValue);
            if (searchedValue.includes('&')) {
                searchedValue = searchedValue.replace('&', '%26');
            }
            const encodedName = encodeURIComponent(searchedValue);
            // console.log('searchedValue: ', encodedName);


            // const encodedNameOne = encodeURIComponent(searchedValue);
            // console.log('encodedName: ', encodedName);
            // console.log('encodedNameOne: ', encodedNameOne);
            const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
            const encodedURI = this.urlHandlerService.getDataAWSFromAWS + '/fods/security/searchsecurity?identifierValue=' + encodedName;
            return this.httpClient.get<any[]>(encodedURI, { headers: httpHeaders, withCredentials: true });
        } else {
            return EMPTY;
        }
    }

    getSectorForSecurity(tradableEntityIds) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        const encodedURI = this.urlHandlerService.getDataAWSFromAWS + '/fods/security/sectorByTradableEntityId?tradableEntityId=' + tradableEntityIds;
        return this.httpClient.get<any[]>(encodedURI, { headers: httpHeaders, withCredentials: true });
    }

    getDebtTicker(searchedValue: string) {

        const fixedIncomeValues = [];
        if (searchedValue.length > 0) {
            this.fixedIncomeDebtTicker.forEach((element) => {

                if (element.debtTicker.toLowerCase().startsWith(searchedValue.toLowerCase())) {
                    return fixedIncomeValues.push(element);
                }
            });
            return fixedIncomeValues;
        } else {
            return [];
        }
    }
    setDebtTicker(debtTickers: any[]) {
        this.fixedIncomeDebtTicker = debtTickers;
    }
    getDebtTickerFromPaas() {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSUtilServiceUrl(this.envName) });
        return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/fi-analyst', { headers: httpHeaders, withCredentials: true });
    }

    getSecurityForTrdEntId(trdEntId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/fods/security/searchbytradabaleentityid?tradableEntityId=' + trdEntId, { headers: httpHeaders, withCredentials: true });
    }

    getMarketCapForTrdEntId(trdEntId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        const _url = this.urlHandlerService.getDataAWSFromAWS + '/fods/security/marketcapitalisation?tradableEntityId=' + trdEntId;
        return this.httpClient.get<any>(_url, { headers: httpHeaders, withCredentials: true });
    }

    getBBCodeForTradEntId(trdEntId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        const _url = this.urlHandlerService.getDataAWSFromAWS + '/fods/security/security-detail?tradableEntityId=' + trdEntId;
        return this.httpClient.get<any>(_url, { headers: httpHeaders, withCredentials: true });
    }
    getPeopleData(searchedNameValue: string) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/fods/persons/searchbyname?name=' + searchedNameValue, { headers: httpHeaders, withCredentials: true });
    }

    getHostDialInDetails(hostCorpId: string) {
        return this.httpClient.get<any[]>(this.urlHandlerService.hostDialInDetails + hostCorpId, { headers: this.headers, withCredentials: true });
    }

    getMeetings(queryString: string) {
        let uri: string = '';
        const httpHeadersForCompany = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        const httpHeadersForOthers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSOtherMeetingServiceUrl(this.envName) });
        const httpHeadersForBrokers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSBrokerMeetingServiceUrl(this.envName) });
        if (queryString.includes('meetingType=Company')) {
            uri = this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting?' + queryString;
            return this.httpClient.get<any[]>(uri, { headers: httpHeadersForCompany, withCredentials: true });
        } else if (queryString.includes('meetingType=Other')) {
            uri = this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting?' + queryString;
            return this.httpClient.get<any[]>(uri, { headers: httpHeadersForOthers, withCredentials: true });
        } else if (queryString.includes('meetingType=Broker')) {
            uri = this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting?' + queryString;
            return this.httpClient.get<any[]>(uri, { headers: httpHeadersForBrokers, withCredentials: true });
        } else {
            return forkJoin([
                this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting?' + queryString, { headers: httpHeadersForCompany, withCredentials: true }).pipe(catchError(error => of(error))),
                this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting?' + queryString, { headers: httpHeadersForOthers, withCredentials: true }).pipe(catchError(error => of(error))),
                this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting?' + queryString, { headers: httpHeadersForBrokers, withCredentials: true }).pipe(catchError(error => of(error))),
            ]);
        }
    }
    getEvents(queryString: string) {
        return this.httpClient.get<any[]>(this.urlHandlerService.conferenceAWSUrl + '?' + queryString, {});
    }

    getConferenceMeeting(eventId: string) {
        // console.log('eventId: ', eventId);
        return forkJoin([
            this.httpClient.get<any[]>(this.urlHandlerService.conferenceAWSUrl + '/' + eventId),
            this.httpClient.get<any[]>(this.urlHandlerService.conferenceAWSUrl + '/meeting/' + eventId)
        ]);
    }
    getConferenceNotesAndTasks(eventId: string) {
        return this.httpClient.get<any[]>(`${this.urlHandlerService.conferenceAWSUrl}?eventId=${eventId}`);
        // https://62hra1bwrb.execute-api.eu-west-1.amazonaws.com/dev/event/conference?eventId=0288f86b-3f38-4eaa-b201-b89aa3ad086c
    }
    updateConferenceNotesAndTasks(notesAndTasks) {
        return this.httpClient.put<any[]>(this.urlHandlerService.conferenceAWSUrl, notesAndTasks);
    }
    insertConferenceSchedules(conferenceSchedule: ConferenceSchedule, callType) {
        if (callType === 'post') {
            return this.httpClient.post<any[]>(this.urlHandlerService.conferenceAWSUrl + '/confirm-draft-meeting', conferenceSchedule);
        } else {
            return this.httpClient.put<any[]>(this.urlHandlerService.conferenceAWSUrl + '/confirm-draft-meeting', conferenceSchedule);
        }
    }
    getExternalContacts(searchedNameValue: string, securityOrFirmIdentifier: string, contactType: string) {
        let _url: string;

        if (contactType === 'All') {
            _url = '?searchText=' + searchedNameValue;
            return this.httpClient.get<any[]>(this.urlHandlerService.paasContacts + '/getOtherAttendeeByName' + _url, { withCredentials: true });
        } else {
            if (contactType === 'Company') {
                const localSecurityOrFirmIdentifier = securityOrFirmIdentifier === '-' ? '' : securityOrFirmIdentifier;
                _url = contactType.toLowerCase() + '?contactName=' + searchedNameValue + '&ticker=' + localSecurityOrFirmIdentifier;
            } else if (contactType === 'Broker' && securityOrFirmIdentifier) {
                // _url = contactType.toLowerCase() + '?contactName=' + searchedNameValue
                //     + (securityOrFirmIdentifier ? '&companyTicker=' + securityOrFirmIdentifier : '');
                let queryString = 'contactType=BC&lastName=' + searchedNameValue + '&brokerFirmId=' + +securityOrFirmIdentifier + '&contact=forthirdparty'
                const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSContactServiceUrl(this.envName) });
                return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/contacts/external/all?' + queryString, { headers: httpHeaders, withCredentials: true });
            } else {
                let localContact: string;
                if (contactType === 'Others') {
                    localContact = 'other';
                } else {
                    localContact = contactType.toLowerCase();
                }
                _url = localContact + '?contactName=' + searchedNameValue;;
            }
            const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSContactServiceUrl(this.envName) });
            return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/contacts/external/' + _url, { headers: httpHeaders, withCredentials: true });
        }
    }

    getInternalContacts(queryString) {
        return this.httpClient.get<any[]>(this.urlHandlerService.paasContacts + '/searchInternalContacts?' + queryString, { withCredentials: true });
    }

    insertMeetingDetails(meeting: Meeting, action: String, oldOrganizerEmail?) {
        let meetingData = JSON.parse(JSON.stringify(meeting));
        if (oldOrganizerEmail) {
            meetingData.arrangementContact.organizerEmail = oldOrganizerEmail;
        }
        const httpHeadersForCompany = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        const httpHeadersForOthers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSOtherMeetingServiceUrl(this.envName) });
        const httpHeadersForBrokers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSBrokerMeetingServiceUrl(this.envName) });
        if (action === 'create') {
            if (meeting.meetingType === 'Company') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting', meetingData, { headers: httpHeadersForCompany, withCredentials: true });
            } else if (meeting.meetingType === 'Other') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting', meetingData, { headers: httpHeadersForOthers, withCredentials: true });
            } else if (meeting.meetingType === 'Broker') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting', meetingData, { headers: httpHeadersForBrokers, withCredentials: true });
            }
        }
        if (action === 'update') {
            if (meeting.meetingType === 'Company') {
                return this.httpClient.put<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting', meetingData, { headers: httpHeadersForCompany, withCredentials: true });
            } else if (meeting.meetingType === 'Other') {
                return this.httpClient.put<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting', meetingData, { headers: httpHeadersForOthers, withCredentials: true });
            } else if (meeting.meetingType === 'Broker') {
                return this.httpClient.put<Meeting>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting', meetingData, { headers: httpHeadersForBrokers, withCredentials: true });
            }
        }
    }

    getMtgDetailsForMtgId(meetingId: any, meetingType: string) {
        const httpHeadersForCompany = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        const httpHeadersForOthers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSOtherMeetingServiceUrl(this.envName) });
        const httpHeadersForBrokers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSBrokerMeetingServiceUrl(this.envName) });
        if (meetingType === 'Other') {
            return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting' + '/' + meetingId, { headers: httpHeadersForOthers, withCredentials: true });
        } else if (meetingType === 'Broker') {
            return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting' + '/' + meetingId, { headers: httpHeadersForBrokers, withCredentials: true });
        } else {
            return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting' + '/' + meetingId, { headers: httpHeadersForCompany, withCredentials: true });
        }
    }

    getPersonData() {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        return this.httpClient.get<any[]>(this.urlHandlerService.personData
            , { headers: httpHeaders, withCredentials: true });
    }

    getPeopleDataForCorpIDs(corporateIDs) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/fods/persons/searchbycorpid?corpIds=' + corporateIDs, { headers: httpHeaders, withCredentials: true });
    }

    getHoldersData(entity, selectedSecurity) {
        if (selectedSecurity === 'Equity') {
            const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
            return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/fods/security/holders?tradableEntityId=' + entity, { headers: httpHeaders, withCredentials: true });
        } else {
            const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
            return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/fods/security/holders/fi-instruments-data?debtTicker=' + entity, { headers: httpHeaders, withCredentials: true });
        }
    }

    getSecurityAnalysts(tradableEntId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSFodeServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/fods/security/analyst?tradableEntityId=' + tradableEntId, { headers: httpHeaders, withCredentials: true });
    }

    getDistributionListEmployees(searchedDL) {
        return this.httpClient.get<any>(this.urlHandlerService.employeeServiceForDLs + searchedDL, { withCredentials: true });
    }

    discardDraftMeeting(meetingId: any) {
        const httpHeadersForCompany = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        const httpHeadersForOthers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSOtherMeetingServiceUrl(this.envName) });
        const httpHeadersForBrokers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSBrokerMeetingServiceUrl(this.envName) });
        if (this.getMeetingType() === 'Company') {
            return this.httpClient.delete<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting/' + meetingId, { headers: httpHeadersForCompany, withCredentials: true });
        } else if (this.getMeetingType() === 'Other') {
            return this.httpClient.delete<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting/' + meetingId, { headers: httpHeadersForOthers, withCredentials: true });
        } else if (this.getMeetingType() === 'Broker') {
            return this.httpClient.delete<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting/' + meetingId, { headers: httpHeadersForBrokers, withCredentials: true });
        }
    }

    getExternalContactMtgs(externalId: any) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSContactServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/contacts/external/' + externalId + '/meetings', { headers: httpHeaders, withCredentials: true });
    }

    getDefaultCompanyAttendees(securityTradableEntityId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting/getPastCompanyAttendees?securityTradableEntityId=' + securityTradableEntityId, { headers: httpHeaders, withCredentials: true });
    }

    getDliListNames(dlSearchVal) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSUtilServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/distributionListNames?dlSearchVal=' + dlSearchVal, { headers: httpHeaders, withCredentials: true });
    }

    getBrokerFirm(queryString) {
        return this.httpClient.get<any>(this.urlHandlerService.paasContacts + '/getBrokerFirm?' + queryString, { withCredentials: true });
    }

    getBrokerGroups() {
        return this.httpClient.get<any>(this.urlHandlerService.paasContacts + '/getBrokerGroup', { withCredentials: true });
    }

    getBrokerFirmsForBrokerGroup(firmId: string) {
        return this.httpClient.get<any>(this.urlHandlerService.paasContacts + '/getBrokerFirmsForBrokerGroup?firmId=' + firmId, { withCredentials: true });
    }


    markContactAsInactive(contact) {
        return this.httpClient.put(this.urlHandlerService.paasContacts + '/markContactInactive', contact, { withCredentials: true });
    }

    markInternalContactAsInActive(contact) {
        return this.httpClient.put(this.urlHandlerService.paasContacts + '/deleteInternalContact', contact, { withCredentials: true });
    }

    deleteBrokerFirm(brokerFirm) {
        return this.httpClient.put(this.urlHandlerService.paasContacts + '/deleteBrokerFirm', brokerFirm, { withCredentials: true });
    }
    addDlName(dlName) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSUtilServiceUrl(this.envName) });
        let dlObj = { 'dlName': dlName };
        return this.httpClient.post<any>(this.urlHandlerService.getDataAWSFromAWS + '/addDistributionListName', dlObj, { headers: httpHeaders, withCredentials: true });
    }

    hideStaticView(isAllowed) {
        this.hideStaticViewSource.next(isAllowed);
    }

    insertMtgSignUpAttendees(signUpAttendees) {
        const signUpDtls = {
            meetingId: '',
            meetingSignUpByName: convertToTitleCase(this.getLoggedInUserInfo().getName()),
            meetingSignUpByCorporateId: this.getLoggedInUserInfo().getCorporateId(),
            fidelityInvitees: []
        };

        signUpDtls['meetingId'] = signUpAttendees.meetingId;
        signUpAttendees['fidelityInvitees'].forEach((rowNode, Index) => {
            const signupArray = Object.assign({}, rowNode);
            signupArray['name'] = signupArray['signUpAttendeeName'];
            delete signupArray['signUpAttendeeName'];
            signUpDtls.fidelityInvitees[Index] = signupArray;
            signUpDtls.fidelityInvitees[Index].isCallIn = signUpDtls.fidelityInvitees[Index].isCallIn === true ? 'Y' : 'N';
            signUpDtls.fidelityInvitees[Index].isInviteRequired = signUpDtls.fidelityInvitees[Index].isInviteRequired === true ? 'Y' : 'N';
            signUpDtls.fidelityInvitees[Index].corporateId = signUpDtls.fidelityInvitees[Index].corporateId.toUpperCase();

            if (this.getMeetingType().includes('Company')) {
                signUpDtls.fidelityInvitees[Index].isInfoPackRequired = signUpDtls.fidelityInvitees[Index].isInfoPackRequired === true ? 'Y' : 'N';
            }
            signUpDtls.fidelityInvitees[Index].isInviteForInfoOnly = signUpDtls.fidelityInvitees[Index].isInviteForInfoOnly === true ? 'Y' : 'N';
        });
        const httpHeadersCompany = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSMeetingServiceUrl(this.envName) });
        const httpHeadersOthers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSOtherMeetingServiceUrl(this.envName) });
        const httpHeadersForBrokers = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSBrokerMeetingServiceUrl(this.envName) });

        if (this.getMeetingType().includes('Company')) {
            return this.httpClient.post<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/company-meeting/signup', signUpDtls, { headers: httpHeadersCompany, withCredentials: true });
        } else if (this.getMeetingType() === 'Other') {
            return this.httpClient.post<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/other-meeting/signup', signUpDtls, { headers: httpHeadersOthers, withCredentials: true });
        } else if (this.getMeetingType() === 'Broker') {
            return this.httpClient.post<any>(this.urlHandlerService.getDataAWSFromAWS + '/meetings/broker-meeting/signup', signUpDtls, { headers: httpHeadersForBrokers, withCredentials: true });
        }
    }

    insertNewContact(contacts, action: string) {
        if (contacts.contactType === 'Broker Firm') {
            if (action === 'add') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.paasContacts + '/createBrokerFirm ', contacts.brokerContact.brokerFirm, { withCredentials: true });
            }
            if (action === 'update') {
                return this.httpClient.put<Meeting>(this.urlHandlerService.paasContacts + '/updateBrokerFirm', contacts.brokerContact.brokerFirm, { withCredentials: true });
            }
        } else if (contacts.contactType === 'BC' || contacts.contactType === 'CC' || contacts.contactType === 'OC') {
            if (action === 'add') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.paasContacts + '/contacts', contacts, { withCredentials: true });
            }
            if (action === 'update') {
                return this.httpClient.patch<Meeting>(this.urlHandlerService.paasContacts + '/contacts', contacts, { withCredentials: true });
            }
        } else {
            if (action === 'add') {
                return this.httpClient.post<Meeting>(this.urlHandlerService.paasContacts + '/internalContact ', contacts, { withCredentials: true });
            }
            if (action === 'update') {
                return this.httpClient.put<Meeting>(this.urlHandlerService.paasContacts + '/internalContact', contacts, { withCredentials: true });
            }
        }
    }
    setSecurityDetails(security: any, meetingScreen: string, checkForConflicts = undefined) {
        this.securities.instrumentLongName = security.instrumentLongName ? security.instrumentLongName : '-';
        this.securities.grdCountryDesc = security.grdCountryDesc ? convertToTitleCase(security.grdCountryDesc) : '-';
        this.securities.primaryAnalystName = security.primaryAnalystName ? convertToTitleCase(security.primaryAnalystName) : '-';
        this.securities.ticker = security.ticker ? security.ticker : '';
        this.securities.tradableEntId = security.tradableEntId ? security.tradableEntId : '';
        this.securities.primaryAnalystCorpId = security.primaryAnalystCorpId ? security.primaryAnalystCorpId : '';
        if (meetingScreen === 'create') {
            if (security.tradableEntId) {
                this.getMarketCapForTrdEntId(security.tradableEntId).subscribe((response) => {
                    if (response.data && response.data[0]) {
                        this.securities.marketCapitalization = response.data[0].marketCapitalization
                            ? response['data'][0].marketCapitalization
                            : '-';
                        this.securities.marketCapitalizationSize = response.data[0].marketCapitalizationSize
                            ? response['data'][0].marketCapitalizationSize
                            : '-';
                    } else {
                        this.securities.marketCapitalization = '-';
                        this.securities.marketCapitalizationSize = '-';
                    }
                    if (checkForConflicts) {
                        checkForConflicts.emit('Security');
                    }
                });
                this.getBBCodeForTradEntId(security.tradableEntId).subscribe((response) => {
                    if (response.data && response.data[0]) {
                        this.securities.bbCode = response.data[0].bbCode ? response.data[0].bbCode : '-';
                        this.securities.tseCode = response.data[0].tseCode ? response.data[0].tseCode : '-';
                        this.securities.grdCountryDesc = response.data[0].grdCountryDesc
                            ? convertToTitleCase(response.data[0].grdCountryDesc) : '-';
                    }
                });
            } else {
                this.securities.marketCapitalization = '-';
                this.securities.marketCapitalizationSize = '-';
                this.securities.bbCode = '-';
                this.securities.tseCode = '-';
                this.securities.grdCountryDesc = '-';
                if (checkForConflicts) {
                    checkForConflicts.emit('Security');
                }
            }
        } else if (meetingScreen === 'update') {
            if (security.tradableEntId || (security.name && security.primaryAnalystName)) {
                this.securities.marketCapitalization = (security && security[0] && security[0].marketCapitalization) ? security[0].marketCapitalization : '-';
                this.securities.marketCapitalizationSize = (security && security[0] && security[0].marketCapitalizationSize) ? security[0].marketCapitalizationSize : '-';
                this.securities.bbCode = security.bbCode ? security.bbCode : '-';
                this.securities.tseCode = security.tseCode ? security.tseCode : '-';
            }
        }
    }

    getExternalContactsForSearch(queryString: string) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSContactServiceUrl(this.envName) });
        return this.httpClient.get<any[]>(this.urlHandlerService.getDataAWSFromAWS + '/contacts/external/all?' + queryString, { headers: httpHeaders, withCredentials: true });
    }

    getSecurityDetails() {
        return this.securities;
    }
    getSecurityArray() {
        return this.securityDetails;
    }
    changeMessage(message: any) {
        this.messageSource.next(message);
    }
    searchedSecurityChange(message: any) {
        this.tradableEntityIdSource.next(message);
    }
    signUpMeetingIdChange(message: any) {
        this.signUpMeetingIdSource.next(message);
    }
    signUpAttendeeListChange(attendeeList: any) {
        this.signUpAttendeeListSource.next(attendeeList);
    }
    updateMtgDtlsChange(mtgDtls: any) {
        this.updateMtgDtlsSource.next(mtgDtls);
    }

    getLoggedInUserDetails(userId) {
        const httpHeaders = new HttpHeaders({ 'HostName': this.urlHandlerService.getAWSUserDetailServiceUrl(this.envName) });
        return this.httpClient.get<any>(this.urlHandlerService.getDataAWSFromAWS + '/user-detail?corporateId=' + userId, { headers: httpHeaders, withCredentials: true });
    }

    insertConferenceMeetings(meeting) {
        return this.httpClient.post<ConferenceMeeting>(this.urlHandlerService.conferenceAWSUrl, meeting);
    }

    setLoggedInUserRoles(roles: Array<Object>) {
        this.loggedInUser.setRoles(roles);
    }

    getLoggedInUserRoles() {
        return this.loggedInUser.getRoles();
    }

    setLoggedInUserInfo(userDeatils: UserDetail) {
        this.loggedInUser.setUserDetails(userDeatils);
    }

    getLoggedInUserInfo() {
        return this.loggedInUser.getUserDetails();
    }
    changeHostDetails(hostDetails: any) {
        this.hostDataSource.next(hostDetails);
    }
    setFormChangeValue(value: boolean) {
        this.formChange = value;
    }
    getFormChangeValue() {
        return this.formChange;
    }

    setMeetingType(meetingType: string) {
        this.meetingType = meetingType;
    }
    getMeetingType() {
        return this.meetingType;
    }
    changeHoldersList(holdersList: any) {
        this.holdersDtlsSource.next(holdersList);
    }
    setTargetUrl(targetUrl) {
        this.targetUrl = targetUrl;
    }
    getTargetUrl() {
        return this.targetUrl;
    }
    changeDlEmployeeList(employeeList: any) {
        this.dLEmployeeSource.next(employeeList);
    }

    changeExternalContactList(contactList: any) {
        this.externalContactSource.next(contactList);
    }
    changeFilAttendeeList(attendeeList: any) {
        this.filAttendeeListSource.next(attendeeList);
    }
    setBrokerFirmDetails(brokerFirmData: any) {
        if (this.meetingType === 'Conference') {
            this.brokerFirmAllDetail = brokerFirmData;
        } else {
            this.brokerFirmDetail = brokerFirmData;
        }
    }
    getBrokerFirmDetails() {
        if (this.meetingType === 'Conference') {
            return this.brokerFirmAllDetail;
        } else {
            return this.brokerFirmDetail;
        }
    }

    setMeetingsForConflict(meetingsForConflict) {
        this.meetingsForConflict = meetingsForConflict;
    }

    getMeetingsForConflict() {
        return this.meetingsForConflict;
    }

    getArrangementContactDetails() {
        return this.arrangementContactDetails;
    }

    setArrangementContactDetails(arrangementContact: ArrangementContact) {
        this.arrangementContactDetails = arrangementContact;
    }

    setConferenceMeetingDtls(mtgDtls: any) {
        if (mtgDtls) {
            this.fetchUtilData();
            this.conferenceMeeting.eventId = mtgDtls.eventId ? mtgDtls.eventId : '';
            this.conferenceMeeting.eventType = mtgDtls.eventType ? mtgDtls.eventType : '';
            this.conferenceMeeting.eventName = mtgDtls.eventName ? mtgDtls.eventName : '';
            this.conferenceMeeting.venue = mtgDtls.venue ? mtgDtls.venue : '';
            this.conferenceMeeting.website = mtgDtls.website ? mtgDtls.website : '';
            this.conferenceMeeting.startDate = mtgDtls.startDate ? mtgDtls.startDate : '';
            this.conferenceMeeting.endDate = mtgDtls.endDate ? mtgDtls.endDate : '';
            this.conferenceMeeting.meetingRequestDeadline = mtgDtls.meetingRequestDeadline ? mtgDtls.meetingRequestDeadline : '';
            this.conferenceMeeting.meetingRegistrationDeadline = mtgDtls.meetingRegistrationDeadline ? mtgDtls.meetingRegistrationDeadline : '';
            this.conferenceMeeting.brokerDetail.brokerFirmId = mtgDtls.brokerDetail ? mtgDtls.brokerDetail.brokerFirmId : '';
            this.conferenceMeeting.brokerDetail.brokerFirmName = mtgDtls.brokerDetail ? mtgDtls.brokerDetail.brokerFirmName : '';
            this.conferenceMeeting.brokerDetail['brokerPhoneNumber'] = mtgDtls.brokerDetail ? mtgDtls.brokerDetail.brokerPhoneNumber : '';
            this.conferenceMeeting.eventInitiator.eventInitiatorCode = mtgDtls.eventInitiatorCode ? mtgDtls.eventInitiatorCode : '';
            this.conferenceMeeting.eventInitiator.eventInitiatorDescription = mtgDtls.eventInitiatorDescription ? mtgDtls.eventInitiatorDescription : '';
            this.conferenceMeeting.eventInitiator.eventInitiatorCode = mtgDtls.eventInitiatorCode ? mtgDtls.eventInitiatorCode : '';
            // this.conferenceMeeting.eventInitiator.brokerUsageInitiator = mtgDtls.brokerUsageInitiator ? mtgDtls.brokerUsageInitiator : '';
            this.conferenceMeeting.businessUnit = mtgDtls.businessUnit ? mtgDtls.businessUnit : '';
            this.conferenceMeeting.country.countryCode = mtgDtls.countryCode ? mtgDtls.countryCode : '';
            this.conferenceMeeting.country.countryDescription = mtgDtls.countryDescription ? mtgDtls.countryDescription : '';
            this.conferenceMeeting.city = mtgDtls.city ? mtgDtls.city : '';
            this.conferenceMeeting.eventState = mtgDtls.eventState ? mtgDtls.eventState : 'NEW';
            this.conferenceMeeting.arrangementContact = mtgDtls.arrangementContact ? mtgDtls.arrangementContact : [];
            if (mtgDtls.eventTimezone) {
                this.conferenceMeeting.eventTimezone = mtgDtls.eventTimezone;
            } else {
                let cityValue = this.cityCountry.filter(element => element.cityCountryVal === mtgDtls.countryDescription);
                if (cityValue[0]) {
                    populateTimeZone(cityValue[0]);
                }
            }
        }
    }
    getConferenceMeetingDtls() {
        return this.conferenceMeeting;
    }
    setSelectedConferenceSubMtgs(meetings: any[]) {
        this.conferenceSubMtgs = meetings;
    }
    getSelectedConfereceSubMtgs() {
        return this.conferenceSubMtgs;
    }
    setConferenceVisibility(conferenceFeatureFlag: any) {
        // console.log('common;: ', conferenceFeatureFlag);
        this.isConferenceVisible = conferenceFeatureFlag.KeyDesc;
    }
    getConferenceVisiblity() {
        // console.log('isConferenceVisible: ', this.isConferenceVisible);
        return this.isConferenceVisible;
    }
    setUtilCountries(countries: any) {
        // console.log('countries: ', countries);
        this.countries = countries;
    }
    getUtilCountries() {
        return this.countries;
    }

    getSelectedDebtTicker() {
        return this.selectedDebtTickervalue;
    }
    //     getSearchMeetingForm() {
    //         return this.serachMeetingForm;
    //     }

    setSelectedDebtTicker(debtTicker: string) {
        this.selectedDebtTickervalue = debtTicker;
    }
    //     setSearchMeetingForm(searchMeetingForm: SearchMeetingForm) {
    //          this.serachMeetingForm = searchMeetingForm;
    //     }

    //    getMeetingFromDate() {
    //        let currDate = new Date();
    //        let dateVar = currDate.setMonth(currDate.getMonth() - 1);

    //         return dateVar
    //    }

    //    getDefaultBUForSearch() {
    //        console.log("inside here", this.getLoggedInUserInfo().getDefaultBU())
    //        return this.getLoggedInUserInfo().getDefaultBU()? [this.getLoggedInUserInfo().getDefaultBU()]: [];
    //           }

    getSearchMeetingForm() {
        return this.searchMeetingForm;
    }

    setSearchMeetingForm(searchMeetingForm: FormGroup) {
        this.searchMeetingForm = searchMeetingForm;
    }

    getSearchContactForm() {
        return this.searchContactForm;
    }

    setSearchContactForm(searchContactForm: FormGroup) {
        this.searchContactForm = searchContactForm;
        // console.log("this search form", this.searchContactForm);
    }
    fetchUtilData() {
        this.utilMessageObservable.subscribe((message) => {
            if (message !== '') {
                this.cityCountry = message.filter(element => element.UtilKeyName === 'country-city-map');
            }
        },
            (error) => {
                console.log(error);
            });
    }
    sendEmailWithAttachement(emailData) {
        return this.httpClient.post<any[]>(`${this.urlHandlerService.conferenceAWSUrl}/advertise`, emailData);
    }
    sendReminder(reminderEmailBody) {
        return this.httpClient.post<any[]>(`https://3iqn2jev90.execute-api.eu-west-1.amazonaws.com/dev/event/conference/sendInvitation`, reminderEmailBody);
    }
    updateExternalContact(newContact, oldEmail) {
        let emailSearch = oldEmail;
        if (oldEmail.includes('&')) {
            emailSearch = oldEmail.replace('&', '%26');
        }
        const encodedName = encodeURIComponent(emailSearch);
        let querySTring = 'email=' + encodedName;
        return new Promise((resolve, reject) => {
            this.getExternalContactsForSearch(querySTring).subscribe((response) => {
                if (response['body'] && response['body'][0]) {
                    let contactUpdated = response['body'][0];
                    contactUpdated['contactTypeObj']['contact']['email'] = newContact.organizerEmail;
                    contactUpdated['contactTypeObj']['contact']['telephone'] = newContact.organizerPhone;
                    contactUpdated['contactTypeObj']['contact']['updateID'] = this.getLoggedInUserInfo().getCorporateId();
                    contactUpdated['contactTypeObj']['contact']['localLanguage'] = contactUpdated['contactTypeObj']['contact']['localLanguage'] ? contactUpdated['contactTypeObj']['contact']['localLanguage'] : new LocalLanguage('', '', '');
                    if (contactUpdated['contactType'] === 'CC') {
                        contactUpdated['contactTypeObj']['ticker'] = contactUpdated['contactTypeObj']['companyTicker'].replace(contactUpdated['contactTypeObj']['companyName'], '')
                        contactUpdated['companyContact'] = Object.assign({}, contactUpdated['contactTypeObj'])
                    } else if (contactUpdated['contactType'] === 'BC') {
                        contactUpdated['brokerContact'] = Object.assign({}, contactUpdated['contactTypeObj'])
                    } else {
                        contactUpdated['otherContact'] = Object.assign({}, contactUpdated['contactTypeObj'])
                    }
                    delete contactUpdated['contactTypeObj'];
                    this.insertNewContact(contactUpdated, 'update').subscribe((response) => {
                        resolve({ contactUpdated: true })
                    }, (error) => {
                        reject({ contactUpdated: false })
                    });
                }
            }, (error) => {
                reject({ contactUpdated: false })
            });
        });
    }
}
