import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mv2-footer',
  templateUrl: './mv2-footer.component.html',
  styleUrls: ['./mv2-footer.component.css']
})
export class Mv2FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
