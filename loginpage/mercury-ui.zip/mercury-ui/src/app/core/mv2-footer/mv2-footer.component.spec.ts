import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mv2FooterComponent } from './mv2-footer.component';

describe('Mv2FooterComponent', () => {
  let component: Mv2FooterComponent;
  let fixture: ComponentFixture<Mv2FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mv2FooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mv2FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
