import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { Injectable } from '@angular/core';

@Injectable()
export class ErrorService {

     updateSubject: BehaviorSubject<string> = new BehaviorSubject<string>('');
     isError = false;
     message = '';

    update$: Observable<string> = this.updateSubject.asObservable();
    constructor(private router: Router) { }

    updateMessage(message: string) {
        this.updateSubject.next(message);
    }

    processError(message: string) {
        this.updateMessage(message);
        this.isError = true;
        this.router.navigate(['error'], { skipLocationChange: true });
    }

    setMessage(message) {
        this.message = message;
    }

    getMessage(message) {
        return this.message;
    }
}
