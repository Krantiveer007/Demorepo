import { Component } from '@angular/core';
import { ErrorService } from './error.service';
import { OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';

@Component({
    template: `
    <section class="mv2-error-message">
        {{message}}</section>
        `
})
export class ErrorComponent implements OnDestroy, OnInit {

    message = '';
     subscription: Subscription;

    constructor(private errorService: ErrorService, private router: Router) {}
    ngOnInit () {
        this.subscription = this.errorService.update$.subscribe(
            message => {
                if (message) {
                    this.message = message;
                } else {
                 //   this.router.navigate(['/search'], { skipLocationChange: true });
                }
            });

    }

    ngOnDestroy() {
       this.subscription.unsubscribe();
    }
}
